import { DatePipe } from '@angular/common';
import { Component, ElementRef, EventEmitter, Inject, OnInit, Output, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ProductService, ReportsService, CommonService, ConstantData } from 'hub2ushared';
import { CommonWebService } from '../../shared/common-web.service';
import { LoadCartService } from '../../shared/loadcart.service';
import { GetimageService } from 'projects/hub2ushared/src/lib/services/getimage.service'
import { CommonSettingService } from '../../shared/common-settings.service';


@Component({
  selector: 'app-searchpopup',
  templateUrl: './searchpopup.component.html',
  styleUrls: ['./searchpopup.component.scss'],
})
export class SearchpopupComponent implements OnInit {
  ellipsisCnt = 52; 
  searchInpt: any;
  showMatCard: boolean = false;
  searchResults: any[] = [];
  userInfo: any = {};
  userRole: any = '';
  functionId = '1';
  catalogSearchData = [];
  mappingList = [];
  catalogSearchColumnMap = [];
  lovList = [];
  cartLoader = false;
  cartCount: number;
  loaderAddToCart: any[] = [];
  cartItems: any[] = [];
  loader: boolean = false;
  nodata: boolean = false;

  minCurrentDate = new Date();
  maxNewDate = new Date();
  minDate = this.minCurrentDate;
  maxDate = this.maxNewDate.setDate(this.maxNewDate.getDate() + 1);
  needByDate;
  attr6: any;
  sourceOrg: any;
  subInv: any = "";

  constructor(private searchService: CommonSettingService, private reportService: ReportsService, public datepipe: DatePipe,
    private productService: ProductService, private commonService: CommonService, public dialog: MatDialog,
    private commonWebService: CommonWebService, private loadCartService: LoadCartService, private router: Router,
    private constantData: ConstantData, @Inject(MAT_DIALOG_DATA) public data: any, private reports: ReportsService,
    private dialogRef: MatDialogRef<SearchpopupComponent>, private GetimageService: GetimageService) {
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    // this.needByDate= this.datepipe.transform(new Date(new Date().getTime() + (2 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd');
    this.searchInpt = this.searchService.getSearchInput();
    this.getPreferenceData();
    this.fetchMappingFeilds();
    this.searchResults = this.data;
    this.getSearchResults(this.searchResults);
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
      else {
        col = columns;
      }
    }
    return col;
  }

  OrganizedCart(resp, col) {
    let cart = [];
    let display_column = [];
    if (resp !== undefined) {
      if (resp[0][col] !== undefined) {
        display_column = this.convertToArray(resp[0][col]);
      }
    }
    return display_column
  }

  getSearchResults(searchData) {
    this.loader = true;
    if (searchData.ROW !== undefined) {
      this.nodata = false;
      this.loader = false;
      this.searchResults = searchData.ROW;
      this.catalogSearchData = this.OrganizedCart(this.searchResults, 'DISPLAY_COLUMNS');
    } else {
      this.nodata = true;
      this.loader = false;
    }

  }

  isAvailable(key, data) {
    let dataToSearch = [];
    if (data == 'catalogSearchData') {
      dataToSearch = this.catalogSearchData
    }
    return dataToSearch.includes(key);
  }

  openItemDetails(item) {
    //this.dialog.closeAll();
    this.dialogRef.close()
    this.loadCartService.sendItem(item);
    this.router.navigate(['hub2u/item_details/'], { state: { item: item } });
  }

  fetchMappingFeilds() {
    let request = {
      ReportId: this.constantData.dynamicSearchId[this.functionId], //this.userValues[0].reportId
      ParametersInput: [
        {
          Name: "REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportService.getReportDisplayFields(request).subscribe(response => {
      if (response.ReportDisplayFieldsOutput != undefined) {
        for (let control of response.ReportDisplayFieldsOutput) {
          this.mappingList.push(control);
          if (control.name == 'MAPPING') {
            let saveSettingColumn = control.options;
            saveSettingColumn.forEach(x => {
              if (x.text !== undefined) {
                this.catalogSearchColumnMap.push({ key: x.text, mappingname: x.value })
              }
            });
          }
        }
        this.loader = false;
      }
    }, error => {
      this.loader = false;
    })
  }

  getPreferenceData() {
    let request = {
      ParametersInput: [
        { Name: "USER_NAME", Value: this.userInfo.NTID }
       
      ],
      // ReportId: "112"
      // ReportId: "7001"
      ReportId:this.constantData.userprofileData[this.functionId],
    }
    this.reports.onGetDynamicReport(request).subscribe(response => {
      if (response != undefined && response.ROW != undefined) {
        this.needByDate = response.ROW[0].NEED_BY_DATE_TIME;
        this.attr6 = response.ROW[0].ATTRIBUTE5
        this.sourceOrg = response.ROW[0].SOURCE_LOCATION
        this.subInv =  response.ROW[0].SUBINVENTORY   
      }
    }, error => {
      console.log(error);
    })
  }

  getDefaultOrderType() {
    if (this.functionId == '50' || this.functionId == '57' || this.functionId == '58' || this.functionId == '63') {
      return "INVENTORY"
    }
    // if (this.functionId == '51') {
      if (this.functionId == '136') {
      return "FULFILLMENT"
    }
    // if (this.functionId == '99' && (!this.attr6 || this.attr6 == "null")) {
      if (this.functionId == '143' && (!this.attr6 || this.attr6 == "null")) {
      return 'PROJECT'
    }
    // if (this.functionId != '47' && this.functionId != '99' && this.functionId != '51' && this.functionId != '50' && this.functionId != '57' && this.functionId != '58' && this.functionId != '63') {
      if (this.functionId != '47' && this.functionId != '143' && this.functionId != '136' && this.functionId != '50' && this.functionId != '57' && this.functionId != '58' && this.functionId != '63') {
      return "PROJECT"
    }
  }

  updateFieldsName(data) {
    let attribut6 = this.getDefaultOrderType();
    let obj = {}
    for (let item of this.catalogSearchColumnMap) {
      obj[item.key] = ''
    }

    let newList = this.getUpdatedObj(data, JSON.parse(JSON.stringify(obj)))
    console.log("newList",newList)
    this.catalogSearchColumnMap.forEach(element => {
      this.replaceKey(newList, element.key, element.mappingname)
    });
    if (data.MIN_ORD_QTY == null) {
      newList['quantity'] = 1
    } else {
      newList['quantity'] = parseInt(data.MIN_ORD_QTY)
    }
    newList["userName"] = this.userInfo.NTID;
    newList["needByDate"] = this.needByDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needByDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (1 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd');
    newList["attribute6"] = this.attr6 && this.attr6 != 'null' ? this.attr6 : attribut6;
    newList["attribute3"] = this.userRole.toUpperCase();
    // newList['sourceSubInventory'] = (this.sourceOrg == (data['ORGANIZATION_CODE'] || data['SOURCE_ORGANIZATION_CODE'])) && this.functionId == '99' ? (this.subInv !== "" ? this.subInv : data['SOURCE_SUBINVENTORY']) : data['SOURCE_SUBINVENTORY'];
    newList['sourceSubInventory'] = (this.sourceOrg == (data['ORGANIZATION_CODE'] || data['SOURCE_ORGANIZATION_CODE'])) && this.functionId == '143' ? (this.subInv !== "" ? this.subInv : data['SOURCE_SUBINVENTORY']) : data['SOURCE_SUBINVENTORY'];
    return newList;
  }
  getUpdatedObj(item, obj) {
    for (let key in obj) {
      obj[key] = item[key]
    }
    return obj
  }
  replaceKey(obj, oldKey, newKey) {
    obj[newKey] = obj[oldKey];
    if (newKey !== oldKey) { delete obj[oldKey] };
  }

  getCartDetails(result, index) {
    result.loading = true;
    this.loader = true;
    var cartInputData = {
      "sourceSystem": "TECHAPP",
      "profile":this.userRole.toUpperCase(),
      "shoppingCartUpsertData": []
    }
    cartInputData.shoppingCartUpsertData.push(this.updateFieldsName(result));

    this.productService.addToCart(cartInputData).subscribe(response => {

      this.loaderAddToCart[index] = false;
      this.cartLoader = false;
      this.loader = false;
      let resp = response || {};
      let message = resp['STATUS_MESSAGE'] || response['statusMessage'] || '';
      this.getCartItems();
      this.commonService.updatedCart(true);
      this.dialogRef.close('clear')
      // this.dialog.closeAll();
      if (resp['status'] === 'SUCCESS') {
        this.commonWebService.openSnackBar(message, "SUCCESS");
        if (window.location.pathname == "/hub2u/catalog/cart") {
          this.loadCartService.sendCart();
        }
      }
      if (resp['status'] === 'FAILED') {
        this.commonWebService.openSnackBar(message, "ERROR")
      }
      result.loading = false;
    }, error => {
      this.loader = false;
      this.loaderAddToCart[index] = false;
      result.loading = false;
    })
  }

  getCartItems() {
    let object = {
      ReportId: "115",
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportService.onGetDynamicReport(object).subscribe(response => {
      this.cartItems = response.ROW || [];
    }, error => {
    });
  }

  getImage(item) {
    let image = this.GetimageService.getImage(item)
    //console.log("image SearchpopupComponent ", image)
    return image;
  }

  showMoreLess(item) {
    item.opt = item.opt == undefined ? true : item.opt;
    item.opt = !item.opt;
  }


}
