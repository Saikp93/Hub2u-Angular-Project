import { Component, EventEmitter, Inject, Input, OnInit, Output, Renderer2, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService, AdministrationService, AuthService, CommonService, ReportsService } from 'hub2ushared';
import { ConstantData } from 'projects/hub2ushared/src/public-api';
import { OAuthService } from 'angular-oauth2-oidc';
import { FormControl } from '@angular/forms';
import { UserIdleService } from 'angular-user-idle';
import { authConfig } from 'projects/hub2uweb/src/app/auth.config'
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonSettingService } from '../../shared/common-settings.service';

import { SearchpopupComponent } from '../searchpopup/searchpopup.component';
import { EventService } from '../../shared/event.service';
import { Storage } from '@ionic/storage-angular';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { CommonWebService } from '../../shared/common-web.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  @ViewChild('onSwitchUserIDRef') onSwitchUserIDRef: TemplateRef<any>;
  @ViewChild('callSessionTimeOut') callSessionTimeOut: TemplateRef<any>;
  @ViewChild('callWarningTimeOut') callWarningTimeOut: TemplateRef<any>;
  @ViewChild('documentlist') documentlist: TemplateRef<any>;
  @Input() role_test;
  @Output() onRefresh = new EventEmitter();
  mainNavigation: any[] = [];
  subNavigation: any[] = [];
  navigation: any[] = [];
  userInfo: any = {};
  count = 5;
  isSearch: boolean = false;
  isMenu: boolean = false;
  cartCount: number = 0;
  notificationsCount: number = 0;
  list: any[] = ["Everything", "CIFA Item", "Category", "Description", "EIS Model Number"];
  defaultSearch = this.list[0];
  searchPlaceholder: string;
  displaySearch: boolean = false;
  searchInput: any;
  userRole = "COMCAST TECH USER IIP";
  title: string = '';
  imageToShow: any;
  sessionTimeOutTimer = 0;
  notifyCount: number = 0;
  isSwitch = true;
  showProfile = false;
  switchUsername = new FormControl('');
  functionId: string;
  cartLoader = false;
  loader: boolean = false;
  isTab = false;
  dynamicFields: any = [];
  public switchUserOptions = [
    { name: 'ESA User', value: 'COMCAST ESA USER', functionId: '61' },
    // { name: 'Tech User', value: 'COMCAST TECH USER IIP', functionId: '99' },
    { name: 'Tech User', value: 'COMCAST TECH USER IIP', functionId: '143' },
    { name: 'Store User', value: 'COMCAST STORE USER', functionId: '50' },
    // { name: 'Business User', value: 'COMCAST BUSINESS SERVICES USER', functionId: '51' },
    { name: 'CPE User', value: 'COMCAST CPE USER', functionId: '58' },
    { name: 'CNA User', value: 'COMCAST CNA USER', functionId: '60' },
    { name: 'Prepaid User', value: 'PREPAID DEALER', functionId: '57' },
    { name: 'NONCPE User', value: 'COMCAST NONCPE USER', functionId: '63' },
    { name: 'XM Supply Chain', value: 'XM SUPPLY CHAIN', functionId: '64' },
    { name: '5G User', value: 'COMCAST 5G USER', functionId: '66' },
    { name: 'Business User', value: 'COMCAST BUSINESS SERVICES USER IIP', functionId: '136' }
  ]
  region: any;

  constructor(private authService: AuthService, private storage: Storage, private commonWebService: CommonWebService,
    private constantData: ConstantData, public dialog: MatDialog, private administrationService: AdministrationService, @Inject('environment') private env: any, private router: Router, private oauthService: OAuthService,
    private commonService: CommonService, private reportService: ReportsService,
    private userIdle: UserIdleService, private spinner: NgxSpinnerService, private route: ActivatedRoute,
    private alertService: CommonSettingService, private messageService: MessageService, private renderer: Renderer2, private eventService: EventService) {
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    console.log("this.userRole",this.userRole)
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.mainNavigation = this.constantData.mainNavigation;
    this.subNavigation = this.constantData.subNavigation;
    this.navigation = this.constantData.navigation;
    this.isSwitch = !this.env.production;
    if (this.oauthService.hasValidIdToken()) {
      this.onInitialLoad();
    }
    this.onSwitchNPID();
    this.onSwitchProfile();
    this.onCartUpdated();
  }

  selectedDropdown = 'Everything';
  getDynamicSearchDropDown() {
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    console.log("this.userRole", this.userRole)
    var input = {
      "ReportId": "10158",
      "ParametersInput": [
        { "Name": "PROFILE_TYPE", "Value": this.userRole }
      ]
    }
    this.reportService.onGetDynamicReport(input).subscribe(response => {
      if (response.ROW != undefined) {
        for (let control of response.ROW) {
          this.dynamicFields.push(control);
        }
      }
    })
  }

  get(data) {
    this.dialog.closeAll();
    this.selectedDropdown = data;
    this.searchInput = "";
    this.loader = false;
    if (this.globalSearchResults) {
      this.globalSearchResults.unsubscribe();
    }
    if (data === "Everything") {
      this.searchPlaceholder = "Search by item,category,description...";
    } else if (data === "Category") {
      this.searchPlaceholder = "Search by category...";
    } else if (data === "CIFA Item") {
      this.searchPlaceholder = "Search by cifa item...";
    } else if (data === "Description") {
      this.searchPlaceholder = "Search by item description...";
    } else {
      this.searchPlaceholder = "Search by model number..";
    }
  }

  showSearchBar() {
    let obj=['136','143']
    var input = {
     "ReportId": obj.includes(this.functionId)?"7007":"10048",
      // "ReportId": "7007",
      "ParametersInput": [
        { "Name": "USERNAME", "Value": this.userInfo.NTID }
      ]
    }
    this.reportService.onGetDynamicReport(input).subscribe(response => {
      if (response != undefined && response.ROW != undefined) {
        let searchQuery = response.ROW[0];
        // console.log("searchQuery",searchQuery);
        if (searchQuery.ITEM_CATALOG == 'Y') {
          this.displaySearch = true;
        } else {
          this.displaySearch = false;
        }
      }

    })
  }

  globalSearchResults = null;
  getSearchResults(searchInput) {
    this.searchInput = searchInput;
    let input;
    if (searchInput.length >= 3) {
      this.loader = true;
      let cifa = "null";
      let category = "null";
      let descript = "null";
      let modelNo = "null";
      //if (this.selectedDropdown != 'Everything' && (this.functionId == '61' || this.functionId == '51' || this.functionId == '99')) {
        if (this.selectedDropdown != 'Everything' && (this.functionId == '61' || this.functionId == '136' || this.functionId == '143')) {
        if (this.selectedDropdown == 'CIFA Item') {
          cifa = searchInput;
        } else if (this.selectedDropdown === "Category") {
          category = searchInput;
        } else if (this.selectedDropdown === "Description") {
          descript = searchInput;
        } else if (this.selectedDropdown === "EIS Model Number") {
          modelNo = searchInput;
        }

        input = {
          "ReportId": this.constantData.globalSearchId[this.functionId],
          "ParametersInput": [
            { Name: "ITEM_CATALOG", Value: "Y" },
            { Name: "cifa_item_number", Value: cifa },
            { Name: "ITEM_DESCRIPTION", Value: descript },
            { Name: "item_category", Value: category },
            { Name: "MANUFACTURER_PART_NUM", Value: modelNo },
            { Name: "USER_NAME", Value: this.userInfo.NTID },
          ]
        }
      } else {
        input = {
          "ReportId": this.constantData.dynamicSearchId[this.functionId],
          "ParametersInput": [
            { "Name": "USER_NAME", "Value": this.userInfo.NTID },
            { "Name": "ONE_INPUT", "Value": searchInput },
            { "Name": "ITEM_CATALOG", "Value": "Y" }]
        }
      }
      if (this.globalSearchResults) {
        this.globalSearchResults.unsubscribe();
      }
      this.globalSearchResults = this.reportService.onGetDynamicReport(input).subscribe(response => {
        this.dialog.closeAll();
        if (response != undefined) {
          this.searchResults = response;
          const dialogRef = this.dialog.open(SearchpopupComponent, {
            panelClass: 'search-dialog',
            data: this.searchResults,
            backdropClass: 'backdropBackground'
          });
          this.loader = false;
          dialogRef.afterClosed().subscribe(result => {     // added to clear data when item added to cart
            if (result == 'clear')
              this.searchInput = ""
          })
        } else {
          this.loader = false;
        }
        setTimeout(() => {
          this.renderer.selectRootElement('#myInput').focus();
        }, 500);
      }, error => {
        this.loader = false;
      })
    } else {
      this.loader = false;
      this.dialog.closeAll();
      if (this.globalSearchResults) {
        this.globalSearchResults.unsubscribe();
      }
    }
  }

  searchResults: any[] = [];
  onCatalogSearch(searchInput) {
    this.dialog.closeAll();
    setTimeout(() => {
      this.renderer.selectRootElement('#myInput').blur();
    }, 500);
    this.alertService.setSearchInput(searchInput);

    if ((searchInput != undefined) && searchInput.length >= 3) {
      var input = {
        "ReportId": this.constantData.dynamicSearchId[this.functionId],
        "ParametersInput": [
          { "Name": "USER_NAME", "Value": this.userInfo.NTID },
          { "Name": "ONE_INPUT", "Value": searchInput },
          { "Name": "ITEM_CATALOG", "Value": "Y" }]
      }
      this.reportService.onGetDynamicReport(input).subscribe(response => {
        this.searchResults = response.ROW;
        this.messageService.sendMessage(this.searchResults);
      })
    }
    this.router.navigate(['/hub2u/catalog/catalogsearch'], {
      queryParams: { searchData: searchInput, defSearch: this.defaultSearch },
    });
  }

  onSwitchNPID() {
    this.commonService.switchNPID.subscribe(data => {
      this.onInitialLoad();
    })
  }

  onSwitchProfile() {
    this.commonService.switchProfile.subscribe(data => {
      this.displaySwitchProfile();
    })
  }

  async displaySwitchProfile() {
    this.showProfile = false;
    // if (!this.env.production) {
    let responsibilities = await JSON.parse(localStorage.getItem(this.userInfo.NTID + "_responsibilities"));
    if (responsibilities) {
      if (responsibilities.ROW && responsibilities.ROW !== undefined) {
        let found = responsibilities.ROW.find(resp => resp.FUNCTION_ID == '138')
        if (found != undefined)
          this.showProfile = true;

        if (found != undefined) {
          document.getElementById("SUID") ? document.getElementById("SUID").style.right = '120px' : ''
          // document.getElementById("readydoc").style.right = '240px'
        }
        else {
          document.getElementById("SUID") ? document.getElementById("SUID").style.right = '0px' : ''
          // document.getElementById("readydoc").style.right = '120px'
        }

      }
      else {
        document.getElementById("SUID") ? document.getElementById("SUID").style.right = '0px' : ''
        // document.getElementById("readydoc").style.right = '120px'
      }
    }
    else {
      document.getElementById("SUID") ? document.getElementById("SUID").style.right = '0px' : ''
      // document.getElementById("readydoc").style.right = '120px'
    }
    //}
  }
  onSelectUser(user, functionId) {
    this.spinner.show();
    let personId;
    let input = {
      //"ReportId": "10019", 
      // "ReportId": "7013", 
      "ReportId": functionId == '136'?"7013":"10019",
      "ParametersInput": [
        { "Name": "USER_NAME", "Value": this.userInfo.NTID },
        { "Name": "USER_ROLE", "Value": user }]
    }
    this.reportService.onGetDynamicReport(input).subscribe(response => {
      if (response.STATUS == 'SUCCESS' && response.ROW) {
        response.ROW.forEach(x => {
          personId = x['PERSON_ID']
        })
        this.updateUser(functionId, personId, user);
        //this.switchpreferences(this.userInfo.NTID, user)
      }
      else {
        this.spinner.hide();
        this.commonWebService.openSnackBar('Sorry! Something went wrong', 'ERROR');
      }
    }, (error: any) => {
      this.spinner.hide();
      this.commonWebService.openSnackBar('Sorry! Something went wrong', 'ERROR');
    })
  }

  switchpreferences(username, userrole) {
    let input = {
      "userName": username,
      "profile": userrole
    }
    this.reportService.switchPreference(input).subscribe(response => {
      if (response.status == 'SUCCESS') {
        this.storeResp();
        this.spinner.hide();
        this.commonWebService.openSnackBar(response.statusMessage, 'SUCCESS');
      }
      else {
        this.spinner.hide();
        this.commonWebService.openSnackBar(response.statusMessage, 'ERROR');
        ;
      }
    }, (error: any) => {
      this.spinner.hide();
      this.commonWebService.openSnackBar('Sorry! Something went wrong', 'ERROR');
    })
  }


  updateUser(functionId, personId, user) {
    let changes = []
    this.switchUserOptions.forEach(user => {
      let actionType = (functionId == user.functionId) ? 'ADD' : 'REMOVE'
      changes.push({
        applicationId: 1,
        actionType: actionType,
        functionId: user.functionId,
        userId: personId,
        userName: this.userInfo.NTID,
      });
    })
    let request = {
      userResponsibilityUpsertInput: changes,
    };
    this.administrationService.updateUser(request).subscribe((response: any) => {
      if (response.status == 'SUCCESS') {
        this.switchpreferences(this.userInfo.NTID, user);

      }
      else {
        this.spinner.hide();
        this.commonWebService.openSnackBar('Sorry! Something went wrong', 'ERROR');
      }
    }, (error: any) => {
      this.spinner.hide();
      this.commonWebService.openSnackBar('Sorry! Something went wrong', 'ERROR');
    });
  }

  resetTimer() {
    this.userIdle.resetTimer();
  }
  onCartUpdated() {
    this.commonService.cartUpdate.subscribe(data => {
      this.getCartCount();
    })
  }

  async onInitialLoad() {
    this.userInfo = JSON.parse(await localStorage.getItem('userDetails'));
    this.onCheckUserInfo();
    this.displaySwitchProfile();
    this.userIdle.startWatching();
    this.searchInput = "";
    this.searchPlaceholder = "Search by item,category,description...";

    this.userIdle.onTimerStart().subscribe(count => {
      if (count === 1) {
        let dialogRef = this.dialog.open(this.callSessionTimeOut, {
          width: '500px'
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result !== undefined) {
            if (result === 'yes') {
              this.resetTimer();
            }
          }
        })
      }
      this.sessionTimeOutTimer = count;
    });
    this.userIdle.onTimeout().subscribe(() => {
      this.logout();
      this.userIdle.stopTimer();
    });
    let countPing = 0;
    // this.userIdle.ping$.subscribe(() => {
    //   if (countPing == 0) {
    //     countPing = countPing + 1;
    //     this.dialog.open(this.callWarningTimeOut, {
    //       width: '500px'
    //     });
    //   }
    // });  
    this.showSearchBar();
  }

  logout() {
    localStorage.clear();
    sessionStorage.clear();
    this.oauthService.logOut();
    window.location.href = authConfig.logoutUrl;
  }

  getUserRole(roles) {
    const keys = Object.keys(this.constantData.roles);
    if (this.userInfo !== null) {
      localStorage.setItem(this.userInfo.NTID + "_userRole", "COMCAST TECH USER IIP");
      // localStorage.setItem(this.userInfo.NTID + "_functionId", '99');
      localStorage.setItem(this.userInfo.NTID + "_functionId", '143');
      keys.map(element => {
        let role = (roles && roles.ROW) ? roles.ROW.filter(e => e.FUNCTION_ID == element) : 0;
        if (role.length > 0) {
          this.userRole = this.constantData.roles[element];
          localStorage.setItem(this.userInfo.NTID + "_userRole", this.userRole);
          localStorage.setItem(this.userInfo.NTID + "_functionId", element);
          this.getCartCount();
          return
        } else {

        }
      });
    }
  }
  loadSettings() {
    var input = {
      //"ReportId": "112",
      // "ReportId": "7001", 
      ReportId:this.constantData.userprofileData[this.functionId], //cifa to iip change
      "ParametersInput": [
        { "Name": "USER_NAME", "Value": this.userInfo.NTID },
       ]
    }
    this.reportService.onGetDynamicReport(input).subscribe(repsonse => {

      if (repsonse.ROW !== undefined && repsonse.ROW.length > 0) {
        let offsetDate = repsonse.ROW[0].NEED_BY_DATE_TIME == null ? 0 : repsonse.ROW[0].NEED_BY_DATE_TIME

        var date = new Date(); // Get current Date
        date.setDate(date.getDate() + offsetDate);
        let needbyDate = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
        this.userInfo['offsetDate'] = offsetDate;
        this.userInfo['needByDate'] = needbyDate;

        repsonse.ROW[0]['REGION_NAME'] ? this.region = repsonse.ROW[0]['REGION_NAME'] : this.region = this.userInfo['region']

        repsonse.ROW[0]['PERSON_ID'] ? sessionStorage.setItem("personId" + this.userInfo.NTID, repsonse.ROW[0]['PERSON_ID']) : '';
        this.onGetCatalogs();
      }

      localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
    });
  }

  loadLocationSetting() {
    var data;

    var input = {
      //"ReportId": "112",
      // "ReportId": "7001",
      ReportId:this.constantData.userprofileData[this.functionId],
      "ParametersInput": [
        {
          "Name": "USER_NAME",
          "Value": this.userInfo.NTID
        },
        
      ]
    }
    this.reportService.onGetDynamicReport(input).subscribe(repsonse => {

      if (repsonse.ROW !== undefined && repsonse.ROW.length > 0) {
        data = repsonse.ROW[0]
        var locReportIdObj = {
          reportid: data.ATTRIBUTE4,
          attribute5: data.ATTRIBUTE4,
          userGroups: data.ATTRIBUTE2
        }
        var warehouseData = {
          srcOrg: data.SOURCE_ORGANIZATION,
          srcOrgSiteId: data.SOURCE_ORG_ADDRESS_SITE_ID,
          org: data.SOURCE_LOCATION,
          srcOrgId: data.SOURCE_ORGANIZATION_ID
        }
        this.userInfo['locationDynamicQuery'] = locReportIdObj;
        this.userInfo['wareHouseDeatils'] = warehouseData;
      }

      localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
    });

  }

  onCheckUserInfo() {
    console.log(window.location.pathname, this.userInfo.NTID);
    if (this.userInfo !== null) {
      if (this.userInfo.NTID !== undefined) {
        if (localStorage.getItem(this.userInfo.NTID + "_responsibilities")) {
          let responsibilities = JSON.parse(localStorage.getItem(this.userInfo.NTID + "_responsibilities"));
          if (responsibilities.ROW !== undefined) {
            this.loadAllOperations(responsibilities)
          } else {
            this.getResp();
          }
        } else {
          this.getResp();
        }
      }
    }
  }
  getResp() {
    let object = {
      //"ReportId": "10087",
      "ReportId": "7002", // oracle fusion
      // ReportId:this.constantData.getresponsibilities[this.functionId],
      "ParametersInput":
        [{ "Name": "BIND_APPLICATIONID", "Value": "7" },
        { "Name": "USER_NAME", "Value": this.userInfo.NTID }]
    };

    //  this.commonService.onFetchUserResp(object).subscribe(response => {
    this.reportService.onGetDynamicReport(object).subscribe(response => {
      let resp = response || [];
      if (resp.ROW !== undefined) {
        localStorage.setItem(this.userInfo.NTID + "_responsibilities", JSON.stringify(resp));
        let responsibilities = JSON.parse(localStorage.getItem(this.userInfo.NTID + "_responsibilities"));
        this.loadAllOperations(responsibilities)
      } else {

      }
    }, error => {
    });
  }
  loadAllOperations(resp) {
    this.dynamicFields = [];
    if (this.userInfo !== null) {
      let role = (resp && resp.ROW) ? resp.ROW.filter(e => e.TYPE == "USER_TYPE") : 0;
      if (role.length > 0) {
        this.userRole = this.constantData.roles[role[0].FUNCTION_ID];
        localStorage.setItem(this.userInfo.NTID + "_userRole", this.userRole);
        localStorage.setItem(this.userInfo.NTID + "_functionId", role[0].FUNCTION_ID);
        this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
      } else {
        localStorage.setItem(this.userInfo.NTID + "_userRole", "COMCAST TECH USER IIP");
        //localStorage.setItem(this.userInfo.NTID + "_functionId", '99');
        localStorage.setItem(this.userInfo.NTID + "_functionId", '143');
        this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
      }

      this.onCheckUserOptions(resp);
      this.checkUserMainNavAccess(resp);
      this.onGetImage();
      this.loadSettings();
      this.loadLocationSetting();
      this.getNotificationsCount();
      this.getCartCount();
      this.getDynamicSearchDropDown();
      this.router.navigate([window.location.pathname]);
    }
  }
  checkUserMainNavAccess(event) {
    this.mainNavigation.forEach((menu, i) => {
      if (event && event.ROW)
        event.ROW.forEach(item => {
          if (item.FUNCTION_ID == menu.functionId) {
            this.mainNavigation[i].hidden = false;
          }
          if (menu.functionId == 100) {
            this.mainNavigation[i].hidden = false;
          }
        });

    });
  }

  onCheckUserOptions(event) {
    this.mainNavigation.forEach((menu, i) => {
      if (event && event.ROW)
        event.ROW.forEach(item => {
          if (item.FUNCTION_ID == 1) {
            this.mainNavigation[i].hidden = true;
          }
          if (item.FUNCTION_ID == this.mainNavigation[i].functionId) {
            this.mainNavigation[i].hidden = true;
          }
        });
    });
  }

  onGetImage() {
    this.authService.onGetProfileImage(this.userInfo.NTID ? this.userInfo.NTID.toUpperCase() : '').subscribe(response => {
      this.imageToShow = '';
      this.onCreateImageFromBlob(response);
    }, error => {
      this.imageToShow = '';
    });
  }

  onCreateImageFromBlob(image: Blob) {
    const reader = new FileReader();
    reader.addEventListener('load', () => {
      this.imageToShow = reader.result;
    }, false);

    if (image) {
      reader.readAsDataURL(image);
    }
  }

  onSwitchUserID() {
    // return this.dialog.open(this.onSwitchUserIDRef, {
    //   width: '500px'
    // });
    console.log("test")
    this.router.navigate(['hub2u/switchntid']);
  }

  onNavigate(path) {
    this.dialog.closeAll();
    this.router.navigate([path]);
  }

  switchUser() {
    this.showSpinner();
    if (this.switchUsername.value) {
      this.userInfo.NTID = this.switchUsername.value.toUpperCase();
      localStorage.clear();
      localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
      localStorage.setItem("switchNTID", 'true');
      this.onCheckUserInfo();
      this.commonService.updateServices(true);
      this.switchUsername.setValue(null);
    }
    //this.spinner.hide();
  }
  showSpinner() {
    this.spinner.show();
    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 5000);
  }

  getCartCount() {
    this.functionId = localStorage.getItem(this.userInfo.NTID + "_functionId");
    this.cartLoader = true;
    if (this.functionId == '61') {
      let request = { "ReportId": "10066", "ParametersInput": [{ "Name": "USER_NAME", "Value": this.userInfo.NTID }] };
      this.reportService.onGetDynamicReport(request).subscribe(response => {
        this.cartCount = response.ROW[0].CART_COUNT;
        this.cartLoader = false;
      })
    }
    else {
      let obj=['136','143']
      let request = { 
       // "ReportId": "1083",
        // "ReportId": "7014",
        "ReportId": obj.includes(this.functionId)?"7014":"1083", 
        "ParametersInput": [{ "Name": "USER_NAME", "Value": this.userInfo.NTID }] };
      this.reportService.onGetDynamicReport(request).subscribe(response => {
        this.cartCount = response.ROW[0].CART_COUNT;
        this.cartLoader = false;
      })
    }
  }

  getNotificationsCount() {
    let request = {
      applicationId: 1,
      ntAccount: this.userInfo.NTID
    }
    this.commonService.onShowAnnouncements(request).subscribe(response => {
      if (response.announcementsForUserListOut === null || response.announcementsForUserListOut === undefined) {
        this.notificationsCount = 0
      } else {
        this.notificationsCount = response.announcementsForUserListOut.length;
      }
    })
  }
  showAlert: boolean = false;
  showNotifications() {
    this.dialog.closeAll();
    this.showAlert = true;
    this.alertService.setAlerts(this.showAlert);
  }

  storeResp() {
    let object = {
    //  "ReportId": "10087",
       "ReportId": "7002", // oracle fusion
      // ReportId:this.constantData.getresponsibilities[this.functionId],

      "ParametersInput":
        [{ "Name": "BIND_APPLICATIONID", "Value": "7" },
        { "Name": "USER_NAME", "Value": this.userInfo.NTID }]
    };
    this.reportService.onGetDynamicReport(object).subscribe(async response => {
      let resp = response || [];
      if (resp.ROW !== undefined) {
        if (this.env.flatform === 'mobile') {
          this.storage.set(this.userInfo.NTID + "_responsibilities", JSON.stringify(resp));
        } else {
          localStorage.setItem(this.userInfo.NTID + "_responsibilities", JSON.stringify(resp));
        }
        if (this.userInfo !== null) {
          let roleNew = (resp && resp.ROW) ? resp.ROW.filter(e => e.TYPE == "USER_TYPE") : 0;
          if (roleNew.length > 0) {
            this.userRole = this.constantData.roles[roleNew[0].FUNCTION_ID];
            if (this.env.flatform === 'mobile') {
              this.storage.set(this.userInfo.NTID + "_userRole", this.userRole);
              this.storage.set(this.userInfo.NTID + "_functionId", roleNew[0].FUNCTION_ID);
            } else {
              localStorage.setItem(this.userInfo.NTID + "_userRole", this.userRole);
              localStorage.setItem(this.userInfo.NTID + "_functionId", roleNew[0].FUNCTION_ID);
            }
          } else {
            if (this.env.flatform === 'mobile') {
              this.storage.set(this.userInfo.NTID + "_userRole", "COMCAST TECH USER IIP");
              // this.storage.set(this.userInfo.NTID + "_functionId", '99');
              this.storage.set(this.userInfo.NTID + "_functionId", '143');
            } else {
              localStorage.setItem(this.userInfo.NTID + "_userRole", "COMCAST TECH USER IIP");
              // localStorage.setItem(this.userInfo.NTID + "_functionId", '99');
              localStorage.setItem(this.userInfo.NTID + "_functionId", '143');
            }
          }
          this.spinner.hide();
          this.router.navigate(['/hub2u']);
          this.onRefresh.emit('');
          this.commonService.updateServices(true);
          sessionStorage.setItem(this.userInfo.NTID + "businessUsrObj", "");
          sessionStorage.setItem("listOfCatalogs" + this.userInfo.NTID, "");
          sessionStorage.setItem(this.userInfo.NTID + "catalogObj", "");
        }
        this.commonService.updateProfile(true);
      } else {
        this.spinner.hide();
        if (this.env.flatform === 'mobile') {
          this.storage.set("userDetails", JSON.stringify(this.userInfo));
          this.storage.set("switchNTID", 'true');
        } else {
          localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
          localStorage.setItem("switchNTID", 'true');
        }
      }
    }, error => {
      this.spinner.hide();

      if (this.env.flatform === 'mobile') {
        this.storage.set("userDetails", JSON.stringify(this.userInfo));
        this.storage.set("switchNTID", 'true');
      } else {
        localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
        localStorage.setItem("switchNTID", 'true');
      }
    });
  }

  opendocumentlist() {
    this.dialog.open(this.documentlist);
  }

  onGetCatalogs() {
    // if (this.functionId != '51')
    if (this.functionId != '136')
      this.loadRegion();
  }

  loadRegion() {
    let request = {
      "ReportId": this.constantData.regionReportId[this.functionId],
      "ParametersInput": [
        {
          "Name": "REQUESTOR",
          "Value": this.userInfo.NTID
        }
      ]
    };
    this.reportService.onGetDynamicReport(request).subscribe(repsonse => {
      if (repsonse.ROW !== undefined) {
        this.region = repsonse.ROW[0].LOOKUP_CODE;
        this.userInfo['region'] = this.region;
        localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
        this.loadCategories();
      }
    }, error => {
    });
  }

  loadCategories() {
    let requestObj = {
      "ReportId": this.constantData.catalogs[this.functionId],
      "ParametersInput": [
        { "Name": "REQUESTOR_USER_NAME", "Value": this.userInfo.NTID },
        {
          "Name": "REGION_NAME", "Value": this.region ? this.region : 'null'
        }
      ]
    }
    this.reportService.onGetDynamicReport(requestObj).subscribe(res => {
      let catalogs = res.ROW || [];
      sessionStorage.setItem("listOfCatalogs" + this.userInfo.NTID, JSON.stringify(catalogs))
    }, error => {

    })
  }

}
