import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DomSanitizer } from '@angular/platform-browser';
import { ReportsService } from 'hub2ushared';
import { TableUtil } from '../../shared/tableUtils';

@Component({
  selector: 'app-multiplefileupload',
  templateUrl: './multiplefileupload.component.html',
  styleUrls: ['./multiplefileupload.component.scss'],
})
export class MultiplefileuploadComponent implements OnInit {
  @Input() mode
  @Input() names
  @Input() url
  // @Input() method
  @Input() multiple
  @Input() disabled
  @Input() id;
  @Input() accept;
  idNew = ''
  @Input() auto = true
  @Input() respmandateCols;
  @Input() respTemplateCols;
  @Input() respmandatoryCols;
  @Input() mandateCols;
  @Output() getUploadedFiles = new EventEmitter<any>();
  @Output() submitFileEvent = new EventEmitter<any>();
  @Output() cancelFileEvent = new EventEmitter<any>();
  @ViewChild('el') el: ElementRef
  inputFileName: string
  fileTypeCsvCheck: boolean;
  public files: any[] = [];
  disableUploadBtn: boolean = true;
  messageForUpload: any;
  messageForUpload2: any;
  messageForUpload3: any;
  msgloader: boolean = true;
  nodata: boolean = false;
  pageName;
  mandatoryColumnData = [];
  templateColumnData = [];

  constructor(private sanitizer: DomSanitizer, private tableUtil: TableUtil, private snackBar: MatSnackBar,
    private reportService: ReportsService,) { }

  ngOnInit() {
  }

  onInput(event) { }

  onFileSelected(pFileList: File[]) {
    // onFileSelected(event) {
    // let files = event.dataTransfer ? event.dataTransfer.files : event.target.files;
    let files = Object.keys(pFileList).map(key => pFileList[key]);

    for (let i = 0; i < files.length; i++) {
      let file = files[i];
      if (this.validateExtention(file.name)) {
        file.objectURL = this.sanitizer.bypassSecurityTrustUrl((window.URL.createObjectURL(files[i])));

        if (!this.isMultiple()) {
          this.files = []
        }
        this.files.push(files[i]);
      }
    }
    if (this.files.length > 0) {
      this.idNew = this.files[0].name
      this.fileTypeCsvCheck = false;
      this.disableUploadBtn = false;
    }
    else {
      this.fileTypeCsvCheck = true;
      this.disableUploadBtn = true;
    }
    this.getUploadedFiles.emit(this.files);
  }

  onFileDropped(event, id) {
    let e = event.target.files;
    if (e.length == 0) {
      this.fileTypeCsvCheck = true;
    } else {
      id = e[0].name;
      this.idNew = e[0].name;
      // this.files = e;
      // this.fileInput = e[0];
      // this.fileName = e[0].name;
    }
    this.onFileSelected(event.target.files);
  }

  removeFile() {
    this.files.splice(0, 1);
    this.idNew = '';
    this.disableUploadBtn = true;
  }

  validate(file: File) {
    if (this.validateExtention(file.name)) {
      return false;
    }
    return true
  }
  submitFile() {
    this.submitFileEvent.emit();
    this.files.splice(0, 1);
    this.clearInputElement()
  }
  cancelFile() {
    this.cancelFileEvent.emit()
    this.files.splice(0, 1);
    this.clearInputElement()
  }
  validateExtention(fileName) {
    let allowExtention;
    if (this.accept.indexOf(".xlsx") > -1) {
      allowExtention = true;
    }
    if (this.accept.indexOf(".csv") > -1) {
      allowExtention = true;
    }
    if (this.accept.indexOf(".txt") > -1) {
      allowExtention = true;
    }
    if (allowExtention) {
      this.fileTypeCsvCheck = true;
    } else {
      this.fileTypeCsvCheck = false;
    }
    return this.fileTypeCsvCheck;
  }

  clearInputElement() {
    // this.fileUpload.nativeElement.value = ''
  }


  isMultiple(): boolean {
    return this.multiple
  }

  getPageName() {
    let today = new Date();
    let y = today.getFullYear();
    let m = today.getMonth() + 1;
    let d = today.getDate();
    let h = today.getHours();
    let mi = today.getMinutes();
    let s = today.getSeconds();
    let currentdate = y + "-" + m + "-" + d + "-" + h + "-" + mi + "-" + s;
    this.pageName = 'Hub2u_Order_' + currentdate
  }

  downloadTemplate(event) {
    this.getPageName();
    let headers;
    headers = this.respTemplateCols;
    let cols = this.respmandatoryCols.toString();
    console.log("downloadTemplate", this.respmandatoryCols, this.respTemplateCols);
    let newCol = cols.replace(/,/g, ' - ');
    this.tableUtil.exportToCsvWithEmptyHeaders("", this.pageName, headers, "BulkUpload", newCol);

  }

}
