import { SelectionModel } from '@angular/cdk/collections';
import { DatePipe } from '@angular/common';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ReportsService } from 'hub2ushared';
import { BulkUploadService } from 'hub2ushared';
import { TableUtil } from '../../../shared/tableUtils';
import { saveAs } from 'file-saver';
import { CommonWebService } from '../../../shared/common-web.service';
import { ConstantData } from 'projects/hub2ushared/src/public-api';

@Component({
  selector: 'app-orderlistdata',
  templateUrl: './orderlistdata.component.html',
  styleUrls: ['./orderlistdata.component.scss'],
})
export class OrderlistdataComponent implements OnInit {
  @Input() showSearchData: boolean;
  public clientForm: FormGroup;
  functionId = '';
  userInfo: any = {};
  userRole: any = '';
  loader: boolean = false;
  secondloader: boolean = false;
  showExportBtn: boolean = false;
  exportLoader: boolean = false;
  reportFields: any = [];
  dynamicFields: any = [];
  dynamicForm = new FormGroup({});
  orderDataList: any = [];
  orderDataListResp: any = [];
  nodata: boolean = false;
  showFilters: boolean = true;
  pageName = "Hub2u_BulkUpload.csv";
  orderListExportData: any = [];
  sucessLength: number = 0;
  pendingLength: number = 0;
  errorLength: number = 0;
  selectedPendingItem: boolean = false;
  selectedSuccessItem: boolean = false;
  selectedErrorItem: boolean = false;
  previewList = [{ name: 'PENDING', count: this.pendingLength, status: 'PENDING', message: '', pageSize: '' },
  { name: 'SUCCESS', count: this.sucessLength, status: 'SUCCESS', message: '', pageSize: '' },
  { name: 'ERROR', count: this.errorLength, status: 'ERROR', message: '', pageSize: '' }];
  selectedItem: any;
  dynamicData: any = [];

  constructor(
    public form: FormBuilder,
    private reportService: ReportsService, private formBuilder: FormBuilder, public datepipe: DatePipe, private constants: ConstantData,
    private tableUtil: TableUtil, private bulkService: BulkUploadService, public commonWebService: CommonWebService,) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.initialFormControl();
    this.getDynamicReport();
    if (this.showSearchData == true) {
      this.secondloader = true;
      setTimeout(() => {
        this.searchData();
      }, 10000);
    }
  }

  initialFormControl() {
    this.clientForm = this.form.group({
      shipmentNum: [''],
      storeId: [''],
      sourceSystem: [''],
      shipmentStatus: [''],
      fromDate: [''],
      toDate: [''],
    });
  }

  getDynamicReport() {
    this.loader = true;
    let request = {
      ReportId: this.constants.bulkUploadDisplayFields[this.functionId],
      ParametersInput: [
        {
          Name: 'REQUESTOR_NAME',
          Value: this.userInfo.NTID,
        },
      ],
    };
    this.reportService.getReportDisplayFields(request).subscribe(
      (response) => {
        if (response != undefined) {
          for (let control of response.ReportDisplayFieldsOutput) {
            this.dynamicFields.push(control);
          }
          this.dynamicForm = this.createDynamicForm();
          this.loader = false;
        } else {
        }
      },
      (error) => { }
    );
  }

  createDynamicForm() {
    let dynamicForm = this.formBuilder.group({});
    this.dynamicFields.forEach(control => {
      dynamicForm.addControl(control.name, this.formBuilder.control(''));
      if (control.name == 'REQUESTOR_NAME') {
        dynamicForm.controls['REQUESTOR_NAME'].setValue(this.userInfo.NTID)
        control.value = this.userInfo.NTID;
      }
    });
    return dynamicForm;
  }

  getOrderListExportData() {
    this.exportLoader = true;
    let request1 = {
      ReportId: this.constants.bulkUploadOrderListexport[this.functionId],
      ParametersInput: [
      ],
    }
    var formData = this.dynamicForm.value;
    for (var key in formData) {
      if (formData.hasOwnProperty(key)) {
        if (key == "REQUESTOR_NAME") {
          request1.ParametersInput.push({
            "Name": key,
            "Value": this.userInfo.NTID
          })
        }
        else {
          if (key == "FROM_DATE" || key == "TO_DATE" || key == 'NEED_BY_DATE') {
            formData[key] = this.datepipe.transform(formData[key], 'yyyy-MM-dd')
          }
          request1.ParametersInput.push({
            "Name": key,
            "Value": formData[key] == "" || formData[key] == null ? "" : formData[key].toString()
          })
        }
      }
    }
    // this.reportService.onGetDynamicReport(request1).subscribe(response => {
    this.bulkService.bulkExportCsv(request1).subscribe(response => {
      // delete (response['@num']);
      if (response != undefined) {
        saveAs(response, this.pageName);
      } else {
        // this.loader = false;
      }
      this.exportLoader = false;
    }, (error) => {
      this.exportLoader = false;
      this.commonWebService.openSnackBar(
        'Experiencing timeout issue, please reach out the Support Team',
        'ERROR'
      );
    })
  }

  searchData() {
    this.secondloader = true;
    this.showExportBtn = false;
    this.selectedItem = '';
    let request = {
      "ReportId": this.constants.bulkUploadDisplayFields[this.functionId],
      "ParametersInput": []
    }
    var formData = this.dynamicForm.value;
    for (var key in formData) {
      if (formData.hasOwnProperty(key)) {
        if (key == "REQUESTOR_NAME") {
          request.ParametersInput.push({
            "Name": key,
            "Value": this.userInfo.NTID
          })
        }
        else {
          if (key == "FROM_DATE" || key == "TO_DATE" || key == 'NEED_BY_DATE') {
            formData[key] = this.datepipe.transform(formData[key], 'yyyy-MM-dd')
          }
          request.ParametersInput.push({
            "Name": key,
            "Value": formData[key] == "" || formData[key] == null ? "" : formData[key].toString()
          })
        }
      }
    }
    this.dynamicData = request.ParametersInput;
    this.reportService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW != undefined) {
        // this.showFilters = false;
        this.orderDataListResp = response.ROW;
        this.orderDataList = response.ROW;
        // this.getOrderListExportData();
        var sucessLength = this.orderDataList.filter(val => val.RECORD_STATUS === "SUCCESS");
        var pendingLength = this.orderDataList.filter(val => val.RECORD_STATUS === "PENDING");
        var errorLength = this.orderDataList.filter(val => val.RECORD_STATUS === "ERROR");
        this.previewList[0].count = this.pendingLength = pendingLength.length != undefined ? pendingLength.length : 0;
        this.previewList[1].count = this.sucessLength = sucessLength.length != undefined ? sucessLength.length : 0;
        this.previewList[2].count = this.errorLength = errorLength.length != undefined ? errorLength.length : 0;
        // console.log("orgCode",this.sucessLength,this.pendingLength,this.errorLength)
        this.showExportBtn = true;
        this.secondloader = false;
        this.nodata = false;
      } else {
        this.showExportBtn = false;
        this.secondloader = false;
        this.nodata = true;
      }
    }, (error) => {
      this.showExportBtn = false;
      this.nodata = true;
      this.secondloader = false;
    });
  }

  loadDatalength() {
    var sucessLength = this.orderDataList.filter(val => val.RECORD_STATUS === "SUCCESS");
    var pendingLength = this.orderDataList.filter(val => val.RECORD_STATUS === "PENDING");
    var errorLength = this.orderDataList.filter(val => val.RECORD_STATUS === "ERROR");
    this.previewList[0].count = this.pendingLength = pendingLength.length != undefined ? pendingLength.length : 0;
    this.previewList[1].count = this.sucessLength = sucessLength.length != undefined ? sucessLength.length : 0;
    this.previewList[2].count = this.errorLength = errorLength.length != undefined ? errorLength.length : 0;
  }

  reloadTableEvent(event) {
    console.log("event in parent", event);
    this.orderDataList = event;
    // this.orderDataListResp = event;
    console.log("list", this.orderDataList.length);
    this.loadDatalength();
  }

  filterRecords(status) {
    this.secondloader = true;
    this.selectedItem = status
    if (status == "PENDING") {
      this.selectedSuccessItem = false;
      this.selectedErrorItem = false;
      this.selectedPendingItem = !this.selectedPendingItem
    } else if (status == "SUCCESS") {
      this.selectedPendingItem = false;
      this.selectedErrorItem = false;
      this.selectedSuccessItem = !this.selectedSuccessItem
    } else if (status == "ERROR") {
      this.selectedSuccessItem = false;
      this.selectedPendingItem = false;
      this.selectedErrorItem = !this.selectedErrorItem
    }
    setTimeout(() => {
      if (status == "PENDING") {
        this.orderDataList = this.orderDataListResp.filter(val => val.RECORD_STATUS === "PENDING");
      } else if (status == "SUCCESS") {
        this.orderDataList = this.orderDataListResp.filter(val => val.RECORD_STATUS === "SUCCESS");
      } else if (status == "ERROR") {
        this.orderDataList = this.orderDataListResp.filter(val => val.RECORD_STATUS === "ERROR");
      }
      if (this.selectedSuccessItem == false && this.selectedPendingItem == false && this.selectedErrorItem == false) {
        this.selectedItem = '';
        this.orderDataList = this.orderDataListResp;
      }
      if (this.orderDataList.length > 0) {
        this.nodata = false;
        this.loadDatalength();
      } else {
        this.nodata = true;
      }
      this.secondloader = false;
    }, 500);
  }

  closeFilters() {
    this.showFilters = !this.showFilters;
  }

  exportToCsv() {
    this.orderListExportData.forEach(data => {
      delete data['@num'];
    })
    this.tableUtil.exportTableToCsv(this.orderListExportData, this.pageName);
  }
}
