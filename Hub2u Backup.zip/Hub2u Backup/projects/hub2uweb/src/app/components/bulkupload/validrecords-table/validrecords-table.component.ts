import { SelectionModel } from '@angular/cdk/collections';
import { Component, EventEmitter, Input, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { HomeService, ReportsService, TemplateManagementService } from 'hub2ushared';
import { BulkUploadService } from 'hub2ushared';

import { CommonWebService } from '../../../shared/common-web.service';
import { TableUtil } from '../../../shared/tableUtils';
import { saveAs } from 'file-saver';
import { FiltertableRecordsComponent } from '../filtertable-records/filtertable-records.component';
import { EventService } from '../../../shared/event.service';
import { ConstantData } from 'projects/hub2ushared/src/public-api';
import { FormControl, FormGroup } from '@angular/forms';
import { LoadCartService } from '../../../shared/loadcart.service';

@Component({
  selector: 'app-validrecords-table',
  templateUrl: './validrecords-table.component.html',
  styleUrls: ['./validrecords-table.component.scss'],
})
export class ValidrecordsTableComponent implements OnInit {

  @Input() columnMapping: any;
  @Input() countMsg: any;
  @Input() pageSize: any;
  @Input() selectedTemplate: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('confirmDeletion') confirmDeletion: TemplateRef<any>;
  @ViewChild(FiltertableRecordsComponent) ChildComponent;
  @Output() submitEvent: EventEmitter<any> = new EventEmitter();
  @Output() countEvent: EventEmitter<any> = new EventEmitter();
  @Output() reloadCount: EventEmitter<any> = new EventEmitter();

  dataSource: MatTableDataSource<any>;
  displayedColumns: string[] = [];
  headers: string[] = [];
  selection: any;
  functionId: string;
  userInfo: any;
  validRecords: any = [];
  userDetails: any = '{}';
  userRole: any = '';
  validRecordsList: any = [];
  validRecordsExportData: any = [];
  userName: any;
  nodata: boolean = false;
  loader: boolean = false;
  reloadTable: boolean = false;
  pageName = "Hub2u_BulkUpload.csv";
  person_id: any;
  // pageSize = 100;
  pageSizeOptions: any;
  tableData: any;
  validCountMsg: any;
  totalCount: any;
  deleteAll: boolean = false;
  pageEvent;
  exportLoader: boolean = false;
  colName = "";
  editableCols = [];
  updateForm = new FormGroup({});
  allCols = [];
  visibleCols = [];
  displayCols = [];
  validRecsReq: any = null;

  constructor(private reportService: ReportsService, private bulkService: BulkUploadService,
    private templateManagementService: TemplateManagementService, private eventService: EventService,
    public commonWebService: CommonWebService, private constants: ConstantData,
    private homeService: HomeService, public dialog: MatDialog, private loadCartService: LoadCartService,) {
    this.loader = true;
    this.validRecsReq = this.loadCartService.getValidBulkCount().subscribe(count => {
      if (count) {
        this.reloadTable = false;
        this.displayedColumns = [];
        this.getValidRecords();
      }
    })

  }

  ngOnInit() {
    // this.reloadCount.emit(false);
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.fetchDynamicReports();
    this.initializeForm();
    this.userName = this.userInfo.NTID;
    // this.pageSizeOptions = this.pageSize;
    this.dataSource = new MatTableDataSource<any>(this.validRecordsList);
    this.selection = new SelectionModel<any>(true, []);
    // this.countMsg.forEach(x => {
    //   if (x.key !== undefined && x.key == 'Valid') {
    //     this.validCountMsg = x.mappingvalue;
    //     this.totalCount = x.totalCount;
    //   }
    // });
  }

  public handlePage(e: any) {
    // this.currentPage = e.pageIndex;
    this.pageSize = e.pageSize;
    this.reloadTable = true;
    this.getValidRecords();
  }

  initializeForm() {
    this.updateForm = new FormGroup({
      columnName: new FormControl('',),
      value: new FormControl('',)
    })
  }

  ngAfterViewInit() {
    this.call();
  }

  call() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.dataSource.filterPredicate = this.createFilter();
  }

  ngOnChanges() {
    this.reloadCount.emit(true);
    setTimeout(() => {
      this.countMsg.forEach(x => {
        if (x.key !== undefined && x.key == 'Valid') {
          this.validCountMsg = x.mappingvalue
        }
      });
    }, 1000)
    setTimeout(() => {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, 1500)
  }

  fetchDynamicReports() {
    let request = {
      //ReportId: 112,
      // ReportId: 7001,
      ReportId:this.constants.userprofileData[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };

    this.reportService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW !== undefined) {
        this.person_id = response.ROW[0].PERSON_ID
      }
    })
  }

  getValidRecords() {
    this.loader = true;
    setTimeout(() => {
      this.countMsg.forEach(x => {
        if (x.key !== undefined && x.key == 'Valid') {
          this.validCountMsg = x.mappingvalue;
          this.totalCount = x.totalCount;
        }
      });
    }, 1000)
    let request1 = {
      ReportId: this.constants.bulkUploadRecords[this.functionId],
      ParametersInput: [
        { Name: 'REQUESTOR_NAME', Value: this.userInfo.NTID },
        { Name: 'P_RECORD_STATUS', Value: 'Valid' },
        { Name: 'RECORD_COUNT', Value: this.pageSize },
        // { Name: 'P_ERROR_TYPE', Value: null}
      ],
    };
    this.reportService.onGetDynamicReport(request1).subscribe(response => { //getReportDisplayFields
      if (response.ROW != undefined && response.ROW != null) {
        this.nodata = false;
        this.loader = false;
        this.validRecordsList = response.ROW;
        this.dataSource = new MatTableDataSource<any>(this.validRecordsList);
        this.tableData = this.dataSource;
        setTimeout(() => {
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.dataSource.filterPredicate = this.createFilter();
        }, 1500)
        if (this.reloadTable == false) {
          this.onInitialLoad();
        }
      } else {
        this.loader = false;
        this.nodata = true;
      }
    }, error => {
      this.loader = false;
      this.nodata = true;
      this.commonWebService.openSnackBar(
        'Experiencing timeout issue, please reach out the Support Team',
        'ERROR'
      );
    })
  }

  filterValues = {};
  getValue(column, event) {
    this.colName = column;
    this.filterValues[column] = event.target.value;
    this.dataSource.filter = JSON.stringify(this.filterValues);
  }

  createFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data, filter): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      for (const [key, value] of Object.entries(searchTerms)) {
        if (`${value}` !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[`${key}`];
        }
      }

      let len = Object.keys(searchTerms).length;
      let searchArray = [];

      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            let word = searchTerms[col].trim().toLowerCase()
            if (data[col] !== null) {
              if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                searchArray.push(true);
                found = len === searchArray.length;
              }
            }
          }
          return found;
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction;
  }

  getValidRecordsExportData() {
    // this.exportLoader = true;
    this.eventService.showSpinner();
    let request1 = {
      ReportId: this.constants.bulkUploadExportData[this.functionId],
      ParametersInput: [
        { Name: "REQUESTOR_NAME", Value: this.userInfo.NTID },
        { Name: 'P_RECORD_STATUS', Value: 'Valid' },
      ],
    };
    this.bulkService.bulkExportCsv(request1).subscribe(response => {
      this.validRecordsExportData = response;
      if (response != undefined) {
        saveAs(response, this.pageName);
      }
      // this.exportLoader = false;
      this.eventService.hideSpinner();
    },
      (error) => {
        this.eventService.hideSpinner();
        this.commonWebService.openSnackBar(
          'Experiencing timeout issue, please reach out the Support Team',
          'ERROR'
        );
      }
    );
  }

  onInitialLoad() {
    this.allCols = [];
    this.visibleCols = [];
    this.displayedColumns = [];
    this.validRecordsList.forEach(data => {
      for (const key in data) {
        if (this.validRecordsList.indexOf(data) == 0) {
          this.visibleCols = data['DISPLAY_COLUMNS'].split(',');
          this.editableCols = data['EDITABLE_COLUMNS'].split(',');
          this.allCols.push(`${key}`);
        }
      }
    })
    this.displayCols = this.visibleCols;
    this.displayCols.forEach(col => {
      if (col != '@num') {
        this.displayedColumns.push(col);
        let word = this.refactorCols(col);
        this.headers.push(word);
      }
    })
    this.displayedColumns.push('action');
    this.headers.push('ACTION');
  }

  refactorCols(col) {
    let r = [];
    r = col.replace(/_/g, ' ');
    let word = "";
    for (let j of r) {
      word = word + j;
    }
    return word;
  }

  updateFieldsName(data) {
    this.columnMapping.forEach(element => {
      data.forEach(obj => {
        this.addKey(obj, element.key, element.mappingname);
      });
    })
    return data;
  }

  addKey(obj, oldKey, newKey) {
    obj[newKey] = obj[oldKey];
  }

  onDelete(item) {
    let array = [];
    // item['REQUESTOR_NAME'] = this.userInfo.NTID ? this.userInfo.NTID : '';
    array.push(item);
    let data = this.updateFieldsName(array);
    let csvObj = {
      data: data === undefined ? [] : data,
      action: 'DELETE',
      batchNumber: item.BATCH_ID,
      attribute1: '',
      attribute2: '',
      attribute3: '',
      attribute4: this.userRole,
      attribute5: '',
      attribute6: '',
      attribute7: '',
      attribute8: '',
      attribute9: '',
      attribute10: '',
    };

    this.loader = true;
    this.saveAPIRequest(csvObj);
  }

  submitUpdateForm() {
    let reports = this.validRecordsList;
    let updateColumn = this.updateForm.value.columnName;
    let updateValue = this.updateForm.value.value
    if (this.updateForm.value.columnName == "") {
      this.commonWebService.openSnackBar('Please Select Column Name To Update Data', 'WARNING');
    }
    else {
      for (let i = 0; i < reports.length; i++) {
        if (Object.keys(reports[i]).includes(updateColumn)) {
          reports[i][updateColumn] = updateValue;
          // reports[i]['errorStatus'] = "TMP_MGMT_UPD";
        }
      }
      this.updateAllRows(reports)
    }
  }

  updateAllRows(list) {
    this.eventService.showSpinner();
    let array = [];
    list['saved'] = true;
    array.push(list);
    let data = this.updateFieldsName(list)
    let csvObj = {
      data: data === undefined ? [] : data,
      action: 'UPDATE',
      requestorName: this.userInfo.NTID ? this.userInfo.NTID : '',
      batchNumber: '',
      attribute1: '',
      attribute2: list.TEMPLATE_NAME ? list.TEMPLATE_NAME : '',
      attribute3: '',
      attribute4: this.userRole,
      attribute5: '',
      attribute6: '',
      attribute7: '',
      attribute8: '',
      attribute9: '',
      attribute10: '',
    };
    this.saveAPIRequest(csvObj);
  }

  saveAPIRequest(request) {
    this.templateManagementService.uploadBulkOrder(request).subscribe(
      (response) => {
        this.eventService.hideSpinner();
        this.loader = false;
        if (response.status == 'SUCCESS') {
          this.selection.clear();
          this.reloadCount.emit(true);
          this.ChildComponent.childMethod();
          setTimeout(() => {
            this.countMsg.forEach(x => {
              if (x.key !== undefined && x.key == 'Valid') {
                this.validCountMsg = x.mappingvalue
              }
            });
          }, 1000)
          this.commonWebService.openSnackBar(response.message, 'SUCCESS');
          this.loadCartService.sendBulkCount(true);
        } else {
          this.commonWebService.openSnackBar(response.message, 'WARNING');
        }
        this.reloadTable = true;
        // this.getValidRecords();
        // this.getValidRecordsExportData();
      },
      (error) => {
        this.eventService.hideSpinner();
        this.loader = false;
        this.commonWebService.openSnackBar(
          'There was some problem updating the records',
          'ERROR'
        );
      }
    );
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.filteredData.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ? this.selection.clear() : this.dataSource.filteredData.forEach(row => this.selection.select(row));
  }

  checkboxLabel(row?): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  }

  deleteAllRowsWarning() {
    let dialogRef1 = this.dialog.open(this.confirmDeletion);
  }

  deleteAllRows() {
    this.deleteAll = true;
    this.commonDeleteFunc(this.validRecordsList);
  }

  deleteSelectedRows() {
    this.deleteAll = false;
    let rows = this.selection.selected;
    if (rows.len == this.validRecordsList.length) {
      this.commonDeleteFunc(this.validRecordsList);
    }
    else {
      this.commonDeleteFunc(rows);
    }
  }

  commonDeleteFunc(rows) {
    this.loader = true;
    let array = [];
    rows.forEach(item => {
      array.push(item);
    })
    let data = this.updateFieldsName(array)
    let request = {
      data: (data === undefined) || (this.deleteAll == true) ? [] : data,
      action: (this.deleteAll == true) ? 'DELETE_ALL' : 'DELETE',
      requestorName: this.userInfo.NTID ? this.userInfo.NTID : '',
      batchNumber: rows.BATCH_ID,
      attribute1: (this.deleteAll == true) ? 'VALID' : '',
      attribute2: '',
      attribute3: '',
      attribute4: this.userRole,
      attribute5: '',
      attribute6: '',
      attribute7: '',
      attribute8: '',
      attribute9: '',
      attribute10: '',
    }
    this.saveAPIRequest(request);
  }

  submit() {    
    console.log('this.functionId', this.functionId);
    this.loader = true;
    let req1 = {
      "action": this.functionId === "143" ? "BULK_CANCEL" : "BULK_UPLOAD",
      //"action": this.functionId === "99" ? "BULK_CANCEL" : "BULK_UPLOAD",
      //"requestorId": this.person_id ? this.person_id.toString() : '',
      "requestorId": this.userInfo.NTID ?this.userInfo.NTID:'',
      "profile":this.userRole.toUpperCase()
    }
    this.homeService.hub2uOrder(req1).subscribe(response => {
      if (response != undefined) {
        this.loader = false;
        let bulkUploadResponse = response.orderDetailResponse;
        if (bulkUploadResponse != undefined) {
          if (bulkUploadResponse[0].status == 'SUCCESS') {
            this.submitEvent.emit(true);
            this.reloadCount.emit(true);
            setTimeout(() => {
              this.countMsg.forEach(x => {
                if (x.key !== undefined && x.key == 'Valid') {
                  this.validCountMsg = x.mappingvalue
                }
              });
            }, 1000)
            this.commonWebService.openSnackBar("You are about to submit " + this.totalCount + " orders for processing. Since this is bulk submission, depending on size of batch, it can take anywhere between few seconds to few minutes for getting order numbers. While we are submitting the orders for you in the background, feel free to grab a coffee or catch up on your pending items. You can look for the latest order submission status in the orders screen.", 'SUCCESS');
          } else if (bulkUploadResponse[0].status == 'ERROR') {
            this.commonWebService.openSnackBar(bulkUploadResponse[0].statusMessage, 'ERROR');
          } else {
            this.commonWebService.openSnackBar(bulkUploadResponse[0].statusMessage, 'WARNING');
          }
        }
      } else {
        this.loader = false;
      }
      this.reloadTable = true;
      // this.getValidRecords();
      // this.getValidRecordsExportData();
    }, (error) => {
      this.loader = false;
      this.commonWebService.openSnackBar('There was some problem in Submitting the records', 'ERROR');
    })
  }

  ngOnDestroy() {
    this.validRecsReq.unsubscribe();
  }

}
