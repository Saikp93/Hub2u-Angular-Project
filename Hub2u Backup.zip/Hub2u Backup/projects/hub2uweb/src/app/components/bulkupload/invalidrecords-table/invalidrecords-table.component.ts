import { SelectionModel } from '@angular/cdk/collections';
import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, SimpleChanges, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ReportsService, TemplateManagementService } from 'hub2ushared';
import { BulkUploadService } from 'hub2ushared';
import { CommonWebService } from '../../../shared/common-web.service';
import { TableUtil } from '../../../shared/tableUtils';
import { saveAs } from 'file-saver';
import { FiltertableRecordsComponent } from '../filtertable-records/filtertable-records.component';
import { EventService } from '../../../shared/event.service';
import { ConstantData } from 'projects/hub2ushared/src/public-api';
import { LoadCartService } from '../../../shared/loadcart.service';
@Component({
  selector: 'app-invalidrecords-table',
  templateUrl: './invalidrecords-table.component.html',
  styleUrls: ['./invalidrecords-table.component.scss'],
})
export class InvalidrecordsTableComponent implements OnInit {
  @Input() columnMapping: any;
  @Input() countMsg: any;
  @Input() pageSize: any;
  @Input() reloadData: boolean;
  @Input() selectedTemplate: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('confirmDeletion') confirmDeletion: TemplateRef<any>;
  @ViewChild(FiltertableRecordsComponent) ChildComponent;
  @Output() reloadCount: EventEmitter<any> = new EventEmitter();
  dataSource: MatTableDataSource<any>;
  displayedColumns: string[] = ['select'];
  headers: string[] = ['select'];
  nonEditFeilds: any[] = [];
  selection: any;
  functionId: string;
  userInfo: any;
  validRecords: any = [];
  userDetails: any = '{}';
  userRole: any = '';
  inValidRecordsList: any = [];
  userName: any;
  nodata: boolean = false;
  loader: boolean = false;
  reloadTable: boolean = false;
  deleteAll: boolean = false;
  pageName = "Hub2u_BulkUpload.csv";
  person_id: any;
  invalidRecordsExportData: any = [];
  enableSave: boolean = false;
  tableData: any;
  inValidCountMsg: any;
  pageEvent;
  pageSizeOptions: any;
  colName = "";
  selectedItem;
  finalobj: any = [];
  editableCols = [];
  totalCountObj: boolean = false;
  updateForm = new FormGroup({});
  templateNames: any = [];
  allCols = [];
  visibleCols = [];
  nonEditableCols = [];
  displayCols = [];
  contArray = [];
  invalidRecsReq: any = null;

  constructor(private reportService: ReportsService, private loadCartService: LoadCartService, private bulkService: BulkUploadService, private constants: ConstantData,
    private templateManagementService: TemplateManagementService, public dialog: MatDialog, private cd: ChangeDetectorRef,
    public commonWebService: CommonWebService, private tableUtil: TableUtil, private eventService: EventService,) {
    this.loader = true;
    this.invalidRecsReq = this.loadCartService.getInValidBulkCount().subscribe(count => {
      if (count) {
        this.reloadTable = false;
        this.displayedColumns = ['select'];
        this.getInValidRecords();
      }
    })

  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.reloadCount.emit(true);
    this.callOninit();
  }

  callOninit() {
    this.templateNames = [];
    this.initializeForm();
    this.pageSizeOptions = this.pageSize;
    this.dataSource = new MatTableDataSource<any>(this.inValidRecordsList);
    this.selection = new SelectionModel<any>(true, []);
    this.enableSave = false;
  }

  DeleteKeys(myObj, array) {
    for (let index = 0; index < array.length; index++) {
      delete myObj[array[index]];
    }
    return myObj;
  }

  ngAfterViewInit() {
    this.call();
  }

  call() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.dataSource.filterPredicate = this.createFilter();
  }

  ngOnChanges(changes: SimpleChanges) {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    // this.reloadCount.emit(true);
    // if (this.reloadData == true) {
    //   this.reloadTable = true;
    //   this.templateNames = [];
    //   this.getInValidRecords();
    // }
    // setTimeout(() => {
    //   this.countMsg.forEach(x => {
    //     if (x.key !== undefined && x.key == 'Invalid') {
    //       this.inValidCountMsg = x.mappingvalue
    //     }
    //   });
    // }, 1000)
    setTimeout(() => {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, 1500)
  }

  initializeForm() {
    this.updateForm = new FormGroup({
      columnName: new FormControl('',),
      value: new FormControl('',)
    })
  }

  public handlePage(e: any) {
    this.pageSize = e.pageSize;
    this.reloadTable = true;
    this.getInValidRecords();
  }

  filterKey: any;
  selected = false;

  onCardfilter(preview) {
    preview.selected = !preview.selected;
    this.selectedItem = !preview.selected ? '' : preview.key;
    this.filterKey = preview.selected ? preview.key : '';
    this.reloadTable = true;
    this.loadCartService.sendInValidBulkCount(true);
  }
  getInValidRecords() {
    this.loader = true;
    setTimeout(() => {
      this.countMsg.forEach(x => {
        if (x.key !== undefined && x.key == 'Invalid') {
          this.contArray = x.countVal;
          this.inValidCountMsg = x.mappingvalue;
        }
      });
      var array = ["MESSAGE", "PAGE_SIZE", "TOTAL_COUNT", "@num"];
      this.finalobj = this.DeleteKeys(this.contArray, array);
      let names = Object.keys(this.contArray).filter((key) => key.includes(this.filterKey))
        .reduce((obj, key) => {
          return Object.assign(obj, {
            [key]: this.contArray[key]
          });
        }, {});
      if (this.filterKey != undefined && this.filterKey != null && Object.values(names)[0] == 0) {
        this.filterKey = 'null';
      }
      let request1 = {
        ReportId: this.constants.bulkUploadRecords[this.functionId],
        ParametersInput: [
          { Name: 'REQUESTOR_NAME', Value: this.userInfo.NTID },
          { Name: 'P_RECORD_STATUS', Value: 'Invalid' },
          { Name: 'RECORD_COUNT', Value: this.pageSize },
          { Name: 'P_ERROR_TYPE', Value: this.filterKey != undefined && this.filterKey != null ? this.filterKey : 'null' }
        ],
      };
      this.reportService.onGetDynamicReport(request1).subscribe(
        (response) => {
          if (response.ROW != undefined) {
            this.nodata = false;
            this.loader = false;
            this.inValidRecordsList = response.ROW;
            this.dataSource = new MatTableDataSource<any>(this.inValidRecordsList);
            this.tableData = this.dataSource;
            setTimeout(() => {
              this.dataSource.paginator = this.paginator;
              this.dataSource.sort = this.sort;
              this.dataSource.filterPredicate = this.createFilter();
            }, 1500)
            if (this.reloadTable == false) {
              this.onInitialLoad();
            }
          } else {
            this.loader = false;
            this.nodata = true;
          }
        },
        (error) => {
          this.loader = false;
          this.nodata = true;
          this.commonWebService.openSnackBar(
            'Experiencing timeout issue, please reach out the Support Team',
            'ERROR'
          );
        }
      )
    }, 500);
  }

  lovList: any = [];
  getLov(data?) {
    let request;
    //if (this.functionId == '51') {
      if (this.functionId == '136') {
      request = {
        ReportId: 10138,
        ParametersInput: [
          { Name: "REQUESTOR_NAME", Value: this.userInfo.NTID }
        ]
      };
    } 
    // else if (this.functionId == '64' || this.functionId == '99') {
      else if (this.functionId == '64' || this.functionId == '143') {
      request = {
        ReportId: this.constants.bulkUploadRecords[this.functionId],
        ParametersInput: [
          { Name: "TEMPLATE_NAME", Value: data.TEMPLATE_NAME }
        ]
      };
    }
    this.reportService.getReportDisplayFields(request).subscribe(response => {
      if (response.ReportDisplayFieldsOutput !== undefined) {
        for (let item of response.ReportDisplayFieldsOutput) {
          if (item.name == 'MAPPING') {
            let saveCartColumn = item.options;
            saveCartColumn.forEach(x => {
              if (x.text !== undefined) {
                this.lovList.push({ key: x.text, mappingname: x.value })
              }
            });
          }
        }
      }
    }, error => {
      this.loader = false;
    })
  }

  onInitialLoad() {
    this.allCols = [];
    this.visibleCols = [];
    this.nonEditableCols = [];
    this.displayedColumns = ['select'];
    this.inValidRecordsList.forEach((data) => {
      for (const key in data) {
        if (this.inValidRecordsList.indexOf(data) == 0 && data['EDITABLE_COLUMNS'] !== undefined && data['NON_EDITABLE'] !== undefined) {
          this.visibleCols = data['DISPLAY_COLUMNS'].split(',');
          this.editableCols = data['EDITABLE_COLUMNS'].split(',');
          // this.nonEditableCols = this.convertToArray(data['NON_EDITABLE']);  
        }
      }
    });
    this.displayCols = this.visibleCols;

    this.displayCols.forEach((col) => {
      if (col != '@num') {
        this.displayedColumns.push(col);
        let word = this.refactorCols(col);
        this.headers.push(word);
      }
    });
    this.displayedColumns.push('action');
    this.headers.push('ACTION');
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(',');
      } else {
        columns = columns + ',';
        col = columns.split(',');
      }
    }
    return col;
  }

  refactorCols(col) {
    let r = [];
    r = col.replace(/_/g, ' ');
    let word = '';
    for (let j of r) {
      word = word + j;
    }
    return word;
  }

  updateFieldsName(data) {
    this.lovList.forEach((element) => {
      data.forEach((obj) => {
        this.addKey(obj, element.key, element.mappingname);
        delete obj['edit'];
      });
    });
    return data;
  }

  addKey(obj, oldKey, newKey) {
    obj[newKey] = obj[oldKey];
  }
  text: any;
  getqtyAvailablemsg(row, key){
    let qtyAvailablemsg = (row.ATTRIBUTE26 != null || row.ATTRIBUTE26 != undefined) ? row.ATTRIBUTE26 : '';
    let selectedVal = '';
    for (let item of qtyAvailablemsg) {
      if (item.includes(key)) {
        selectedVal = item;
      }
    }
    if (selectedVal !== '') {
      return selectedVal;
    } else {
      this.text = "&nbsp;";
      return "";
    }
  }
  
  getError(row, key) {
    let msg = (row.VALIDATION_MESSAGE != null || row.VALIDATION_MESSAGE != undefined) ? row.VALIDATION_MESSAGE.split(',') : '';
    let selectedVal = '';
    for (let item of msg) {
      if (item.includes(key)) {
        selectedVal = item;
      }
    }
    if (selectedVal !== '') {
      let msgNew = selectedVal.split(':');
      this.text = msgNew[1];
      var testArr = {};
      testArr[msgNew[0]] = msgNew[1];
      return msgNew[1];
    } else {
      this.text = "&nbsp;";
      return "";
    }
  }

  filterValues = {};
  getValue(column, event) {
    this.colName = column;
    this.filterValues[column] = event.target.value;
    this.dataSource.filter = JSON.stringify(this.filterValues);
  }

  createFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data, filter): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      for (const [key, value] of Object.entries(searchTerms)) {
        if (`${value}` !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[`${key}`];
        }
      }

      let len = Object.keys(searchTerms).length;
      let searchArray = [];

      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            let word = searchTerms[col].trim().toLowerCase()
            if (data[col] !== null) {
              if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                searchArray.push(true);
                found = len === searchArray.length;
              }
            }
          }
          return found;
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction;
  }

  getInvalidRecordsExportData() {
    // this.exportLoader = true;
    this.eventService.showSpinner();
    let request1 = {
      ReportId: this.constants.bulkUploadExportData[this.functionId],
      ParametersInput: [
        { Name: "REQUESTOR_NAME", Value: this.userInfo.NTID },
        { Name: 'P_RECORD_STATUS', Value: 'Invalid' },
      ],
    };
    // this.reportService.onGetDynamicReport(request1).subscribe(response => {
    this.bulkService.bulkExportCsv(request1).subscribe(response => {
      // delete (response['@num']);
      // let updatedResp: any = []; 
      // console.log("response",response)
      if (response !== undefined && response !== null) {
        // updatedResp = this.updateFieldsName(response);
        saveAs(response, this.pageName);
      }
      this.eventService.hideSpinner();
    }, (error) => {
      this.eventService.hideSpinner();
      this.commonWebService.openSnackBar(
        'Experiencing timeout issue, please reach out the Support Team',
        'ERROR'
      );
    })
  }

  onDelete(item) {
    this.loader = true;
    let array = [];
    const keys = Object.keys(item);
    if (!this.templateNames.includes(item.TEMPLATE_NAME)) {
      this.templateNames.push(item.TEMPLATE_NAME);
      this.getLov(item);
    } else {
      console.log("existing")
    }
    if (item['EDITABLE_COLUMNS'] !== undefined && item['NON_EDITABLE'] !== undefined) {
      item.editableCols = item['EDITABLE_COLUMNS'].split(',');
      item.nonEditableCols = this.convertToArray(item['NON_EDITABLE']);
    }

    setTimeout(() => {
      array.push(item);
      let data = this.updateFieldsName(array);
      let csvObj = {
        data: data === undefined ? [] : data,
        action: 'DELETE',
        requestorName: this.userInfo.NTID ? this.userInfo.NTID : '',
        batchNumber: item.BATCH_ID,
        attribute1: '',
        attribute2: '',
        attribute3: '',
        attribute4: this.userRole,
        attribute5: '',
        attribute6: '',
        attribute7: '',
        attribute8: '',
        attribute9: '',
        attribute10: '',
      };
      this.saveAPIRequest(csvObj);
    }, 1000);

  }

  saveRecords() {
    let array = [];
    this.inValidRecordsList.forEach((item) => {
      item['isEdit'] = false;
      item['editIcon'] = true;
      item['saveIcon'] = false;
      item['isChanged'] = true;
      array.push(item);
    });
    let newData = [];
    newData = array.filter((item) => {
      return item.saved === true || item.edited === true;
    });
    let data = this.updateFieldsName(newData);
    let csvObj = {
      data: data === undefined ? [] : data,
      action: 'UPDATE',
      requestorName: this.userInfo.NTID ? this.userInfo.NTID : '',
      batchNumber: '',
      attribute1: '',
      attribute2: newData[0].TEMPLATE_NAME ? newData[0].TEMPLATE_NAME : '',
      attribute3: '',
      attribute4: this.userRole,
      attribute5: '',
      attribute6: '',
      attribute7: '',
      attribute8: '',
      attribute9: '',
      attribute10: '',
    };
    this.loader = true;
    this.saveAPIRequest(csvObj);
  }

  cancelRecords() {
    this.enableSave = false;
    this.inValidRecordsList.forEach((item) => {
      item['isEdit'] = false;
      item['editIcon'] = true;
      item['saveIcon'] = false;
      item['isChanged'] = true;
    });
    this.selection.clear();
  }

  onEdit(item) {
    this.enableSave = true;
    item.saveIcon = true;
    item.editIcon = false;
    item['edited'] = true;
    const keys = Object.keys(item);
    if (!this.templateNames.includes(item.TEMPLATE_NAME)) {
      this.templateNames.push(item.TEMPLATE_NAME);
      this.getLov(item);
    } else {
      console.log("existing")
    }
    if (item['EDITABLE_COLUMNS'] !== undefined && item['NON_EDITABLE'] !== undefined) {
      item.editableCols = item['EDITABLE_COLUMNS'].split(',');
      item.nonEditableCols = this.convertToArray(item['NON_EDITABLE']);

      keys.forEach((element) => {
        if (item.nonEditableCols === element) {
          item.isEdit = false;
        } else {
          item.isEdit = true;
        }
      });
    }
  }
  isNonEditable(key, row) {
    return row.nonEditableCols.includes(key);
  }

  onSaveitem(item) {
    item.isEdit = false;
    item.isChanged = true;
    item.editIcon = true;
    item.saveIcon = false;

    let array = [];
    item['saved'] = true;
    array.push(item);
    let data = this.updateFieldsName(array);

    let csvObj = {
      data: data === undefined ? [] : data,
      action: 'UPDATE',
      requestorName: this.userInfo.NTID ? this.userInfo.NTID : '',
      batchNumber: '',
      attribute1: '',
      attribute2: item.TEMPLATE_NAME ? item.TEMPLATE_NAME : '',
      attribute3: '',
      attribute4: this.userRole,
      attribute5: '',
      attribute6: '',
      attribute7: '',
      attribute8: '',
      attribute9: '',
      attribute10: '',
    };
    this.loader = true;
    this.saveAPIRequest(csvObj);
  }

  submitUpdateForm() {
    let reports = this.inValidRecordsList;
    let updateColumn = this.updateForm.value.columnName;
    let updateValue = this.updateForm.value.value
    if (this.updateForm.value.columnName == "") {
      this.commonWebService.openSnackBar('Please Select Column Name To Update Data', 'WARNING');
    }
    else {
      for (let i = 0; i < reports.length; i++) {
        if (Object.keys(reports[i]).includes(updateColumn)) {
          reports[i][updateColumn] = updateValue;
        }
      }
      this.updateAllRows(reports)
    }
  }

  updateAllRows(list) {
    this.eventService.showSpinner();
    let array = [];
    const keys = Object.keys(list);
    if (!this.templateNames.includes(list.TEMPLATE_NAME)) {
      this.templateNames.push(list.TEMPLATE_NAME);
      this.getLov(list[0]);
    } else {
      console.log("existing")
    }
    if (list[0]['EDITABLE_COLUMNS'] !== undefined && list[0]['NON_EDITABLE'] !== undefined) {
      list.editableCols = list[0]['EDITABLE_COLUMNS'].split(',');
      list.nonEditableCols = this.convertToArray(list[0]['NON_EDITABLE']);
    }
    list['saved'] = true;
    setTimeout(() => {
      array.push(list);
      let data = this.updateFieldsName(list)
      let csvObj = {
        data: data === undefined ? [] : data,
        action: 'UPDATE',
        requestorName: this.userInfo.NTID ? this.userInfo.NTID : '',
        batchNumber: '',
        attribute1: '',
        attribute2: list[0].TEMPLATE_NAME ? list[0].TEMPLATE_NAME : '',
        attribute3: '',
        attribute4: this.userRole,
        attribute5: '',
        attribute6: '',
        attribute7: '',
        attribute8: '',
        attribute9: '',
        attribute10: '',
      };
      this.saveAPIRequest(csvObj);
    }, 1000);
  }

  saveAPIRequest(request) {
    this.templateManagementService.uploadBulkOrder(request).subscribe(
      (response) => {
        this.eventService.hideSpinner();
        // this.loader = false;
        if (response.status == 'SUCCESS') {
          this.reloadCount.emit(true);
          // this.loadCartService.sendInValidBulkCount(true);
          this.ChildComponent.childMethod();
          setTimeout(() => {
            this.countMsg.forEach(x => {
              if (x.key !== undefined && x.key == 'Invalid') {
                this.inValidCountMsg = x.mappingvalue
              }
            });
          }, 1000)
          this.selection.clear();
          this.enableSave = false;
          this.commonWebService.openSnackBar(response.message, 'SUCCESS');
        } else {
          this.enableSave = false;
          this.commonWebService.openSnackBar(response.message, 'WARNING');
        }
        this.reloadTable = true;
        // this.getInValidRecords();
        // this.getInvalidRecordsExportData();
      },
      (error) => {
        this.eventService.hideSpinner();
        this.loader = false;
        this.commonWebService.openSnackBar(
          'There was some problem updating the records',
          'ERROR'
        );
      }
    );
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.filteredData.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ? this.selection.clear() : this.dataSource.filteredData.forEach(row => this.selection.select(row));
  }

  checkboxLabel(row?): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  }

  deleteAllRowsWarning() {
    let dialogRef1 = this.dialog.open(this.confirmDeletion);
  }

  deleteAllRows() {
    this.deleteAll = true;
    this.commonDeleteFunc(this.inValidRecordsList);
  }

  deleteSelectedRows() {
    this.deleteAll = false;
    let rows = this.selection.selected;
    if (rows.len == this.inValidRecordsList.length) {
      this.commonDeleteFunc(this.inValidRecordsList);
    }
    else {
      this.commonDeleteFunc(rows);
    }
  }

  commonDeleteFunc(rows) {
    this.loader = true;
    let array = [];
    const keys = Object.keys(rows[0]);
    if (!this.templateNames.includes(rows[0].TEMPLATE_NAME)) {
      this.templateNames.push(rows[0].TEMPLATE_NAME);
      this.getLov(rows[0]);
    } else {
      console.log("existing")
    }
    setTimeout(() => {
      rows.forEach(item => {
        array.push(item);
      })
      let data = this.updateFieldsName(array)
      let request = {
        data: (data === undefined) || (this.deleteAll == true) ? [] : data,
        action: (this.deleteAll == true) ? 'DELETE_ALL' : 'DELETE',
        requestorName: this.userInfo.NTID ? this.userInfo.NTID : '',
        batchNumber: rows.BATCH_ID,
        attribute1: (this.deleteAll == true) ? 'INVALID' : '',
        attribute2: '',
        attribute3: '',
        attribute4: this.userRole,
        attribute5: '',
        attribute6: '',
        attribute7: '',
        attribute8: '',
        attribute9: '',
        attribute10: '',
      }
      this.saveAPIRequest(request);
    }, 1000);
  }

  ngOnDestroy() {
    this.invalidRecsReq.unsubscribe();
  }
}
