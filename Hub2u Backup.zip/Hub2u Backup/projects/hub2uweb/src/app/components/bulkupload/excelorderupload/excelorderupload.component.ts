import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReportsService, TemplateManagementService } from 'hub2ushared';
import { ConstantData } from 'projects/hub2ushared/src/public-api';
import { CommonWebService } from '../../../shared/common-web.service';
import { EventService } from '../../../shared/event.service';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-excelorderupload',
  templateUrl: './excelorderupload.component.html',
  styleUrls: ['./excelorderupload.component.scss'],
})
export class ExcelorderuploadComponent implements OnInit {
  public fileInput;
  public records;
  public fileName: any;
  functionId = '';
  userInfo: any = {};
  userRole: any = '';
  loader: boolean = false;
  temploader: boolean = false;
  files;
  accept = '.xlsx,.csv';
  fileTypeCsvCheck: boolean;
  convertedObj: any = '';
  @ViewChild('fileUploadForm') fileUploadForm: any;
  validRecordsList: any = [];
  uploadResponse: any;
  person_id: any;
  errorMsg: any;
  maxLimit: any;
  xmRespData: any = [];
  respData: any = [];
  expand: boolean = false;
  mandateCols: any;
  // expandData: any = [];
  respmandateCols: any = [];
  respmandatoryCols: any = [];
  respTemplateCols: any = [];
  mandatoryColumnData: any = [];
  templateColumnData: any = [];
  messageForUpload: any;
  messageForUpload2: any;
  callApi: boolean = false;
  currentlyOpenedItemIndex = -1;
  storeTemplate: any;

  constructor(
    public dialogRef: MatDialogRef<ExcelorderuploadComponent>,
    private eventService: EventService, private constants: ConstantData,
    private commonWebService: CommonWebService, @Inject(MAT_DIALOG_DATA) public data: any, private templateManagementService: TemplateManagementService,
    private reportService: ReportsService,public datepipe: DatePipe,
  ) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.checkLimit();
    //if (this.functionId == '51') {
      if (this.functionId == '136') {
      this.getLov();
      this.getDynamicData();
    }
    // else if (this.functionId == '64' || this.functionId == '99') {
      else if (this.functionId == '64' || this.functionId == '143') {
      this.getTemplates();
    } 
    //else if (this.functionId != '64' && this.functionId != '99' && this.functionId != '51') {
      else if (this.functionId != '64' && this.functionId != '143' && this.functionId != '136') {
      this.getDynamicData();
    }
    
  }

  getTemplates() {
    this.temploader = true;
    let request = {
      ReportId: 60162,
      ParametersInput: [
        {
          Name: "USER_PROFILE",
          Value: this.userRole
        }
      ]
    };
    this.reportService.onGetDynamicReport(request).subscribe(resp => {
      if (resp.ROW != undefined) {
        this.temploader = false;
        this.xmRespData = resp.ROW || [];
        this.xmRespData.forEach(x => {
          x.isExpand = false;
        });
      } else {
        this.temploader = false;
      }
    }, (error) => { this.temploader = false; })
  }

  lovList: any = [];
  getLov(data?) {
    let request;
    //if (this.functionId == '51') {
      if (this.functionId == '136') {
      request = {
        ReportId: 10138,
        ParametersInput: [
          { Name: "REQUESTOR_NAME", Value: this.userInfo.NTID }
        ]
      };
    } 
    // else if (this.functionId == '64' || this.functionId == '99') {
      else if (this.functionId == '64' || this.functionId == '143') {
      request = {
        ReportId: 60162,
        ParametersInput: [
          { Name: "TEMPLATE_NAME", Value: data.ATTRIBUTE1 }
        ]
      };
    }
    this.reportService.getReportDisplayFields(request).subscribe(response => {
      if (response.ReportDisplayFieldsOutput !== undefined) {
        for (let item of response.ReportDisplayFieldsOutput) {
          if (item.name == 'MAPPING') {
            let saveCartColumn = item.options;
            saveCartColumn.forEach(x => {
              if (x.text !== undefined) {
                this.lovList.push({ key: x.text, mappingname: x.value })
              }
            });
          }
        }
      }
    }, error => {
      this.loader = false;
    })
  }

  expandCard(data) {
    // this.expandData = data;
    // console.log("data",this.expandData)
    // data.isExpand = !data.isExpand;
    data.isExpand = true;
    this.getLov(data)
    this.storeTemplate = data.ATTRIBUTE1;
    this.mandateCols = true;
    let request = {
      ReportId: 60162,
      ParametersInput: [
        { Name: "USER_PROFILE", Value: this.userRole },
        { Name: "TEMPLATE_NAME", Value: this.storeTemplate }
      ]
    };
    this.reportService.onGetDynamicReport(request).subscribe(resp => {
      if (resp.ROW != undefined) {
        this.mandateCols = false;
        let responsRow = resp.ROW || [];
        this.maxLimit = resp.ROW[0].ATTRIBUTE7;
        this.respTemplateCols = this.OrganizedCart(responsRow, 'ATTRIBUTE4');
        this.respmandatoryCols = this.OrganizedCart(responsRow, 'ATTRIBUTE3');
        this.respmandateCols = resp.ROW[0].LATTRIBUTE1 || [];
      } else {
        this.mandateCols = false;
      }
    }, (error) => { this.mandateCols = false; })
  }

  setOpened(itemIndex) {
    this.currentlyOpenedItemIndex = itemIndex;
  }

  setClosed(itemIndex) {
    if (this.currentlyOpenedItemIndex === itemIndex) {
      this.currentlyOpenedItemIndex = -1;
    }
  }

  getDynamicData() {
    this.temploader = true;
    let object = {
      ReportId: this.constants.bulkUploadColumnMap[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportService.onGetDynamicReport(object).subscribe(response => {
      if (response.ROW != undefined) {
        this.respData = response.ROW || [];
        this.respmandateCols = response.ROW[0].MESSAGE_FOR_UPLOAD || [];
        this.mandatoryColumnData = this.OrganizedCart(this.respData, 'MANDATORY_COLUMNS');
        this.templateColumnData = this.OrganizedCart(this.respData, 'TEMPLATE_COLUMNS');
        this.temploader = false;
      } else {
        this.temploader = false;
      }

    }, error => {
      this.temploader = false;
    });
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
    }
    return col;
  }

  OrganizedCart(resp, col) {
    let display_column = [];
    if (resp[0][col] !== undefined) {
      display_column = this.convertToArray(resp[0][col]);
    }

    return display_column
  }

  resetUpload() {
    // this.fileUploadForm.reset();
  }

  reset() {
    // this.fileUploadForm.reset();
    this.dialogRef.close(true);
  }

  selectedCsvFile(e) {
    if (e.length == 0) {
      this.fileTypeCsvCheck = true;
    } else {
      this.files = e;
      this.fileInput = e[0];
      this.fileName = e[0].name;
    }
  }

  convertFile(ev) {
   // this.accept = 
    this.eventService.showSpinner();
    if (this.fileInput === undefined) {
      return;
    }
    let allowExtention = /(\.csv)$/i;
    let allowxlsxExtention = /(\.xlsx)$/i;
    if (!allowExtention.exec(this.fileName) && !allowxlsxExtention.exec(this.fileName)) {
      return;
    } else if (allowExtention.exec(this.fileName)) {
      let reader = new FileReader();
      reader.readAsText(this.fileInput);
      reader.onload = () => {
        let text = reader.result;
        this.csvJSON(text);
      };
    } else if (allowxlsxExtention.exec(this.fileName)) {
      let file = this.fileInput
      let workBook = null;
      let jsonData = null;
      let sheetName = null;
      const reader = new FileReader();
      reader.onload = (event) => {
        const data = reader.result;
        workBook = XLSX.read(data, { type: 'binary',cellText:false,cellDates: true});
        jsonData = workBook.SheetNames.reduce((initial, name) => {
          const sheet = workBook.Sheets[name];
  
          let cell = sheet['A1'].v;
          if(cell.includes("Mandatory Columns")) {
            this.delete_row(sheet, 0);
            var range = XLSX.utils.decode_range(sheet['!ref']); //<-- start "select"
            range.s.r = 1; // <-- start row
            // range.e.r = 12; // <-- end row
            sheet['!ref'] = XLSX.utils.encode_range(range); //<-- end "select"
          }
  
          initial[name] = XLSX.utils.sheet_to_json(sheet,{raw:false,dateNF:'mm/dd/yyyy'});
          sheetName = initial[name]
          return initial;
        }, {});
        this.changeFields(sheetName)
      }
      reader.readAsBinaryString(file); 
    }

    
  }

  ec(r, c){
    return XLSX.utils.encode_cell({r:r,c:c});
  }
  delete_row(ws, row_index){
    var variable = XLSX.utils.decode_range(ws["!ref"])
      for(var R = row_index; R < variable.e.r; ++R){
        for(var C = variable.s.c; C <= variable.e.c; ++C){
          ws[this.ec(R,C)] = ws[this.ec(R+1,C)];
        }
      }
      variable.e.r--
      ws['!ref'] = XLSX.utils.encode_range(variable.s, variable.e);
  }

  updatedData: any = []
  changeFields(jsonData) {
    this.updatedData = this.updateFieldsName(jsonData);
    if(this.respmandatoryCols.includes("QTY")){
      const index = this.respmandatoryCols.indexOf("QTY");
      if (index > -1) {
        this.respmandatoryCols.splice(index, 1);
      }
      this.respmandatoryCols.push("quantity");
    }
    let dataKeys = Object.keys(this.updatedData[0]);
    let arr1 = dataKeys;
    let arr2 = this.respmandatoryCols != undefined ? this.respmandatoryCols : [];
    let arr3 = arr2.filter(x => arr1.includes(x))
    // if (this.functionId == '64' || this.functionId == '99') {
      if (this.functionId == '64' || this.functionId == '143') {
      if (arr2.sort().join(',') === arr3.sort().join(',')) {
        this.callApi = true
      } else {
        this.callApi = false
      }
    } else {
      this.callApi = true
    }
    if (this.callApi == true) {
      if (this.updatedData.length <= this.maxLimit) {
        let csvObj = {
          data: this.updatedData === undefined ? [] : this.updatedData,
          action: "CREATE",
          batchNumber: null,
          requestorName: this.userInfo.NTID ? this.userInfo.NTID : '',
          attribute1: this.fileName,
          attribute2: this.storeTemplate ? this.storeTemplate : '',
          attribute3: '',
          attribute4: this.userRole,
          attribute5: '',
          attribute6: '',
          attribute7: '',
          attribute8: '',
          attribute9: '',
          attribute10: '',
        };
      this.uploadData(csvObj);
    } else {
      this.eventService.hideSpinner();
      this.dialogRef.close({ event: this.uploadResponse });
      // this.fileUploadForm.reset();
      this.loader = false;
      this.commonWebService.openSnackBar(this.errorMsg, 'ERROR');
    }
    }else {
      this.eventService.hideSpinner();
      this.dialogRef.close({ event: this.uploadResponse });
      // this.fileUploadForm.reset();
      this.loader = false;
      this.commonWebService.openSnackBar('Please upload the correct template with ' + arr2.sort().join(',') + ' and try again.', 'ERROR');
    }
  }

  uploadData(csvObj) {
    this.loader = true;
    this.templateManagementService.uploadBulkOrder(csvObj).subscribe(
      (response) => {
        this.eventService.hideSpinner();
        if (response != undefined && response != null) {
          this.uploadResponse = response.status;
          if (response.status === 'SUCCESS') {
            this.commonWebService.openSnackBar(response.message, 'SUCCESS');
          } else if (response.status === 'ERROR') {
            this.commonWebService.openSnackBar(response.message, 'ERROR');
          } else
            this.commonWebService.openSnackBar(response.message, 'WARNING');
          this.dialogRef.close({ event: this.uploadResponse });
          // this.fileUploadForm.reset();
        } else {
          this.eventService.hideSpinner();
          this.dialogRef.close({ event: this.uploadResponse });
          // this.fileUploadForm.reset();
          this.loader = false;
          this.commonWebService.openSnackBar(
            'Experiencing timeout issue, please reach out the Support Team',
            'ERROR'
          );
        }
      },
      (error) => {
        this.eventService.hideSpinner();
        this.dialogRef.close({ event: this.uploadResponse });
        // this.fileUploadForm.reset();
        this.loader = false;
        let filteredData = this.updatedData.filter(val => (val.GROUP_ID != undefined && val.GROUP_ID != null) ? !val.GROUP_ID.match("^[0-9]*$") : '');
        if (filteredData.length > 0) {
          this.commonWebService.openSnackBar(
            'Please correct the template and try again. If you face any issues please reach out to the Support Team',
            'ERROR'
          );
        } else {
          this.commonWebService.openSnackBar(
            'Experiencing timeout issue, please reach out the Support Team',
            'ERROR'
          );
        }
      }
    );
  }

  checkLimit() {
    let request1 = {
      ReportId: this.constants.bulkUploadTemplate[this.functionId],
      ParametersInput: [
        {
          Name: 'P_PROCESS',
          Value: 'BULK_UPLOAD',
        },
      ],
    };
    this.reportService.onGetDynamicReport(request1).subscribe(response => {
      if (response.ROW != undefined) {
        //if(this.functionId == '51'){
          // if(this.functionId == '136'){
          this.maxLimit = response.ROW[0].MAX_LIMIT;
        // }
        this.errorMsg = response.ROW[0].UI_MESSAGE;
      }
    })
  }
  csvJSON(csv) {
    let data;
    let result = [];
    if (csv != '\r\n') {
      // to handle empty csv file
      var p = '',
        row = [''],
        ret = [row],
        n = 0,
        r = 0,
        s = !0,
        l;
      for (var x = 0; x <= csv.length; x++) {
        l = csv.charAt(x);
        if ('"' === l) {
          if (s && l === p) row[n] += l;
          s = !s;
        } else if (',' === l && s) l = row[++n] = '';
        else if ('\n' === l && s) {
          if ('\r' === p) row[n] = row[n].slice(0, -1);
          row = ret[++r] = [(l = '')];
          n = 0;
        } else row[n] += l;
        p = l;
      }

      ret.forEach((arr) => {
        // removes MAndatory Columns row if present
        let del = false;
        if (arr[0].includes('Mandatory Columns:')) {
          del = true;
        }
        if (del == true) ret.splice(ret.indexOf(arr), 1);
      });

      ret.forEach((arr) => {
        // removes empty row if any
        let count = 0;
        for (let z = 0; z < arr.length; z++) {
          if (arr[z] == '') {
            count++;
          }
        }
        if (count == arr.length) ret.splice(ret.indexOf(arr), 1);
      });

      let length = ret[0].length;
      ret.forEach((arr) => {
        if (length == arr.length) {
          for (let j = 0; j < arr.length; j++) {
            arr[j] = arr[j].replace('\t', '');
            if (arr[j] == 'null' || arr[j] == '') {
              arr[j] = null;
            }
            if ((arr[j] == 'null' || arr[j] == '') && arr[j].includes('\t')) {
              let dt = arr[j].replace('\t', '');
              arr[j] = dt;
            }
          }
        } else {
          // handling extra empty row from excel
          ret.splice(ret.indexOf(arr), 1);
        }
      });
      // let result = [];
      for (let i = 1; i < ret.length; i++) {
        let obj = {};
        for (let j = 0; j < ret[0].length; j++) {
          obj[ret[0][j]] = ret[i][j];
        }
        result.push(obj);
      }
      data = this.updateFieldsName(result);
    }
    // this.changeFields(result)
    let dataKeys = Object.keys(data[0]);
    let arr1 = dataKeys;
    let arr2 = this.respmandatoryCols != undefined ? this.respmandatoryCols : [];
    let arr3 = arr2.filter(x => arr1.includes(x))
    // if (this.functionId == '64' || this.functionId == '99') {
      if (this.functionId == '64' || this.functionId == '143') {
      if (arr2.sort().join(',') === arr3.sort().join(',')) {
        this.callApi = true
      } else {
        this.callApi = false
      }
    } else {
      this.callApi = true
    }
    if (this.callApi == true) {
      if (data.length <= this.maxLimit) {
        let csvObj = {
          data: data === undefined ? [] : data,
          action: "CREATE",
          batchNumber: null,
          requestorName: this.userInfo.NTID ? this.userInfo.NTID : '',
          attribute1: this.fileName,
          attribute2: this.storeTemplate ? this.storeTemplate : '',
          attribute3: '',
          attribute4: this.userRole,
          attribute5: '',
          attribute6: '',
          attribute7: '',
          attribute8: '',
          attribute9: '',
          attribute10: '',
        };

        this.loader = true;
        this.templateManagementService.uploadBulkOrder(csvObj).subscribe(
          (response) => {
            this.eventService.hideSpinner();
            if (response != undefined && response != null) {
              this.uploadResponse = response.status;
              if (response.status === 'SUCCESS') {
                this.commonWebService.openSnackBar(response.message, 'SUCCESS');
              } else if (response.status === 'ERROR') {
                this.commonWebService.openSnackBar(response.message, 'ERROR');
              } else
                this.commonWebService.openSnackBar(response.message, 'WARNING');
              this.dialogRef.close({ event: this.uploadResponse });
              // this.fileUploadForm.reset();
            } else {
              this.eventService.hideSpinner();
              this.dialogRef.close({ event: this.uploadResponse });
              // this.fileUploadForm.reset();
              this.loader = false;
              this.commonWebService.openSnackBar(
                'Experiencing timeout issue, please reach out the Support Team',
                'ERROR'
              );
            }
          },
          (error) => {
            this.eventService.hideSpinner();
            this.dialogRef.close({ event: this.uploadResponse });
            // this.fileUploadForm.reset();
            this.loader = false;
            let filteredData = data.filter(val => (val.GROUP_ID != undefined && val.GROUP_ID != null) ? !val.GROUP_ID.match("^[0-9]*$") : '');
            if (filteredData.length > 0) {
              this.commonWebService.openSnackBar(
                'Please correct the template and try again. If you face any issues please reach out to the Support Team',
                'ERROR'
              );
            } else {
              this.commonWebService.openSnackBar(
                'Experiencing timeout issue, please reach out the Support Team',
                'ERROR'
              );
            }
          }
        );
      } 
      else {
        this.eventService.hideSpinner();
        this.dialogRef.close({ event: this.uploadResponse });
        // this.fileUploadForm.reset();
        this.loader = false;
        this.commonWebService.openSnackBar(this.errorMsg, 'ERROR');
      }
    } 
    else {
      this.eventService.hideSpinner();
      this.dialogRef.close({ event: this.uploadResponse });
      // this.fileUploadForm.reset();
      this.loader = false;
      this.commonWebService.openSnackBar('Please upload the correct template with ' + arr2.sort().join(',') + ' and try again.', 'ERROR');
    }
  }

  updateFieldsName(data) {
    this.lovList.forEach(element => {
      data.forEach((obj) => {
        this.addKey(obj, element.key, element.mappingname);
      });
    });
    return data;
  }

  addKey(obj, oldKey, newKey) {
    obj[newKey] = obj[oldKey];
  }

  onError(err) {
    this.convertedObj = err;
    this.fileTypeCsvCheck = true;
  }
}
