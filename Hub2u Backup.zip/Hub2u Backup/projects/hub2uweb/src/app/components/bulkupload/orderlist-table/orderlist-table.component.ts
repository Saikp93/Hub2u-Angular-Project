import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-orderlist-table',
  templateUrl: './orderlist-table.component.html',
  styleUrls: ['./orderlist-table.component.scss'],
})
export class OrderlistTableComponent implements OnInit {
  
  @Input() orderDataList : any;
  @Input() columnMapping: any
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @Output() reloadTable : EventEmitter<any> = new EventEmitter();

  dataSource : MatTableDataSource<any>;
  displayedColumns: string[] = [];
  selection: any;
  headers: string[] = [];
  functionId: string;
  userInfo: any;
  previousIndex: number;

  constructor() { }

  ngOnInit() {
    this.onInitialLoad();
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.dataSource = new MatTableDataSource<any>(this.orderDataList);
  }  

  ngAfterViewInit() {
    this.call();
  }

  call() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.dataSource.filterPredicate = this.createFilter();
  }

  ngOnChanges(){
    setTimeout(()=>{
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    },1500)
  }

  onInitialLoad() {
    let allCols = [];
    let visibleCols = [];
    this.orderDataList.forEach(data => {
      for (const key in data) {
        if(this.orderDataList.indexOf(data) == 0 ) {
          visibleCols = data['DISPLAY_COLUMNS'].split(',');
          allCols.push(`${key}`);
        }
      }
    })
    let displayCols = visibleCols;
    displayCols.forEach(col => {
      if(col != '@num') {
        this.displayedColumns.push(col);
        let word = this.refactorCols(col);
        this.headers.push(word);
      }
    })
  }

  refactorCols(col) {
    let r = [];
    r = col.replace(/_/g, ' ');
    let word = "";
    for(let j of r) {
      word = word + j;
    }
    return word;
  }

  expandLine: any[] = [];
  expandSerial: any[] = [];
  filterValues = {};
  getValue(column, event) {
    for(let i=0; i<this.orderDataList.length ; i++) {   // for closing all the expanded rows
      this.expandLine[i] = false;
      this.expandSerial[i] = false;
    }
    this.filterValues[column] = event.target.value;
    this.dataSource.filter = JSON.stringify(this.filterValues);
    this.reloadTable.emit(this.dataSource.filteredData);
  }

  createFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data, filter): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      for (const [key, value] of Object.entries(searchTerms)) {
        if(`${value}` !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[`${key}`];
        }
      }

      let len = Object.keys(searchTerms).length;
      let searchArray = [];

      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            let word = searchTerms[col].trim().toLowerCase()
              if (data[col] !== null) {
                if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                  searchArray.push(true);
                  found = len === searchArray.length;
                }
              }
          }
          return found;
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction;
  }

}
