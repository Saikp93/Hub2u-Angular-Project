import { SelectionModel } from '@angular/cdk/collections';
import { Component, EventEmitter, Input, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { HomeService, ReportsService, TemplateManagementService } from 'hub2ushared';
import { ConstantData } from 'projects/hub2ushared/src/public-api';
import { CommonWebService } from '../../../shared/common-web.service';
import { LoadCartService } from '../../../shared/loadcart.service';
import { TableUtil } from '../../../shared/tableUtils';

@Component({
  selector: 'app-inprogress-table',
  templateUrl: './inprogress-table.component.html',
  styleUrls: ['./inprogress-table.component.scss'],
})
export class InprogressTableComponent implements OnInit {

  @Input() columnMapping: any;
  @Input() countMsg: any;
  @Input() pageSize: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('confirmDeletion') confirmDeletion: TemplateRef<any>;
  @Output() submitEvent: EventEmitter<any> = new EventEmitter();
  @Output() countEvent: EventEmitter<any> = new EventEmitter();
  @Output() reloadCount : EventEmitter<any> = new EventEmitter();

  dataSource : MatTableDataSource<any>;
  displayedColumns: string[] = [];
  headers: string[] = [];
  selection: any;
  functionId: string;
  userInfo: any;
  userDetails: any = '{}';
  userRole: any = '';
  inprogressRecordsList: any = [];
  userName: any;
  nodata: boolean = false;
  loader:boolean = false;
  reloadTable: boolean = false;
  pageName = "Hub2u_BulkUpload";
  person_id: any;
  tableData: any;
  inProgressCountMsg: any;
  pageSizeOptions :any;
  pageEvent;
  allCols = [];
  visibleCols = [];
  displayCols = [];
  inprogressRecsReq: any = null;

  constructor(private reportService: ReportsService, private constants: ConstantData,
    private templateManagementService: TemplateManagementService, private loadCartService: LoadCartService,
    public commonWebService: CommonWebService, public dialog: MatDialog) {
      this.inprogressRecsReq = this.loadCartService.getInProgressBulkCount().subscribe(count => {
        this.loader = true;
        if (count) {
          this.reloadTable = false;
          this.displayedColumns = [];
          this.getInprogressRecords();
        }
      })
     }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.fetchDynamicReports();
    // this.getInprogressRecords();
    this.pageSizeOptions = this.pageSize;
    // this.getInProgressRecordsCount();
    this.userName = this.userInfo.NTID;
    this.dataSource = new MatTableDataSource<any>(this.inprogressRecordsList);
    this.selection = new SelectionModel<any>(true, []);
    // this.countMsg.forEach(x => {
    //   if (x.key !== undefined && x.key == 'New') {
    //     this.inProgressCountMsg = x.mappingvalue
    //   }
    // });
  }

  ngOnChanges(){
    this.reloadCount.emit(true);
    setTimeout(()=>{
      this.countMsg.forEach(x => {
        if (x.key !== undefined && x.key == 'New') {
          this.inProgressCountMsg = x.mappingvalue
        }
      });
    },1000)
    setTimeout(()=>{
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    },1500)
  }

  public handlePage(e: any) {
    this.pageSize = e.pageSize;
    this.reloadTable = true;
    this.getInprogressRecords();
  }

  fetchDynamicReports() {
    let request = {
      //ReportId: 112,
      //ReportId: 7001,
      ReportId:this.constants.userprofileData[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }]
    };

    this.reportService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW !== undefined) {
        this.person_id = response.ROW[0].PERSON_ID
      }
    })
  }

  getInprogressRecords(){
    this.loader = true;
    setTimeout(()=>{
      this.countMsg.forEach(x => {
        if (x.key !== undefined && x.key == 'New') {
          this.inProgressCountMsg = x.mappingvalue
        }
      });
    },1000)
    let request1 = {
      ReportId: this.constants.bulkUploadRecords[this.functionId],
      ParametersInput: [
        { Name: 'REQUESTOR_NAME', Value: this.userInfo.NTID },
        { Name: 'P_RECORD_STATUS', Value: 'New' },
        { Name: 'RECORD_COUNT', Value: this.pageSize},
        // { Name: 'P_ERROR_TYPE', Value: ''}
      ],
    };
    this.reportService.onGetDynamicReport(request1).subscribe(response => { //getReportDisplayFields
      if(response.ROW != undefined){
        this.nodata = false;
        this.loader = false;
        this.inprogressRecordsList = response.ROW;
        this.dataSource = new MatTableDataSource<any>(this.inprogressRecordsList);
        this.tableData = this.dataSource;
        setTimeout(()=>{
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },1500)
        if(this.reloadTable == false){
          this.onInitialLoad();
        }
      }else {
        this.loader = false;
        this.nodata = true;
      }
    }, error => {
      this.loader = false;
      this.nodata = true;
    })
  }

  onInitialLoad() {
    this.allCols = [];
    this.visibleCols = [];
    this.displayedColumns = [];
    this.inprogressRecordsList.forEach(data => {
      for (const key in data) {
        if(this.inprogressRecordsList.indexOf(data) == 0 ) {
          this.visibleCols = data['DISPLAY_COLUMNS'].split(',');
          this.allCols.push(`${key}`);
        }
      }
    })
    this.displayCols = this.visibleCols;
    this.displayCols.forEach(col => {
      if(col != '@num') {
        this.displayedColumns.push(col);
        let word = this.refactorCols(col);
        this.headers.push(word);
      }
    })
    this.displayedColumns.push('action');
    this.headers.push('ACTION');
  }

  refactorCols(col) {
    let r = [];
    r = col.replace(/_/g, ' ');
    let word = "";
    for(let j of r) {
      word = word + j;
    }
    return word;
  }

  updateFieldsName(data) {
    this.columnMapping.forEach(element => {
      data.forEach(obj => {
        this.addKey(obj, element.key, element.mappingname);
      });
    })
    return data;
  }

  addKey(obj, oldKey, newKey) {
    obj[newKey] = obj[oldKey];
  }

  onDelete(item) {
    let array = [];
    // item['REQUESTOR_NAME'] = this.userInfo.NTID ? this.userInfo.NTID : '';
    array.push(item);
    let data = this.updateFieldsName(array);
    let csvObj = {
      data: data === undefined ? [] : data,
      action: 'DELETE',
      batchNumber: item.BATCH_ID,
      attribute1: '',
      attribute2: '',
      attribute3: '',
      attribute4: this.userRole,
      attribute5: '',
      attribute6: '',
      attribute7: '',
      attribute8: '',
      attribute9: '',
      attribute10: '',
    };

    this.loader = true;
    this.saveAPIRequest(csvObj);
  }

  saveAPIRequest(request) {
    this.templateManagementService.uploadBulkOrder(request).subscribe(
      (response) => {
        this.loader = false;
        if (response.status == 'SUCCESS') {
          this.selection.clear();
          this.loadCartService.sendBulkCount(true);
          this.commonWebService.openSnackBar(response.message, 'SUCCESS');
        } else {
          this.commonWebService.openSnackBar(response.message, 'WARNING');
        }
        this.reloadTable = true;
        this.getInprogressRecords();
      },
      (error) => {
        this.loader = false;
        this.commonWebService.openSnackBar(
          'There was some problem updating the records',
          'ERROR'
        );
      }
    );
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }
    this.selection.select(...this.dataSource.data);
  }

  checkboxLabel(row?): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  }

  deleteAllRowsWarning() {
    let dialogRef1 = this.dialog.open(this.confirmDeletion);
  }

  deleteAllRows() {
    this.commonDeleteFunc(this.inprogressRecordsList);
  }

  deleteSelectedRows() {
    let rows = this.selection.selected;
    if(rows.len == this.inprogressRecordsList.length) {
      this.commonDeleteFunc(this.inprogressRecordsList);
    }
    else {
      this.commonDeleteFunc(rows);
    }
  }

  commonDeleteFunc(rows) {
    this.loader = true;
    let array = [];
    rows.forEach(item => {
      array.push(item);
    })
    let data = this.updateFieldsName(array)
    let request = {
      data: data === undefined ? [] : data,
      action: 'DELETE',
      requestorName: this.userInfo.NTID ? this.userInfo.NTID : '',
      batchNumber: rows.BATCH_ID,
      attribute1: '',
      attribute2: '',
      attribute3: '',
      attribute4: this.userRole,
      attribute5: '',
      attribute6: '',
      attribute7: '',
      attribute8: '',
      attribute9: '',
      attribute10: '',
    }
    this.saveAPIRequest(request);
  }

  ngOnDestroy(){
    this.inprogressRecsReq.unsubscribe();
  }

}
