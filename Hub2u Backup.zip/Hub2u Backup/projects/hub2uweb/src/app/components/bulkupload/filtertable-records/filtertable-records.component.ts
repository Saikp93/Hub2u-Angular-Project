import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-filtertable-records',
  templateUrl: './filtertable-records.component.html',
  styleUrls: ['./filtertable-records.component.scss'],
})
export class FiltertableRecordsComponent implements OnInit {

  @Input() tableData: any;
  @Input() clearField: boolean;
  batchId: any;
  fileName: any;
  constructor() { }

  ngOnInit() { }

  setupFilter(column: string) {
    this.tableData.filterPredicate = (d, filter: string) => {
      const textToSearch = (typeof(d[column])) == 'number' ? d[column].toString() : d[column] && d[column].toLowerCase() || '';
      return textToSearch.indexOf(filter) !== -1;
    };
  }
  
  applyFilter(filterValue) {
    this.tableData.filter = filterValue.target.value.trim().toLowerCase();
  }

  childMethod() {
    this.batchId = '';
    this.fileName = '';
  }

}
