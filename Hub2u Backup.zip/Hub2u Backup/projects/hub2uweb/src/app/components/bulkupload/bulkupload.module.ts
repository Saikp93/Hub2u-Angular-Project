import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatListModule } from '@angular/material/list';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { Hub2usharedModule } from 'hub2ushared';
import { MatToolbarModule } from '@angular/material/toolbar';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatTabsModule } from '@angular/material/tabs';
import { MatRadioModule } from '@angular/material/radio';
import { BulkuploadComponent } from './bulkupload.component';
import { UploaddataComponent } from './uploaddata/uploaddata.component';
import { ExcelorderuploadComponent } from './excelorderupload/excelorderupload.component';
import { OrderlistdataComponent } from './orderlistdata/orderlistdata.component';
import { OrderfileuploadComponent } from '../orderfileupload/orderfileupload.component';
import { FileUploadModule } from '../fileupload/fileupload.module';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { OrderlistTableComponent } from './orderlist-table/orderlist-table.component';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {MatMenuModule} from '@angular/material/menu';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import {DragDropModule} from '@angular/cdk/drag-drop';
import {ScrollingModule} from '@angular/cdk/scrolling';
import {CdkTableModule} from '@angular/cdk/table';
import {CdkTreeModule} from '@angular/cdk/tree';
import {A11yModule} from '@angular/cdk/a11y';
import { ValidrecordsTableComponent } from './validrecords-table/validrecords-table.component';
import { MatSelectModule } from '@angular/material/select';
import { InvalidrecordsTableComponent } from './invalidrecords-table/invalidrecords-table.component';
import { FiltertableRecordsComponent } from './filtertable-records/filtertable-records.component';
import { InprogressTableComponent } from './inprogress-table/inprogress-table.component';
import { MultiplefileuploadComponent } from '../multiplefileupload/multiplefileupload.component';
import { FileDragNDropDirective } from 'projects/hub2ushared/src/lib/directives/file-drag-ndrop.directive';
import { MatChipsModule } from '@angular/material/chips'; 

const routes: Routes = [
  {
    path: '', component: BulkuploadComponent,
    children: [
      { path: 'orderlist', component: OrderlistdataComponent },
      { path: 'uploaddata', component: UploaddataComponent }
    ]
  }
];

@NgModule({
  declarations: [BulkuploadComponent,OrderlistdataComponent,UploaddataComponent,
    ExcelorderuploadComponent,OrderfileuploadComponent, MultiplefileuploadComponent, OrderlistTableComponent,
    ValidrecordsTableComponent,InvalidrecordsTableComponent,FiltertableRecordsComponent,InprogressTableComponent,FileDragNDropDirective],
  // exports: [ApprovalsdetailsComponent],
//   entryComponents: [CheckStatusComponent],
  imports: [
    MatButtonModule,
    NgxSpinnerModule,
    MatCardModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatTooltipModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatListModule,
    MatTabsModule,
    MatRadioModule,
    MatSnackBarModule,
    MatDialogModule,
    MatDatepickerModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatSelectModule,
    MatCheckboxModule,
    MatMenuModule,
    MatExpansionModule,
    FormsModule, ReactiveFormsModule,
    NgbModule,
    Hub2usharedModule,
    MatToolbarModule,
    FileUploadModule,
    MatChipsModule,
    CommonModule, RouterModule.forChild(routes),
    DragDropModule,
    ScrollingModule,
    CdkTableModule,
    CdkTreeModule,
    A11yModule,
    // NgCircleProgressModule.forRoot({
    //   // set defaults here
    //   radius: 100,
    //   outerStrokeWidth: 16,
    //   innerStrokeWidth: 8,
    //   outerStrokeColor: "#78C000",
    //   innerStrokeColor: "#C7E596",
    //   animationDuration: 300
    // }),
  ]
})
export class BulkuploadModule { }