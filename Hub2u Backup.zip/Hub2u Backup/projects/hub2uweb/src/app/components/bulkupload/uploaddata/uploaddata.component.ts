import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ReportsService } from 'hub2ushared';
import { ConstantData } from 'projects/hub2ushared/src/public-api';
import { TableUtil } from '../../../shared/tableUtils';
import { ExcelorderuploadComponent } from '../excelorderupload/excelorderupload.component';

@Component({
  selector: 'app-uploaddata',
  templateUrl: './uploaddata.component.html',
  styleUrls: ['./uploaddata.component.scss'],
})
export class UploaddataComponent implements OnInit {

  functionId = '';
  userInfo: any = {};
  userRole: any = '';
  loader: boolean = false;
  mandatoryColumns: any;
  headers: any = [];
  mandatoryColumnsforExcel: any = [];
  pageName;
  viewData: any[];
  mandatoryColumnData = [];
  templateColumnData = [];
  // columnMapping = [];
  @Input() columnMapping: any
  @Output() uploadEvent: EventEmitter<any> = new EventEmitter();
  messageForUpload: any;
  messageForUpload2: any;

  constructor(private reportService: ReportsService, private tableUtil: TableUtil, public dialog: MatDialog,
    private constants: ConstantData,) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.getDynamicData();
  }

  getDynamicData() {
    this.loader = true;
    let object = {
      ReportId: this.constants.bulkUploadColumnMap[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportService.onGetDynamicReport(object).subscribe(response => {
      if (response.ROW != undefined) {
        this.viewData = response.ROW || [];
        this.messageForUpload = response.ROW[0].MESSAGE_FOR_UPLOAD.split('\n')[1];
        this.messageForUpload2 = response.ROW[0].MESSAGE_FOR_UPLOAD.split('\n')[2] != undefined ? response.ROW[0].MESSAGE_FOR_UPLOAD.split('\n')[2] : ''
        this.mandatoryColumnData = this.OrganizedCart(this.viewData, 'MANDATORY_COLUMNS');
        this.templateColumnData = this.OrganizedCart(this.viewData, 'TEMPLATE_COLUMNS');
        this.loader = false;
      } else {
        this.loader = false;
      }

    }, error => {
    });
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
    }
    return col;
  }

  OrganizedCart(resp, col) {
    let display_column = [];
    if (resp[0][col] !== undefined) {
      display_column = this.convertToArray(resp[0][col]);
    }

    return display_column
  }

  getPageName() {
    let today = new Date();
    let y = today.getFullYear();
    let m = today.getMonth() + 1;
    let d = today.getDate();
    let h = today.getHours();
    let mi = today.getMinutes();
    let s = today.getSeconds();
    let currentdate = y + "-" + m + "-" + d + "-" + h + "-" + mi + "-" + s;
    this.pageName = 'Hub2u_Order_' + currentdate
  }

  downloadTemplate(action) {
    this.getPageName();
    let headers;
    headers = this.templateColumnData;
    let cols = this.mandatoryColumnData.toString()
    let newCol = cols.replace(/,/g, ' - ');
    this.tableUtil.exportToCsvWithEmptyHeaders("", this.pageName, headers, "BulkUpload", newCol);
  }

  mappingnames: any = [];
  modelShow() {
    let dialogRef = this.dialog.open(ExcelorderuploadComponent, {
      width: '500px',
      data: {
        columnMapping: this.columnMapping
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.uploadEvent.emit(result);
    })
  }

}
