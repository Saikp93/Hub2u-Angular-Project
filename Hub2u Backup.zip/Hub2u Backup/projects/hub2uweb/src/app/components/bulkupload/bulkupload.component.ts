import { DecimalPipe } from '@angular/common';
import { Component, EventEmitter, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ReportsService } from 'hub2ushared';
import { ConstantData } from 'projects/hub2ushared/src/public-api';
import { Observable, of } from 'rxjs';
import { CommonWebService } from '../../shared/common-web.service';
import { LoadCartService } from '../../shared/loadcart.service';
import { TableUtil } from '../../shared/tableUtils';
import { ExcelorderuploadComponent } from './excelorderupload/excelorderupload.component';

@Component({
  selector: 'app-bulkupload',
  templateUrl: './bulkupload.component.html',
  styleUrls: ['./bulkupload.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers:[DecimalPipe]
})
export class BulkuploadComponent implements OnInit {
  userInfo: any;
  userRole: any;
  functionId: any;
  selectedTab: number;
  selectedRadio = '';
  reportId: any;
  ntId: any;
  dynamicReq: any;
  aprrovalsResponse: any = [];
  pendingApprovalData = [];
  nodata: boolean = false;
  loadSpinner: boolean = false;
  refreshSpinner: boolean = false;
  showTable: boolean = false;
  validData: boolean = false;
  invalidData: boolean = false;
  inprogressData: boolean = false;
  uploadExcel: any;
  options: string[] = ['ORDER LIST', 'UPLOAD ORDER DATA'];
  previewList = [{ name: 'VALID RECORDS', count: 0, status: 'Valid', message: '', pageSize: '', loadingPercent: 0 },
  { name: 'INVALID RECORDS', count: 0, status: 'Invalid', message: '', pageSize: '', loadingPercent: 0 },
  { name: 'VALIDATION IN-PROGRESS', count: 0, status: 'New', message: '', pageSize: '', loadingPercent: 0 }];
  validRecordsList: any = [];
  selectedBtn: any;
  columnMapping = [];
  showSearchData: boolean = false;
  recordsCount: any;
  recordVal: any;
  countMsg = [];
  reloadData: boolean = false;
  pageSize: any;
  pageName;
  viewData: any[];
  mandatoryColumnData = [];
  templateColumnData = [];
  loader: boolean = false;
  messageForUpload: any;
  messageForUpload2: any;
  @Output() uploadEvent: EventEmitter<any> = new EventEmitter();
  isHidden = false;
  selectedItem;
  selected = false;
  xmRespData: any = [];
  // selectedTemplate: any = 'Pullback/Rebalance';
  selectedTemplate: any = '';
  progress = 0;
  circlerefreshSpinner: boolean = false;

  constructor(private router: Router,private decimalPipe:DecimalPipe,
    private loadCartService: LoadCartService,
    private reportService: ReportsService, private commonWebService: CommonWebService,
    private constants: ConstantData, private tableUtil: TableUtil, public dialog: MatDialog,) {
    this.loadCartService.getBulkCount().subscribe(isZero => {
      if (isZero) {
        setTimeout(() => {
          this.previewList.forEach(item => {
            item.loadingPercent = this.getLoadingPercentage(item.count, this.previewList.reduce((sum, item) => sum + item.count, 0))
          })
        }, 500);        
      }
    })
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.selectedRadio = 'ORDER LIST';
    this.showTable = true;
    this.columnsMapping();
    this.getRecordsCount();
    this.getDynamicData();
    this.getTemplates();
  }
  isStart = false;
  loadingInProgressNum = 1;
  res: Observable<null | string> = of(null);
  getLoadingPercentage(count, total) {
    if (total > 0) { 
      return Number.isNaN(this.decimalPipe.transform(((count / total) * 100),'1.0-0')) ? 0 : Number(this.decimalPipe.transform(((count / total) * 100),'1.0-0'));
    } else {
      return 0;
    }
  }
  columnsMapping() {
    let request = {
      ReportId: this.constants.bulkUploadColumnMap[this.functionId],
      ParametersInput: [
        {
          Name: "REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportService.getReportDisplayFields(request).subscribe(response => {
      for (let item of response.ReportDisplayFieldsOutput) {
        if (item.name == 'MAPPING') {
          let saveCartColumn = item.options;
          saveCartColumn.forEach(x => {
            if (x.text !== undefined) {
              this.columnMapping.push({ key: x.text, mappingname: x.value })
            }
          });
        }
      }
    });
  }

  tabChanged(event) {
    if (event.index == 0) {
      this.selectedRadio = 'ORDER LIST';
      // this.radioChange('ORDER LIST');
      this.showTable = true;
      this.validData = false;
      this.invalidData = false;
      this.inprogressData = false;
    }
    else if (event.index == 1) {
      this.selectedRadio = 'VALID RECORDS';
      // this.radioChange('VALID RECORDS');
      this.validData = true;
      this.showTable = false;
      this.invalidData = false;
      this.inprogressData = false;
      this.selectedBtn = this.selectedRadio;
      this.selectedItem = this.selectedRadio;
    }
    // this.invalidData = false;
  }

  uploadEventHandler(update: any) {
    this.uploadExcel = update;
    if (update != undefined) {
      if (update.event == 'SUCCESS') {
        this.selectedTab = 1;
        this.getRecordsCount();
        this.selectedItem = this.selectedItem;
        this.onCardClick({ name: this.selectedItem });
        this.reloadData = true;
        // this.validData = true;
        // this.showTable = false;
        // this.invalidData = false;
        // this.inprogressData = false;
        // this.selectedItem = 'VALID RECORDS';
      } else {
        this.reloadData = false;
      }
    }
  }

  getTemplates() {
    // this.temploader = true;
    let request = {
      ReportId: 60162,
      ParametersInput: [
        {
          Name: "USER_PROFILE",
          Value: this.userRole
        }
      ]
    };
    this.reportService.onGetDynamicReport(request).subscribe(resp => {
      if (resp.ROW != undefined) {
        // this.temploader = false;
        this.xmRespData = resp.ROW || [];
      } else {
        // this.temploader = false;
      }
    }, (error) => {
      // this.temploader = false;
    })
  }

  getRecordsCount(event?) {
    if (event != undefined && event.type == 'click') {
      this.circlerefreshSpinner = true;
    } else {
      this.refreshSpinner = true;
    }
    for (let x of this.previewList) {
      let request1 = {
        ReportId: this.constants.bulkUploadRecCount[this.functionId],
        ParametersInput: [
          { Name: 'REQUESTOR_NAME', Value: this.userInfo.NTID },
          { Name: 'P_RECORD_STATUS', Value: x.status },
        ],
      };
      this.reportService.onGetDynamicReport(request1).subscribe(response => { //getReportDisplayFields
        if (response.ROW != undefined) {
          // this.loader = false;
          this.circlerefreshSpinner = false;
          let inProgressCount = response.ROW;
          x.count = inProgressCount[0].TOTAL_COUNT;
          x.message = inProgressCount[0].MESSAGE;
          x.pageSize = inProgressCount[0].PAGE_SIZE;
          this.countMsg.push({ key: x.status, mappingvalue: x.message, countVal: inProgressCount[0], totalCount: x.count });
          this.pageSize = x.pageSize;
          if (x.status == 'New') {
            if (x.count != 0) {
              setTimeout(() => {
                this.getRecordsCount();
              }, 500);
            }
            if (x.count == 0) {
              console.log("x.status",x.status,this.selectedItem)
              this.loadCartService.sendBulkCount(true)
              if(this.selectedItem == 'VALID RECORDS'){
                this.loadCartService.sendInValidBulkCount(false);
                this.loadCartService.sendInProgressBulkCount(false);
                this.loadCartService.sendValidBulkCount(true);
              }else if(this.selectedItem == 'INVALID RECORDS'){
                this.loadCartService.sendValidBulkCount(false);
                this.loadCartService.sendInProgressBulkCount(false);
                this.loadCartService.sendInValidBulkCount(true);
              }else if(this.selectedItem == 'VALIDATION IN-PROGRESS'){
                this.loadCartService.sendValidBulkCount(false);
                this.loadCartService.sendInValidBulkCount(false);
                this.loadCartService.sendInProgressBulkCount(true);
              }
              
              this.refreshSpinner = false;
            }
          }
        } else {
          // this.loader = false;
        }
      }, error => {
      })
    }
    //x.loadingPercent = this.getLoadingPercentage(response.ROW[0].TOTAL_COUNT) ;
  }

  getCount(val) {
    let total = 0;
    for (var i = 0; i < val.length; i++) {
      total += val[i].count;
    }
    return total;
  }

  submitEventHandler(event: any) {
    if (event != undefined && event == true) {
      this.selectedTab = 0;
      this.showSearchData = true;
    } else {
      this.showSearchData = false;
    }
  }

  reloadCountEvent(event: any) {
    if (event != undefined && event == true) {
      this.getRecordsCount();
    }
  }
  refresh(event) {
    console.log("event", event)
    this.getRecordsCount(event);
  }

  onCardClick(event) {
    this.reloadData = false;
    this.selectedItem = event.selected ? '' : event.name;
    if (event.name == 'VALID RECORDS' || event == 'VALID RECORDS') {
      this.validData = true;
      this.showTable = false;
      this.invalidData = false;
      this.inprogressData = false;
    } else if (event.name == 'INVALID RECORDS') {
      this.showTable = false;
      this.validData = false;
      this.inprogressData = false;
      this.invalidData = true;
    } else if (event.name == 'VALIDATION IN-PROGRESS') {
      this.inprogressData = true;
      this.invalidData = false;
      this.showTable = false;
      this.validData = false;
    }
  }

  getDynamicData() {
    this.loader = true;
    let object = {
      ReportId: this.constants.bulkUploadColumnMap[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportService.onGetDynamicReport(object).subscribe(response => {
      if (response.ROW != undefined) {
        this.viewData = response.ROW || [];
        this.messageForUpload = response.ROW[0].MESSAGE_FOR_UPLOAD.split('\n')[1];
        this.messageForUpload2 = response.ROW[0].MESSAGE_FOR_UPLOAD.split('\n')[2] != undefined ? response.ROW[0].MESSAGE_FOR_UPLOAD.split('\n')[2] : ''
        this.mandatoryColumnData = this.OrganizedCart(this.viewData, 'MANDATORY_COLUMNS');
        this.templateColumnData = this.OrganizedCart(this.viewData, 'TEMPLATE_COLUMNS');
        this.loader = false;
      } else {
        this.loader = false;
      }

    }, error => {
    });
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
    }
    return col;
  }

  OrganizedCart(resp, col) {
    let display_column = [];
    if (resp[0][col] !== undefined) {
      display_column = this.convertToArray(resp[0][col]);
    }

    return display_column
  }

  getPageName() {
    let today = new Date();
    let y = today.getFullYear();
    let m = today.getMonth() + 1;
    let d = today.getDate();
    let h = today.getHours();
    let mi = today.getMinutes();
    let s = today.getSeconds();
    let currentdate = y + "-" + m + "-" + d + "-" + h + "-" + mi + "-" + s;
    this.pageName = 'Hub2u_Order_' + currentdate
  }

  downloadTemplate(action) {
    this.getPageName();
    let headers;
    headers = this.templateColumnData;
    let cols = this.mandatoryColumnData.toString()
    let newCol = cols.replace(/,/g, ' - ');
    this.tableUtil.exportToCsvWithEmptyHeaders("", this.pageName, headers, "BulkUpload", newCol);
  }

  mappingnames: any = [];
  modelShow() {
    let dialogRef = this.dialog.open(ExcelorderuploadComponent, {
      width: '600px',
      data: {
        columnMapping: this.columnMapping
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.uploadEvent.emit(result);
      this.uploadEventHandler(result)
    })
  }

  goBack() {
    this.router.navigate(['hub2u/home']);
  }

}
