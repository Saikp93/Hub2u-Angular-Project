import { Component, OnInit, ViewChild } from '@angular/core';
import { ConstantData, AdministrationService, ReportsService } from 'hub2ushared';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router'
import { FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSelectionListChange } from '@angular/material/list';
import { NotifierService } from 'projects/hub2ushared/src/lib/services/notifier.service';
import { EventService } from '../../../shared/event.service';
import { CommonWebService } from '../../../shared/common-web.service';

export interface Region {
  REGION_NAME: string;
  REGION_CODE: string;
  selected: boolean;
}

export interface User {
  FIRST_NAME: string;
  LAST_NAME: string;
  USER_NAME: string;
  FUNCTION_ID: Number;
  USER_ID: Number;
  Name: string;
}

@Component({
  selector: 'app-administration-home',
  templateUrl: './administration-home.component.html',
  styleUrls: ['./administration-home.component.scss'],
})
export class AdministrationHomeComponent implements OnInit {
  selectedTab = new FormControl(0);
  userDetails: any = '{}';
  userInfo: any;
  userRole: any = '';
  functionId: any = '';
  loader: boolean = false;

  selectedResponsibility: number = 7;
  selectedResponsibilityText: string = '';
  activeRegion: string = 'selected_regions';

  responsibilities: any[] = [];
  allRegions: Region[] = [];
  foundUserResponsibilities: any[] = [];
  foundUserResponsibilitiesRemote: any[] = [];
  responsibilityUserTypeIds = [1, 2, 6, 13, 14, 48, 47, 50, 51, 52, 57, 58, 59, 60, 65];

  displayedColumns: string[] = ['REGION_NAME', 'action'];
  selectedRegionsDataSource: Region[] = [];
  otherRegionsDataSource: Region[] = [];
  responsibilityUsersDataSource: MatTableDataSource<User> = null;
  userDisplayedColumns: string[] = ['USER_NAME', 'Name', 'action'];

  ntUsername: string = this.administrationService.getNtUser()?.userName || '';
  elementUsername: any;

  private paginator: MatPaginator;
  saveLoader: boolean = false;

  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.responsibilityUsersDataSource.paginator = this.paginator;
  }

  constructor(private router: Router, private administrationService: AdministrationService,
    private constantData: ConstantData, private route: ActivatedRoute, private eventService: EventService, private notifierService: NotifierService, private commonWebService: CommonWebService, private reportService: ReportsService) { }


  ngOnInit(): void {
    this.userDetails = localStorage.getItem('userDetails');
    this.userInfo = JSON.parse(this.userDetails);
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.responsibilityUsersDataSource = new MatTableDataSource<User>([]);
    this.responsibilityUsersDataSource.paginator = this.paginator;
    // console.log(this.userDetails);
    if (this.route.snapshot.paramMap.get('tab') === 'user') {
      this.selectedTab.setValue(1);
      if (this.selectedTab.value == 1 && this.ntUsername != '') {
        this.getUserDetails();
      }
    }

    this.fetchResponsibilities();
    this.handleResposibilityChange();
    // console.log(this.administrationService.getNtUser());

  }

  ngAfterViewInit() {
    this.responsibilityUsersDataSource.paginator = this.paginator;
  }

  assignUser(event) {
    this.ntUsername = event ? event.toUpperCase() : '';
  }

  handleResposibilityChange() {
    console.log("this.responsibilities", this.responsibilities)
    this.selectedResponsibilityText = this.responsibilities.filter(r => r.functionId === this.selectedResponsibility)[0]?.functionName;
    this.loader = true;
    if (this.responsibilityUserTypeIds.includes(this.selectedResponsibility)) {
      this.fetchResponsibilityUsers();
    } else {
      this.fetchRegions();
    }
  }

  /**SOA TO JAVA */
  fetchResponsibilities() {
    // let request = {
    //   "applicationId": 1
    // };
    let request = {
      "applicationId": 7,
      "profile":this.userRole.toUpperCase()
    };
    this.administrationService.getResposibilities(request).subscribe((response: any) => {
      if (response !== null || response !== undefined) {
        this.responsibilities = response.responsibilitiesDetail || [];
        this.selectedResponsibilityText = this.responsibilities
          .filter(r => r.functionId === this.selectedResponsibility)[0]?.functionName;
        this.loader = false;
      }
      else {
        this.loader = false;
      }

    }, (error: any) => {
      console.log(error);
      this.loader = false;
    });
  }


  fetchRegions() {
    let request = {
      // applicationId: 1,
      // functionId: this.selectedResponsibility,
      applicationId: 7,
      functionId: this.selectedResponsibility,
      // ParametersInput: [{
      //   Name: "REQUESTOR",
      //   Value: this.userInfo.NTID
      // }],
    };
    this.administrationService.getRegions(request).subscribe((response: any) => {
      const availableRegions = response.regionLookUp?.map(item => {
        return { REGION_NAME: item.meaning, REGION_CODE: item.lookupCode, selected: false };
      }) || [];
      const selectedRegions = response.regionDetailOutput?.map(item => {
        return { ...item, selected: true };
      }) || [];
      this.allRegions = [...availableRegions, ...selectedRegions];
      // console.log(this.allRegions);

      this.refreshTable();
      // console.log(response);
      this.loader = false;
    }, (error: any) => {
      console.log(error);
      this.loader = false;
    });
  }

 
  fetchResponsibilityUsers() {
    // let request = {
    //   applicationId: 1,
    //   functionId: this.selectedResponsibility
    // }
    let request = {
      applicationId: 7,
      functionId: this.selectedResponsibility,
    profile:this.userRole.toUpperCase()
    }
    this.administrationService.getUsers(request).subscribe((response: any) => {
      if (response !== null || response !== undefined) {
        const respUsers = response.responsibilitiesDetail?.map(item => {
          return { ...item, Name: item.firstName + ' ' + item.lastName };
        }) || [];
        this.responsibilityUsersDataSource = new MatTableDataSource<User>(respUsers);
        this.responsibilityUsersDataSource.paginator = this.paginator;
        this.refreshTable();
        this.loader = false;
      }
      else {
        this.loader = false;
      }

    }, (error: any) => {
      console.log(error);
      this.loader = false;
    });
  }

  refreshTable() {
    if (!this.responsibilityUserTypeIds.includes(this.selectedResponsibility)) {
      this.selectedRegionsDataSource = this.allRegions.filter(r => r.selected);
      this.otherRegionsDataSource = this.allRegions.filter(r => !r.selected);
    }
  }

  addToSelectedRegionsByValue(v: string) {
    // let request = {
    //   userRegionUpsertInput: [{
    //     applicationId: 1,
    //     functionId: this.selectedResponsibility,
    //     regionName: v,
    //     userName: this.userInfo.NTID,
    //     actionType: "ADD"
    //   }],
    // };
    let request = {
      profile:this.userRole.toUpperCase(),
      userRegionUpsertInput: [{
        applicationId: 7,
        functionId: this.selectedResponsibility,
        regionName: v,
        userName: this.userInfo.NTID,
        actionType: "ADD"
      }],
    };
    this.administrationService.addRegion(request).subscribe((response: any) => {
      if (response.status === 'SUCCESS') {
        this.allRegions = this.allRegions.map(r => {
          if (r.REGION_CODE === v) {
            return { ...r, selected: true };
          }
          return r;
        });
        this.fetchRegions();
      }
      this.commonWebService.openSnackBar(response.statusMessage, response.status);
      this.loader = false;
    }, (error: any) => {
      console.log(error);
      this.loader = false;
      alert('Error processing request');
    });
  }

  removeFromSelectedRegionsByValue(v: string) {
    // let request = {
    //   userRegionUpsertInput: [{
    //     applicationId: 1,
    //     functionId: this.selectedResponsibility,
    //     regionName: v,
    //     userName: this.userInfo.NTID,
    //     actionType: "REMOVE"
    //   }],
    // };
    let request = {
      profile:this.userRole.toUpperCase(),
      userRegionUpsertInput: [{
        applicationId: 7,
        functionId: this.selectedResponsibility,
        regionName: v,
        userName: this.userInfo.NTID,
        actionType: "REMOVE"
      }],
    };
    this.administrationService.removeRegion(request).subscribe((response: any) => {
      if (response.status === 'SUCCESS') {
        this.allRegions = this.allRegions.map(r => {
          if (r.REGION_CODE === v) {
            return { ...r, selected: false };
          }
          return r;
        });
        this.fetchRegions();
      }
      this.commonWebService.openSnackBar(response.statusMessage, response.status);
      // this.notifierService.showNotification(response.statusMessage);
      this.loader = false;
    }, (error: any) => {
      console.log(error);
      this.loader = false;
      alert('Error processing request');
    });

  }

  onNtUsernameNavigate(event) {
    this.administrationService.setNtUser({ userName: this.ntUsername });
    this.router.navigate(['hub2u/administration/ntusername']);
  }

  getUserDetails() {
    this.loader = true;
    setTimeout(() => {
      let request = {
        "applicationId": 7,
        "userName": this.ntUsername,
        "profile":this.userRole.toUpperCase(),
      };
      this.administrationService.getUserDetails(request).subscribe((response: any) => {
        if (response !== null || response !== undefined) {
          if (response.status == 'FAILED') {
            this.loader = false;
            this.commonWebService.openSnackBar(response.statusMessage, "FAILED")
          }
          else {
            if (response.responsibilitiesDetail) {
              this.foundUserResponsibilities = response.responsibilitiesDetail.map(r => ({
                ...r,
                checked: true,
              }));
            }
            this.foundUserResponsibilities = [...this.foundUserResponsibilities, ...response.availableResponsibilitiesDetail];
            this.foundUserResponsibilitiesRemote = JSON.parse(JSON.stringify(this.foundUserResponsibilities));
            this.loader = false;
          }
        }
        else {
          this.loader = false;
          this.commonWebService.openSnackBar('Error in fetching response from server', "FAILED")

        }

      }, (error: any) => {
        console.log(error);
        this.loader = false;
      });
    }, 1000);
  }

  getResp() {
    let object = {
      // "ReportId": "10087",
      "ReportId": "7002", // oracle fusion
      "ParametersInput":
        [{ "Name": "BIND_APPLICATIONID", "Value": "7" },
        { "Name": "USER_NAME", "Value": this.userInfo.NTID }]
    };

    //  this.commonService.onFetchUserResp(object).subscribe(response => {
    this.reportService.onGetDynamicReport(object).subscribe(response => {
      let resp = response || [];
      if (resp.ROW !== undefined) {
        localStorage.setItem(this.userInfo.NTID + "_responsibilities", JSON.stringify(resp));
        let responsibilities = JSON.parse(localStorage.getItem(this.userInfo.NTID + "_responsibilities"));
        console.log("responsibilities", responsibilities)
      } else {

      }
    }, error => {
    });
  }


  goToAddNtUser() {
    this.administrationService.setSelectedresponsibility(this.selectedResponsibility);
    this.router.navigateByUrl('/hub2u/administration/addntusername');
  }

  disableSave() {
    let count = 0;
    this.foundUserResponsibilitiesRemote.map((record, i) => {
      if (record.checked != undefined) {
        if (record.checked !== this.foundUserResponsibilities[i].checked) {
          count++;
        }
      }
      else {
        if (this.foundUserResponsibilities[i].checked == true) {
          count++;
        }
      }
    });
    if (count > 0)
      return false;
    else
      return true;
  }
  wmsrolecheck(event, resp) {

    if (resp.functionId == 48 && resp.checked == true) {
      this.foundUserResponsibilities.map((item) => {
        if (item.functionId == 65) {
          item.checked = false
        }
        if (item.functionId == 47) {
          item.checked = true;
        }
      })
    }
    if (resp.functionId == 65 && resp.checked == true) {
      this.foundUserResponsibilities.map((item) => {
        if (item.functionId == 48) {
          item.checked = false
        }
        if (item.functionId == 47) {
          item.checked = true;
        }
      })
    }
  }

  saveUserResposbilities() {
    this.eventService.showSpinner();
    const changes = [];
    this.foundUserResponsibilitiesRemote.map((record, i) => {
      if (record.checked !== this.foundUserResponsibilities[i].checked) {
        const actionType = this.foundUserResponsibilities[i].checked ? 'ADD' : 'REMOVE';
        changes.push({
          // applicationId: 1,
          applicationId: 7,
          actionType: actionType,
          functionId: record.functionId,
          userId: record.userId,
          userName: record.userName
          
        });
      }
    });
    let request = {
      profile:this.userRole.toUpperCase(),
      userResponsibilityUpsertInput: changes,
    };
    this.administrationService.updateUser(request).subscribe((response: any) => {
      this.getUserDetails();
      this.eventService.hideSpinner();
      this.commonWebService.openSnackBar(response.statusMessage, response.status);
    }, (error: any) => {
      this.eventService.hideSpinner();
      this.commonWebService.openSnackBar("Sorry something went wrong", "ERROR");
    });
  }

  removeUserResponsibility(element) {
    this.elementUsername = element.userName
    let request = {
      userResponsibilityUpsertInput: [{
        functionId: this.selectedResponsibility,
        userName: element.userName,
        applicationId: 1,
        actionType: "REMOVE"
      }],
    };

    this.administrationService.removeUser(request).subscribe((response: any) => {
      // this.getUserDetails();
      // this.fetchResponsibilityUsers();
      if (this.responsibilityUserTypeIds.includes(this.selectedResponsibility)) {
        if (response.status == 'SUCCESS') {
          this.selectedTab.setValue(1);
          this.ntUsername = element.userName;
          this.getUserDetails();
        } else {
          this.fetchResponsibilityUsers();
        }
      } else {
        this.getUserDetails();
      }

      this.commonWebService.openSnackBar(response.statusMessage, response.status);

    }, (error: any) => {
      console.log(error);

    });

  }

}
