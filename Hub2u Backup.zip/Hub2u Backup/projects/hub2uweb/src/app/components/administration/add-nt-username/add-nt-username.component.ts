import { Component, OnInit } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { AdministrationService } from 'hub2ushared';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';
import { NotifierService } from 'projects/hub2ushared/src/lib/services/notifier.service';
import { CommonWebService } from '../../../shared/common-web.service';

export interface Element {
  user_name: string;
  selected: boolean;
  selectable?: boolean;
}

@Component({
  selector: 'app-add-nt-username',
  templateUrl: './add-nt-username.component.html',
  styleUrls: ['./add-nt-username.component.scss'],
})
export class AddNtUsernameComponent implements OnInit {
  ntUsername: string = '';
  getTableCount: any;
  requests: any[] = [];
  myRequests: any[] = [];
  columns = [];
  userInfo: any = {};
  userRole: any;
  userDetails: any[] = [];
  showResults: boolean = false;
  loadSpinner: boolean = false;
  showNoRec: boolean = false;
  functionId = '1';
  selectedSiteData: any;
  selectedresponsibility: number = 7;
  displayedColumns = ['selection', 'user_name'];
  selection: SelectionModel<Element> = new SelectionModel<Element>(false, []);
  dataSource: MatTableDataSource<any>;

  constructor(private router: Router, private administrationService: AdministrationService,
    private notifierService: NotifierService, private commonWebService: CommonWebService,) {
    this.dataSource = new MatTableDataSource(this.userDetails);
  }

  ngOnInit() {
    this.selectedresponsibility = this.administrationService.getSelectedresponsibility();
    this.onInitialLoad();
  }

  async onInitialLoad() {
    this.userInfo = await JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');
    console.log("getting user role in settings", this.userRole);
  }

  assignUser(event) {
    this.ntUsername = event ? event.toUpperCase() : '';
  }


  // onSearchClick(event){
  //   this.loadSpinner = false;
  //   this.showResults = false;
  //   this.showNoRec = false;
  //   if(event.type == "click"){
  //     this.loadSpinner = true;
  //   }
  //   let request = {
  //     USER_NAME: this.ntUsername,
  //     ParametersInput: [
  //       {
  //         Name: "P_REQUESTOR_NAME",
  //         Value: this.userInfo.NTID
  //       }
  //     ]
  //   };
  //   this.administrationService.getSearchedUser(request).subscribe(response => {
  //       this.userDetails = response.EXC_DB_FETCH_USER_NAMEOutput ;
  //       // console.log(response);
  //       if(this.userDetails != null || this.userDetails != undefined){
  //         this.showResults = true;
  //         this.loadSpinner = false;
  //         this.showNoRec = false;
  //         this.userDetails.map(function(user) { 
  //           user.selected="false";             
  //           user.selectable="true";
  //         });
  //     }else{
  //       this.showResults = false;
  //       this.loadSpinner = false;
  //       this.showNoRec = true;
  //     }

  //     this.dataSource = new MatTableDataSource<any>(this.userDetails);
  //   },
  //   error => {
  //     console.log("error:",error)
  // })

  // }

  /**SOA TO JAVA */
  onSearchClick(event) {
    this.loadSpinner = false;
    this.showResults = false;
    this.showNoRec = false;
    if (event.type == "click") {
      this.loadSpinner = true;
    }
    let request = {
      "userName": this.ntUsername

    };
    this.administrationService.getSearchedUser(request).subscribe(response => {
      if (response !== null || response !== undefined) {
        if (response.status == 'SUCCESS') {
          this.userDetails = response.userDetailOutput;
          console.log(response);
          if (this.userDetails != null || this.userDetails != undefined) {
            this.showResults = true;
            this.loadSpinner = false;
            this.showNoRec = false;
            this.userDetails.map(function (user) {
              user.selected = "false";
              user.selectable = "true";
            });
          } else {
            this.showResults = false;
            this.loadSpinner = false;
            this.showNoRec = true;
          }

          this.dataSource = new MatTableDataSource<any>(this.userDetails);
        }
        else {
          this.loadSpinner = false;
          this.commonWebService.openSnackBar(response.statusMessage, response.status);
        }
      }
      else {
        this.loadSpinner = false;
        this.commonWebService.openSnackBar('Error in fetching response from server', 'ERROR');
      }

    },
      error => {
        console.log("error:", error)
        this.loadSpinner = false;
      })

  }

  selectRow(row) {
    this.dataSource.filteredData.forEach((row) => {
      if (row.selected == true) {
        console.log("previous selected row >>>>>" + JSON.stringify(row));
        row.selected = false;
      }
    });
    if (this.userDetails != null || this.userDetails != undefined) {
      row.selected = true;
      this.selection.select(row);
      this.selectedSiteData = row;
    }
    console.log("selected InvData", this.selectedSiteData)
  }

  onBackClick() {
    this.router.navigate(['hub2u/administration/']);
  }

  onAddClick() {

    let request = {
      profile:this.userRole.toUpperCase(),
      userResponsibilityUpsertInput: [{
        functionId: this.selectedresponsibility,
        userName: this.ntUsername,
        // applicationId: 1,
        applicationId: 7,
        actionType: "ADD",
       }],
    };

    this.administrationService.addUser(request).subscribe((response: any) => {
      if (response !== null || response !== undefined) {
        if (response.status === 'SUCCESS') {
          this.administrationService.setNtUser(this.selectedSiteData);
          this.router.navigate(['hub2u/administration/', 'user']);
        }
        else {
          this.commonWebService.openSnackBar(response.statusMessage, response.status);
        }
      }
      else {
        this.commonWebService.openSnackBar('Error in fetching response from server', 'ERROR');
      }


    }, (error: any) => {
      console.log(error);

    });

  }

}



