import { Component, OnInit } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { AdministrationService } from 'hub2ushared';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';
import { CommonWebService } from '../../../shared/common-web.service';

export interface Element {
  user_name: string;
  selected: boolean;
  selectable?: boolean;
}

@Component({
  selector: 'app-nt-username',
  templateUrl: './nt-username.component.html',
  styleUrls: ['./nt-username.component.scss'],
})
export class NtUsernameComponent implements OnInit {

  ntUsername: string = '';
  getTableCount: any;
  requests: any[] = [];
  myRequests: any[] = [];
  columns = [];
  userInfo: any = {};
  userRole: any;
  userDetails: any[] = [];
  showResults: boolean = false;
  loadSpinner: boolean = false;
  showNoRec: boolean = false;
  functionId = '1';
  selectedSiteData: any;
  page: any;

  displayedColumns = ['selection', 'user_name'];

  selection: SelectionModel<Element> = new SelectionModel<Element>(false, []);

  dataSource: MatTableDataSource<any>;

  constructor(private router: Router, private administrationService: AdministrationService, private commonWebService: CommonWebService) {
    this.dataSource = new MatTableDataSource(this.userDetails);
    if (this.router.getCurrentNavigation().extras.state != undefined) {
      this.page = this.router.getCurrentNavigation().extras.state.page;
    }
  }

  ngOnInit() {
    this.onInitialLoad();

  }

  async onInitialLoad() {
    this.userInfo = await JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');

  }

  assignUser(event) {
    this.ntUsername = event ? event.toUpperCase() : '';
  }


  // onSearchClick(event){
  //   this.loadSpinner = false;
  //   this.showResults = false;
  //   this.showNoRec = false;
  //   if(event.type == "click"){
  //     this.loadSpinner = true;
  //   }
  //   let request = {
  //     USER_NAME: this.ntUsername,
  //     ParametersInput: [
  //       {
  //         Name: "P_REQUESTOR_NAME",
  //         Value: this.userInfo.NTID
  //       }
  //     ]
  //   };
  //   this.administrationService.getSearchedUser(request).subscribe(response => {
  //       this.userDetails = response.EXC_DB_FETCH_USER_NAMEOutput ;
  //       console.log(response);
  //       if(this.userDetails != null || this.userDetails != undefined){
  //         this.showResults = true;
  //         this.loadSpinner = false;
  //         this.showNoRec = false;
  //         this.userDetails.map(function(user) { 
  //           user.selected="false";             
  //           user.selectable="true";
  //         });
  //     }else{
  //       this.showResults = false;
  //       this.loadSpinner = false;
  //       this.showNoRec = true;
  //     }

  //     this.dataSource = new MatTableDataSource<any>(this.userDetails);
  //   },
  //   error => {
  //     console.log("error:",error)
  // })

  // }

  onSearchClick(event) {
    this.loadSpinner = false;
    this.showResults = false;
    this.showNoRec = false;
    if (event.type == "click") {
      this.loadSpinner = true;
    }
    let request = {
      "userName": this.ntUsername

    };
    this.administrationService.getSearchedUser(request).subscribe(response => {
      if (response !== null && response !== undefined) {
        if (response.status == 'SUCCESS') {
          this.userDetails = response.userDetailOutput;
          console.log(response);
          if (this.userDetails != null || this.userDetails != undefined) {
            this.showResults = true;
            this.loadSpinner = false;
            this.showNoRec = false;
            this.userDetails.map(function (user) {
              user.selected = "false";
              user.selectable = "true";
            });
          } else {
            this.showResults = false;
            this.loadSpinner = false;
            this.showNoRec = true;
          }

          this.dataSource = new MatTableDataSource<any>(this.userDetails);
        }
        else {
          this.loadSpinner = false;
          this.commonWebService.openSnackBar(response.statusMessage, response.status);
        }
      }
      else {
        this.loadSpinner = false;
        this.commonWebService.openSnackBar('Error in fetching response from server', 'ERROR');
      }

    },
      error => {
        console.log("error:", error)
        this.loadSpinner = false;
      })

  }

  selectRow(row) {
    console.log("clicked", row);

    this.dataSource.filteredData.forEach((row) => {
      if (row.selected == true) {
        console.log("previous selected row >>>>>" + JSON.stringify(row));
        row.selected = false;
      }
    });
    if (this.userDetails != null || this.userDetails != undefined) {
      row.selected = true;
      this.selection.select(row);
      this.selectedSiteData = row;
    }
    console.log("selected InvData", this.selectedSiteData)
  }

  onBackClick() {
    if (this.page != undefined && this.page == "bu-administration") {
      this.router.navigate(['hub2u/bu-administration/']);
    } else {
      this.router.navigate(['hub2u/administration/', 'user']);
    }

  }

  onDoneClick() {
    if (this.page != undefined && this.page == "bu-administration") {
      this.administrationService.setNtUser(this.selectedSiteData);
     // this.router.navigate(['hub2u/bu-administration/']);
      this.router.navigate(['hub2u/bu-administration/'], {
        state: { data: this.selectedSiteData }
      });
    } else {
      this.administrationService.setNtUser(this.selectedSiteData);
      this.router.navigate(['hub2u/administration/', 'user']);
    }
  }

}



