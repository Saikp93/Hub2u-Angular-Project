import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdministrationComponent } from './administration.component';
import { RouterModule, Routes } from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatMenuModule} from '@angular/material/menu';
import {MatSelectModule} from '@angular/material/select';
import {MatButtonModule} from '@angular/material/button';
import {MatTooltipModule} from '@angular/material/tooltip';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Hub2usharedModule } from 'hub2ushared';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { AdministrationHomeComponent } from './administration-home/administration-home.component';
import { NtUsernameComponent } from './nt-username/nt-username.component';
import { MatListModule } from '@angular/material/list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule } from '@angular/material/radio';
import { AddNtUsernameComponent } from './add-nt-username/add-nt-username.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { NgxSpinnerModule } from 'ngx-spinner';

const routes: Routes = [
  {
    path: '',
    component: AdministrationComponent,
    children: [
      { path: '', component: AdministrationHomeComponent },
      { path: 'ntusername', component: NtUsernameComponent },
      { path: 'addntusername', component: AddNtUsernameComponent },
      { path: ':tab', component: AdministrationHomeComponent },
      
    ]
  }
];

@NgModule({
  declarations: [AdministrationComponent, NtUsernameComponent, AdministrationHomeComponent, AddNtUsernameComponent],
  imports: [
    CommonModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    NgxSpinnerModule,
    MatMenuModule,
    MatSelectModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    Hub2usharedModule,
    MatButtonToggleModule,
    MatTabsModule,
    MatTableModule,
    MatCardModule,
    MatInputModule,
    MatFormFieldModule,
    MatListModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatPaginatorModule,
    MatCheckboxModule,
    
    RouterModule.forChild(routes)
  ]
})
export class AdministrationModule { }
