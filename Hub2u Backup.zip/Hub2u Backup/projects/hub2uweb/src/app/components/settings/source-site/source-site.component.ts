import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ConstantData, ReportsService } from 'hub2ushared';
import { CommonSettingService } from '../../../shared/common-settings.service';

@Component({
  selector: 'app-source-site',
  templateUrl: './source-site.component.html',
  styleUrls: ['./source-site.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class SourceSiteComponent implements OnInit {

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  pageSizeOptions: number[] = [20, 30, 60, 100];
  paginationCaptions: any;
  getTableCount: any;
  requests: any[] = [];
  myRequests: any[] = [];
  columns = [];
  userInfo: any = {};
  userRole: any;
  customerValue: any = "";
  siteValue: any = "";
  sourceSiteAdress: any = "";
  customer: any = "";
  cityValue: any = "";
  stateValue: any = "";
  zipValue: any = "";
  siteDetails: any[] = [];
  showResults: boolean = false;
  enableDone: boolean = false;
  // deliverSiteResults: boolean = false;
  // deliverSiteDone: boolean = false;
  loadSpinner: boolean = false;
  showNoRec: boolean = false;
  functionId = '1';
  selectedSiteData: any;
  comTechUser: boolean = false;
  esaUser: boolean = false;
  comBusinesServiceUser: boolean = false;
  comCPEUser: boolean = false;
  storeUser: boolean = false;
  cnaUser: boolean = false;
  prepaidUser: boolean = false;
  request: any;
  reportFeilds: any;
  checkRole: any;
  page: any;
  sourceSiteName;
  sourceSiteindex;
  sourceSiteReq: any = null;
  selection: SelectionModel<Element> = new SelectionModel<Element>(false, []);
  dataSource: MatTableDataSource<any>;
  displayedColumns = [];
  dynamicFields: any = [];
  dynamicId: any;
  dynamicFieldsSpinner: boolean = false;
  form = new FormGroup({});

  constructor(private reportsService: ReportsService, private comSettingService: CommonSettingService,
    private router: Router, private formBuilder: FormBuilder, private constantData: ConstantData,) {
    if (this.router.getCurrentNavigation().extras.state != undefined) {
      this.page = this.router.getCurrentNavigation().extras.state.page;
    }
    if (this.page == 'cart' || this.page == 'settings' || this.page == 'bu-administration') {
      this.sourceSiteName = this.router.getCurrentNavigation().extras.state.sourceSiteName;
      this.sourceSiteindex = this.router.getCurrentNavigation().extras.state.sourceHouseindex;
      this.siteValue = this.router.getCurrentNavigation().extras.state.sourceSiteVal;
    }
    // if (this.page == 'bu-administration') {
    //   this.sourceSiteName = this.router.getCurrentNavigation().extras.state.sourceSiteName;
    //   this.siteValue = this.router.getCurrentNavigation().extras.state.sourceSiteVal;
    // }
    if (this.page == 'settings') {
      this.siteValue = this.router.getCurrentNavigation().extras.state.sourceSiteVal;
    }
    this.dataSource = new MatTableDataSource(this.siteDetails);
    this.dataSource.paginator = this.paginator;
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.enableDone = false;
    this.onInitialLoad();
    this.dynamicId = (localStorage.getItem('wareHousedynamicId') !== undefined && localStorage.getItem('wareHousedynamicId') !== null) ? localStorage.getItem('wareHousedynamicId') : ''
    if (this.dynamicId == '' || this.dynamicId == undefined) {
      this.dynamicId = this.constantData.sourceSiteId[this.functionId];
    }
    this.onGetReportFields();
    // this.loadMyRequests();
  }

  async onInitialLoad() {
    // this.userInfo = await JSON.parse(localStorage.getItem('userDetails'));
    // this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');
  }

  onGetReportFields() {
    this.dynamicFieldsSpinner = true;
    let request = {
      ReportId: this.dynamicId,
      ParametersInput: [
        {
          Name: "P_REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.getReportDisplayFields(request).subscribe(response => {
      if (response != undefined) {
        this.dynamicFieldsSpinner = false;
        for (let control of response.ReportDisplayFieldsOutput) {
          this.dynamicFields.push(control);
        }
        this.form = this.createDynamicForm();
        // this.loader = false;
      } else {
        this.dynamicFieldsSpinner = false;
      }
    }, (error) => { this.dynamicFieldsSpinner = false; })
  }

  createDynamicForm() {
    let dynamicForm = this.formBuilder.group({});
    this.dynamicFields.forEach(control => {
      dynamicForm.addControl(control.name, this.formBuilder.control(''));
      if (control.name == 'REQUESTOR_NAME') {
        dynamicForm.controls['REQUESTOR_NAME'].setValue(this.userInfo.NTID)
        control.value = this.userInfo.NTID;
      }
    });
    return dynamicForm;
  }

  onSearchClick(event) {
    this.loadSpinner = false;
    this.showResults = false;
    this.showNoRec = false;
    this.displayedColumns = [];
    this.columns = [];
    let visibleCols = [];
    if (event.type == "click") {
      this.loadSpinner = true;
    }
    if (this.sourceSiteReq) {
      this.sourceSiteReq.unsubscribe();
    }
    let request = {
      ReportId: this.dynamicId,
      ParametersInput: [
      ]
    };
    var formData = this.form.value;
    request.ParametersInput.push({
      "Name": "P_REQUESTOR_NAME",
      "Value": this.userInfo.NTID
    })
    for (var key in formData) {
      if (formData.hasOwnProperty(key)) {
        request.ParametersInput.push({
          "Name": key,
          "Value": formData[key] == "" || formData[key] == null ? "" : formData[key].toString()
        })
      }
    }

    this.sourceSiteReq = this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW != undefined) {
        this.siteDetails = response.ROW;
        this.siteDetails.forEach(data => {
          for (const key in data) {
            if (this.siteDetails.indexOf(data) == 0 && data['DISPLAY_COLUMNS'] != undefined) {
              visibleCols = data['DISPLAY_COLUMNS'].split(',');
              // allCols.push(`${key}`);
            }
          }
        })
        let displayCols = visibleCols;
        if (this.displayedColumns.length == 0) {
          this.displayedColumns.push("selected");
          displayCols.forEach(col => {
            this.columns.push(col);
            this.displayedColumns.push(col);
          })
        }
        this.showResults = true;
        this.loadSpinner = false;
        this.showNoRec = false;
        this.siteDetails.map(function (material) {
          material.selected = "false",
            material.selectable = "true"

        });
      } else {
        this.showResults = false;
        this.loadSpinner = false;
        this.showNoRec = true;
      }
      this.dataSource = new MatTableDataSource<any>(this.siteDetails);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    },
      error => {
        this.loadSpinner = false;
        this.showNoRec = true;
        console.log("error:", error)
      })

  }

  selectRow(row) {

    this.dataSource.filteredData.forEach((row) => {
      if (row.selected == true) {
        // console.log("previous selected row >>>>>" + JSON.stringify(row));
        row.selected = false;
      }
    });
    if (this.siteDetails != null || this.siteDetails != undefined) {
      row.selected = true;
      this.enableDone = true;
      this.selection.select(row);
      this.selectedSiteData = row;
    }
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  onBackClick() {
    if (this.page != undefined && this.page == "cart") {
      this.router.navigate(['hub2u/catalog/cart']);
    } else if (this.page != undefined && this.page == "bu-administration") {
      this.router.navigate(['hub2u/bu-administration/']);
    } else {
      this.router.navigate(['hub2u/settings/']);
    }
  }

  onDoneClick() {
    this.comSettingService.setSourceSite(this.selectedSiteData, this.sourceSiteName, this.siteValue, this.sourceSiteAdress, this.sourceSiteindex);
    if (this.page != undefined && this.page == "cart") {
      this.router.navigate(['hub2u/catalog/cart']);
    } else if (this.page != undefined && this.page == "bu-administration") {
      this.router.navigate(['hub2u/bu-administration/']);
    } else {
      this.router.navigate(['hub2u/settings/']);
    }
  }

}

export interface Element {
  ADDRESS: string;
  CHANNEL: string;
  CONTACT_EMAIL: string;
  CONTACT_PHONE: string;
  CUSTOMER: string;
  LOCATION_DESCRIPTION: string;
  LOCATION_TYPE: string;
  SITE_ID: string;
  selected: boolean;
  selectable?: boolean;
}
