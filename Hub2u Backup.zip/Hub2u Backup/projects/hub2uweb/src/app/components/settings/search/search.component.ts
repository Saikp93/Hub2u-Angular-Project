import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ConstantData, ReportsService } from 'hub2ushared';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import { CommonSettingService } from '../../../shared/common-settings.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class SearchComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  projectName: any = '';
  projectNumber: any = '';
  description: any = '';
  bUnit: any = '';
  orderType: any = '';
  projectStatus: any = '';
  type: any = '';
  projectType: any = '';
  p2Type: any = '';
  userValues: any;
  p2Dropdown: any[]=['--Select--','P2'];
  projStatusDropDown: any[] = [];
  projTypeDropDown: any[] = [];
  typeDropDown: any[] = [];
  comnRequest: any;
  userInfo: any = {};
  userRole: any = '';
  functionId = '1';
  form: FormGroup;
  showResults: boolean = false;
  showNoRec: boolean = false;
  loadSpinner: boolean = false;
  enableDone: boolean = false;
  searchResults: any[] = [];
  selectProjectData: any;
  projectColName: any;
  innerRowIndex: any;
  projectIndex: any;
  projectVal: any;
  page: any;
  projNumReq: any = null;
  displayedColumns = [];
  columns = [];
  selection: SelectionModel<ProjectData> = new SelectionModel<ProjectData>(false, []);
  dataSource: MatTableDataSource<any>;

  constructor(private reportsService: ReportsService,
    private router: Router, private comSettingService: CommonSettingService,private constantData:ConstantData) {
    this.dataSource = new MatTableDataSource(this.searchResults);
    this.dataSource.paginator = this.paginator;
    if (this.router.getCurrentNavigation().extras.state != undefined) {
      this.page = this.router.getCurrentNavigation().extras.state.page;
    }
    if (this.page == 'cart') {
      this.projectColName = this.router.getCurrentNavigation().extras.state.projectColName;
      this.projectIndex = this.router.getCurrentNavigation().extras.state.projectIndex;
      this.innerRowIndex = this.router.getCurrentNavigation().extras.state.innerRowIndex;
    }
    if (this.page == 'bu-administration') {
      this.projectColName = this.router.getCurrentNavigation().extras.state.projectColName;
      this.projectVal = this.router.getCurrentNavigation().extras.state.projectVal;
    }
    if (this.page == 'settings') {
      this.projectColName = this.router.getCurrentNavigation().extras.state.projectColName;
      this.projectVal = this.router.getCurrentNavigation().extras.state.projectVal;
    }
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.enableDone = false;
    this.onInitialLoad();
    this.onGetProjectDetails();
    if (this.projectVal != undefined || this.projectVal != null) {
      this.projectNumber = this.projectVal;
    }
  }

  async onInitialLoad() {
    this.initialFormControl();
  }

  initialFormControl() {
    this.form = new FormGroup({
      projNums: new FormControl(''),
      projName: new FormControl(''),
      description: new FormControl(''),
      bUnit: new FormControl(''),
      orderType: new FormControl(''),
      projType: new FormControl(''),
      projStatus: new FormControl(''),
      type: new FormControl(''),
      p2Type: new FormControl('')
    });
  }

  commonData() {
    this.reportsService.getCpeOrderReeport().subscribe(response => {
      this.userValues = response.reportNamesOutput;
    })
    this.comnRequest = [{
      // ReportId: "112",
      // ReportId: "7001",
      ReportId:this.constantData.userprofileData[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    }];
  }

  onGetProjectDetails() {
    // this.commonData();
    // let request = this.comnRequest;
    let req = {
      ReportId: "10184",
      ParametersInput: [
        {
          Name: "P_REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.onGetDynamicReport(req).subscribe(response => {
      if (response.ROW != undefined) {
        this.projTypeDropDown.push('--Select--');
        for (let projType of response.ROW) {
          projType = projType.DESCRIPTION;
          this.projTypeDropDown.push(projType);
        }
      }
    })

    let reque = {
      ReportId: "10185",
      ParametersInput: [
        {
          Name: "P_REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.onGetDynamicReport(reque).subscribe(response => {
      if (response.ROW != undefined) {
        this.projStatusDropDown.push('--Select--');
        for (let projStat of response.ROW) {
          projStat = projStat.PROJECT_STATUS_NAME;
          this.projStatusDropDown.push(projStat);
        }
      }
    })

    let request = {
      ReportId: "10186",
      ParametersInput: [
        {
          Name: "P_REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW != undefined) {
        this.typeDropDown.push('--Select--');
        for (let type of response.ROW) {
          type = type.PROJECT_TYPE;
          this.typeDropDown.push(type);
        }
      }
    })
  }

  onSearchClick(event) {
    this.loadSpinner = false;
    this.showResults = false;
    this.displayedColumns = [];
    this.columns = [];
    let visibleCols = [];
    if (event.type == "click") {
      this.loadSpinner = true;
    }
    if (this.projNumReq) {
      this.projNumReq.unsubscribe();
    }
    let req = {
      ReportId: "10187",
      "ParametersInput": [
        { "Name": "PROJECT_NUMBER", "Value": this.projectNumber },
        { "Name": "PROJECT_NAME", "Value": this.projectName },
        { "Name": "PROJECT_DESCRIPTION", "Value": this.description },
        { "Name": "PROJECT_CLASS_CODE", "Value": this.projectType != '--Select--'? this.projectType : '' },
        { "Name": "PROJECT_STATUS_NAME", "Value": this.projectStatus != '--Select--'? this.projectStatus : '' },
        { "Name": "BUSINESS_UNIT", "Value": this.bUnit },
        { "Name": "PROJECT_TYPE", "Value": this.type != '--Select--'? this.type : '' },
        { "Name": "JOB_FLAG", "Value": this.p2Type == 'P2'? 'Yes' : ''}
      ]
    };
    // this.settingsService.getProjectDetails(req).subscribe(response => {
    this.projNumReq = this.reportsService.onGetDynamicReport(req).subscribe(response => {
      if (response.ROW != undefined) {
        this.searchResults = response.ROW;
        this.searchResults.forEach(data => {
          for (const key in data) {
            if (this.searchResults.indexOf(data) == 0) {
              visibleCols = data['DISPLAY_COLUMNS'].split(',');
            }
          }
        })
        let displayCols = visibleCols;
        if (this.displayedColumns.length == 0) {
          this.displayedColumns.push("selected");
          displayCols.forEach(col => {
            this.columns.push(col);
            this.displayedColumns.push(col);
          })
        }
        this.showResults = true;
        this.loadSpinner = false;
        this.showNoRec = false;
        this.searchResults.map(function (material) {
          material.selected = "false",
            material.selectable = "true"
        });
      } else {
        this.showResults = false;
        this.loadSpinner = false;
        this.showNoRec = true;
      }
      this.dataSource = new MatTableDataSource<any>(this.searchResults);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    },
      error => {
        this.loadSpinner = false;
        this.showNoRec = true;
        console.log("error:", error)
      })

  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  selectedRow(row) {
    this.dataSource.filteredData.forEach((row) => {
      if (row.selected == true) {
        console.log("previous selected row >>>>>" + JSON.stringify(row));
        row.selected = false;
      }
    });

    if (this.searchResults != null || this.searchResults != undefined) {
      row.selected = true;
      this.enableDone = true;
      this.selection.select(row);
      this.selectProjectData = row;
      //this.currentSelected = index;
    }
  }

  onBackClick() {
    this.comSettingService.setProjCode(this.selectProjectData, this.projectColName, this.projectIndex);
    if (this.page != undefined && this.page == "cart") {
      this.router.navigate(['hub2u/catalog/cart']);
    } else if (this.page != undefined && this.page == "bu-administration") {
      this.router.navigate(['hub2u/bu-administration/']);
    } else {
      this.comSettingService.setSettingProjectCode(null, null);
      this.router.navigate(['hub2u/settings/']);
    }
  }

  onDoneClick() {

    if (this.page != undefined && this.page == "cart") {
      this.comSettingService.setProjCode(this.selectProjectData, this.projectColName, this.projectIndex, this.innerRowIndex);
      this.router.navigate(['hub2u/catalog/cart']);
    } else if (this.page != undefined && this.page == "bu-administration") {
      this.comSettingService.setSettingProjectCode(this.selectProjectData, this.projectColName);
      this.router.navigate(['hub2u/bu-administration/']);
    } else {
      this.comSettingService.setSettingProjectCode(this.selectProjectData, this.projectColName);
      this.router.navigate(['hub2u/settings/']);
    }
  }

}

export interface ProjectData {
  ProjectId: number;
  BusinessUnit: string;
  ProjectClassCode: string;
  ProjectDescription: string;
  ProjectName: string;
  ProjectNumber: string;
  ProjectStatusName: string;
  selected: boolean;
  selectable?: boolean;
}
