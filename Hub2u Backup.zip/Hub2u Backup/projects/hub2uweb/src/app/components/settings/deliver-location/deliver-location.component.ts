import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ConstantData, ReportsService, SettingsService } from 'hub2ushared';
import { CommonSettingService } from '../../../shared/common-settings.service';

@Component({
  selector: 'app-deliver-location',
  templateUrl: './deliver-location.component.html',
  styleUrls: ['./deliver-location.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class DeliverLocationComponent implements OnInit {

  userInfo: any = {};
  userRole: any = '';
  functionId = '1';
  // form : FormGroup;
  dynamicFields: any = [];
  form = new FormGroup({});
  selectedCardData: any;
  orgCode: any;
  orgCodeValue: any = "";
  locCodeValue: any = "";
  descValue: any = "";
  wareHouseDetails: any[] = [];
  loadSpinner: boolean = false;
  dynamicFieldsSpinner: boolean = false;
  showResults: boolean = false;
  showNoRecords: boolean = false;
  showNoRec: boolean = false;
  enableDone: boolean = false;
  page: any;
  initOrgCode: any;
  warehouseCode: any[] = []
  delLocName;
  delLocVal;
  index;
  dynamicId: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns = [];
  deliveryLocReq: any = null;
  columns = [];

  selection: SelectionModel<SourceData> = new SelectionModel<SourceData>(false, []);

  dataSource: MatTableDataSource<any>;
  catalogObj: any;
  view: any;
  favorite: any;

  constructor(private formBuilder: FormBuilder, private constantData: ConstantData,
    private router: Router, private comSettingService: CommonSettingService, private settingsService: SettingsService,
    private activatedRoute: ActivatedRoute, private reportsService: ReportsService) {
      this.dataSource = new MatTableDataSource(this.wareHouseDetails);
      this.dataSource.paginator = this.paginator;
      if (this.router.getCurrentNavigation().extras.state != undefined) {
        this.page = this.router.getCurrentNavigation().extras.state.page;
      }
      if (this.page == 'cart') {
        this.delLocName = this.router.getCurrentNavigation().extras.state.delLocName;
        this.delLocVal = this.router.getCurrentNavigation().extras.state.delLocVal;
        this.index = this.router.getCurrentNavigation().extras.state.index
      }
      if (this.page == 'catalog') {
        this.catalogObj = this.router.getCurrentNavigation().extras.state.catalogObj;
        this.view = this.router.getCurrentNavigation().extras.state.view
        this.favorite = this.router.getCurrentNavigation().extras.state.favorite
      }

      if (this.page == 'bu-administration') {
        this.delLocName = this.router.getCurrentNavigation().extras.state.delLocName;
        this.index = this.router.getCurrentNavigation().extras.state.index
      }

      if (this.page == 'settings') {
        this.delLocName = this.router.getCurrentNavigation().extras.state.delLocName;
        this.delLocVal = this.router.getCurrentNavigation().extras.state.delLocVal;
      }
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.enableDone = false;
    //this.displayedColumns.push("selected");
    //this.displayedColumns = this.displayedColumns.concat(this.columns);
    this.dynamicId = (localStorage.getItem('deliverLocdynamicId') !== undefined && localStorage.getItem('deliverLocdynamicId') !== null) ? localStorage.getItem('deliverLocdynamicId') : ''
    if (this.dynamicId == '' || this.dynamicId == undefined) {
      this.dynamicId = this.constantData.deliverLocId[this.functionId];
    }
    this.onInitialLoad();
  }

  async onInitialLoad() {
    // this.userInfo = await JSON.parse(localStorage.getItem('userDetails'));
    // this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    // this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.onGetReportFields();
    // this.onGetDynamicReportFields();
  }

  onGetReportFields() {
    this.dynamicFieldsSpinner = true;
    let request = {
      ReportId: this.dynamicId,
      ParametersInput: [
        {
          Name: "P_REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.getReportDisplayFields(request).subscribe(response => {
      // this.orgCode = response.ReportDisplayFieldsOutput[0].label;
      if (response != undefined) {
        this.dynamicFieldsSpinner = false;
        for (let control of response.ReportDisplayFieldsOutput) {
          this.dynamicFields.push(control);
        }
        this.form = this.createDynamicForm();
        // this.loader = false;
      } else {
        this.dynamicFieldsSpinner = false;
      }
    }, (error) => { this.dynamicFieldsSpinner = false; })
  }

  onGetDynamicReportFields() {
    let request = {
      ReportId: this.dynamicId,
      ParametersInput: [
        {
          Name: "P_REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.onGetDynamicReport(request).subscribe(response => {

      if (response.ROW !== undefined && response.ROW !== null) {
        this.columns = this.convertToArray(response.ROW[0].DISPLAY_COLUMNS);
        this.displayedColumns.push("selected");
        this.displayedColumns = this.displayedColumns.concat(this.columns);
      }
      // this.orgCode = response.ReportDisplayFieldsOutput[0].label;
      if (response != undefined) {
        console.log("response", response)
        // for (let control of response.ReportDisplayFieldsOutput) {
        //   this.dynamicFields.push(control);
        // }
        // this.form = this.createDynamicForm();
        // this.loader = false;
      } else {
      }
    }, (error) => { })
  }

  createDynamicForm() {
    let dynamicForm = this.formBuilder.group({});
    this.dynamicFields.forEach(control => {
      dynamicForm.addControl(control.name, this.formBuilder.control(''));
      if (control.name == 'REQUESTOR_NAME') {
        dynamicForm.controls['REQUESTOR_NAME'].setValue(this.userInfo.NTID)
        control.value = this.userInfo.NTID;
      }
    });
    return dynamicForm;
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '' && columns !== null) {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",").map(item => item.trim());
      }
      else {
        columns = columns + ',';
        col = columns.split(",")
      }
    }
    return col;
  }

  onDelLocSearchClick(event) {
    this.loadSpinner = false;
    this.showResults = false;
    this.displayedColumns = [];
    this.columns = [];
    let visibleCols = [];
    if (event.type == "click") {
      this.loadSpinner = true;
    }
    if (this.deliveryLocReq) {
      this.deliveryLocReq.unsubscribe();
    }
    let request = {
      ReportId: this.dynamicId,
      ParametersInput: [
      ]
    };

    var formData = this.form.value;
    request.ParametersInput.push({
      "Name": "P_REQUESTOR_NAME",
      "Value": this.userInfo.NTID
    })
    for (var key in formData) {
      if (formData.hasOwnProperty(key)) {
        request.ParametersInput.push({
          "Name": key,
          "Value": formData[key] == "" || formData[key] == null ? "" : formData[key].toString()
        })
      }
    }
    this.deliveryLocReq = this.settingsService.getLocationDetails(request).subscribe(response => {
      if (response.ROW != undefined) {
        this.wareHouseDetails = response.ROW;
        this.wareHouseDetails.forEach(data => {
          for (const key in data) {
            if (this.wareHouseDetails.indexOf(data) == 0 && data['DISPLAY_COLUMNS'] != undefined) {
              visibleCols = data['DISPLAY_COLUMNS'].split(',');
            }
          }
        })
        let displayCols = visibleCols;
        if (this.displayedColumns.length == 0) {
          this.displayedColumns.push("selected");
          displayCols.forEach(col => {
            this.columns.push(col);
            this.displayedColumns.push(col);
          })
        }
        this.showResults = true;
        this.loadSpinner = false;
        this.showNoRec = false;
        this.wareHouseDetails.map(function (material) {
          material.selected = "false",
            material.selectable = "true"

        });
      } else {
        this.showResults = false;
        this.loadSpinner = false;
        this.showNoRec = true;
      }
      this.dataSource = new MatTableDataSource<any>(this.wareHouseDetails);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.loadSpinner = false;
      this.showNoRec = true;
      console.log("error:", error);
    })
  }

  // ngAfterViewInit() {
  //   this.dataSource.paginator = this.paginator;
  //   this.dataSource.sort = this.sort;
  // }

  ngOnChanges() {
    this.dataSource = new MatTableDataSource<any>(this.wareHouseDetails);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  selectedRow(row) {

    this.dataSource.filteredData.forEach((row) => {
      if (row.selected == true) {
        // console.log("previous selected row >>>>>" + JSON.stringify(row));
        row.selected = false;
      }
    });
    row.selected = true;
    this.enableDone = true;
    this.selection.select(row);
    this.selectedCardData = row;
    console.log("selectedCardData", this.selectedCardData)
  }

  onBackClick() {
    if (this.page != undefined && this.page == "cart") {
      this.router.navigate(['hub2u/catalog/cart']);
    } else if (this.page != undefined && this.page == "bu-administration") {
      this.router.navigate(['hub2u/bu-administration/']);
    } else if (this.page != undefined && this.page == "catalog") {
      this.router.navigate(['hub2u/catalog'], { state: { catalogObj: this.catalogObj, view: this.view, favorite: this.favorite } });
    } else {
      this.router.navigate(['hub2u/settings/']);
    }
  }

  onDoneClick() {
    this.warehouseCode.push({
      "ORGANIZATION_CODE": this.initOrgCode
    }
    );
    this.comSettingService.setdelLocCode(this.selectedCardData, this.delLocName, this.delLocVal, this.index);
    if (this.page != undefined && this.page == "cart") {
      this.router.navigate(['hub2u/catalog/cart']);
    } else if (this.page != undefined && this.page == "bu-administration") {
      this.router.navigate(['hub2u/bu-administration/']);
    } else if (this.page != undefined && this.page == "catalog") {
      this.router.navigate(['hub2u/catalog'], { state: { catalogObj: this.catalogObj, view: this.view, favorite: this.favorite } });
    } else {
      this.router.navigate(['hub2u/settings/']);
    }
  }

}

export interface SourceData {
  ADDRESS: string;
  BUSINESS_GROUP_ID: string;
  CONTACT: string
  DELIVER_TO_ORG_ID: number;
  DESCRIPTION: string;
  INSTANCE_NAME: string;
  LOCATION_CODE: string;
  LOCATION_DISPLAY: string;
  LOCATION_ID: number;
  ORGANIZATION_CODE: string;
  SET_OF_BOOKS_ID: number;
}