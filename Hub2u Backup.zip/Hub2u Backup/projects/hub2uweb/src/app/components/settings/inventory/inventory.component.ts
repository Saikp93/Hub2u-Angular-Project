import { Component, ViewChild, OnInit } from '@angular/core';
import { SelectionModel } from "@angular/cdk/collections";
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
//import { DialogExmpComponent } from '../dialog-exmp/dialog-exmp.component';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { JsonpClientBackend } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { ReportsService, SettingsService } from 'hub2ushared';
import { CommonSettingService } from '../../../shared/common-settings.service';



//const queryParamName = "pippo";
@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.scss'],
})
export class InventoryComponent implements OnInit {

  userInfo: any = {};
  userRole: any = '';
  functionId = '1';
  showInv;
  showSubInv;
  siteValue: any = "";
  locCodeValue: any = "";
  descValue: any = "";
  wareHouseDetails: any[] = [];
  loadSpinner: boolean = false;
  loadInvSpinner: boolean = false;
  showNoRec: boolean = false;
  orgCode: any;
  orgCodeValue: any = "";
  invCodeValue: any;
  invNameValue: any = "";
  subInvSearchResults: any[] = [];
  showResults: boolean = false;
  subInvResults: boolean = false;
  selectInvData: any;
  page: any;
  subInvName;
  invValue;
  displayedColumns = ['selection', 'ORGANIZATION_CODE', 'SUBINVENTORY_NAME'];
  columns = [];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  selection: SelectionModel<Element> = new SelectionModel<Element>(false, []);

  dataSource: MatTableDataSource<any>;

  constructor(public dialog: MatDialog, private reportsService: ReportsService, private fb: FormBuilder, private settingsService: SettingsService,
    private router: Router, private comSettingService: CommonSettingService) {
    if (this.router.getCurrentNavigation().extras.state != undefined) {
      this.page = this.router.getCurrentNavigation().extras.state.page;
    }
    if (this.page == 'cart' || this.page == 'settings') {
      this.subInvName = this.router.getCurrentNavigation().extras.state.subInvName;
      this.invValue = this.router.getCurrentNavigation().extras.state.subInvVal;
      // this.sourceSiteindex = this.router.getCurrentNavigation().extras.state.sourceHouseindex;
    }
    this.dataSource = new MatTableDataSource(this.subInvSearchResults);
    this.dataSource.paginator = this.paginator;
  }

  ngOnInit() {
    this.onInitialLoad();
    if (this.invValue != undefined && this.invValue != null && this.invValue != 'null') {
      this.invNameValue = this.invValue;
    }
  }

  async onInitialLoad() {
    this.userInfo = await JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.onGetReportFields();
  }

  onGetReportFields() {
    console.log("inventory this.userInfo.NTID", this.userInfo.NTID)
    let request = {
      ReportId: "10008", //this.userValues[0].reportId
      ParametersInput: [
        {
          Name: "P_REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.getReportDisplayFields(request).subscribe(response => {
      this.orgCode = response.ReportDisplayFieldsOutput[0].label;
      console.log("displayFields are:", this.orgCode);
    })
  }

  onSubInvSearchClick(event) {
    // this.currentSelected = null;
    // this.displayedColumns = [];
    // this.columns = [];
    this.loadSpinner = false;
    this.showResults = false;
    // let allCols = [];
    // let visibleCols = [];
    if (event.type == "click") {
      this.loadInvSpinner = true;
    }
    let req = {
      ORGANIZATION_CODE: this.orgCodeValue,
      SUBINVENTORY_NAME: this.invNameValue
    };

    this.settingsService.getSubInventoryDetails(req).subscribe(response => {
      this.subInvSearchResults = response.EXC_DB_SELECT_SUBINVENTORYOutput;

      if (this.subInvSearchResults != null || this.subInvSearchResults != undefined) {
        this.subInvResults = true;
        this.loadInvSpinner = false;
        this.showNoRec = false;
        this.subInvSearchResults.map(function (material) {
          material.selected = "false",
            material.selectable = "true"
        });
      } else {
        this.subInvResults = false;
        this.loadInvSpinner = false;
        this.showNoRec = true;
      }
      this.dataSource = new MatTableDataSource<any>(this.subInvSearchResults);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    },
      error => {
        this.loadSpinner = false;
        this.showNoRec = true;
        console.log("error:", error)
      })
    this.selectedRow(this.subInvSearchResults, null);
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  // applyFilter(event: Event) {
  //   const filterValue = (event.target as HTMLInputElement).value;
  //   this.dataSource.filter = filterValue.trim().toLowerCase();

  //   if (this.dataSource.paginator) {
  //     this.dataSource.paginator.firstPage();
  //   }
  // }

  selectedRow(row, i) {
    this.dataSource.filteredData.forEach((row) => {
      if (row.selected == true) {
        // console.log("previous selected row >>>>>" + JSON.stringify(row));
        row.selected = false;
      }
    });
    if (this.subInvSearchResults != null && this.subInvSearchResults != undefined) {
      row.selected = true;
      this.selection.select(row);
      this.selectInvData = row;
    }
  }
  onBackClick() {
    //this.comSettingService.setInvCode(this.selectInvData);
    this.router.navigate(['hub2u/settings/']);
  }

  onDoneClick() {
    this.comSettingService.setSubinv(this.selectInvData, this.subInvName);
    this.router.navigate(['hub2u/settings/']);
  }
}

export interface Element {
  ASSET_INVENTORY: number;
  DESCRIPTION: string;
  ORGANIZATION_CODE: string;
  ORGANIZATION_ID: number;
  SUBINVENTORY_NAME: string;
  selected: boolean;
  selectable?: boolean;
}
