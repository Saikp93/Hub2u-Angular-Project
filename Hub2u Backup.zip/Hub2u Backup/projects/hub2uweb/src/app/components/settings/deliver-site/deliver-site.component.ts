import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ConstantData, ReportsService } from 'hub2ushared';
import { CommonSettingService } from '../../../shared/common-settings.service';

@Component({
  selector: 'app-deliver-site',
  templateUrl: './deliver-site.component.html',
  styleUrls: ['./deliver-site.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class DeliverSiteComponent implements OnInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  pageSizeOptions: number[] = [20, 30, 60, 100];
  paginationCaptions: any;
  getTableCount: any;
  requests: any[] = [];
  myRequests: any[] = [];
  userInfo: any = {};
  userRole: any;
  customerValue: any = "";
  siteValue: any = "";
  customer: any = "";
  cityValue: any = "";
  stateValue: any = "";
  zipValue: any = "";
  siteDetails: any[] = [];
  showResults: boolean = false;
  // deliverSiteResults: boolean = false;
  // deliverSiteDone: boolean = false;
  loadSpinner: boolean = false;
  showNoRec: boolean;
  functionId = '1';
  selectedSiteData: any;
  comTechUser: boolean = false;
  esaUser: boolean = false;
  comBusinesServiceUser: boolean = false;
  comCPEUser: boolean = false;
  storeUser: boolean = false;
  cnaUser: boolean = false;
  prepaidUser: boolean = false;
  enableDone: boolean = false;
  request: any;
  reportFeilds: any;
  checkRole: any;
  displayedColumns = [];
  columns = [];
  page: any;
  deliverySiteReq: any = null;
  isPrepaid: boolean = true;

  selection: SelectionModel<any> = new SelectionModel<any>(false, []);
  dataSource: MatTableDataSource<any>;
  businessUsrObj: any;
  view: any;
  column;
  DelSiteindex;
  delLocVal;
  delAddress;
  delSiteVal;
  dynamicId: any;
  form = new FormGroup({});
  dynamicFieldsSpinner: boolean = false;
  dynamicFields: any = [];
  catalogObj: any;
  favorite: any;

  constructor(private reportsService: ReportsService, private comSettingService: CommonSettingService,
    private router: Router, private constantData: ConstantData, private formBuilder: FormBuilder,) {
    this.dataSource = new MatTableDataSource(this.siteDetails);
    this.dataSource.paginator = this.paginator;
    if (this.router.getCurrentNavigation().extras.state != undefined) {
      this.page = this.router.getCurrentNavigation().extras.state.page;
    }
    if (this.page == 'catalog') {
      this.businessUsrObj = this.router.getCurrentNavigation().extras.state.businessUsrObj;
      this.catalogObj = this.router.getCurrentNavigation().extras.state.catalogObj;
      this.view = this.router.getCurrentNavigation().extras.state.view
      this.favorite = this.router.getCurrentNavigation().extras.state.favorite
    }
    if (this.page == 'cart') {
      this.column = this.router.getCurrentNavigation().extras.state.column;
      this.DelSiteindex = this.router.getCurrentNavigation().extras.state.DelSiteindex;
    }
    if (this.page == 'bu-administration') {
      this.column = this.router.getCurrentNavigation().extras.state.columnName;
      this.delSiteVal = this.router.getCurrentNavigation().extras.state.delSiteVal;
    }
    if (this.page == 'settings') {
      this.column = this.router.getCurrentNavigation().extras.state.columnName;
      this.delSiteVal = this.router.getCurrentNavigation().extras.state.delSiteVal;
      this.delLocVal = this.router.getCurrentNavigation().extras.state.delLocVal;
    }
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.enableDone = false;
    this.dynamicId = (localStorage.getItem('deliverSitedynamicId') !== undefined && localStorage.getItem('deliverSitedynamicId') !== null) ? localStorage.getItem('deliverSitedynamicId') : ''
    if (this.dynamicId == '' || this.dynamicId == undefined) {
      this.dynamicId = this.constantData.deliverySiteId[this.functionId];
    }
    this.onGetReportFields();
    if (this.delSiteVal != undefined && this.delSiteVal != null) {
      this.siteValue = this.delSiteVal;
    }
  }

  onGetReportFields() {
    this.dynamicFieldsSpinner = true;
    let request = {
      ReportId: this.dynamicId,
      ParametersInput: [
        {
          Name: "P_REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.getReportDisplayFields(request).subscribe(response => {
      if (response != undefined) {
        this.dynamicFieldsSpinner = false;
        for (let control of response.ReportDisplayFieldsOutput) {
          this.dynamicFields.push(control);
        }
        this.form = this.createDynamicForm();
        // this.loader = false;
      } else {
        this.dynamicFieldsSpinner = false;
      }
    }, (error) => { this.dynamicFieldsSpinner = false; })
  }

  createDynamicForm() {
    let dynamicForm = this.formBuilder.group({});
    this.dynamicFields.forEach(control => {
      dynamicForm.addControl(control.name, this.formBuilder.control(''));
      if(control.name == 'CUSTOMER' && this.functionId == '57'){
        dynamicForm.controls['CUSTOMER'].setValue('Prepaid Dealer');
      }
      if (control.name == 'REQUESTOR_NAME') {
        dynamicForm.controls['REQUESTOR_NAME'].setValue(this.userInfo.NTID);
        control.value = this.userInfo.NTID;
      }
    });
    return dynamicForm;
  }

  onSearchClick(event) {
    this.loadSpinner = false;
    this.showResults = false;
    this.displayedColumns = [];
    this.columns = [];
    let visibleCols = [];
    if (event.type == "click") {
      this.loadSpinner = true;
    }
    if (this.deliverySiteReq) {
      this.deliverySiteReq.unsubscribe();
    }
    let request = {
      ReportId: this.dynamicId,
      ParametersInput: [
      ]
    };

    var formData = this.form.value;
    request.ParametersInput.push({
      "Name": "P_REQUESTOR_NAME",
      "Value": this.userInfo.NTID
    })
    for (var key in formData) {
      if (formData.hasOwnProperty(key)) {
        request.ParametersInput.push({
          "Name": key,
          "Value": formData[key] == "" || formData[key] == null ? "" : formData[key].toString()
        })
      }
    }
    this.deliverySiteReq = this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW != undefined) {
        this.siteDetails = response.ROW;
        this.siteDetails.forEach(data => {
          for (const key in data) {
            if (this.siteDetails.indexOf(data) == 0 && data['DISPLAY_COLUMNS'] != undefined) {
              visibleCols = data['DISPLAY_COLUMNS'].split(',');
              // allCols.push(`${key}`);
            }
          }
        })
        let displayCols = visibleCols;
        if (this.displayedColumns.length == 0) {
          this.displayedColumns.push("selected");
          displayCols.forEach(col => {
            this.columns.push(col);
            this.displayedColumns.push(col);
          })
        }
        this.showResults = true;
        this.loadSpinner = false;
        this.showNoRec = false;
        this.siteDetails.map(function (material) {
          material.selected = "false",
            material.selectable = "true"

        });
      } else {
        this.showResults = false;
        this.loadSpinner = false;
        this.showNoRec = true;
      }
      this.dataSource = new MatTableDataSource<any>(this.siteDetails);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.loadSpinner = false;
      this.showNoRec = true;
      console.log("error:", error);
    })

  }

  selectRow(row) {
    this.dataSource.filteredData.forEach((row) => {
      if (row.selected == true) {
        // console.log("previous selected row >>>>>" + JSON.stringify(row));
        row.selected = false;
      }
    });
    if (this.siteDetails != null || this.siteDetails != undefined) {
      row.selected = true;
      this.enableDone = true;
      this.selection.select(row);
      this.selectedSiteData = row;
    }
    // console.log("deliver site",this.selectedSiteData)
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  onBackClick() {
    // this.router.navigate(['hub2u/settings/']);
    if (this.page != undefined && this.page == "cart") {
      this.router.navigate(['hub2u/catalog/cart']);
    }
    else if (this.page != undefined && this.page == "catalog") {
      // if(this.functionId == '51') {
        if(this.functionId == '136') {
        this.router.navigate(['hub2u/catalog'], { state: { businessUsrObj: this.businessUsrObj, catalogObj: this.catalogObj, view: this.view, favorite: this.favorite } });
      } else {
        this.router.navigate(['hub2u/catalog'], { state: { catalogObj: this.catalogObj, view: this.view, favorite: this.favorite } });
      }
    }
    else if (this.page != undefined && this.page == 'bu-administration') {
      this.router.navigate(['hub2u/bu-administration/']);
    }
    else {
      this.router.navigate(['hub2u/settings/']);
    }
  }

  onDoneClick() {
    this.comSettingService.setdeliverSite(this.selectedSiteData, this.column, this.DelSiteindex);
    if (this.page != undefined && this.page == "cart") {
      this.router.navigate(['hub2u/catalog/cart']);
    }
    else if (this.page != undefined && this.page == "catalog") {
      // if(this.functionId == '51') {
        if(this.functionId == '136') {
        this.router.navigate(['hub2u/catalog'], { state: { businessUsrObj: this.businessUsrObj, catalogObj: this.catalogObj, view: this.view, favorite: this.favorite } });
      } else {
        this.router.navigate(['hub2u/catalog'], { state: { catalogObj: this.catalogObj, view: this.view, favorite: this.favorite } });
      }
    }
    else if (this.page != undefined && this.page == 'bu-administration') {
      this.router.navigate(['hub2u/bu-administration/']);
    }
    else {
      this.comSettingService.setdeliverSite(this.selectedSiteData, this.column, this.delLocVal);
      this.router.navigate(['hub2u/settings/']);
    }
  }

}

export interface Element {
  ADDRESS: string;
  CHANNEL: string;
  CONTACT_EMAIL: string;
  'CONTACT INFO': string;
  CUSTOMER: string;
  LOCATION_DESCRIPTION: string;
  LOCATION_TYPE: string;
  SITE_ID: string;
  SITE_DESCRIPTION: string;
  selected: boolean;
  selectable?: boolean;
}