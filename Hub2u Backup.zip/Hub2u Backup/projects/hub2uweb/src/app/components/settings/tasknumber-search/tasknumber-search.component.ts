import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { ReportsService, FilterpipePipe } from 'hub2ushared';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { CommonSettingService } from '../../../shared/common-settings.service';

@Component({
  selector: 'app-tasknumber-search',
  templateUrl: './tasknumber-search.component.html',
  styleUrls: ['./tasknumber-search.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class TasknumberSearchComponent implements OnInit {
  TaskNumber = '';
  bUnit;
  TaskName = '';
  userInfo
  taskdetails;
  requestParams;
  responseResults = false;
  showNoRec: boolean = false;
  loadSpinner: boolean = false;
  enableDone: boolean = false;
  selectedCardData;
  taskColName: any;
  innertaskRowIndex: any;
  taskIndex: any;
  page: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  taskNumReq: any = null;
  displayedColumns = [];
  columns = [];
  selection: SelectionModel<any> = new SelectionModel<any>(false, []);
  dataSource: MatTableDataSource<any>;

  constructor(private comSettingService: CommonSettingService, private router: Router,
    private reportsService: ReportsService) {
    if (this.router.getCurrentNavigation().extras.state != undefined ||
      this.router.getCurrentNavigation().extras.state != null) {
      this.requestParams = this.router.getCurrentNavigation().extras.state.data;
      this.page = this.router.getCurrentNavigation().extras.state.page;
    }
    if (this.page == 'cart') {
      this.taskColName = this.router.getCurrentNavigation().extras.state.taskColName;
      this.taskIndex = this.router.getCurrentNavigation().extras.state.taskIndex;
      this.innertaskRowIndex = this.router.getCurrentNavigation().extras.state.innertaskRowIndex;
      this.requestParams = this.router.getCurrentNavigation().extras.state.row;
    }
  }

  ngOnInit() {
    this.enableDone = false;
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
  }

  onTaskSearch(event) {
    this.displayedColumns = [];
    this.columns = [];
    let visibleCols = [];
    if (event.type == "click") {
      this.loadSpinner = true;
    }
    //1086 - reportID
    if (this.taskNumReq) {
      this.taskNumReq.unsubscribe();
    }
    let req = {
      "ReportId": "10193", "ParametersInput": [
        { "Name": "PROJECT_ID", "Value": this.requestParams['PROJECT_ID'] ? this.requestParams['PROJECT_ID'] : this.requestParams.projectId },
        { "Name": "BUSINESS_UNIT", "Value": "null" },
        { "Name": "TASK_NUMBER", "Value": this.TaskNumber != '' ? this.TaskNumber : 'null' },
        { "Name": "TASK_NAME", "Value": this.TaskName != '' ? this.TaskName : 'null' },
        { "Name": "PROJECT_NUMBER", "Value": this.requestParams['Project Number'] },
        { "Name": "TASK_TYPE", "Value": this.requestParams != undefined ? this.requestParams['attribute1'] : 'null' },
        { "Name": "EXPENDITURE_TYPE", "Value": "null" },
        { "Name": "REQUESTOR_NAME", "Value": this.userInfo.NTID },
        { "Name": "CIFA_ITEM_NUMBER", "Value": this.requestParams['CIFA#'] }
      ]
    }

    this.taskNumReq = this.reportsService.onGetDynamicReport(req).subscribe(res => {
      this.taskdetails = res.ROW;
      if (this.taskdetails != null && this.taskdetails != undefined) {
        this.taskdetails.forEach(data => {
          for (const key in data) {
            if (this.taskdetails.indexOf(data) == 0) {
              visibleCols = data['HEADER_COLUMNS'].split(',');
            }
          }
        })
        let displayCols = visibleCols;
        if (this.displayedColumns.length == 0) {
          this.displayedColumns.push("selected");
          displayCols.forEach(col => {
            this.columns.push(col);
            this.displayedColumns.push(col);
          })
        }
        this.responseResults = true;
        this.showNoRec = false
        this.loadSpinner = false;
        this.taskdetails.map(function (material) {
          material.selected = "false",
            material.selectable = "true"
        });
      }
      else {
        this.showNoRec = true
        this.loadSpinner = false;
        this.responseResults = false;
      }
      this.dataSource = new MatTableDataSource<any>(this.taskdetails);
      setTimeout(() => {
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }, 300)
    }, error => {
      this.loadSpinner = false;
    })

  }
  ngOnChanges() {
    this.dataSource = new MatTableDataSource<any>(this.taskdetails);
    setTimeout(() => {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, 300)
  }

  selectedRow(row) {
    this.dataSource.filteredData.forEach((row) => {
      if (row.selected == true) {
        row.selected = false;
      }
    });
    row.selected = true;
    this.enableDone = true;
    this.selection.select(row);
    this.selectedCardData = row;
    //console.log("selectedCardData",this.selectedCardData)
  }

  onSelectionTaskNo() {
    this.comSettingService.setTaskNumber(this.selectedCardData, this.taskColName, this.taskIndex, this.innertaskRowIndex);
    this.router.navigate(['hub2u/catalog/cart'], {
      state: { page: "cart", data: this.selectedCardData }
    });
  }

  onBackClick() {
    this.router.navigate(['hub2u/catalog/cart']);
  }

}
