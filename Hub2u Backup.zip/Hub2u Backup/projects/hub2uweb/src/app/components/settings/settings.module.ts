import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatBadgeModule } from '@angular/material/badge';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTabsModule } from '@angular/material/tabs';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { SearchComponent } from './search/search.component';
import { OptionsComponent } from './options/options.component';
import { InventoryComponent } from './inventory/inventory.component';
import { DeliverSiteComponent } from './deliver-site/deliver-site.component';
import { SettingsComponent } from './setting.component';
import { Hub2usharedModule } from 'hub2ushared';
import { MatRadioModule } from '@angular/material/radio';
import { CdkTableModule } from '@angular/cdk/table';
import { WareHouseComponent } from './ware-house/ware-house.component';
import { MatSortModule } from '@angular/material/sort';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { NgxSpinnerModule } from 'ngx-spinner';
import { SourceSiteComponent } from './source-site/source-site.component';
import { DeliverLocationComponent } from './deliver-location/deliver-location.component';
import { TasknumberSearchComponent } from './tasknumber-search/tasknumber-search.component';
import { JobidComponent } from './jobid/jobid.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';


const routes: Routes = [
  {
    path: '',
    component: SettingsComponent,
    children: [
      { path: '', component: OptionsComponent,data: {
        breadcrumb: 'SETTINGS'}, },
      { path: 'search', component: SearchComponent },
      { path: 'deliver', component: DeliverSiteComponent },
      { path: 'inventory', component: InventoryComponent },
      { path: 'source', component: WareHouseComponent},
      { path: 'deliverToLoc', component: DeliverLocationComponent},
      { path: 'sourceSite', component: SourceSiteComponent},
      { path: 'tasknosearch', component:TasknumberSearchComponent } ,
      { path: 'jobIdSearch', component:JobidComponent }
    ]
  }
];

@NgModule({

  declarations: [SettingsComponent, SearchComponent, OptionsComponent, 
    InventoryComponent,DeliverSiteComponent,
    WareHouseComponent,DeliverLocationComponent,SourceSiteComponent,TasknumberSearchComponent,JobidComponent],
  imports: [
    Hub2usharedModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    MatPaginatorModule,
    MatSortModule,
    MatTableModule,
    MatToolbarModule,
    MatBadgeModule,
    MatButtonModule,
    MatSelectModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatGridListModule,
    MatNativeDateModule,
    MatIconModule,
    MatTabsModule,
    MatSlideToggleModule,
    MatRadioModule,
    MatSnackBarModule,
    CdkTableModule,
    NgxSpinnerModule,
    RouterModule.forChild(routes)
  ],
  providers: [
    { provide: MatDialogRef, useValue: {} },
    { provide: MAT_DIALOG_DATA, useValue: [] }
   ]
})
export class SettingsModule { }
