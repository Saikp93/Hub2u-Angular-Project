import { AfterViewInit, Component, OnInit, Renderer2, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonService, SettingsService, ConstantData, ReportsService } from 'hub2ushared';
import { EventService } from '../../../shared/event.service';
import { CommonWebService } from '../../../shared/common-web.service';
import { CommonSettingService } from '../../../shared/common-settings.service';


@Component({
  selector: 'app-options',
  templateUrl: './options.component.html',
  styleUrls: ['./options.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class OptionsComponent implements OnInit {
  isUpdatedAddress = true;
  userInfo: any = {};
  userRole: any = '';
  role: any;
  functionId = '1';
  userName: any;
  userMail: any;
  supervisorName: any;
  supervisorMail: any;
  userValues: any;
  person_id: any;
  comTechUser: boolean = false;
  esaUser: boolean = false;
  comBusinesServiceUser: boolean = false;
  comCPEUser: boolean = false;
  storeUser: boolean = false;
  cnaUser: boolean = false;
  prepaidUser: boolean = false;
  tempURole: any;
  dynamicForm = new FormGroup({});
  dynamicFields: any = [];
  displayFields = [];
  editableFields = [];
  mappingList = [];
  subInvmappingList = [];
  saveSettingColumnMap = [];
  defBsuUnit: boolean;
  respList: any = [];
  loader: boolean = false;
  resp: any[] = [];
  disableSave: boolean = false;
  errMsg: string;
  noData: boolean = false;
  label: any;
  isInvalid: boolean = false;
  locationOrgCode = '';
  locationOrgId = '';
  regionName = '';

  constructor(private router: Router, private reportsService: ReportsService,
    private constants: ConstantData, public navCtrl: NavController,
    public fb: FormBuilder, private comSettingService: CommonSettingService,
    private eventService: EventService, private settingsService: SettingsService,
    private commonWebService: CommonWebService, private commonService: CommonService,
    private renderer: Renderer2) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.onSwitchNPID();
    this.onInitialLoad();
    this.fetchDynamicFeilds();
    this.fetchMappingFeilds();
    this.loader = true;
  }

  async onInitialLoad() {
    this.fetchDynamicReports();
  }

  onSwitchNPID() {
    this.commonService.switchNPID.subscribe(data => {
      this.comSettingService.setdeliverSite(null);
    })
  }
  fetchDynamicReports() {

    this.reportsService.getCpeOrderReeport().subscribe(response => {
      this.userValues = response.reportNamesOutput;
    })
    let request = {
      // ReportId: 112, //this.userValues[0].reportId
      // ReportId: "7001",
      ReportId: this.constants.userprofileData[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };

    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW !== undefined) {
        this.respList = response.ROW[0];
        this.person_id = response.ROW[0].PERSON_ID
      } else {
        this.loader = false;
      }
    }, error => {
      this.loader = false;
    });

  }

  fetchDynamicFeilds() {
    let reportId: any;
    this.dynamicFields = [];
    this.loader = true;
    if (this.functionId != undefined) {
      reportId = this.constants.settingsDynamicFields[this.functionId];
    }
    let request = {
      ReportId: reportId, //this.userValues[0].reportId
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        },
        {
          Name: "PROFILE_TYPE",
          Value: this.userRole ? this.userRole.toUpperCase() : ''
        }
      ]
    };

    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW != undefined) {
        this.noData = false;
        let resp = response.ROW || [];
        for (let control of response.ROW) {
          this.dynamicFields.push(control);
        }
        // console.log("dynamicFields", this.dynamicFields);
        this.userName = resp[0]['EMPLOYEE_NAME'];
        this.userMail = resp[0]['EMPLOYEE_EMAIL'];
        this.supervisorName = resp[0]['SUPERVISOR_NAME'];
        this.supervisorMail = resp[0]['SUPERVISOR_EMAIL'];
        this.displayFields = this.OrganizedCart(resp, 'DISPLAY_COLUMNS');
        this.editableFields = this.OrganizedCart(resp, 'EDITABLE_COLUMNS');
        this.dynamicForm = this.createDynamicForm();
        // this.dynamicForm.controls[delColName].setValue(this.comSettingService.delLocCode.LOCATION_CODE)
        if (sessionStorage.getItem("Prev_Url").indexOf("settings") > -1) {
          if (this.comSettingService.deliverSite !== undefined && this.comSettingService.deliverSite !== null) {
            this.updateDeliveryToSite();
          }
          if (this.comSettingService.wareHouseCode !== undefined && this.comSettingService.wareHouseCode !== null) {
            this.updateSourceWarehouse();
          }
          if (this.comSettingService.delLocCode !== undefined && this.comSettingService.delLocCode !== null) {
            this.updateDeliveryToLoc();
          }
          if (this.comSettingService.projectVal !== undefined && this.comSettingService.projectVal !== null) {
            this.updateProjectNum();
          }
          if (this.comSettingService.sourceSite !== undefined && this.comSettingService.sourceSite !== null) {
            this.updateSourceSite();
          }
          if (this.comSettingService.subInv !== undefined && this.comSettingService.subInv !== null) {
            this.updateSubInv();
          }
          if (this.comSettingService.getInvCode() !== undefined && this.comSettingService.getInvCode() !== null) {
            this.dynamicForm.controls['subinventory'].setValue(this.comSettingService.getInvCode())
          }
          if (this.comSettingService.getOrderType() !== undefined && this.comSettingService.getOrderType() !== null) {
            this.dynamicForm.controls['attribute5'].setValue(this.comSettingService.getOrderType())
          }
        }
        if (sessionStorage.getItem("Prev_Url").indexOf("wms") > -1) {
          if (this.comSettingService.wareHouseCode !== undefined) {
            this.updateSourceWarehouseWMS();
          }
        }
        this.loader = false;
        this.onSubInvClick();
      }
      else {
        this.loader = false;
        this.noData = true;
        this.userMail = "No Data Found!"
        this.supervisorMail = "No Data Found!";
      }
    }, error => {
      this.loader = false;
      this.noData = true;
      this.userMail = "No Data Found!"
      this.supervisorMail = "No Data Found!";
    })
  }
  getOpt(val) {
    console.log(val == 'false' ? true : false);
    return val == 'false' ? true : false;
  }
  fetchMappingFeilds() {
    let request = {
      ReportId: this.constants.settingsDynamicFields[this.functionId], //this.userValues[0].reportId
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.getReportDisplayFields(request).subscribe(response => {
      if (response.ReportDisplayFieldsOutput != undefined) {
        for (let control of response.ReportDisplayFieldsOutput) {
          this.mappingList.push(control);
          if (control.name == 'MAPPING') {
            let saveSettingColumn = control.options;
            saveSettingColumn.forEach(x => {
              if (x.text !== undefined) {
                this.saveSettingColumnMap.push({ key: x.text, mappingname: x.value })
              }
            });
          }
        }
      } else {
        // this.loader = false;
      }
    }, error => {
      this.loader = false;
    })
  }

  getList(colName) {
    let respOrderList = [];
    for (let item of this.mappingList) {
      if (item.name == colName) {
        let orderList = item.options;
        orderList.forEach(x => {
          if (x.value !== undefined) {
            respOrderList.push(x.value)
          }
        });
      }
    }
    return respOrderList;
  }

  getSubInvList(colName) {
    let subInvList = [];
    // subInvList.push(' ')
    for (let item of this.subInvmappingList) {
      if (item.SUBINVENTORY_NAME !== undefined) {
        subInvList.push(item.SUBINVENTORY_NAME)
      }
    }
    return subInvList;
  }

  OrganizedCart(resp, col) {
    let display_column = [];
    if (resp[0][col] !== undefined) {
      display_column = this.convertToArray(resp[0][col]);
    }

    return display_column
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
      else {
        col = columns;
      }
    }
    return col;
  }

  isAvailable(key, data) {
    let dataToSearch = [];
    if (data == 'settingsFields') {
      dataToSearch = this.displayFields
    } else if (data == 'editableFields') {
      dataToSearch = this.editableFields
    }
    return dataToSearch.includes(key);
  }

  isReadOnly(label) {
    let isread = false;
    if (label === 'User Groups') {
      isread = true;
    }
    return isread;
  }
  createDynamicForm() {
    let dynamicForm = this.fb.group({});

    this.dynamicFields.forEach(control => {
      dynamicForm.addControl(control.SAVE_INPUT, this.fb.control(null));
      // console.log("dynamic", dynamicForm.controls)
      if (control.MANDATORY == 'Yes') {
        dynamicForm.controls[control.SAVE_INPUT].setValidators([Validators.required])
      }
      if (control.DEFAULT_VALUE) {
        control.DEFAULT_VALUE != 'null' ? dynamicForm.controls[control.SAVE_INPUT].setValue(control.DEFAULT_VALUE) : dynamicForm.controls[control.SAVE_INPUT].setValue('');
      }
      if (control.EDITABLE == 'false') {
        dynamicForm.controls[control.SAVE_INPUT].disable();
      }
      if (control.SAVE_INPUT === 'Defaultbusinessuser') {
        if (control.DEFAULT_VALUE === 'Y') {
          this.defBsuUnit = true;
        } else {
          this.defBsuUnit = false;
        }
      }
    });

    return dynamicForm;
  }

  ToggleDefaultBSU(key, toggle) {
    if (toggle === true) {
      this.defBsuUnit = true;
    } else {
      this.defBsuUnit = false;
    }
  }

  onSelection(key, event) {
    // console.log("value",key, event.value);
    if (key == 'subinventory') {
      this.comSettingService.setInvCode(event.value);
    }
    if (key == 'attribute5') {
      this.comSettingService.setOrderType(event.value);
    }
    this.dynamicForm.controls[key].setValue(event.value);
  }

  clickToNavigate(key, label, dqId) {
    let val = this.dynamicForm.get(key).value
    this.label = label;
    switch (label) {
      case 'Project Number':
        this.onProjNumNavigate(key, val);
        break;
      case 'Delivery To Location':
        this.onDeliverLocNavigate(key, val, dqId)
        break;
      case 'Source Site':
        this.onWareHouseNavigate(key, val, dqId)
        break;
      case 'Source Warehouse':
        this.onWareHouseNavigate(key, val, dqId)
        break;
      case 'Delivery To Site':
        this.onDeliverSiteNavigate(key, val, dqId)
        break;
      case 'Job ID':
        this.onJobIdNavigate(key, val, dqId);
        break;
    }
  }

  onSubInvClick() {
    this.subInvmappingList = [];
    //if (this.functionId == '99') {
      if (this.functionId == '143') { // cifa_to_iip
      var sourceOrg = this.dynamicForm.value.sourceLocation;
      var orgCode = this.dynamicFields.filter(val => val.SAVE_INPUT === "deliveryToLocation")
      let req = {
        ReportId: 10180,
        ParametersInput: [
          {
            // Name: "USER_NAME",
            Name: "REQUESTOR_NT_ID",
            Value: this.userInfo.NTID
          },
          {
            Name: "ORGANIZATION_CODE",
            Value: sourceOrg
          }
        ]
      };
      this.reportsService.getSubInv(req).subscribe(response => {
        if (response.ROW != undefined) {
          for (let control of response.ROW) {
            this.subInvmappingList.push(control);
          }
        }
      })
    }
  }

  onAddItem(size, item: any, key) {
    item.DEFAULT_VALUE = size.toString();
    this.dynamicForm.controls[key].setValue(item.DEFAULT_VALUE);
  }

  onProjNumNavigate(key, val) {
    // console.log("onProjNumNavigate", key, val)
    this.comSettingService.setSettingProjectCode(val, key);
    this.router.navigate(['hub2u/settings/search'], {
      state: { page: "settings", projectColName: key, projectVal: val }
    });
  }

  onWareHouseNavigate(key, val, dqId) {
    let navigateLink = (this.label === "Source Site") ? 'hub2u/settings/sourceSite' : 'hub2u/settings/source';
    this.comSettingService.setWareHouseCode(val, key);
    localStorage.setItem("wareHousedynamicId", dqId);
    this.router.navigate([navigateLink], {
      state: { page: "settings", sourceSiteName: key, sourceSiteVal: val }
    });
  }

  onDeliverLocNavigate(key, val, dqId) {
    // let navigateLink = (this.label === "Delivery To Site") ? 'hub2u/settings/deliver' : 'hub2u/settings/deliverToLoc';
    this.comSettingService.setdelLocCode(val, key);
    localStorage.setItem("deliverLocdynamicId", dqId);
    this.router.navigate(['hub2u/settings/deliverToLoc'],
      {
        state: { page: "settings", delLocName: key, delLocVal: val },
      }
    );
  }
  onDeliverSiteNavigate(key, val, dqId) {
    this.comSettingService.setdeliverLoc(val);
    localStorage.setItem("deliverSitedynamicId", dqId);
    this.router.navigate(['hub2u/settings/deliver'], {
      state: { page: "settings", columnName: key, delSiteVal: val }
    });
  }
  onJobIdNavigate(key, val, index) {
    this.router.navigate(['hub2u/settings/jobIdSearch'], {
      state: { page: "cart", jobIdName: key, jobIdindex: index }
    });
  }

  //***************Update Navigate Values Start**********************/
  updateProjectNum() {
    this.isUpdatedAddress = true;
    let colNam = this.comSettingService.projectColName;
    this.dynamicForm.controls[colNam] ? this.dynamicForm.controls[colNam].setValue(this.comSettingService.projectVal['Project Number']) : '';

  }

  updateSourceSite() {
    this.isUpdatedAddress = true;
    let sourceColNam = this.comSettingService.sourceSiteName;
    this.dynamicForm.controls[sourceColNam] && (this.comSettingService.sourceSite.SITE_ID != undefined) ? this.dynamicForm.controls[sourceColNam].setValue((this.comSettingService.sourceSite.SITE_ID)) : '';
    let srcAddress;
    srcAddress = this.dynamicFields.filter(val => val.SAVE_INPUT == sourceColNam);
    if (srcAddress !== undefined && srcAddress !== null) {
      if (srcAddress.length > 0) {
        srcAddress[0].TOOL_TIP = this.functionId == '58' ? this.comSettingService.sourceSite.ADDRESS.replace(/,\s*$/, "") : this.comSettingService.sourceSite.ADDRESS;
      }
    }
  }

  updateSourceWarehouse() {
    this.isUpdatedAddress = true;
    let sourceColNam = this.comSettingService.sourceSiteName;
    this.dynamicForm.controls['subInventory'].reset();
    this.dynamicForm.controls[sourceColNam] && (this.comSettingService.wareHouseCode.ORGANIZATION_CODE != undefined) ? this.dynamicForm.controls[sourceColNam].setValue(this.comSettingService.wareHouseCode.ORGANIZATION_CODE) : this.comSettingService.wareHouseCode;
  }

  updateSourceWarehouseWMS() {
    this.isUpdatedAddress = true;
    // console.log("sourceSiteName", this.comSettingService.sourceSiteName, this.comSettingService.wareHouseCode, this.comSettingService.wareHouseCode.ORGANIZATION_CODE)
    let sourceColNam = "sourceLocation";
    this.dynamicForm.controls[sourceColNam] && (this.comSettingService.wareHouseCode.ORGANIZATION_CODE != undefined) ? this.dynamicForm.controls[sourceColNam].setValue(this.comSettingService.wareHouseCode.ORGANIZATION_CODE) : this.comSettingService.wareHouseCode;
  }

  updateDeliveryToLoc() {
    this.isUpdatedAddress = true;
    let delColName = this.comSettingService.delLocName;
    (this.dynamicForm.controls[delColName] && (this.comSettingService.delLocCode.LOCATION_CODE != undefined)) ? this.dynamicForm.controls[delColName].setValue(this.comSettingService.delLocCode.LOCATION_CODE) : this.dynamicForm.controls[delColName].setValue(this.comSettingService.delLocCode);
    if (this.dynamicForm.controls[delColName] && (this.comSettingService.delLocCode)) {
      this.regionName = this.comSettingService.delLocCode.REGION_NAME;
      this.locationOrgCode = this.comSettingService.delLocCode.ORGANIZATION_CODE;
      this.locationOrgId = this.comSettingService.delLocCode.DELIVER_TO_ORG_ID;
      if (this.regionName == 'KEYSTONE_REGION') {
        this.dynamicForm.controls['projectNumber'].disable();
        this.dynamicFields.forEach(control => {
          if (control.COLUMN_NAME == 'PROJECT_NUMBER') {
            control.EDITABLE = 'false';
            this.dynamicForm.controls['projectNumber'].disable();
            this.dynamicForm.controls['projectNumber'].setValue(null);
            if (this.comSettingService.projectVal != undefined) {
              this.comSettingService.projectVal['Project Number'] = null;
            }
          }
        })
      } else {
        this.dynamicForm.controls['projectNumber'].enable();
        this.dynamicFields.forEach(control => {
          if (control.COLUMN_NAME == 'PROJECT_NUMBER') {
            control.EDITABLE = 'true';
            this.dynamicForm.controls['projectNumber'].setValue(control.DEFAULT_VALUE)
          }
        })

      }
    }

  }
  updateSubInv() {
    this.isUpdatedAddress = true;
    let subInvName = this.comSettingService.subInvName;
    (this.dynamicForm.controls[subInvName] && (this.comSettingService.subInv['Inventory Name'] != undefined)) ? this.dynamicForm.controls[subInvName].setValue(this.comSettingService.subInv['Inventory Name']) : this.dynamicForm.controls[subInvName].setValue(this.comSettingService.subInv);
  }
  updateDeliveryToSite() {
    let delSiteName = this.comSettingService.columnName;
    (this.dynamicForm.controls[delSiteName] && (this.comSettingService.deliverSite.SITE_ID != undefined)) ? this.dynamicForm.controls[delSiteName].setValue((this.comSettingService.deliverSite.SITE_ID)) : '';
    let address, delAddress;
    address = this.dynamicFields.filter(val => val.SAVE_INPUT == delSiteName);
    if (address !== undefined && address !== null) {
      if (address.length > 0) {
        address[0].TOOL_TIP = this.functionId == '58' ? this.comSettingService.deliverSite.ADDRESS.replace(/,\s*$/, "") : this.comSettingService.deliverSite.ADDRESS;
        // if (this.functionId == '51' || this.functionId == '57') {
        if (this.functionId == '136' || this.functionId == '57') {
          address[0].ADD_ON = this.comSettingService.deliverSite.SITE_DESCRIPTION;
          address[0].CUSTOMER = this.comSettingService.deliverSite.CUSTOMER;
        }
      }
    }
    this.isUpdatedAddress = true;
  }
  //***************Update Navigate Values End**********************/

  newSourceValue: any;

  showmatErr: boolean = false;
  checkStatus() {
    this.eventService.showSpinner();
    let requ = {
      ReportId: "10008",
      ParametersInput: [
        {
          Name: "P_REQUESTOR_NAME",
          Value: this.userInfo.NTID
        },
        {
          Name: "ORGANIZATION_CODE",
          Value: this.newSourceValue
        },
        {
          Name: "LOCATION_CODE",
          Value: ""
          // Value: this.deliverToLoc
        },
        {
          Name: "DESCRIPTION",
          Value: ""
        }
      ]
    };
    this.reportsService.onGetDynamicReport(requ).subscribe(response => {
      // console.log("options page dynamic search reports", response.ROW);
      if (response.ROW == undefined || response.ROW == null) {
        this.disableSave = true;
        this.eventService.hideSpinner();
        this.showmatErr = true;
        this.errMsg = "Invalid location. Please use the select feature to choose the correct location"
      } else if (response.ROW !== undefined && response.ROW.length > 1) {
        this.showmatErr = true;
        this.disableSave = true;
        this.eventService.hideSpinner();
        this.errMsg = "There are multpile options available for the location code. Please use the select feature to choose the correct location"
      }
    })
  }
  deliverToSite: any = '';
  projNum: any = '';
  input: any;
  validateAdress(input) {
    this.isUpdatedAddress = false;
    this.input = input;
  }

  saveRequest: any;
  getAddressVal(key) {
    let address, delAddress;
    address = this.dynamicFields.filter(val => val.SAVE_INPUT == key);
    // if (address !== undefined && address !== null && this.functionId == '51') {
    if (address !== undefined && address !== null && this.functionId == '136') {
      delAddress = address.length > 0 ? address[0].TOOL_TIP : null;
    } else if (address !== undefined && address !== null) {
      delAddress = address.length > 0 ? address[0].TOOL_TIP : null;
    }

    let siteDesc, siteDescVal;
    siteDesc = this.dynamicFields.filter(val => val.SAVE_INPUT === "deliveryToLocation");
    // if (siteDesc !== undefined && siteDesc !== null && this.functionId == '51') {
    if (siteDesc !== undefined && siteDesc !== null && this.functionId == '136') {
      if (key === "deliveryToLocation")
        siteDescVal = siteDesc.length > 0 ? (siteDesc[0].ADD_ON ? '|' + siteDesc[0].ADD_ON : '|null') : null;
    }
    return delAddress !== null ? '|' + delAddress + (siteDescVal !== null && siteDescVal !== undefined ? siteDescVal : '') : '';
  }

  getCustomer(key) {
    let customer, customerVal;
    customer = this.dynamicFields.filter(val => val.SAVE_INPUT === "deliveryToLocation");
    // if (customer !== undefined && customer !== null && (this.functionId == '57' || this.functionId == '51')) {
    if (customer !== undefined && customer !== null && (this.functionId == '57' || this.functionId == '136')) {
      if (key === "deliveryToLocation")
        customerVal = customer.length > 0 ? (customer[0].CUSTOMER ? customer[0].CUSTOMER + '|' : 'null|') : null;
    }
    return (customerVal !== null && customerVal !== undefined) ? customerVal : '';
  }

  onSaveSettings() {
    console.log("valid", this.dynamicForm.valid)
    if (!this.dynamicForm.valid) {
      this.isInvalid = true
      return;
    }
    this.eventService.showSpinner();
    let req, delToLoc, sourceLoc;
    var formData = this.dynamicForm.getRawValue();
    delToLoc = this.dynamicFields.filter(val => val.SAVE_INPUT == 'deliveryToLocation');
    sourceLoc = this.dynamicFields.filter(val => val.SAVE_INPUT == 'sourceLocation');
    // console.log("delLoc,sourceLoc",delToLoc,sourceLoc)
    if (delToLoc.length > 0 && sourceLoc.length > 0 && (this.dynamicForm.value['deliveryToLocation'] == this.dynamicForm.value['sourceLocation'])) {
      this.eventService.hideSpinner();
      this.commonWebService.openSnackBar("Source Site cannot be same as Delivery to Site", "WARNING");
    } else {
      if (this.isUpdatedAddress == false) {
        // if ((this.functionId == "51") && this.input === 'deliveryToLocation') {
        if ((this.functionId == "136") && this.input === 'deliveryToLocation') {
          let request = {
            ReportId: "1088",
            ParametersInput: [
              {
                Name: "P_REQUESTOR_NAME", Value: this.userInfo.NTID
              },
              {
                Name: "CUSTOMER", Value: ''
              },
              {
                Name: "SITE_ID", Value: formData.deliveryToLocation
              },
              {
                Name: "CITY", Value: ''
              },
              {
                Name: "STATE", Value: ''
              },
              {
                Name: "ZIP_CODE", Value: ''
              }
            ]
          }
          this.reportsService.onGetDynamicReport(request).subscribe(response => {
            this.deliverToSite = response.ROW;
          })

        }
      }
      setTimeout(() => {
        req = {}
        // req["attribute3"] = this.userRole.toUpperCase();
        req["profileType"] = this.userRole.toUpperCase();
        if (this.locationOrgId != '' && this.locationOrgId != undefined &&
          this.locationOrgCode != '' && this.locationOrgId != undefined) {
          req["expenditureOrgId"] = this.locationOrgId;
          req["expenditureOrg"] = this.locationOrgCode;
        }
        // if(this.functionId == '50' || this.functionId == '51' || this.functionId == '57'){
        if (this.functionId == '50' || this.functionId == '136' || this.functionId == '57') {
          if (this.respList.SOURCE_LOCATION) {
            req["sourceLocation"] = this.respList.SOURCE_LOCATION
          }
        }
        req["personId"] = this.person_id ? this.person_id : null;
        req["userName"] = this.userInfo.NTID;
        for (var key in formData) {
          req[key] = this.getCustomer(key) + formData[key] + this.getAddressVal(key);
          req[key] = req[key] == "null" ? "" : req[key];
          // if (req['subinventory'] != undefined && req['subinventory'] != '') {
          //   req['subinventory'] = (req[key] == "--Select--") ? "" : req[key];
          // }
          if (req['needByDateTime'] != undefined && req['needByDateTime'] != '') {
            req['needByDateTime'] = req['needByDateTime'] != 0 ? req['needByDateTime'] : 1;
          }
          req["Defaultbusinessuser"] = (this.defBsuUnit == true) ? 'Y' : 'N'
        }
        let request = {
          profile: this.userRole.toUpperCase(),
          preferencesUpsertDetails: req
        }

        if (this.isUpdatedAddress == false) {
          if (this.deliverToSite !== undefined && this.projNum !== undefined) {
            if (((this.projNum != "") && (this.projNum[0].ProjectNumber === formData.projectNumber) && (formData.projectNumber == "")) ||
              ((this.deliverToSite != "") && (this.deliverToSite[0].SITE_ID === formData.deliveryToLocation) && (formData.deliveryToLocation == ""))) {
              this.settingsService.onSaveSettings(request).subscribe(response => {
                this.eventService.hideSpinner();
                if (response.status == "SUCCESS") {
                  this.commonWebService.openSnackBar('Your changes have been saved successfully!', "SUCCESS");

                } else if (response.status == "FAILED") {
                  this.commonWebService.openSnackBar(response.statusMessage, "ERROR");
                }

              }, (error) => {
                this.eventService.hideSpinner();
                this.commonWebService.openSnackBar("Something went wrong. Please try again later", "ERROR");
              });
            } else {
              this.eventService.hideSpinner();
              this.commonWebService.openSnackBar("Enter Valid Values", "ERROR");
            }
          } else {
            this.eventService.hideSpinner();
            this.commonWebService.openSnackBar("Enter Valid Values", "ERROR");
          }
        } else if (this.isUpdatedAddress == true) {
          this.settingsService.onSaveSettings(request).subscribe(response => {
            this.eventService.hideSpinner();
            if (response.status == "SUCCESS") {
              this.commonWebService.openSnackBar('Your changes have been saved successfully!', "SUCCESS");

              // this.dynamicFields = [];
              // this.fetchDynamicFeilds();
            } else if (response.status == "FAILED") {
              this.commonWebService.openSnackBar(response.statusMessage, "ERROR");
            }

          },
            (error) => {
              this.eventService.hideSpinner();
              this.commonWebService.openSnackBar("Something went wrong. Please try again later", "ERROR");
            });
        }
      }, 2000);
    }
    sessionStorage.setItem("listOfCatalogs" + this.userInfo.NTID, "");
    sessionStorage.setItem(this.userInfo.NTID + "catalogObj", "");
  }
}
