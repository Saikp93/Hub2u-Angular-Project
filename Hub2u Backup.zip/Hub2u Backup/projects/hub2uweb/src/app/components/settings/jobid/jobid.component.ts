import { SelectionModel } from '@angular/cdk/collections';
import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit, Optional, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ReportsService } from 'hub2ushared';
import { CommonSettingService } from '../../../shared/common-settings.service';
import { FormBuilder, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-jobid',
  templateUrl: './jobid.component.html',
  styleUrls: ['./jobid.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class JobidComponent implements OnInit {

  userInfo: any = {};
  userRole: any = '';
  functionId = '1';
  jobIdSearchResults: any[] = [];
  jobIdResultsLength: any;
  selectJobData: any;
  jobIdName;
  page: any;
  jobIdResults: boolean = false;
  loadJobSpinner: boolean = false;
  showNoRec: boolean = false;
  enableDone: boolean = false;
  innerJobRowIndex: any;
  jobIdindex: any;
  jobValue = '';
  categoryValue = '';
  statusValue = '';
  divisonValue = '';
  displayedColumns: any[];
  columns = [];
  pageSize: any = 10;
  pageIndex: any = 0;
  pageEvent;
  jobIdRow: any;
  jobIdReq: any = null;
  jobIdStatusDropDown: any[] = [];
  categoryDropDown: any[] = [];
  jobIdDivisionDropDown: any[] = [];
  approvalText: any = "";
  form = new FormGroup({});
  dynamicFields: any = [];
  dynamicFieldsSpinner: boolean = false;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  selection: SelectionModel<ProjectData> = new SelectionModel<ProjectData>(false, []);

  dataSource: MatTableDataSource<any>;
  colName = "";

  constructor(public dialogRef: MatDialogRef<JobidComponent>,@Optional()  @Inject('environment') private env: any, private formBuilder: FormBuilder,
    private router: Router, private comSettingService: CommonSettingService, private http: HttpClient, private reportsService: ReportsService, @Inject(MAT_DIALOG_DATA) public data: any) {
    if (this.router.getCurrentNavigation() !== null && this.router.getCurrentNavigation().extras.state != undefined) {
      this.page = this.router.getCurrentNavigation().extras.state.page;
      if (this.page == 'cart') {
        this.jobIdRow = this.router.getCurrentNavigation().extras.state.row != undefined ? this.router.getCurrentNavigation().extras.state.row['DIVISION'] : '';
        this.jobIdName = this.router.getCurrentNavigation().extras.state.jobIdName;
        this.jobIdindex = this.router.getCurrentNavigation().extras.state.jobIdindex;
        this.innerJobRowIndex = this.router.getCurrentNavigation().extras.state.innerJobRowIndex;
      }

    }
    this.dataSource = new MatTableDataSource(this.jobIdSearchResults);
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.enableDone = false;
    if (this.data.page) {
      this.page = this.data.page
    }
    this.approvalText = localStorage.getItem('division');
    let division = this.userInfo.wareHouseDeatils.division;
    this.divisonValue = this.approvalText ? this.approvalText : division;
    this.onInitialLoad();
    this.getStatusDetails();
    this.getCategoryDetails();
    this.getDivisionDetails();

  }

  async onInitialLoad() {
    this.userInfo = await JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.onGetReportFields();
  }

  onGetReportFields() {
    this.dynamicFieldsSpinner = true;
    let request = {
      ReportId: 60199,
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.getReportDisplayFields(request).subscribe(response => {
      if (response != undefined) {
        this.dynamicFieldsSpinner = false;
        for (let control of response.ReportDisplayFieldsOutput) {
          this.dynamicFields.push(control);
        }
        this.form = this.createDynamicForm();
      } else {
        this.dynamicFieldsSpinner = false;
      }
    }, (error) => { this.dynamicFieldsSpinner = false; })
  }

  createDynamicForm() {
    let dynamicForm = this.formBuilder.group({});
    let division = this.userInfo.wareHouseDeatils.division;
    console.log('createDynamicForm',division,this.approvalText);
    this.dynamicFields.forEach(control => {
      console.log('control.name',control.name)
      dynamicForm.addControl(control.name, this.formBuilder.control(''));
      if (control.name == 'REQUESTOR_NAME') {
        dynamicForm.controls['REQUESTOR_NAME'].setValue(this.userInfo.NTID)
        control.value = this.userInfo.NTID;
      }
      if(control.name == 'DIVISION'){
        dynamicForm.controls["DIVISION"].setValue(this.approvalText ? this.approvalText : division)
      }
    });
    return dynamicForm;
  }

  getStatusDetails() {
    let reque = {
      ReportId: "50050",
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.onGetDynamicReport(reque).subscribe(response => {
      if (response != undefined && response.ROW != undefined) {
        this.jobIdStatusDropDown.push('--Select--');
        for (let projStat of response.ROW) {
          projStat = projStat.P2_PROJECT_STATUS;
          this.jobIdStatusDropDown.push(projStat);
        }
      }
    })
  }

  getCategoryDetails() {
    let reque = {
      ReportId: "10261",
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.onGetDynamicReport(reque).subscribe(response => {
      if (response != undefined && response.ROW != undefined) {
        this.categoryDropDown.push('--Select--');
        for (let categoryList of response.ROW) {
          categoryList = categoryList.CATEGORY;
          this.categoryDropDown.push(categoryList);
        }
      }
    })
  }

  getDivisionDetails() {
    let reque = {
      ReportId: "10240",
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.onGetDynamicReport(reque).subscribe(response => {
      if (response != undefined && response.ROW != undefined) {
        this.jobIdDivisionDropDown.push('--Select--')
        for (let divisionStat of response.ROW) {
          this.jobIdDivisionDropDown.push(divisionStat.DIVISION)
        }
      }
      if (this.divisonValue) {
        this.pageIndex = 0;
        this.paginator.pageIndex = 0;
        // this.jobIdSearchResponse('click')

      }
    })
  }

  public handlePage(e: any, length) {
    this.pageSize = e.pageSize;
    this.pageIndex = e.pageIndex + 1;
    this.jobIdResultsLength = length;
    this.loadJobSpinner = true;
    this.jobIdResults = false;
    this.jobIdSearchResponse('click')
  }

  onJobIdSearchClick(event) {
    this.pageIndex = 0;
    this.paginator.pageIndex = 0;
    this.jobIdSearchResponse(event)
  }
  jobIdSearchResponse(event) {
    this.displayedColumns = [];
    this.columns = [];
    this.jobIdSearchResults = [];
    this.enableDone = false;
    let visibleCols = [];
    // this.pageIndex = 0;
    if (event.type == "click") {
      this.loadJobSpinner = true;
    }
    let params;
    params = {
      pageNumber: this.pageIndex,
      pageSize: this.pageSize,
      category: this.form.value['CATEGORY'] ? this.form.value['CATEGORY'] : '',
      canonicalId: 'JB00',
      status: this.form.value['STATUS'] != '--Select--'? this.form.value['STATUS'] : '' ,
      divisions: this.form.value['DIVISION'] != '--Select--'? this.form.value['DIVISION'] : '' 
    }
    if (this.jobIdReq) {
      this.jobIdReq.unsubscribe();
    }
    this.jobIdReq = this.http.get(this.env.jobIdurl + '/api/pullP2JobDetails?', { params }).subscribe(response => {
      if (response != undefined && response[0].data != undefined && response[0].data.length != 0) {
        // const mapped = Object.entries(response).map(([type, value]) => ({type, value}));
        // this.jobIdSearchResults = mapped[1].value
        this.jobIdSearchResults = response[0].data;
        this.jobIdResultsLength = response[0].pageDetails.totalCount;
        this.jobIdSearchResults.forEach(data => {
          for (const key in data) {
            if (this.jobIdSearchResults.indexOf(data) == 0) {
              visibleCols = data['displayColumns'].split(',');
            }
          }
        })
        let displayCols = visibleCols;
        if (this.displayedColumns.length == 0) {
          this.displayedColumns.push("selected");
          displayCols.forEach(col => {
            this.columns.push(col.trim());
            this.displayedColumns.push(col.trim());
          })
        }
        this.jobIdResults = true;
        this.loadJobSpinner = false;
        this.showNoRec = false;
        this.jobIdSearchResults.map(function (material) {
          material.selected = "false",
          material.selectable = "true"
        });
        this.dataSource = new MatTableDataSource<any>(this.jobIdSearchResults);
        this.dataSource.filterPredicate = this.createFilter();
        this.dataSource.sort = this.sort;
      } else {
        this.jobIdResults = false;
        this.loadJobSpinner = false;
        this.showNoRec = true;
      }

    },
      error => {
        this.loadJobSpinner = false;
        this.showNoRec = true;
        console.log("error:", error)
      })
    // this.selectedRow(this.jobIdSearchResults);
  }

  filterValues = {};
  getValue(column, event) {
    this.colName = column;
    this.filterValues[column] = event.target.value;
    this.dataSource.filter = JSON.stringify(this.filterValues);
  }

  createFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data, filter): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      for (const [key, value] of Object.entries(searchTerms)) {
        if (`${value}` !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[`${key}`];
        }
      }

      let len = Object.keys(searchTerms).length;
      let searchArray = [];

      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            let word = searchTerms[col].trim().toLowerCase()
            if (data[col] !== null) {
              if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                searchArray.push(true);
                found = len === searchArray.length;
              }
            }
          }
          return found;
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction;
  }

  // ngAfterViewInit() {
  //   this.dataSource.paginator = this.paginator;
  //   this.dataSource.sort = this.sort;
  // }

  selectedRow(row) {
    this.dataSource.filteredData.forEach((row) => {
      if (row.selected == true) {
        // console.log("previous selected row >>>>>" + JSON.stringify(row));
        row.selected = false;
      }
    });
    if (this.jobIdSearchResults != null && this.jobIdSearchResults != undefined) {
      row.selected = true;
      this.enableDone = true;
      this.selection.select(row);
      this.selectJobData = row;
    }
  }
  onBackClick() {
    if (this.page == "cart") {
      this.router.navigate(['hub2u/catalog/cart']);
    }
    if (this.page == "issues_transfer") {
      this.dialogRef.close();
      // this.dialogRef.close();

      //this.router.navigate(['hub2u/wms/issuetoproject']);
    }
  }

  onDoneClick() {
    if (this.page != undefined && this.page == "cart") {
      this.comSettingService.setJobId(this.selectJobData, this.jobIdName, this.jobIdindex, this.innerJobRowIndex);
      this.router.navigate(['hub2u/catalog/cart']);
    }
    if (this.page != undefined && this.page == "issues_transfer") {
      //this.comSettingService.setJobIdinvop(this.selectJobData);
      this.dialogRef.close({ data: this.selectJobData });

      //this.router.navigate(['hub2u/wms/issuetoproject']);
    }
  }
}

export interface ProjectData {
  canonicalId: string;
  selected: boolean;
  selectable?: boolean;
}
