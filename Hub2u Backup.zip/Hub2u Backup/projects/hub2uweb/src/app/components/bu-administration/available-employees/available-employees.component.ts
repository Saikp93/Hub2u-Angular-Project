import { Component, OnInit, ViewChild } from '@angular/core';
import { AdministrationService } from 'hub2ushared';
import { CommonWebService } from '../../../shared/common-web.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-available-employees',
  templateUrl: './available-employees.component.html',
  styleUrls: ['./available-employees.component.scss'],
})
export class AvailableEmployeesComponent implements OnInit {

  loader: boolean = false;
  userInfo: any;
  userRole: any = '';
  availableEmployeesDataSource: MatTableDataSource<any>;
  displayedColumns: string[] = ['EMPLOYEE_NAME', 'action'];
  addLoading: any[] = [];

  private paginator: MatPaginator;
  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
  }

  constructor(private administrationService: AdministrationService, private commonWebService: CommonWebService) { }

  ngOnInit() {
    this.availableEmployeesDataSource = new MatTableDataSource<any>();
    this.loader = true;
    this.GetOtherUserList();
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
  }

  ngOnChanges() {
    setTimeout(() => {
      this.availableEmployeesDataSource.paginator = this.paginator;
    }, 1200)
  }

  ngOnLoad() {
    this.GetOtherUserList();
  }

  // GetOtherUserList(index?) {
  //   var request = {
  //     "BUSINESS_UNIT":"000854"
  //   }

  //   this.administrationService.getAvailableEmployees(request).subscribe((response:any) => {
  //     this.addLoading[index] = false;
  //     this.availableEmployeesDataSource = new MatTableDataSource<any>(response.UsersListOutput);
  //     this.availableEmployeesDataSource.paginator = this.paginator;
  //     this.ngOnChanges();
  //     this.loader = false;
  //   }, (error: any) => {
  //     console.log(error);
  //     this.loader = false;
  //   });
  // }

  /*SOA TO JAVA*/
  GetOtherUserList(index?) {
    var request = {
      "businessUnit": "000854"
    }

    this.administrationService.getAvailableEmployees(request).subscribe((response: any) => {
      this.addLoading[index] = false;
      if (response.status == "SUCCESS") {
        this.availableEmployeesDataSource = new MatTableDataSource<any>(response.buAdminUserList);
        this.availableEmployeesDataSource.paginator = this.paginator;
        this.ngOnChanges();
        this.commonWebService.openSnackBar(response.statusMessage, response.status);
        this.loader = false;
      }
      else {
        this.commonWebService.openSnackBar(response.statusMessage, response.status);
        this.loader = false;
      }
    }, (error: any) => {
      console.log(error);
      this.loader = false;
    });
  }

  // addToSelectedEmployeesByValue(v, index) {
  //   this.addLoading[index] = true;
  //   let request = {
  //     REQUESTOR_NAME: this.userInfo.NTID,
  //     InsertUsersDetailsInput: [{
  //       ATTRIBUTE1: v.EMPLOYEE_NTUSERNAME,
  //       ATTRIBUTE2: v.EMPLOYEE_NAME,
  //       BUSINESS_UNIT: v.BUSINESS_UNIT,
  //       PERNR: v.PERNR,
  //       PERSON_ID: v.PERSON_ID,
  //       TITLE: v.TITLE
  //     }],
  //   }
  //   this.administrationService.InsertUserDetails(request).subscribe((response: any) => {
  //     if (response.STATUS == 'SUCCESS') {
  //       this.GetOtherUserList(index);
  //     }
  //     this.commonWebService.openSnackBar(response.STATUS_MESSAGE, response.STATUS);
  //   }, (error: any) => {
  //     console.log(error);
  //     this.addLoading[index] = false;
  //     alert('Error processing request');
  //   });
  // }

  /*SOA TO JAVA*/
  addToSelectedEmployeesByValue(v, index) {
    console.log("v", v)
    this.addLoading[index] = true;
    let request = {
      requestorName: this.userInfo.NTID,
      buAdminUserDetails: [{
        attribute1: v.ntId,
        attribute2: v.employeeName,
        businessUnit: v.businessUnit,
        pernr: v.pernr,
        personId: v.personId,
        title: v.title
      }],
    }
    this.administrationService.InsertUserDetails(request).subscribe((response: any) => {
      this.addLoading[index] = false;
      if (response.status == 'SUCCESS') {
        this.GetOtherUserList(index);
      }
      this.commonWebService.openSnackBar(response.statusMessage, response.status);
    }, (error: any) => {
      console.log(error);
      this.addLoading[index] = false;
      alert('Error processing request');
    });
  }

}
