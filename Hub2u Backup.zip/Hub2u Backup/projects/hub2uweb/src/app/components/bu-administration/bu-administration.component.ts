import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, ViewChild, } from '@angular/core';
import { Router } from '@angular/router';
import { CommonWebService } from '../../shared/common-web.service';
import { ReportsService, SettingsService, AdministrationService, ConstantData } from 'hub2ushared';
import { EventService } from '../../shared/event.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { CommonSettingService } from '../../shared/common-settings.service';


@Component({
  selector: 'app-bu-administration',
  templateUrl: './bu-administration.component.html',
  styleUrls: ['./bu-administration.component.scss'],
})
export class BuAdministrationComponent implements OnInit {
  userName: any;
  userDetails: any = '{}';
  userInfo: any;
  userLookupRole: any = '';
  userRole: any = '';
  functionId: any = '';
  isUpdatedAddress = true;
  dynamicForm = new FormGroup({});
  dynamicFields: any = [];
  mappingList = [];
  displayFields = [];
  editableFields = [];
  label: any;
  defBsuUnit: boolean;
  disableSave: boolean = false;
  noData: boolean = false;
  isInvalid: boolean = false;
  loader: boolean = false;
  detailsHide: boolean = false;
  person_id: any;
  deliverToSite: any = '';
  projNum: any = '';
  saveBUColumnMap = [];
  errMsg: string;
  //ntUsername: string = this.administrationService.getNtUser()?.user_name || '';
  /*SOA TO JAVA*/
  //ntUsername: string = this.administrationService.getNtUser()?.userName || '';
  ntUsername: '';

  selectedTab = new FormControl(0);
  subInvmappingList = [];
  locationOrgCode = '';
  activeEmployee: string
  selectedEmployeesDataSource: MatTableDataSource<any>;
  availableEmployeesDataSource: MatTableDataSource<any>;
  displayedColumns: string[] = ['EMPLOYEE_NAME', 'action'];
  openEmployeesDataLoader = false;
  sortCol = 'EMPLOYEE_NAME';
  buRegionName: any = "";
  currentNtUserName;
  currentUserRole;
  regionName = '';

  private paginator: MatPaginator;
  namedata: any;
  searchedusername: any;
  locationOrgId: any;
  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
  }

  constructor(private router: Router, private administrationService: AdministrationService,
    private commonWebService: CommonWebService, private reportsService: ReportsService,
    private comSettingService: CommonSettingService, public fb: FormBuilder,
    private eventService: EventService, private settingsService: SettingsService,
    private constants: ConstantData) {

    if (this.router.getCurrentNavigation().extras.state != undefined) {
      this.namedata = this.router.getCurrentNavigation().extras.state.data;
    }
  }

  ngOnInit(): void {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.loadRegion();
    //this.currentNtUserName = this.administrationService.getNtUser()?.user_name || '';
    /**SOA TO JAVA */
    this.currentNtUserName = this.administrationService.getNtUser()?.userName || '';
    this.loader = true;
    if (this.currentNtUserName == "") {
      this.currentNtUserName = localStorage.getItem("currentNtUserName");
      if (this.currentNtUserName !== null && this.currentNtUserName !== undefined) {
        this.ntUsername = this.currentNtUserName;
        this.getProfileName();
        //this.getUserInfo(this.ntUsername)
      }
    }
    if (this.namedata) {
      if (this.namedata !== null && this.namedata !== undefined) {
        this.ntUsername = this.namedata.userName;
        this.getProfileName();
        //this.getUserInfo(this.ntUsername)
      }
    }
    this.loader = false;
  }


  tabClick(tab) {
    if (tab.tab.textLabel == 'Region Employees') {
      this.activeEmployee = 'selected_employees';
    }
  }
  assignUser(event) {
    this.ntUsername = event ? event.toUpperCase() : '';
  }

  ngOnChanges() {
  }

  getProfileName() {
    this.loader = true;
    let object =
    {
      //"ReportId": "10239",
     "ReportId": "7017",
      // "ReportId": this.functionId == '136'?"7017":"10239",
      "ParametersInput":
        [{ "Name": "USERNAME", "Value": this.ntUsername }]
    };

    this.reportsService.onGetDynamicReport(object).subscribe(response => {
      this.loader = false;
      if (response != undefined) {
        if (response.ROW[0]) {
          this.noData = false;
          let resp = response.ROW[0];
          this.searchedusername = resp.PROFILE_NAME.toUpperCase()
          if (resp.PROFILE_NAME.toUpperCase() == this.userRole.toUpperCase()) {
            this.getUserInfo()
          }
          else {
            this.commonWebService.openSnackBar("Switch your profile matching to searched user", "ERROR");
            this.dynamicFields = [];

            this.detailsHide = false;
          }
        }
        else {
          this.commonWebService.openSnackBar("No data in response", "ERROR");
          this.dynamicFields = [];

          this.detailsHide = false;
        }
      }
      else {
        this.loader = false;
        this.commonWebService.openSnackBar("Service error", "ERROR");
      }
    }, error => {

    });
  }

  getUserInfo(ntuserName?) {
    this.loader = true;
    let object =
    {
      //"ReportId": "10087",
       "ReportId": "7002", // oracle fusion
       "ParametersInput":
        [{ "Name": "BIND_APPLICATIONID", "Value": "7" },
        { "Name": "USER_NAME", "Value": this.ntUsername }]
    };
    this.reportsService.onGetDynamicReport(object).subscribe(response => {
      if (response.ROW != undefined) {
        this.noData = false;
        let resp = response.ROW[0];
        this.userLookupRole = resp.FUNCTION_NAME;
        this.functionId = resp.FUNCTION_ID;
        this.fetchDynamicFields();
        this.fetchMappingFields();
        localStorage.setItem("currentNtUserName", this.ntUsername);
        this.currentNtUserName = this.ntUsername;
        this.currentUserRole = resp.FUNCTION_NAME;
        this.person_id = resp.USER_ID;
      }
      else {
        this.noData = true;
        this.detailsHide = false;
        this.loader = false;
      }
    }, error => {
      this.noData = true;
      this.detailsHide = false;
      this.loader = false;
    });
  }

  fetchDynamicFields() {
    this.dynamicFields = [];
   this.loader = true;
    // reportId = 10196;
    // reportId = 7018;
     let request = {
      ReportId:this.constants.buadmindynamicfields[this.functionId],  
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.ntUsername
        },
        {
          Name: "PROFILE_TYPE",
          Value: this.searchedusername
        }
      ]
    };

    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW != undefined) {
        this.noData = false;
        this.detailsHide = true;
        let resp = response.ROW || [];
        for (let control of response.ROW) {
          this.dynamicFields.push(control);
        }
        this.userName = resp[0]['EMPLOYEE_NAME'];
        //this.displayFields = this.OrganizedCart(resp, 'DISPLAY_COLUMNS');
        //this.editableFields = this.OrganizedCart(resp, 'EDITABLE_COLUMNS');
        this.dynamicForm = this.createDynamicForm();

        // this.dynamicForm.controls[delColName].setValue(this.comSettingService.delLocCode.LOCATION_CODE)
        if (sessionStorage.getItem("Prev_Url").indexOf("settings") > -1) {
          if (this.comSettingService.deliverSite !== undefined && this.comSettingService.deliverSite !== null) {
            this.updateDeliveryToSite();
          }
          if (this.comSettingService.wareHouseCode !== undefined && this.comSettingService.wareHouseCode !== null) {
            this.updateSourceWarehouse();
          }
          if (this.comSettingService.delLocCode !== undefined && this.comSettingService.delLocCode !== null) {
            this.updateDeliveryToLoc();
          }
          if (this.comSettingService.projectVal !== undefined && this.comSettingService.projectVal !== null) {
            this.updateProjectNum();
          }
          if (this.comSettingService.sourceSite !== undefined && this.comSettingService.sourceSite !== null) {
            this.updateSourceSite();
          }
          if (this.comSettingService.subInv !== undefined && this.comSettingService.subInv !== null) {
            this.updateSubInv();
          }
          sessionStorage.setItem("Prev_Url", null);
        } else {
          this.clearSettingData();
          this.loader = false;
        }
        if (sessionStorage.getItem("Prev_Url").indexOf("wms") > -1) {
          if (this.comSettingService.wareHouseCode !== undefined) {
            this.updateSourceWarehouseWMS();
          }
        }
        this.loader = false;
        this.onSubInvClick();
      }
      else {
        this.loader = false;
        this.noData = true;
        this.detailsHide = false;
      }
    }, error => {
      this.loader = false;
      this.noData = true;
      this.detailsHide = false;
    })
  }

  fetchMappingFields() {
    this.mappingList = [];
    let request = {
      //ReportId: 10196, //this.userValues[0].reportId
      // ReportId: 7018,
      ReportId:this.constants.buadmindynamicfields[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.ntUsername
        },
        {
          Name: "PROFILE_TYPE",
          Value: this.searchedusername
        }

      ]
    };
    this.reportsService.getReportDisplayFields(request).subscribe(response => {
      if (response.ReportDisplayFieldsOutput != undefined) {
        for (let control of response.ReportDisplayFieldsOutput) {
          this.mappingList.push(control);
          if (control.name == 'MAPPING') {
            let saveBUColumn = control.options;
            saveBUColumn.forEach(x => {
              if (x.text !== undefined) {
                this.saveBUColumnMap.push({ key: x.text, mappingname: x.value })
              }
            });
          }
        }
      } else {
        // this.loader = false;
      }
    }, error => {
      this.loader = false;
    })
  }

  getMappingList(colName) {
    if (colName == "SUB_INVENTORY") {
      let subInvList = [];
      for (let item of this.subInvmappingList) {
        if (item.SUBINVENTORY_NAME !== undefined) {
          subInvList.push(item.SUBINVENTORY_NAME)
        }
      }
      return subInvList;
    } else {
      let mappingListValues = [], sel = [], unsel = [];
      for (let item of this.mappingList) {
        if (item.name == colName) {
          if (colName == "Override Location Master") {
            mappingListValues.push('Please Select');
          }
          let orderTypeList = item.options;
          orderTypeList.forEach(x => {
            if (x.value !== undefined) {
              mappingListValues.push(x.value)
            }
          });
          if (colName == "USER_GROUPS") {
            if (this.dynamicForm.get("userGroup").value !== null) {
              mappingListValues.forEach(item => {
                if (this.dynamicForm.get("userGroup").value.indexOf(item) !== -1) {
                  sel.push(item);
                } else {
                  unsel.push(item);
                }
              });
              mappingListValues = [...sel, ...unsel];
              return mappingListValues;
            }
          }
        }
      }
      return mappingListValues;
    }
  }

  // getSubInvList(colName) {
  //   let subInvList = [];
  //   subInvList.push('--Select--')
  //   for (let item of this.subInvmappingList) {
  //     if (item.SUBINVENTORY_NAME !== undefined) {
  //       subInvList.push(item.SUBINVENTORY_NAME)
  //     }
  //   }
  //   return subInvList;
  // }

  onSubInvClick() {
    this.subInvmappingList = [];
    // if (this.functionId == '99') {
      if (this.functionId == '143') { //cifa_to_iip
      var sourceOrg = this.dynamicForm.value.sourceLocation;
      var orgCode = this.dynamicFields.filter(val => val.SAVE_INPUT === "deliveryToLocation")
      let req = {
        ReportId: 10180,
        ParametersInput: [
          {
            // Name: "USER_NAME",
            Name: "REQUESTOR_NT_ID",
            Value: this.userInfo.NTID
          },
          {
            Name: "ORGANIZATION_CODE",
            Value: sourceOrg
          },
          {
            Name: "DELIVERY_TO_SITE",
            Value: (this.locationOrgCode != '' && this.locationOrgCode != undefined && this.locationOrgCode != null) ? this.locationOrgCode : orgCode[0].ORG
          }
        ]
      };
      this.reportsService.getSubInv(req).subscribe(response => {
        if (response.ROW != undefined) {
          for (let control of response.ROW) {
            this.subInvmappingList.push(control);
          }
        }
      })
    }
  }

  onSelection(key, event) {
    if (key == 'attribute1') {
      this.dynamicForm.controls[key].setValue(event.target.value.trim());
    } else {
      this.dynamicForm.controls[key].setValue(event.value.trim());
    }
  }



  input: any;
  validateAdress(input) {
    this.isUpdatedAddress = false;
    this.input = input;

  }

  ToggleDefaultBSU(key, toggle, event) {
    if (event.checked === true) {
      this.defBsuUnit = true;
    } else {
      this.defBsuUnit = false;
    }
  }

  // clickToNavigate(key, label, dqId) {
  //   let val = this.dynamicForm.get(key).value
  //   this.label = label;
  //   switch (label) {
  //     case 'Project Number':
  //       this.onProjNumNavigate(key, val);
  //       break;
  //     case 'Delivery':
  //       if (this.functionId == '58' || this.functionId == '51' || this.functionId == '57' || this.functionId == '61') {
  //         this.onDeliverSiteNavigate(key, val, dqId);
  //       } else this.onDeliverLocNavigate(key, val, dqId)
  //       break;
  //     case 'Source':
  //       this.onWareHouseNavigate(key, val, dqId);
  //       break;
  //   }
  // }

  clickToNavigate(key, label, dqId) {
    let val = this.dynamicForm.get(key).value
    this.label = label;
    switch (label) {
      case 'Project Number':
        this.onProjNumNavigate(key, val);
        break;
      case 'Delivery To Location':
        this.onDeliverLocNavigate(key, val, dqId)
        break;
      case 'Source Site':
        this.onWareHouseNavigate(key, val, dqId)
        break;
      case 'Source Warehouse':
        this.onWareHouseNavigate(key, val, dqId)
        break;
      case 'Delivery To Site':
        this.onDeliverSiteNavigate(key, val, dqId)
        break;
      case 'Job ID':
        this.onJobIdNavigate(key, val, dqId);
        break;
    }
  }

  onNtUsernameNavigate(event) {
    //this.administrationService.setNtUser({ user_name: this.ntUsername });
    /**SOA TO JAVA */
    this.administrationService.setNtUser({ userName: this.ntUsername });

    this.router.navigate(['hub2u/administration/ntusername'], {
      state: { page: "bu-administration" }
    });
  }

  onProjNumNavigate(key, val) {
    this.comSettingService.setSettingProjectCode(val, key);
    this.router.navigate(['hub2u/settings/search'], {
      state: { page: "bu-administration", projectColName: key, projectVal: val }
    });
  }

  onWareHouseNavigate(key, val, dqId) {
    let navigateLink = (this.label === "Source Site") ? 'hub2u/settings/sourceSite' : 'hub2u/settings/source';
    // if (this.functionId == '58') {
    //   navigateLink = 'hub2u/settings/sourceSite';
    // } else {
    //   navigateLink = 'hub2u/settings/source';
    // }

    this.comSettingService.setWareHouseCode(val, key);
    localStorage.setItem("wareHousedynamicId", dqId);
    this.router.navigate([navigateLink], {
      state: { page: "bu-administration", sourceSiteName: key, sourceSiteVal: val }
    });
  }

  onDeliverLocNavigate(key, val, dqId) {
    // let navigateLink = (this.label === "Delivery To Site") ? 'hub2u/settings/deliver' : 'hub2u/settings/deliverToLoc';
    //this.comSettingService.setdelLocCode(val, key);
    this.comSettingService.setdelLocCode(val, key);
    localStorage.setItem("deliverLocdynamicId", dqId);
    this.router.navigate(['hub2u/settings/deliverToLoc'],
      {
        state: { page: "bu-administration", delLocName: key, delLocVal: val },
      }
    );
  }

  onDeliverSiteNavigate(key, val, dqId) {
    this.comSettingService.setdeliverLoc(val);
    localStorage.setItem("deliverSitedynamicId", dqId);
    this.router.navigate(['hub2u/settings/deliver'], {
      state: { page: "bu-administration", columnName: key, delSiteVal: val }
    });
  }

  onJobIdNavigate(key, val, index) {
    this.router.navigate(['hub2u/settings/jobIdSearch'], {
      state: { page: "cart", jobIdName: key, jobIdindex: index }
    });
  }

  onSubInvNavigate(key, val) {
    //this.comSettingService.setSubinv(val, key);
    this.router.navigate(['hub2u/settings/inventory'], {
      state: { page: "bu-administration", subInvName: key, subInvVal: val }
    });

  }

  onAddItem(size, item: any, key) {
    item.DEFAULT_VALUE = size.toString();
    this.dynamicForm.controls[key].setValue(item.DEFAULT_VALUE);
  }

  OrganizedCart(resp, col) {
    let cart = [];
    let display_column = [];
    if (resp[0][col] !== undefined) {
      display_column = this.convertToArray(resp[0][col]);
    }

    return display_column
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
      else {
        col = columns;
      }
    }
    return col;
  }

  /***************Update Navigate Values Start**********************/
  updateProjectNum() {
    this.isUpdatedAddress = true;
    let colNam = this.comSettingService.projectColName;
    this.dynamicForm.controls[colNam] ? this.dynamicForm.controls[colNam].setValue(this.comSettingService.projectVal['Project Number']) : '';

  }

  updateSourceSite() {
    this.isUpdatedAddress = true;
    let sourceColNam = this.comSettingService.sourceSiteName;
    this.dynamicForm.controls[sourceColNam] && (this.comSettingService.sourceSite.SITE_ID != undefined) ? this.dynamicForm.controls[sourceColNam].setValue(this.comSettingService.sourceSite.SITE_ID) : '';
    let srcAddress;
    srcAddress = this.dynamicFields.filter(val => val.SAVE_INPUT == sourceColNam);
    if (srcAddress !== undefined && srcAddress !== null) {
      if (srcAddress.length > 0) {
        srcAddress[0].TOOL_TIP = this.functionId == '58' ? this.comSettingService.sourceSite.ADDRESS.replace(/,\s*$/, "") : this.comSettingService.sourceSite.ADDRESS;
      }
    }
  }

  createDynamicForm() {
    this.dynamicForm = this.fb.group({});
    this.dynamicFields.forEach(control => {
      this.dynamicForm.addControl(control.SAVE_INPUT, this.fb.control(null));
      if (control.MANDATORY == 'Yes') {
        this.dynamicForm.controls[control.SAVE_INPUT].setValidators([Validators.required])
      }
      if (control.DEFAULT_VALUE) {
        control.DEFAULT_VALUE != 'null' ? this.dynamicForm.controls[control.SAVE_INPUT].setValue(control.DEFAULT_VALUE) : this.dynamicForm.controls[control.SAVE_INPUT].setValue('');
      }
      if (control.EDITABLE == 'false') {
        this.dynamicForm.controls[control.SAVE_INPUT].disable();
      }
      if (control.SAVE_INPUT === 'attribute6') {
        if (control.DEFAULT_VALUE === 'Y') {
          this.defBsuUnit = true;
        } else {
          this.defBsuUnit = false;
        }
      }
      // if (control.SAVE_INPUT == 'subInventory' && this.functionId != '99') {
        if (control.SAVE_INPUT == 'subInventory' && this.functionId != '143') {
        this.dynamicForm.controls[control.SAVE_INPUT].disable();
      }
      if (control.SAVE_INPUT == 'userGroup') {
        if (control.DEFAULT_VALUE !== null) {
          this.dynamicForm.controls["userGroup"].setValue(control.DEFAULT_VALUE.split(','));
        }
      }
    });

    return this.dynamicForm;
  }

  updateSourceWarehouse() {
    this.isUpdatedAddress = true;
    let sourceColNam = this.comSettingService.sourceSiteName;
    this.dynamicForm.controls[sourceColNam] && (this.comSettingService.wareHouseCode.ORGANIZATION_CODE != undefined) ? this.dynamicForm.controls[sourceColNam].setValue(this.comSettingService.wareHouseCode.ORGANIZATION_CODE) : this.comSettingService.wareHouseCode;
  }

  updateSourceWarehouseWMS() {
    this.isUpdatedAddress = true;
    let sourceColNam = "sourceLocation";
    this.dynamicForm.controls[sourceColNam] && (this.comSettingService.wareHouseCode.ORGANIZATION_CODE != undefined) ? this.dynamicForm.controls[sourceColNam].setValue(this.comSettingService.wareHouseCode.ORGANIZATION_CODE) : this.comSettingService.wareHouseCode;
  }

  updateDeliveryToLoc() {
    this.isUpdatedAddress = true;
    let delColName = this.comSettingService.delLocName;
    this.dynamicForm.controls[delColName] && [(this.comSettingService.delLocCode.LOCATION_CODE != undefined) ?
      this.dynamicForm.controls[delColName].setValue(this.comSettingService.delLocCode.LOCATION_CODE) :
      this.dynamicForm.controls[delColName].setValue(this.comSettingService.delLocCode)];
    if (this.dynamicForm.controls[delColName] && (this.comSettingService.delLocCode)) {
      this.regionName = this.comSettingService.delLocCode.REGION_NAME;
      this.locationOrgCode = this.comSettingService.delLocCode.ORGANIZATION_CODE;
      this.locationOrgId = this.comSettingService.delLocCode.DELIVER_TO_ORG_ID;
      if(this.regionName == 'KEYSTONE_REGION'){
        this.dynamicForm.controls['projectNumber'].disable();
        this.dynamicFields.forEach(control => {
          if (control.COLUMN_NAME == 'PROJECT_NUMBER') {
            control.EDITABLE = 'false';
            this.dynamicForm.controls['projectNumber'].disable();
            this.dynamicForm.controls['projectNumber'].setValue(null);
            if(this.comSettingService.projectVal != undefined){
              this.comSettingService.projectVal['Project Number'] = null;
            }  
          }
        })
      }else{
        this.dynamicForm.controls['projectNumber'].enable();
        this.dynamicFields.forEach(control => {
          if (control.COLUMN_NAME == 'PROJECT_NUMBER') {
            control.EDITABLE = 'true';
            this.dynamicForm.controls['projectNumber'].setValue(control.DEFAULT_VALUE)
          }  
        })

      }
    }
  }

  updateSubInv() {
    this.isUpdatedAddress = true;
    let subInvName = this.comSettingService.subInvName;
    (this.dynamicForm.controls[subInvName] && (this.comSettingService.subInv['Inventory Name'] != undefined)) ? this.dynamicForm.controls[subInvName].setValue(this.comSettingService.subInv['Inventory Name']) : this.dynamicForm.controls[subInvName].setValue(this.comSettingService.subInv);
  }

  updateDeliveryToSite() {
    let delSiteName = this.comSettingService.columnName;
    // (this.dynamicForm.controls[delSiteName] && (this.comSettingService.deliverSite.SITE_ID != undefined)) ? this.dynamicForm.controls[delSiteName].setValue((this.comSettingService.deliverSite.SITE_ID)) : '';
    (this.dynamicForm.controls[delSiteName] && (this.comSettingService.deliverSite.SITE_ID != undefined)) ?
      this.dynamicForm.controls[delSiteName].setValue((this.comSettingService.deliverSite.SITE_ID)) : ''
    let address, delAddress;
    address = this.dynamicFields.filter(val => val.SAVE_INPUT == delSiteName);
    if (address !== undefined && address !== null) {
      if (address.length > 0) {
        address[0].TOOL_TIP = this.functionId == '58' ? this.comSettingService.deliverSite.ADDRESS.replace(/,\s*$/, "") : this.comSettingService.deliverSite.ADDRESS;
        //if (this.functionId == '51' || this.functionId == '57') {
          if (this.functionId == '136' || this.functionId == '57') {
          address[0].ADD_ON = this.comSettingService.deliverSite.SITE_DESCRIPTION;
          address[0].CUSTOMER = this.comSettingService.deliverSite.CUSTOMER;
        }
      }
    }
    this.isUpdatedAddress = true;
  }
  /***************Update Navigate Values End**********************/

  getCustomer(key) {
    let customer, customerVal;
    customer = this.dynamicFields.filter(val => val.SAVE_INPUT === "deliveryToLocation");
    //if (customer !== undefined && customer !== null && (this.functionId == '57' || this.functionId == '51')) {
      if (customer !== undefined && customer !== null && (this.functionId == '57' || this.functionId == '136')) {
      if (key === "deliveryToLocation")
        customerVal = customer.length > 0 ? (customer[0].CUSTOMER ? customer[0].CUSTOMER + '|' : 'null|') : null;
    }
    return (customerVal !== null && customerVal !== undefined) ? customerVal : '';
  }

  getAddressVal(key) {
    let address, delAddress;
    address = this.dynamicFields.filter(val => val.SAVE_INPUT == key);
    //if (address !== undefined && address !== null && this.functionId == '51') {
      if (address !== undefined && address !== null && this.functionId == '136') {
      delAddress = address.length > 0 ? address[0].TOOL_TIP : null;
    } else if (address !== undefined && address !== null) {
      delAddress = address.length > 0 ? address[0].TOOL_TIP : null;
    }

    let siteDesc, siteDescVal;
    siteDesc = this.dynamicFields.filter(val => val.SAVE_INPUT === "deliveryToLocation");
    //if (siteDesc !== undefined && siteDesc !== null && this.functionId == '51') {
      if (siteDesc !== undefined && siteDesc !== null && this.functionId == '136') {
      if (key === "deliveryToLocation")
        siteDescVal = siteDesc.length > 0 ? (siteDesc[0].ADD_ON ? '|' + siteDesc[0].ADD_ON : '|null') : null;
    }
    return delAddress !== null ? '|' + delAddress + (siteDescVal !== null && siteDescVal !== undefined ? siteDescVal : '') : '';

  }

  onSaveBUAdministratrion() {
    if (!this.dynamicForm.valid) {
      this.isInvalid = true
      return;
    }
    this.eventService.showSpinner();
    let req, delToLoc, sourceLoc;
    var formData = this.dynamicForm.value;
    delToLoc = this.dynamicFields.filter(val => val.SAVE_INPUT == 'deliveryToLocation');
    sourceLoc = this.dynamicFields.filter(val => val.SAVE_INPUT == 'sourceLocation');
    if (delToLoc.length > 0 && sourceLoc.length > 0 && (this.dynamicForm.value['deliveryToLocation'] == this.dynamicForm.value['sourceLocation'])) {
      this.eventService.hideSpinner();
      this.commonWebService.openSnackBar("Source Site cannot be same as Delivery to Site", "WARNING");
    } else {
      if (this.isUpdatedAddress == false) {

        //if ((this.functionId == "51") && this.input === 'deliveryToLocation') {
          if ((this.functionId == "136") && this.input === 'deliveryToLocation') {
          let request = {
            ReportId: "1088",
            ParametersInput: [
              {
                Name: "P_REQUESTOR_NAME", Value: this.userInfo.NTID
              },
              {
                Name: "CUSTOMER", Value: ''
              },
              {
                Name: "SITE_ID", Value: formData.deliveryToLocation
              },
              {
                Name: "CITY", Value: ''
              },
              {
                Name: "STATE", Value: ''
              },
              {
                Name: "ZIP_CODE", Value: ''
              }
            ]
          }
          this.reportsService.onGetDynamicReport(request).subscribe(response => {
            this.deliverToSite = response.ROW;
          })

        }
        // if ((this.functionId == "99" && this.input === 'attribute1')) {
          if ((this.functionId == "143" && this.input === 'attribute1')) {
          this.isUpdatedAddress = true
        }
      }

      // setTimeout(() => {
      //   req = {}
      //   req["attribute3"] = this.currentUserRole.toUpperCase();
      //   if (this.locationOrgId != '' && this.locationOrgId != undefined &&
      //     this.locationOrgCode != '' && this.locationOrgId != undefined) {
      //     req["expenditureOrgId"] = this.locationOrgId;
      //     req["expenditureOrg"] = this.locationOrgCode;
      //   }
      //   req["personId"] = this.person_id ? this.person_id : null;
      //   req["userName"] = this.currentNtUserName;
      //   for (var key in formData) {
      //     req[key] = this.getCustomer(key) + formData[key] + this.getAddressVal(key);
      //     req[key] = req[key] == "null" ? "" : req[key];
      //     if (req['subInventory'] == '') {
      //       req['subInventory'] = "";
      //     }
      //     req["attribute6"] = (this.defBsuUnit == true) ? 'Y' : 'N'
      //     if (formData["attribute4"] == 'Please Select') {
      //       req["attribute4"] = "";
      //     }
      //     if (formData["attribute2"] == 'Please Select') {
      //       req["attribute2"] = "";
      //     }
      //     if (formData["attribute1"] == null) {
      //       req["attribute1"] = "";
      //     }


      //   }
      //   let request = { preferencesUpsertDetails: req }
      //   if (this.isUpdatedAddress == false) {
      //     if (this.deliverToSite !== undefined && this.projNum !== undefined) {
      //       // ((this.projNum != "") && (this.projNum[0].ProjectNumber === formData.projectNumber) && (formData.projectNumber == "")) ||
      //       if (((this.deliverToSite != "") && (this.deliverToSite[0].SITE_ID === formData.deliveryToLocation) && (formData.deliveryToLocation == ""))) {
      //         this.settingsService.onSaveSettings(request).subscribe(response => {
      //           this.eventService.hideSpinner();
      //           if (response.status == "SUCCESS") {
      //             this.commonWebService.openSnackBar('Your changes have been saved successfully!', "SUCCESS");

      //           } else if (response.status == "ERROR") {
      //             this.commonWebService.openSnackBar(response.statusMessage, "ERROR");
      //           }

      //         }, (error) => {
      //           this.eventService.hideSpinner();
      //           this.commonWebService.openSnackBar("Something went wrong. Please try again later", "ERROR");
      //         });
      //       } else {
      //         this.eventService.hideSpinner();
      //         this.commonWebService.openSnackBar("Enter Valid Values", "ERROR");
      //       }
      //     } else {
      //       this.eventService.hideSpinner();
      //       this.commonWebService.openSnackBar("Enter Valid Values", "ERROR");
      //     }
      //   } else if (this.isUpdatedAddress == true) {
      //     this.settingsService.onSaveSettings(request).subscribe(response => {
      //       this.eventService.hideSpinner();
      //       if (response.status == "SUCCESS") {
      //         this.commonWebService.openSnackBar('Your changes have been saved successfully!', "SUCCESS");
      //         this.clearSettingData();
      //       } else if (response.status == "ERROR") {
      //         this.commonWebService.openSnackBar(response.statusMessage, "ERROR");
      //       }

      //     },
      //       (error) => {
      //         this.eventService.hideSpinner();
      //         this.commonWebService.openSnackBar("Something went wrong. Please try again later", "ERROR");
      //       });
      //   }
      // }, 2000);
      setTimeout(() => {
        req = {}
        // req["attribute3"] = this.currentUserRole.toUpperCase();
        req["profileType"] = this.currentUserRole.toUpperCase();
        if (this.locationOrgId != '' && this.locationOrgId != undefined &&
          this.locationOrgCode != '' && this.locationOrgId != undefined) {
          req["expenditureOrgId"] = this.locationOrgId;
          req["expenditureOrg"] = this.locationOrgCode;
        }
        req["personId"] = this.person_id ? this.person_id : null;
        req["userName"] = this.currentNtUserName;
        for (var key in formData) {
          req[key] = this.getCustomer(key) + formData[key] + this.getAddressVal(key);
          req[key] = req[key] == "null" ? "" : req[key];
          if (req['subInventory'] == '') {
            req['subInventory'] = "";
          }
          req["attribute6"] = (this.defBsuUnit == true) ? 'Y' : 'N'
          if (formData["attribute4"] == 'Please Select') {
            req["attribute4"] = "";
          }
          if (formData["userGroup"] == 'Please Select') {
            // req["attribute2"] = "";
            req["userGroup"] = "";
          }
          if (formData["attribute1"] == null) {
            // req["attribute1"] = "";
            req["locator"] = "";

          }


        }
        let request = { 
          profile:this.currentUserRole.toUpperCase(),
          preferencesUpsertDetails: req }
        if (this.isUpdatedAddress == false) {
          if (this.deliverToSite !== undefined && this.projNum !== undefined) {
            // ((this.projNum != "") && (this.projNum[0].ProjectNumber === formData.projectNumber) && (formData.projectNumber == "")) ||
            if (((this.deliverToSite != "") && (this.deliverToSite[0].SITE_ID === formData.deliveryToLocation) && (formData.deliveryToLocation == ""))) {
              this.settingsService.onSaveSettings(request).subscribe(response => {
                this.eventService.hideSpinner();
                if (response.status == "SUCCESS") {                  
                  this.loadRegion();
                  this.commonWebService.openSnackBar('Your changes have been saved successfully!', "SUCCESS");

                } else if (response.status == "ERROR") {
                  this.commonWebService.openSnackBar(response.statusMessage, "ERROR");
                }

              }, (error) => {
                this.eventService.hideSpinner();
                this.commonWebService.openSnackBar("Something went wrong. Please try again later", "ERROR");
              });
            } else {
              this.eventService.hideSpinner();
              this.commonWebService.openSnackBar("Enter Valid Values", "ERROR");
            }
          } else {
            this.eventService.hideSpinner();
            this.commonWebService.openSnackBar("Enter Valid Values", "ERROR");
          }
        } else if (this.isUpdatedAddress == true) {
          this.settingsService.onSaveSettings(request).subscribe(response => {
            this.eventService.hideSpinner();
            if (response.status == "SUCCESS") {
              this.loadRegion();
              this.commonWebService.openSnackBar('Your changes have been saved successfully!', "SUCCESS");
              this.clearSettingData();
            } else if (response.status == "ERROR") {
              this.commonWebService.openSnackBar(response.statusMessage, "ERROR");
            }

          },
            (error) => {
              this.eventService.hideSpinner();
              this.commonWebService.openSnackBar("Something went wrong. Please try again later", "ERROR");
            });
        }
      }, 2000);
      
      sessionStorage.setItem("listOfCatalogs" + this.userInfo.NTID, "");
      sessionStorage.setItem(this.userInfo.NTID + "catalogObj", "");

    }
  }

  loadRegion() {
    let request = {
      "ReportId": this.constants.regionReportId[this.functionId],
      "ParametersInput": [
        {
          "Name": "REQUESTOR",
          "Value": this.userInfo.NTID
        }]
    };
    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW != undefined) {
        this.buRegionName = response.ROW[0].LOOKUP_CODE || '';
      }
    });
  }

  clearSettingData() {
    this.comSettingService.deliverSite = null;
    this.comSettingService.wareHouseCode = null;
    this.comSettingService.delLocCode = null;
    this.comSettingService.projectNum = null;
    this.comSettingService.grpData = null;
    this.comSettingService.taskNum = null;
    this.comSettingService.jobId = null;
  }
}

