import { Component, NgModule, OnInit, ViewChild } from '@angular/core';
import { AdministrationService } from 'hub2ushared';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { CommonWebService } from '../../../shared/common-web.service';

@Component({
  selector: 'app-selected-employees',
  templateUrl: './selected-employees.component.html',
  styleUrls: ['./selected-employees.component.scss'],
})

export class SelectedEmployeesComponent implements OnInit {
  loader: boolean = false;
  userInfo: any;
  userRole: any = '';
  selectedEmployeesDataSource: MatTableDataSource<any>;
  displayedColumns: string[] = ['EMPLOYEE_NAME', 'action'];
  removeLoading: any[] = [];

  private paginator: MatPaginator;
  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
  }

  constructor(private commonWebService: CommonWebService, private administrationService: AdministrationService) { }

  ngOnChanges() {
    setTimeout(() => {
      this.selectedEmployeesDataSource.paginator = this.paginator;
    }, 1200)
  }

  ngOnInit() {
    this.selectedEmployeesDataSource = new MatTableDataSource<any>();
    this.loader = true;
    this.GetSelectedUserList();
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
  }

  ngOnLoad() {
    this.GetSelectedUserList();
  }

  // GetSelectedUserList(index?) {
  //   var request = {
  //     "BUSINESS_UNIT":"000854"
  //   }

  //   this.administrationService.getSelectedEmployees(request).subscribe((response:any) => {
  //     this.removeLoading[index] = false;
  //     this.selectedEmployeesDataSource = new MatTableDataSource<any>(response.SelectedUsersListOutput);
  //     this.selectedEmployeesDataSource.paginator = this.paginator;
  //     this.ngOnChanges();
  //     this.loader = false;
  //   }, (error: any) => {
  //     console.log(error);
  //     this.loader = false;
  //   });
  // }

  /*SOA TO JAVA*/
  GetSelectedUserList(index?) {
    var request = {
      "businessUnit": "000854"
    }

    this.administrationService.getSelectedEmployees(request).subscribe((response: any) => {
      this.removeLoading[index] = false;
      if (response.status == "SUCCESS") {
        this.selectedEmployeesDataSource = new MatTableDataSource<any>(response.buAdminUserList);
        this.selectedEmployeesDataSource.paginator = this.paginator;
        this.ngOnChanges();
      }
      this.commonWebService.openSnackBar(response.statusMessage, response.status);

      this.loader = false;
    }, (error: any) => {
      console.log(error);
      this.loader = false;
    });
  }

  // removeFromSelectedEmployeesByValue(v, index) {
  //   this.removeLoading[index] = true;
  //   let request = {
  //     REQUESTOR_NAME: this.userInfo.NTID,
  //     DeleteUsersInput: [{
  //       BUSINESS_UNIT: v.BUSINESS_UNIT,
  //       PERSON_ID: v.PERSON_ID,
  //     }],
  //   }
  //   this.administrationService.DeleteUserList(request).subscribe((response: any) => {
  //     if (response.STATUS == 'SUCCESS') {
  //       this.GetSelectedUserList(index);
  //     }
  //     this.notifierService.showNotification(response.STATUS_MESSAGE);
  //   }, (error: any) => {
  //     console.log(error);
  //     this.removeLoading[index] = false;
  //     alert('Error processing request');
  //   });
  // }

  /*SOA TO JAVA*/
  removeFromSelectedEmployeesByValue(v, index) {
    this.removeLoading[index] = true;
    let request = {
      requestorName: this.userInfo.NTID,
      buAdminUserDetails: [{
        businessUnit: v.businessUnit,
        personId: v.personId,
      }],
    }
    this.administrationService.DeleteUserList(request).subscribe((response: any) => {
      this.removeLoading[index] = false;
      if (response.status == 'SUCCESS') {
        this.GetSelectedUserList(index);
      }
      //this.notifierService.showNotification(response.statusMessage);
      this.commonWebService.openSnackBar(response.statusMessage, response.status);

    }, (error: any) => {
      console.log(error);
      this.removeLoading[index] = false;
      alert('Error processing request');
    });
  }
}
