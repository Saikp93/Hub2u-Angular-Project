import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import {MatIcon, MatIconModule} from '@angular/material/icon';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatMenuModule} from '@angular/material/menu';
import {MatSelectModule} from '@angular/material/select';
import {MatButtonModule} from '@angular/material/button';
import {MatTooltipModule} from '@angular/material/tooltip';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Hub2usharedModule } from 'hub2ushared';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule } from '@angular/material/radio';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { NgxSpinnerModule } from 'ngx-spinner';
import { BuAdministrationComponent } from './bu-administration.component';
import { SelectedEmployeesComponent } from './selected-employees/selected-employees.component';
import { AvailableEmployeesComponent } from './available-employees/available-employees.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

const routes: Routes = [
  {
    path: '',
    component: BuAdministrationComponent,
    children: [
      { path: 'selected-employees', component: SelectedEmployeesComponent},
      { path: 'available-employees', component: AvailableEmployeesComponent},
    ]
  }
];

@NgModule({
  declarations: [BuAdministrationComponent, SelectedEmployeesComponent, AvailableEmployeesComponent],
  imports: [
    CommonModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    NgxSpinnerModule,
    MatMenuModule,
    MatSelectModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    Hub2usharedModule,
    MatButtonToggleModule,
    MatTabsModule,
    MatTableModule,
    MatCardModule,
    MatInputModule,
    MatFormFieldModule,
    MatListModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatPaginatorModule,
    MatCheckboxModule,
    MatSlideToggleModule,
    
    RouterModule.forChild(routes)
  ],

  exports: []
})
export class BUAdministrationModule {}
