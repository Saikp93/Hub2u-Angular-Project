import { I } from '@angular/cdk/keycodes';
import { Component, Input, OnInit } from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ProductService, CommonService, ConstantData, ReportsService } from 'hub2ushared';
import { CommonWebService } from '../../shared/common-web.service';
import { EventService } from '../../shared/event.service';
import { CheckstatuspopupComponent } from '../checkstatuspopup/checkstatuspopup.component';
import { ClearCartComponent } from '../order-details/clear-cart/clear-cart.component';

@Component({
  selector: 'app-order-history-list',
  templateUrl: './order-history-list.component.html',
  styleUrls: ['./order-history-list.component.scss'],
  providers: [DatePipe]
})
export class OrderHistoryListComponent implements OnInit {

  userInfo: any;
  functionId: string;
  verifyStatus = [];
  @Input() reportOutput: any;
  delLocation: string = "";
  recentOrder = [];
  displayFields = [];
  loader: boolean;
  storeOrder: any='';
  userRole: string;

  constructor(private bottomSheet: MatBottomSheet, private router: Router, private reportService: ReportsService,
    private constantData: ConstantData, private productService: ProductService, private commonService: CommonService,
    private commonWebService: CommonWebService, public datepipe: DatePipe, private eventService: EventService, public _dialog: MatDialog) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    //this.functionId = '57';
    if (this.functionId == '60') {
      this.findDeliveryLoc(this.reportOutput);
    }
    this.displayFields = this.OrganizedCart(this.reportOutput, 'DISPLAY_COLUMNS');
    this.getRecentOrders();
  }

  OrganizedCart(resp, col) {
    let display_column = [];
    if (resp[0][col] !== undefined) {
      display_column = this.convertToArray(resp[0][col]);
    }
    return display_column
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
      else {
        col = columns;
      }
    }
    return col;
  }

  isAvailable(key, data) {
    let dataToSearch = [];
    if (data == 'historyFields') {
      dataToSearch = this.displayFields
    }
    return dataToSearch.includes(key);
  }

  getFormattedDate(date) {
    return this.datepipe.transform(date, 'dd MMM yyyy');
  }

  findDeliveryLoc(reportOutput: any) {
    reportOutput.forEach(report => {
      if (report.DELIVERY_LOCATION) {
        let addr1 = report.DELIVERY_LOCATION.split('|')[1].split('.')[1];
        let addr2 = report.DELIVERY_LOCATION.split('|')[2].split('.')[1];
        let city = report.DELIVERY_LOCATION.split('|')[3].split('.')[1];
        let state = report.DELIVERY_LOCATION.split('|')[4].split('.')[1];
        let zipCode = report.DELIVERY_LOCATION.split('|')[5].split('.')[1];
        this.delLocation = addr1 + ', ' + addr2 + ', ' + city + ', ' + state + ', ' + zipCode
      }
    });
  }

  repeatOrder(reportData) {
    // reportData['loader'] = true;
    this.storeOrder = reportData;
    let req_num = reportData['Order No.'];

    var dataInput = {
      // "requestorId": this.userInfo.NTID,
      "profile": this.userRole.toUpperCase(),
      "requestorName": this.userInfo.NTID,
      "requisitionNumber": req_num
    };
    this.eventService.showSpinner();

    this.productService.repeatOrder(dataInput).subscribe(response => {
      // reportData['loader'] = false;
      this.eventService.hideSpinner()
      let msg, msgStatus
      if (response && response != undefined) {
        msg = response['statusMessage']
        msgStatus = response['status']

        if (response['status'] == "SUCCESS") {
          this.commonService.updatedCart(true);
        }
        if (response['status'] == 'FAILED') {
          if(response['statusMessage'].includes('items in the cart already added')){
            this.openclearCartDialog();
          }
          this.commonService.updatedCart(true);
        }

        this.commonWebService.openSnackBar(msg, msgStatus)
      }

      this.eventService.hideSpinner()
    }, error => {
      this.commonWebService.openSnackBar("There is some error in repeating the order", "ERROR")
      this.eventService.hideSpinner()
      // reportData['loader'] = false;
    });
  }

  openclearCartDialog(): void {
    const dialogRef = this._dialog.open(ClearCartComponent, {
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.onClearCart();
      }
    });
  }

  onClearCart() {
    // let object = { requestorId: this.userInfo.NTID, operation: "Clear" };
    let object = { requestorName: this.userInfo.NTID, operation: "Clear",profile: this.userRole.toUpperCase() };
    this.loader = true;
    this.productService.clearCart(object).subscribe(response => {
      this.loader = false;
      let resp = response || [];
      if(resp != undefined){
        let message = resp['STATUS_MESSAGE'] || resp['statusMessage'] || '';
        if(resp['status'] == 'SUCCESS'){
          this.commonWebService.openSnackBar(message, resp['status']);
          this.repeatOrder(this.storeOrder);
        }else{
          this.commonWebService.openSnackBar('Error while clearing the Cart, hence the new item is not added.', 'WARNING')
        }
      }else{
        this.loader = false;
      }
      this.commonService.updatedCart(true);
    }, error => {
      this.loader = false;
      this.commonWebService.openSnackBar('Something went wrong.Can you please try later', 'WARNING')
    })
  }

  statusColor(status) {
    if (status) {
      status = status.toUpperCase();
      if (this.constantData.statusColors[status] === undefined)
        return this.constantData.statusColors.OTHERS;
      else
        return this.constantData.statusColors[status]
    }
  }

  getRecentOrders() {
    var dataInput = {
      "ReportId": this.constantData.dynamicrecentOrderId[this.functionId],
      "ParametersInput": [{ "Name": "REQUESTOR", "Value": this.userInfo.NTID }]
    }
    this.reportService.onGetDynamicReport(dataInput).subscribe(response => {
      if (response.ROW !== undefined) {
        this.recentOrder = response.ROW;
      } else {
        this.recentOrder = [];
      }
    }, error => {
    });
  }

  checkStatus(item) {
    this.eventService.showSpinner();
    var dataInput;
    var locationQuery = JSON.parse(sessionStorage.getItem('locationDynamicQuery'));

    let attrReq = this.recentOrder.filter(element => element.REQUISITION_NUMBER === item.REQUISITION_NUMBER)

    let attributeVal = ''
    if (attrReq.length > 0) {
      attributeVal = attrReq[0].ATTRIBUTE2
    }
    //if (this.constantData.orderStatusParam[this.functionId] !== undefined && this.functionId != "51") {
      if (this.constantData.orderStatusParam[this.functionId] !== undefined && this.functionId != "136") {
      dataInput = {
        "ReportId": this.constantData.checkStatus[this.functionId], "ParametersInput": [
          { "Name": "P_ORDER_NUMBER", "Value": item.REQUISITION_NUMBER ? item.REQUISITION_NUMBER : item['Order No.'] },
          { "Name": "P_MODULE", "Value": this.constantData.orderStatusParam[this.functionId] }]
      }
    } else if (locationQuery != null || locationQuery != undefined) {
      //if (locationQuery.userGroups === "NONCPE" && this.functionId != "51" ) {
        if (locationQuery.userGroups === "NONCPE"  && this.functionId != "136") {
        dataInput = {
          "ReportId": this.constantData.checkStatus[this.functionId], "ParametersInput": [
            { "Name": "P_ORDER_NUMBER", "Value": item.REQUISITION_NUMBER ? item.REQUISITION_NUMBER : item['Order No.'] },
            { "Name": "P_MODULE", "Value": "NONCPE" }]
        }
      }
    } else {
      dataInput = {
        "ReportId": this.constantData.checkStatus[this.functionId], "ParametersInput": [
          { "Name": "P_ORDER_NUMBER", "Value": item.REQUISITION_NUMBER ? item.REQUISITION_NUMBER : item['Order No.'] },
          { "Name": "P_MODULE", "Value": attributeVal }]
      }
    }
    this.reportService.onGetDynamicReport(dataInput).subscribe(response => {
      if (response.ROW !== undefined) {
        this.verifyStatus = response.ROW;
        // this.bottomSheet.open(CheckStatusComponent, {
        //   data: this.verifyStatus
        // });
        this._dialog.open(CheckstatuspopupComponent, {
          data: this.verifyStatus,
          width: '1100px',
          panelClass: 'full-panel-modal'
        });
      } else {
        this.verifyStatus = [];
        this.commonWebService.openSnackBar("No Data Found", "WARNING")
      }
      this.eventService.hideSpinner();
    }, error => {
      this.eventService.hideSpinner();
    });
  }

  orderDetails(order) {
    localStorage.setItem("reqData", JSON.stringify(order));
    this.router.navigate(['hub2u/requisitionDetail/']);
  }

  newTrack: any = [];
  trackLength: number = 0;
  httpVal: boolean = false;
  getTrackingNo(trackingNo, report) {
    // getTrackingNo(trackingNo) {
    this.newTrack = [];
    this.trackLength = 0
    if (trackingNo != undefined && trackingNo != null && trackingNo.toString().startsWith("https")) {
      let no = trackingNo.split('>')[1];
      this.httpVal = true;
      this.newTrack.push(no);
      this.trackLength = this.newTrack.length;
      return this.newTrack;
      // this.trackLength = this.newTrack.length;
      // return no;
    } else if (trackingNo != undefined && trackingNo != null && trackingNo.includes(',')) {
      this.httpVal = false;
      this.newTrack = trackingNo.split(',');
      this.trackLength = this.newTrack.length;
      report['TrackLength'] = this.trackLength;
      return this.newTrack;
    }
    else {
      this.httpVal = false;
      this.newTrack.push(trackingNo);
      this.trackLength = this.newTrack.length;
      return this.newTrack;
    }
    // else {
    //   return trackingNo;
    // }
  }

  trackOrder(trackNo) {
    trackNo = trackNo.trim();
    if (trackNo.startsWith("https")) {
      window.open(trackNo, '_blank')
    } else {
      this.router.navigate(['hub2u/trackorder/'], { state: { trackNo: trackNo, redirect: 'fromHomePage' } })
    }
  }

}
