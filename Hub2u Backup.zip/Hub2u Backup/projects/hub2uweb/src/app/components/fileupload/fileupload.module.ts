import { NgModule } from '@angular/core';
import { FileuploadComponent } from './fileupload.component';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@NgModule({
    declarations: [
        FileuploadComponent,
    ],
    exports: [
        FileuploadComponent,
    ],
    imports:[MatIconModule,MatInputModule,MatButtonModule,FormsModule,CommonModule]
})
export class FileUploadModule { }