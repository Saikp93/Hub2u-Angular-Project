import { Component, Inject, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ConstantData, ReportsService } from 'hub2ushared';
import { CommonWebService } from '../../shared/common-web.service';
import html2canvas from 'html2canvas';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SnackbarComponent } from '../snackbar/snackbar.component';
// declare let html2canvas: any;
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent implements OnInit {
  @ViewChild('TermsConditions') TermsConditions: TemplateRef<any>;
  @ViewChild('itSupport') itSupport: TemplateRef<any>;
  @ViewChild('help') help: TemplateRef<any>;
  footerLinks: any[] = [];
  helpLinks: any[] = [];
  loader: boolean = false;
  loaderSupport: boolean = false;
  nodata = false;
  userInfo;
  priority = 'High';
  priorityList = ['High', 'Medium', 'Low'];
  currentYear = (new Date()).getFullYear();
  constructor(@Inject('environment') private env: any, private _snackBar: MatSnackBar, private commonWebService: CommonWebService, private constants: ConstantData, private reportsService: ReportsService, private constantData: ConstantData, public dialog: MatDialog, private router: Router) { }

  ngOnInit() {
    this.footerLinks = this.constantData.subNavigation;
    this.onInitialLoad();

  }
  ngOnChanges() {
    this.footerLinks = this.constantData.subNavigation;
    this.onInitialLoad();
  }
  async onInitialLoad() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
  }
  onNavigate(event) {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    if (event['webLink'] === 'termsConditions') {
      this.dialog.open(this.TermsConditions, {
        width: '800px'
      });
    }
    if (event['webLink'] === 'help') {
      this.dialog.open(this.help, {
        width: '800px'
      });
      let obj = {
        "ReportId": "1008",
        "ParametersInput": [
          {
            "Name": "LOOKUP_TYPE",
            "Value": "XXCMST_HUB2U_HELP_SECTION"
          }
        ]
      };

      this.loader = true;

      let functionID = localStorage.getItem(this.userInfo.NTID + '_functionId');
      this.reportsService.onGetDynamicReport(obj).subscribe(response => {
        this.loader = false;
        let resp = response['ROW'] || [];
        this.helpLinks = [];

        if (resp.length > 0) {
          //this.helpLinks = resp.filter(item => item.MEANING.toLowerCase() === (this.constants.roles[functionID] ? this.constants.roles[functionID].toUpperCase() : null));
          this.helpLinks = response.ROW.filter(item => item.MEANING.toUpperCase() === (this.constants.roles[functionID] ? this.constants.roles[functionID].toUpperCase() : null));
          if (this.helpLinks.length === 0) {
            this.nodata = true;
            this.loader = false;
          }
        } else {
          this.nodata = true;
          this.loader = false;
        }

      }, error => {
        this.loader = false;
        this.nodata = true;
      });

    }
    if (event['title'] === 'Submit Feedback') {
      let feedbackLink = this.env.feedbackformURL + "?appId=1&token=" + this.userInfo.access_token;
      window.open(feedbackLink, '_blank');
    }
    if (event['title'] === 'IT Support') {
      this.loaderSupport = true;
      this.callItSupport()

      // this.dialog.open(this.itSupport, {
      //   width: '400px'
      // });
    }
  }

  // callItSupport() {
  //   if (this.router.url != '/hub2u/itsupport') {
  //     let responsedata = {
  //       message: 'Taking a screenshot',
  //       status: 'WARNING'
  //     }
  //     this._snackBar.openFromComponent(SnackbarComponent, {
  //       data: responsedata,
  //       duration: 1500
  //     });
  //   }
  //   html2canvas(document.body).then(canvas => {
  //     var screenshot = null;
  //     try {
  //       screenshot = canvas.toDataURL("image/jpeg");
  //     } catch (e) {
  //       console.log(e);
  //     }
  //     var data =
  //     {
  //       "REQUESTOR_NTID": this.userInfo.NTID,
  //       "CATEGORY": "HUB2U",
  //       "PRIORITY": this.priority,
  //       "DetailsInput": [{
  //         "PROBLEM_CODE": "47060",
  //         "PROBLEM_DETAILS": "::" + window.location.href + "::" + "Provide Additional details here. At present ignore this ticket. This ticket is created from finsysSR application for testing.",
  //         "ContactEmail": "",
  //         "ContactName": "",
  //         "ContactPhone": "",
  //         "AttachmentList": [{
  //           "DocumentName": "Screenshot",
  //           "DocumentDescription": "Screenshot captured automatically",
  //           "Document": screenshot
  //         }
  //         ]
  //       }],
  //       "TOKEN": sessionStorage.getItem('id_token')
  //     }
  //     //this.loaderSupport=false;
  //     this.router.navigate(['hub2u/itsupport'], { state: { data: data } });
  //   });
  // }

  callItSupport() {
    let itsupport = this.env.itsupportticket
    window.open(itsupport, '_blank');
  }
}
