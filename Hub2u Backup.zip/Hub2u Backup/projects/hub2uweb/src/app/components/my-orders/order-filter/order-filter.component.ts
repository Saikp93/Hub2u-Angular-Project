import { SelectionModel } from '@angular/cdk/collections';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ReportsService, FilterpipePipe } from 'hub2ushared';

@Component({
  selector: 'app-order-filter',
  templateUrl: './order-filter.component.html',
  styleUrls: ['./order-filter.component.scss'],
  providers: [FilterpipePipe]
})
export class OrderFilterComponent implements OnInit {

  @Input() newFilter: any;
  // @Input() filterForm: FormGroup;
  // @Input() loader = true;
  // @Output() filterEvent = new EventEmitter<any>();
  @Output() searchEvent = new EventEmitter<any>();
  searchText;
  selectionList = []
  panelState: boolean = false;
  //filterForm: FormGroup;
  Categories: any[] = [];
  subCategories: any[] = [];
  userInfo: any = {};
  isFilterData = false;
  filterData = [];
  seletedFilters: any = {
    catalogs: null,
    tags: [],
    reserved: []
  };
  selectedFil: any = [{
    control: '',
    tags: []
  }]
  range = new FormGroup({
    start: new FormControl(),
    end: new FormControl(),
  });
  showTotalList: boolean = false;
  selection = new SelectionModel<any>(true, []);
  filterloader: boolean = false;
  minCurrentDate = new Date();
  maxDate = new Date();
  minDate;
  userDetails: any = '{}';
  userRole: any = '';
  functionId = '1';
  // minDate = new Date(new Date().setDate(this.minCurrentDate.getDate() - 29));
  constructor(private fb: FormBuilder, private reportsService: ReportsService) { }

  ngOnInit() {
    this.userDetails = localStorage.getItem('userDetails');
    this.userInfo = JSON.parse(this.userDetails);
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    // if(this.functionId == '51'){
      if(this.functionId == '136'){
      this.minDate = new Date(new Date().setDate(this.minCurrentDate.getDate() - 29));
    }else{
      this.minDate = ''
    }
    
    this.onInitialLoad();
  }

  async onInitialLoad() {
    // let userInfo = await localStorage.getItem("userDetails");
    // this.userInfo = JSON.parse(userInfo);
    this.checkStorage();
  }

  // ngOnChanges() {
  //   this.onFilterChange();
  // }

  checkStorage() {
    if(sessionStorage.getItem("Prev_Url") == '/hub2u/requisitionDetail' && sessionStorage.getItem(this.userInfo.NTID + "Filter")) {
      let filterArr = JSON.parse(sessionStorage.getItem(this.userInfo.NTID + "Filter"))
      this.selectedFil = filterArr['filterArr']
      this.isFilterData = true;
      console.log(this.newFilter, filterArr['filterArr']);
      for (let filter of this.newFilter) {
        filter.tagsList.forEach(x => {
          for (let opt of filterArr['filterArr']) {
            if(opt.control == filter.control) {
              opt.tags.forEach(tag => {
                if(tag.name ==  x.name) {
                  x.selected = tag.selected;
                }
              })
            }
          }
        })
      }
      let endDate = filterArr.endDate 
      let startDate = filterArr.startDate
      this.range.controls.start.setValue(startDate);
      this.range.controls.end.setValue(endDate);
      this.searchEvent.emit({startDate: startDate, endDate: endDate, filterArr: this.selectedFil})
    }
  }

  cancel(control, opt) {
    this.filterloader = true;
    this.setTime();
    for (let item of this.selectedFil) {
      if (item.control == control) {
        item.tags.forEach(x => {
          if (x.name == opt && x.selected) {
            x.selected = false;
          }
        });
        item.tags = item.tags.filter(x => x.name != opt);
      }
    }
    //For showing no filters 
    let count = 0;
    for (let item of this.selectedFil) {
      if(item.tags.length > 0) {
        count++;
      }
    }
    if(count == 0)
      this.isFilterData = false;
    else 
      this.isFilterData = true;
    // added for issue while storing in storage
    for(let filter of this.newFilter) {
      if(filter.control == control) {
        filter.tagsList.forEach(x => {
          if(x.name == opt) {
            x.selected = false;
          }
        })
      }
    }

    this.searchEvent.emit({startDate: this.range.controls.start.value, endDate: this.range.controls.end.value, filterArr: this.selectedFil });
  }
  clearFilter(action : String) {
    this.filterloader = true;
    this.setTime();
    for (let item of this.selectedFil) {
      item.tags.forEach(x => {
        x.selected = false;
      });
      item.tags = []
    }
    this.isFilterData = false;
    for (let filter of this.newFilter) {
      filter.searchTxt = ""
    }
    this.clearDateRange();

    // added for issue while storing in storage
    for(let filter of this.newFilter) {
      if(filter.control == 'STATUS') {
        filter.tagsList.forEach(x => {
          x.selected = false;
        })
      }
    }

    this.searchEvent.emit({ filterArr: this.selectedFil });
  }
  clearDateRange(){
    this.range.controls.start.setValue(null);
    this.range.controls.end.setValue(null); 
    this.searchEvent.emit({ startDate: this.range.controls.start.value, endDate: this.range.controls.end.value, filterArr: this.selectedFil,});
  }
  onFilterChange() {
    this.filterloader = true;
    this.setTime();
    this.selectedFil = [];
    for (let filter of this.newFilter) {
      let seletedTags = [];
      filter.tagsList.forEach(x => {
        if (x.selected) {
          seletedTags.push(x);
          this.isFilterData = true;
        }
      });
      this.selectedFil.push({
        control: filter.control,
        tags: seletedTags
      })
    }
    //For showing no filters 
    let count = 0;
    for (let item of this.selectedFil) {
      if(item.tags.length > 0) {
        count++;
      }
    }
    if(count == 0)
      this.isFilterData = false;
    else 
      this.isFilterData = true;
    this.searchEvent.emit({startDate: this.range.controls.start.value, endDate: this.range.controls.end.value, filterArr: this.selectedFil});
  } 

  onDateChange(){
    this.searchEvent.emit({startDate: this.range.controls.start.value, endDate: this.range.controls.end.value, filterArr: this.selectedFil,})
  }

  setTime() {
    this.filterloader = false;
    // setTimeout(() => {
    //   this.filterloader = false;
    // },2000);
  }

}
