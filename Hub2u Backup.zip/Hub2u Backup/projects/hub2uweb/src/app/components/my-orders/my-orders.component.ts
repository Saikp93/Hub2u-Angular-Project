
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ConstantData, ReportsService } from 'hub2ushared';
import { TableUtil } from '../../shared/tableUtils';
import { EventService } from '../../shared/event.service';
import { FilterpipePipe, MultipleFilterPipe } from 'hub2ushared';
import { CommonWebService } from '../../shared/common-web.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.scss'],
  providers: [MultipleFilterPipe, FilterpipePipe]
})
export class MyOrdersComponent implements OnInit {
  userInfo: any;
  userRole: string;
  functionId: string;
  range = new FormGroup({
    startDate: new FormControl(),
    endDate: new FormControl()
  });
  status = new FormControl();
  deliverySite = new FormControl();
  customer = new FormControl();
  reportOutput: any;
  data: any;
  spinner: boolean;
  statuses = [];
  sites = [];
  customers = [];
  fileName = "Hub2u_My_Order_Details";
  showData: boolean = false;
  delLocation: string;
  originalData: any;
  newFilter;
  storeTags = [];
  loader: boolean = false;
  exportLoader: boolean = false;
  value = '';
  reportOutputOriginal: any;
  pageNumber = 1;
  pageSizes = [5, 10, 15, 20];
  ItemPerPage = 15;
  pagedItems = [];
  displayMsg: any;

  constructor(
    private reportsService: ReportsService,
    private constantData: ConstantData,
    private multipleFilterPipe: MultipleFilterPipe,
    private tableUtil: TableUtil,
    private eventService: EventService,
    public datepipe: DatePipe,
    private commonWebService: CommonWebService,
    private filterpipe: FilterpipePipe,
  ) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    // this.userRole = this.constantData.roles[99];
    // this.userInfo.NTID = 'VTALAU187'
    // this.functionId = '57';
    //this.eventService.showSpinner();
    this.loader = true
    this.fetchOrders();
    this.fetchOrdersCount();
  }

  fetchOrders() {
    let request = {
      ParametersInput: [{
        Name: "REQUESTOR",
        Value: this.userInfo.NTID
      }],
      ReportId: this.constantData.dynamicmyorderId[this.functionId]
    };
    this.fetchDynamicReport(request);
  }

  fetchOrdersCount() {
   // if (this.functionId == '51') {
      if (this.functionId == '136') {
      let request = {
        ReportId: '50017',
        ParametersInput: [{
          Name: "REQUESTOR",
          Value: this.userInfo.NTID
        }]
      }
      this.reportsService.onGetDynamicReport(request).subscribe(response => {
        this.displayMsg = response.ROW[0].MESSAGE;
      })
    }
  }

  fetchDynamicReport(request: any) {
    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      this.loader = false;
      //this.eventService.hideSpinner();
      this.reportOutput = response.ROW;
      this.reportOutputOriginal = response.ROW;
      this.data = this.reportOutput;
      this.pagedItems = this.reportOutput

      this.originalData = response.ROW;
      //this.searchEventCall(this.storeTags);
      this.newFilter = [];
      this.newFilter.push(
        { control: 'STATUS', label: 'Status', tagsList: [], searchTxt: '' },
        // { control: 'ORDER_SOURCE', label: 'Order Source', tagsList: [], searchTxt: '' },  
      )

      // if (this.functionId == '51') {
        if (this.functionId == '136') {
        this.filterBySite(this.originalData);
        this.filterByCustomer(this.originalData);
        this.newFilter.push(
          { control: 'site', label: 'Delivery Site', tagsList: this.sites, searchTxt: '' },
          { control: 'Order_Type', label: 'Order Type', tagsList: [], searchTxt: '' },
          //{ control: 'customer', label: 'Customer', tagsList: this.customers, searchTxt: '' },
        )
      }

      for (let key of this.newFilter) {
        if ((key.control === 'STATUS' && this.originalData) || (key.control === 'Order_Type' && this.originalData)) {
          for (let x of this.originalData) {

            let findKey = key.tagsList.find(o => this.getUpperCase(o.name) === this.getUpperCase(x[key.control])) ? false : true;
            if (findKey) {
              key.tagsList.push({ selected: false, name: this.getUpperCase(x[key.control]), value: this.data.filter(v => this.getUpperCase(v[key.control]) == this.getUpperCase(x[key.control])).length })
            }
          }
        }

        key.tagsList = key.tagsList.sort((a, b) => (a.value > b.value ? -1 : 1))
      }

    }, error => {
      // console.log(error);
      this.spinner = false;
    });
  }
  getUpperCase(val) {
    return (val !== undefined && val !== null) ? val.toUpperCase() : val;
  }
  searchEventCall(tags) {
    sessionStorage.setItem(this.userInfo.NTID + "Filter", JSON.stringify(tags))
    //this.data = [];
    let isFilter = false;
    let filters = {
      customer: [],
      site: []
    };
    let filter1 = {};
    if (tags.filterArr) {
      for (let opt of tags.filterArr) {
        let arr = [];
        if (opt.control == 'site' || opt.control == 'customer') {
          opt.tags.forEach(tag => {
            arr.push(tag.name)
          })
          filters[opt.control] = arr
        }
        else {
          opt.tags.forEach(tag => {
            isFilter = true;
            arr.push(tag.name)
          })
          filter1[opt.control] = arr
        }
      }
    }

    let result;
    if (tags.startDate && tags.endDate) {
      result = this.originalData.filter(report => new Date(report.CREATION_DATE) >= new Date(tags.startDate) && new Date(report['CREATION_DATE']) <= new Date(tags.endDate));
    } else {
      result = this.originalData;
    }
    let filteredItems;
    if (filters.customer.length != 0) {
      filteredItems = result.filter(i => {
        for (let j = 0; j < filters.customer.length; j++) {
          if (i['Delivery Location'] && i['Delivery Location'].split('|')[0] == filters.customer[j])
            return true;
        }
      })
    }
    if (filters.site.length != 0) {
      filteredItems = (filteredItems ? filteredItems : result).filter(i => {
        for (let j = 0; j < filters.site.length; j++) {
          if (i['Delivery Location'] && i['Delivery Location'].split('|')[0] == filters.site[j])
            return true;
        }
      })
    }
    if (isFilter) {
      this.data = this.multipleFilterPipe.transform((filteredItems) ? filteredItems : result, filter1)
    }
    else {
      this.data = (filteredItems) ? filteredItems : result;
    }
    if ((this.data && this.data.length === 0) && isFilter == false && result.length === 0 && (!tags.startDate && !tags.endDate)) {
      this.data = this.originalData;
    }

    this.value = '';
    this.pageNumber = 1;
    // this.pagedItems = this.data
    this.reportOutput = this.data;
    this.storeTags = tags;




    // if(tags.endDate) {
    //   let result;
    //   result = this.originalData.filter(report => new Date(report.CREATION_DATE) >= tags.startDate && new Date(report.SHIP_BY_DATE) <= tags.endDate);
    //   this.reportOutput = result;
    // }
    // else {
    //   this.data = this.multipleFilterPipe.transform(this.originalData, filters)
    //   if (this.data.length === 0 && isFilter == false) {
    //     this.data = this.originalData;
    //   }
    //   this.data = this.removeDuplicate(this.data);
    //   this.storeTags = tags;  
    //   this.reportOutput = this.data;
    // }
  }

  setPage($event) {
    if ($event !== undefined) {
      this.pagedItems = $event.pagedItems;
      this.pageNumber = $event.pageNumber;
      this.ItemPerPage = $event.itemsPerPage;
    }
  }

  clearAll() {
    this.value = '';
    this.reportOutput = this.data;
    // this.pagedItems = this.reportOutput
    this.pageNumber = 1;
  }

  removeDuplicate(arr) {
    return arr.filter((el, i, a) => i === a.indexOf(el))
  }

  filterByCustomer(reportOutput: any) {
    let eventList = [...new Set(reportOutput.map(item => item['Delivery Location'] && item['Delivery Location'].split('|')[0]))];
    let event = this.removeDuplicate(eventList);
    eventList.forEach(customerItem => {
      if (customerItem != undefined) {
        this.customers.push({
          selected: false,
          name: customerItem,
          value: this.countByCustomer(customerItem)
        })
      }
    })
    this.pagedItems = this.reportOutput
  }
  countByCustomer(customerItem) {
    let counter = 0;
    for (const obj of this.reportOutput) {
      if (obj['Delivery Location'] && obj['Delivery Location'].split('|')[0] === customerItem)
        counter++;
    }
    return counter;
  }

  filterBySite(reportOutput: any) {
    let eventList = [...new Set(reportOutput.map(item => item['Delivery Location'] && item['Delivery Location'].split('|')[0]))];
    eventList.forEach(siteItem => {
      if (siteItem != undefined) {
        this.sites.push({
          selected: false,
          name: siteItem,
          value: this.countBySite(siteItem)
        })
      }
    })
    this.pagedItems = this.reportOutput
  }
  countBySite(siteItem) {
    let counter = 0;
    for (const obj of this.reportOutput) {
      if (obj['Delivery Location'] && obj['Delivery Location'].split('|')[0] === siteItem)
        counter++;
    }
    return counter;
  }

  onDateChange() {
    let reports = this.data;
    let result;
    result = reports.filter(report => new Date(report.CREATION_DATE) >= this.range.controls.startDate.value && new Date(report.CREATION_DATE) <= this.range.controls.endDate.value);
    this.reportOutput = result;
    if (result.length == 0) {
      this.reportOutput = null;
    }
    this.deliverySite.patchValue([]);
    this.status.patchValue([]);
    this.customer.patchValue([]);
    this.pagedItems = this.reportOutput
  }

  onRefresh() {
    this.spinner = true;
    this.fetchOrders();
  }

  exportOrders() {
    this.exportLoader = true;
    let ESIdata;
    if (this.constantData.exportingOrdersId[this.functionId]) {
      let statusArray = []
      let siteArray = []
      let typeArray = [];
      if (this.storeTags['filterArr']) {
        for (let opt of this.storeTags['filterArr']) {
          if (opt.control == 'STATUS') {
            opt.tags.forEach(e => {
              statusArray.push(e.name)
            })
          }
          if (opt.control == 'site') {
            opt.tags.forEach(e => {
              siteArray.push(e.name)
            })
          }
          if (opt.control == 'Order_Type') {
            opt.tags.forEach(e => {
              typeArray.push(e.name)
            })
          }
        }
      }
      let Reqdata = {
        "ReportId": this.constantData.exportingOrdersId[this.functionId],
        "ParametersInput": [
          { "Name": "REQUESTOR", "Value": this.userInfo.NTID },
          { "Name": "STATUS", "Value": statusArray.toString() },
          { "Name": "ORDER_DATE_FROM", "Value": this.storeTags['startDate'] ? this.datepipe.transform(this.storeTags['startDate'], 'yyyy-MM-dd') : "" },
          { "Name": "ORDER_DATE_TO", "Value": this.storeTags['endDate'] ? this.datepipe.transform(this.storeTags['endDate'], 'yyyy-MM-dd') : "" }
        ]
      }
      // if (this.functionId == '51') {
        if (this.functionId == '136') {
        Reqdata.ParametersInput.push({
          "Name": "DELIVERY_SITE",
          "Value": siteArray.toString()
        })
        Reqdata.ParametersInput.push({
          "Name": "ORDER_TYPE",
          "Value": typeArray.toString()
        })
      }
      this.reportsService.onGetDynamicReport(Reqdata).subscribe(response => {
        if (response && response != undefined) {

          if (response.ROW && response.ROW.length > 0) {
            ESIdata = response.ROW
            ESIdata.forEach(data => {
              delete data['@num'];
            })
            this.tableUtil.exportTableToCsv(ESIdata, this.fileName)
          }
          this.exportLoader = false;
        }
        else {
          this.commonWebService.openSnackBar("There is some error while exporting the data", "ERROR")
          this.exportLoader = false;
        }

      }, error => {
        this.exportLoader = false;
        this.commonWebService.openSnackBar("There is some error while exporting the data", "ERROR")
      })
    }
    else {
      let headers = ['REQUISITION_NUMBER', 'REQ_HEADER_DESCRIPTION', 'STATUS', 'REQUESTOR', 'ISO_ORDER_STATUS', 'NOTE_TO_AUTHORIZER', 'SHIPPING_STATUS', 'TRACKING_NUMBER', 'DELIVERY_LOCATION', 'SHIP_BY_DATE', 'PREPARER']
      this.tableUtil.exportToCsvWithGivenHeaders(this.data, this.fileName, headers)
      this.exportLoader = false;
    }
    //this.tableUtil.exportTableToCsv( this.data , this.fileName);
  }

  goBack() {
    window.history.back();
  }

  search() {
    this.reportOutput = this.filterpipe.transform(this.data, this.value);
    this.pageNumber = 1;
    // this.pagedItems = [...this.reportOutput]
  }

}
