import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { CommonService, ProductService, ReportsService, ConstantData, GetimageService } from 'hub2ushared';
import { Subscription } from 'rxjs';
import { CommonWebService } from '../../shared/common-web.service';
import { EventService } from '../../shared/event.service';
import { LoadCartService } from '../../shared/loadcart.service';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.scss'],
})
export class ItemDetailsComponent implements OnInit {
  cifaItemNo: any;
  modelNum: any;
  userInfo: any;
  functionId: string;
  userRole: string;
  item: any;
  itemDetails: any;
  previewImage;
  // imageURL = this.env.baseIMGUrl;
  noData: boolean = true;
  date: Date;
  displayFields = [];
  displayLineFields = [];
  attr6: any;
  needByDate: any;
  itemEventSubscription: Subscription;

  @ViewChild('callImagePreview') callImagePreview: TemplateRef<any>;
  detailsResponse: any;
  loader: boolean = false;
  loaderAddtocart: boolean = false;
  sourceOrg: any;
  subInv: any = "";

  constructor(@Inject('environment') private env: any, private loadCartService: LoadCartService,
    private router: Router, private eventService: EventService, private dialog: MatDialog, public datepipe: DatePipe,
    private reportsService: ReportsService, private productService: ProductService, private commonWebService: CommonWebService,
    private commonService: CommonService, private constantData: ConstantData, private GetimageService: GetimageService) {
    this.itemEventSubscription = this.loadCartService.getItem().subscribe(response => {
      this.item = response;
      this.cifaItemNo = (response.CIFA_ITEM_NUMBER || response['CIFA#']);
      this.modelNum = response.MANUFACTURER_PART_NUM
      this.onInitialLoad();
    })
    if (this.router.getCurrentNavigation().extras.state != undefined) {
      this.item = this.router.getCurrentNavigation().extras.state.item;
      this.cifaItemNo = (this.item.CIFA_ITEM_NUMBER || this.item['CIFA#']);
      this.modelNum = this.item.MANUFACTURER_PART_NUM
    }
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    //this.eventService.showSpinner()
    // this.loader = true;
    this.onInitialLoad();
    this.getPreferenceData();
  }

  onInitialLoad() {
    this.loader = true;
    let request1;
    let reportId = this.constantData.cifaItemDetails[this.functionId]

    if (reportId == '1091' || reportId == ' 10161') {
      request1 = {
        ParametersInput: [
          { Name: "USER_NAME", Value: this.userInfo.NTID },
          { Name: "REGION_NAME", Value: (this.item['Region Name'] || this.item['REGION_NAME']) ? (this.item['Region Name'] || this.item['REGION_NAME']) : "null" },
          { Name: "TEMPLATE_NAME", Value: (this.item['Template Name'] || this.item['TEMPLATE_NAME']) ? (this.item['Template Name'] || this.item['TEMPLATE_NAME']) : "null" },
          { Name: "CIFA_ITEM_NUMBER", Value: this.cifaItemNo ? this.cifaItemNo : "null" },
          { Name: "eis_model_number", Value: this.item.MANUFACTURER_PART_NUM ? this.item.MANUFACTURER_PART_NUM : "null" },
        ],
        ReportId: reportId
      }
    } else {
      request1 = {
        ParametersInput: [
          { Name: "USER_NAME", Value: this.userInfo.NTID },
          { Name: "REGION_NAME", Value: (this.item['REGION_NAME'] || this.item['Region Name']) ? (this.item['REGION_NAME'] || this.item['Region Name']) : "null" },
          { Name: "TEMPLATE_NAME", Value: (this.item['TEMPLATE_NAME'] || this.item['Template Name']) ? (this.item['TEMPLATE_NAME'] || this.item['Template Name']) : "null" },
          { Name: "CIFA_ITEM_NUMBER", Value: this.cifaItemNo ? this.cifaItemNo : "null" },
          { Name: "MANUFACTURER_PART_NUM", Value: this.modelNum ? this.modelNum : "null" },
        ],
        ReportId: reportId
      }
    }
    this.reportsService.onGetDynamicReport(request1).subscribe(response => {
      if (response && response != undefined) {
        if (response.ROW && response.ROW != undefined) {
          this.itemDetails = response.ROW[0];
          console.log(this.itemDetails);
          this.displayFields = this.OrganizedCart(this.itemDetails, 'HEADER_COLUMNS');
          this.displayLineFields = this.OrganizedCart(this.itemDetails, 'LINE_COLUMNS');
          this.noData = false;
        }

      }
      else {
        this.noData = true;
      }

      this.loader = false;
    }, error => {
      this.noData = true;
      this.loader = false;
      this.eventService.hideSpinner();
      console.log(error);
    })
  }

  OrganizedCart(resp, col) {
    let display_column = [];
    if (resp !== undefined) {
      if (resp[col] !== undefined) {
        display_column = this.convertToArray(resp[col]);
      }
    }
    return display_column
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
      else {
        col = columns;
      }
    }
    return col;
  }

  isAvailable(key, data) {
    let dataToSearch = [];
    if (data == 'itemListHeader') {
      dataToSearch = this.displayFields
    } if (data == 'itemListLineDetails') {
      dataToSearch = this.displayLineFields
    }
    return dataToSearch.includes(key);
  }

  errorHandler(event) {
    // console.debug(event);
    event.target.src = "../../../../assets/images/no-image.jpg";
  }
  // getImage(cifaItem) {
  //   return this.imageURL + cifaItem + ".jpg";
  // }

  openPreview(imagePath) {
    this.previewImage = imagePath
    let dialogRef = this.dialog.open(this.callImagePreview);
    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        if (result === 'yes') {
        } else if (result === 'no') {
        }
      }
    })
  }

  // getImage(cardDetails) {
  //   // let cifaItem=cardDetails.CIFA_ITEM_NUMBER ? cardDetails.CIFA_ITEM_NUMBER : cardDetails.MANUFACTURER_PART_NUM.replace(/ /g,"-")  
  //   let cifaItem = this.cifaItemNo ? this.cifaItemNo : this.modelNum;
  //   return this.imageURL + cifaItem + ".jpg";
  // }


  /**SOA TO JAVA */
  getImage(cardDetails) {
    // let cifaItem=cardDetails.CIFA_ITEM_NUMBER ? cardDetails.CIFA_ITEM_NUMBER : cardDetails.MANUFACTURER_PART_NUM.replace(/ /g,"-")  
    let cifaItem = this.cifaItemNo ? this.cifaItemNo : this.modelNum;
    let image = this.GetimageService.getImagefromcifa(cifaItem)
    return image
  }
  dateFormatter(date) {
    if (date === "" || date === undefined) {
      return "";
    }
    var tempDate = date;
    if (date.replace != undefined) {
      tempDate = new Date(date.replace(/-/g, '/').replace('T‌​', ' ').replace(/\..*|\+.*/, ""));
    }
    var month = ("0" + (tempDate.getMonth() + 1)).slice(-2);
    var day = ("0" + tempDate.getDate()).slice(-2);
    var displayDate = tempDate.getFullYear() + "-" + month + "-" + day;
    return displayDate;
  }

  getDefaultOrderType() {
    if (this.functionId == '50' || this.functionId == '57' || this.functionId == '58' || this.functionId == '63') {
      return "INVENTORY"
    }
    // if (this.functionId == '51' ) {
      if (this.functionId == '136') {
      return "FULFILLMENT"
    }
    if (this.functionId == '99' && (!this.attr6 || this.attr6 == "null")) {
      return 'PROJECT'
    }
    // if (this.functionId != '47' && this.functionId != '99' && this.functionId != '51'&& this.functionId != '136' && this.functionId != '50' && this.functionId != '57' && this.functionId != '58' && this.functionId != '63') {
      if (this.functionId != '47' && this.functionId != '143' && this.functionId != '136'&& this.functionId != '136' && this.functionId != '50' && this.functionId != '57' && this.functionId != '58' && this.functionId != '63') {
      return "PROJECT"
    }
  }

  getPreferenceData() {
    let request = {
      ParametersInput: [
        { Name: "USER_NAME", Value: this.userInfo.NTID },
      ],
      // ReportId: "112"
      // ReportId: "7001"
      ReportId:this.constantData.userprofileData[this.functionId],
    }
    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response != undefined && response.ROW != undefined) {
        this.needByDate = response.ROW[0].NEED_BY_DATE_TIME;
        this.attr6 = response.ROW[0].ATTRIBUTE5;
        this.sourceOrg = response.ROW[0].SOURCE_LOCATION
        this.subInv =  response.ROW[0].SUBINVENTORY 
      }
    }, error => {
      console.log(error);
    })
  }

  addToCart() {
    let attribut6 = this.getDefaultOrderType();
    let item = this.item;   // tech user
    // let date = new Date();
    // date.setDate(date.getDate() + 6);
    // let needByDate = this.dateFormatter(date);
    let qty = this.itemDetails['MIN_ORD_QTY'] != null ? this.itemDetails['MIN_ORD_QTY'] : 1;
    this.loaderAddtocart = true;
    // var cartInputData = {
    //   "sourceSystem": "TECHAPP",
    //   "shoppingCartUpsertData": [{
    //     "attribute3" : this.userRole.toUpperCase(),
    //     "attribute6": this.attr6 && this.attr6 != 'null' ? this.attr6 : attribut6,
    //     "cifaItemNumber": this.itemDetails["CIFA#"],
    //     "itemDescription": this.itemDetails.DESCRIPTION,
    //     "itemCategory": this.itemDetails.CATEGORY,
    //     "quantity": qty,
    //     "needByDate": this.needByDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needByDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (2 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),
    //     "userName": this.userInfo.NTID,
    //     "sourceSubInventory": (this.sourceOrg == (this.itemDetails['ORGANIZATION_CODE'] || this.itemDetails.SOURCE_ORGANIZATION_CODE)) && this.functionId == '99' ? (this.subInv !== "" ? this.subInv : this.itemDetails['SOURCE_SUBINVENTORY']) : this.itemDetails['SOURCE_SUBINVENTORY'],
    //     "sourceOrganizationCode": this.itemDetails.SOURCE_ORGANIZATION_CODE,
    //     "regionName": this.itemDetails.REGION_NAME ? this.itemDetails.REGION_NAME : this.itemDetails['Region Name'],
    //     "regionTemplate": this.itemDetails.TEMPLATE_NAME ? this.itemDetails.TEMPLATE_NAME : this.itemDetails['Template Name'],
    //     "vendorItemNumber": this.itemDetails['MODEL#'],
    //   }]
    // }

    var cartInputData = {
      "sourceSystem": "TECHAPP",
      "profile":this.userRole.toUpperCase(),
      "shoppingCartUpsertData": [{
        "quantity": qty,
        "kitQty": "",
        "requestorName": this.userInfo.NTID,
        "profileType": this.userRole.toUpperCase(),
        "orderType": this.attr6 && this.attr6 != 'null' ? this.attr6 : attribut6,
        // "deliveryLocationCode": this.getLocCode(),
        "needByDate": this.needByDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needByDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (2 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),
        "cifaItemNumber": this.itemDetails["CIFA#"],
        "itemDesc": this.itemDetails.DESCRIPTION,
        "sourceOrganizationCode": this.itemDetails.SOURCE_ORGANIZATION_CODE,
        // "customer": this.functionId == '136' ? (this.storeBusinessObj ? this.storeBusinessObj.CUSTOMER : this.catalogObj['LOOKUP_CODE']) : '',
        "regionName": this.itemDetails.REGION_NAME ? this.itemDetails.REGION_NAME : this.itemDetails['Region Name'],
        "templateName": this.itemDetails.TEMPLATE_NAME ? this.itemDetails.TEMPLATE_NAME : this.itemDetails['Template Name'],
        // "attribute13": item['ATTRIBUTE13'],
      }]
    }
    this.productService.addToCart(cartInputData).subscribe(response => {
      if (response !== undefined) {
        let message = response['STATUS_MESSAGE'] || response['statusMessage'] || '';
        if (response['status'] === 'SUCCESS') {
          this.commonService.updatedCart(true);
          this.commonWebService.openSnackBar(message, "SUCCESS")
        }
        if (response['status'] === 'FAILED') {
          this.commonWebService.openSnackBar(message, "ERROR")
        }
        this.loaderAddtocart = false;
      } else {
        this.loaderAddtocart = false;
      }
    }, error => {
      this.commonWebService.openSnackBar("There is some error in adding product to the cart", "ERROR")
      this.loaderAddtocart = false;
    });
  }

  selectSource() {
    this.router.navigate(['hub2u/select_source/'], { state: { item: this.itemDetails, favItem: this.item } })
  }

  goBack() {
    window.history.back();
  }

}
