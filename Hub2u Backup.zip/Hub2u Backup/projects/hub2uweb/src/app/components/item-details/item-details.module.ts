import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ItemDetailsComponent } from './item-details.component';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgxSpinnerModule } from 'ngx-spinner';
import {MatDialogModule} from '@angular/material/dialog';
import {MatButtonModule} from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { Hub2usharedModule } from 'hub2ushared';

const routes: Routes = [
  {
    path: '',
    component: ItemDetailsComponent
  }
];

@NgModule({
  declarations: [ItemDetailsComponent],
  imports: [
    CommonModule,
    MatTooltipModule,
    MatIconModule,
    NgxSpinnerModule,
    MatCardModule,
    MatDialogModule,
    MatButtonModule,
    Hub2usharedModule,
    RouterModule.forChild(routes)
  ]
})
export class ItemDetailsModule { }
