import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import {MAT_DIALOG_DATA} from '@angular/material/dialog';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { AnnouncementsService } from 'hub2ushared';
import { SafehtmlPipe } from 'hub2ushared';




@Component({
  selector: 'app-announcement-popup',
  templateUrl: './announcement-popup.component.html',
  styleUrls: ['./announcement-popup.component.scss'],
  providers:[SafehtmlPipe,NgbCarouselConfig]
  
})
export class AnnouncementPopupComponent implements OnInit {
  contentModel;
  userInfo: any = {};
  isDisabled=true
  disable=false;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,private announcementsService: AnnouncementsService,configAnn: NgbCarouselConfig) { 

    // configAnn.interval = 2000;
    // configAnn.keyboard = true;
    // configAnn.pauseOnHover = true;
    configAnn.showNavigationIndicators = true;
    configAnn.showNavigationArrows=false;
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.contentModel=this.data;
    for (let item of this.contentModel) {
      if(item.flag != undefined){
        if(item.flag == "preview"){
          item.disableButton=false;
        }else{
          item.disableButton=true;
        }
      }else {
      item.disableButton=true;
      }
    }
  //  console.log(" this.contentModel", this.contentModel)

  }


  updateLike(msgId, noOfLikes,i) {
   // console.log("updateLike",msgId, noOfLikes);
    for (let item of this.contentModel) {
      if(item.flag != undefined){
        if(item.flag == "preview"){
          item.disableButton=false;
        }
      }else {
        if (item.msgId == msgId) {
          item.noOfLikes= noOfLikes + 1;
          item.disableButton=true;
          //console.log("item.enableButton",item.disableButton)
          this.updateInDB(msgId);
        }
      }
    }
    //this.disable=false;
    // this.updateInDB(msgId);
  }
  updateLikes(event) {
    //console.log("likes",event);
    //this.updateInDB(event.msgId)
  }


  updateInDB(msgId) {
    //document.getElementById("likeBtn").innerHTML = noOfLikes + 1;
    //console.log("msgId",msgId)

    var flashCardsInput = {
      'applicationId': "1",
      'messageId': msgId,
      'userId': this.userInfo.NTID
    };
    this.announcementsService.updateAnnouncementLikes(flashCardsInput).subscribe(response => {
     // console.log(response);
    }, error => {
    });
  }

  updateReadInDB(msgId){

  //  console.log("msgId",msgId)

    var flashCardsInput = {
      'applicationId': "1",
      'messageId': msgId,
      'userId': this.userInfo.NTID
    };
    this.announcementsService.updateAnnouncementRead(flashCardsInput).subscribe(response => {
     // console.log(response);
    }, error => {
    });

  }
}
