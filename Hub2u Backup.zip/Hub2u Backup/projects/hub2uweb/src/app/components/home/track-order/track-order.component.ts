import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ReportsService } from 'hub2ushared';
@Component({
  selector: 'app-track-order',
  templateUrl: './track-order.component.html',
  styleUrls: ['./track-order.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TrackOrderComponent implements OnInit {

  constructor(private fb: FormBuilder,private router:Router, private reportService: ReportsService) { }
  trackFormControl: FormGroup;
  trackingNo = ''

  ngOnInit() {
    // this.trackFormControl = this.fb.group({
    //   trackNo: ['', Validators.required]
    // });
  }
  trackNumber() { 
    // var formValues = this.trackFormControl.value;
    // this.router.navigate(['hub2u/trackorder/'] , { state: { trackNo: formValues["trackNo"],redirect: 'fromHomePage'} })
    this.router.navigate(['hub2u/trackorder/'] , { state: { trackNo: this.trackingNo,redirect: 'fromHomePage'} })
  }
}
