import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home.component';
import { AnnouncementComponent } from './announcement/announcement.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FrequentOrderComponent } from './frequent-order/frequent-order.component';
import { AnnouncementPopupComponent } from './announcement-popup/announcement-popup.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { MyDetailsComponent } from './my-details/my-details.component';
import { RecentOrderComponent } from './recent-order/recent-order.component';
import { MyApprovalsComponent } from './my-approvals/my-approvals.component';
import { CheckStatusComponent } from './recent-order/check-status/check-status.component';
import { SupportComponent } from './support/support.component';
import { TrackOrderComponent } from './track-order/track-order.component';
import { RibbonAnnouncementComponent } from './ribbon-announcement/ribbon-announcement.component';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatBottomSheetModule } from '@angular/material/bottom-sheet';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatListModule } from '@angular/material/list';
import { MatBadgeModule } from '@angular/material/badge';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { Hub2usharedModule } from 'hub2ushared';
import { MatToolbarModule } from '@angular/material/toolbar';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AnimatedDigitComponent } from './animated-digit/animated-digit.component';
const routes: Routes = [
  {
    path: '', component: HomeComponent,
    children: [
      {
        path: '', component: DashboardComponent 
      }
    ]
  }
];

@NgModule({
  declarations: [HomeComponent, AnnouncementComponent, MyApprovalsComponent, DashboardComponent, FrequentOrderComponent, OrderDetailsComponent,
    RecentOrderComponent, SupportComponent, TrackOrderComponent, MyDetailsComponent, AnimatedDigitComponent, 
    CheckStatusComponent, AnnouncementPopupComponent, RibbonAnnouncementComponent],
  exports: [CheckStatusComponent],
  entryComponents: [CheckStatusComponent],
  imports: [
    MatButtonModule,
    NgxSpinnerModule,
    MatCardModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatTooltipModule,
    MatBottomSheetModule,
    MatListModule,
    MatBadgeModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatDialogModule,
    FormsModule, ReactiveFormsModule,
    NgbModule,
    Hub2usharedModule,
    MatToolbarModule,
    CommonModule, RouterModule.forChild(routes)
  ]
})
export class HomeModule { }
