import { Component, OnInit, ViewChild, ElementRef, ViewEncapsulation, TemplateRef } from '@angular/core';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog } from '@angular/material/dialog'
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AnnouncementPopupComponent } from './../announcement-popup/announcement-popup.component'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  providers: [NgbCarouselConfig],
  encapsulation: ViewEncapsulation.None,
  // animations: [ 
  //   trigger('slideInOut', [
  //     state('in', style({
  //       transform: 'translate3d(0, 0, 0)'
  //     })),
  //     state('out', style({
  //       transform: 'translate3d(100%, 0, 0)'
  //     })),
  //     transition('in => out', animate('400ms ease-in-out')),
  //     transition('out => in', animate('400ms ease-in-out'))
  //   ]),
  // ],
})
export class DashboardComponent implements OnInit {
  @ViewChild('closeBtn') closeBtn: ElementRef;
  @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;
  contentModel = [];
  isShowMyDetails = true;
  isMyApproval = true;
  userInfo: any = {};
  showTrackOrder: string = 'out';
  ribbonData: any =[];
  allRibbonData: any =[];
  constructor(configAnn: NgbCarouselConfig, private dialog: MatDialog) {
    configAnn.interval = 2000;
    configAnn.keyboard = true;
    configAnn.pauseOnHover = true;
    configAnn.showNavigationIndicators = true;
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
  }

  checkData(event) {
    // console.log(event);
  }

  openTrackOrder() {
    this.showTrackOrder = this.showTrackOrder === 'out' ? 'in' : 'out';
  }
  showMyDetails(event) {
    if (event == 'Y') {
      this.isShowMyDetails = true;
    } else {
      this.isShowMyDetails = false;
    }
  }
  showMyApproval(event) {
    if (event > 0) {
      this.isMyApproval = true;
    } else {
      this.isMyApproval = false;
    }
  }

  loadtickerData(data){
    this.allRibbonData = data;
    this.ribbonData = data.filter(item => item.msgType == 'RIBBON')
  }

  openAnnoucementModalpopup(data) {
    this.contentModel = data; 
        const dialogRef = this.dialog.open(AnnouncementPopupComponent,
          {
            width: '800px',
            // height:'400px',
            panelClass: 'annu-dialog',
            data: data
          });
        dialogRef.afterClosed().subscribe(result => {
          sessionStorage.setItem("flashCardPopupRendered", "Y");
          if (result !== undefined) {
            if (result === 'show') {
              sessionStorage.setItem("showPopup", "yes");
            } else if (result === 'nice') {
              sessionStorage.setItem("showPopup", "no");
            }
          }
        }) 
  } 
}
