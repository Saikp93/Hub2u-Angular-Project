import { Component, OnInit, ViewEncapsulation, Output, EventEmitter, Input } from '@angular/core';
import { ConstantData, MessageService, ReportsService } from 'hub2ushared';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { AnnouncementPopupComponent } from './../announcement-popup/announcement-popup.component'
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-announcement',
  templateUrl: './announcement.component.html',
  styleUrls: ['./announcement.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [NgbCarouselConfig],
})
export class AnnouncementComponent implements OnInit {
  userInfo: any = {};
  userRole: any = '';
  announcements: any = [];
  annoucementArray = [];
  loader = false;
  contentModel;
  disable = [false];
  @Input() showNavigationIndicators: boolean;
  @Output() annoucementDetails = new EventEmitter();
  @Output() tickerData = new EventEmitter();
  @Output() updateLikes = new EventEmitter();

  sampleTickerData =[
    {
        "APPLICATION_ID": 1,
        "MESSAGE_ID": 47082,
        "MESSAGE_TYPE": "FLASH CARDS",
        "CREATION_DATE": 1689056416000,
        "CREATED_BY": "VTALAU187",
        "REGION_NAME": null,
        "MESSAGE_TEXT": "<p>TEST ANNAOUNCEMENT&nbsp;</p>",
        "START_DATE": 1689056380000,
        "EXPIRES_ON": 1696832380000,
        "PUBLISHED": "Y",
        "ACKNOWLEDGEMENT_REQ": "N",
        "ATTRIBUTE1": "COMCAST TECH USER IIP, COMCAST STORE USER, COMCAST BUSINESS SERVICES USER",
        "ATTRIBUTE2": null,
        "ATTRIBUTE3": null,
        "ATTRIBUTE4": null,
        "ATTRIBUTE5": null,
        "USER_LIKES": 0,
        "LIKES": 0,
        "@num": 1
    },
    {
        "APPLICATION_ID": 1,
        "MESSAGE_ID": 47085,
        "MESSAGE_TYPE": "RIBBON",
        "CREATION_DATE": 1689060823000,
        "CREATED_BY": "VTALAU187",
        "REGION_NAME": null,
        "MESSAGE_TEXT": "<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s</p>",
        "START_DATE": 1689060780000,
        "EXPIRES_ON": 1696836780000,
        "PUBLISHED": "Y",
        "ACKNOWLEDGEMENT_REQ": "N",
        "ATTRIBUTE1": "COMCAST TECH USER IIP, COMCAST STORE USER, COMCAST BUSINESS SERVICES USER",
        "ATTRIBUTE2": null,
        "ATTRIBUTE3": null,
        "ATTRIBUTE4": null,
        "ATTRIBUTE5": null,
        "USER_LIKES": 0,
        "LIKES": 0,
        "@num": 2
    },
    {
      "APPLICATION_ID": 1,
      "MESSAGE_ID": 47085,
      "MESSAGE_TYPE": "FLASH CARDS",
      "CREATION_DATE": 1689060823000,
      "CREATED_BY": "VTALAU187",
      "REGION_NAME": null,
      "MESSAGE_TEXT": "<p>Old UI test Announcement&nbsp;</p>",
      "START_DATE": 1689060780000,
      "EXPIRES_ON": 1696836780000,
      "PUBLISHED": "Y",
      "ACKNOWLEDGEMENT_REQ": "N",
      "ATTRIBUTE1": "COMCAST TECH USER IIP, COMCAST STORE USER, COMCAST BUSINESS SERVICES USER",
      "ATTRIBUTE2": null,
      "ATTRIBUTE3": null,
      "ATTRIBUTE4": null,
      "ATTRIBUTE5": null,
      "USER_LIKES": 0,
      "LIKES": 0,
      "@num": 3
  },
  {
    "APPLICATION_ID": 1,
    "MESSAGE_ID": 47085,
    "MESSAGE_TYPE": "RIBBON",
    "CREATION_DATE": 1689060823000,
    "CREATED_BY": "VTALAU187",
    "REGION_NAME": null,
    "MESSAGE_TEXT": "<p>Old UI test Announcement&nbsp;</p>",
    "START_DATE": 1689060780000,
    "EXPIRES_ON": 1696836780000,
    "PUBLISHED": "Y",
    "ACKNOWLEDGEMENT_REQ": "N",
    "ATTRIBUTE1": "COMCAST TECH USER IIP, COMCAST STORE USER, COMCAST BUSINESS SERVICES USER",
    "ATTRIBUTE2": null,
    "ATTRIBUTE3": null,
    "ATTRIBUTE4": null,
    "ATTRIBUTE5": null,
    "USER_LIKES": 0,
    "LIKES": 0,
    "@num": 4
}
  
  ]
  functionId: string;

  constructor(private reportService: ReportsService, configAnn: NgbCarouselConfig, private dialog: MatDialog,
    private messageService: MessageService,private constantData: ConstantData) {
    // configAnn.interval = 2000;
    // configAnn.keyboard = true;
    // configAnn.pauseOnHover = true;
    configAnn.showNavigationIndicators = true;
    configAnn.showNavigationArrows = false;
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.onInitialLoad();
  }

  async onInitialLoad() {
    this.userInfo = await JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');

    this.onCheckUserInfo();
  }
  onCheckUserInfo() {
    console.log('checking user info',window.location.pathname, this.userInfo.NTID,this.userRole,this.userInfo);
    if (this.userInfo !== null) {
      if (this.userInfo.NTID !== undefined) {
        if (localStorage.getItem(this.userInfo.NTID + "_responsibilities")) {
          let responsibilities = JSON.parse(localStorage.getItem(this.userInfo.NTID + "_responsibilities"));
          if (responsibilities.ROW !== undefined) {
            this.loadAllOperations(responsibilities)
          } else {
            this.getResp();
          }
        } else {
          this.getResp();
        }
      }
    }
  }

  getResp() {
    let object = {
      //"ReportId": "10087",
       "ReportId": "7002", // oracle fusion
       "ParametersInput":
        [{ "Name": "BIND_APPLICATIONID", "Value": "7" },
        { "Name": "USER_NAME", "Value": this.userInfo.NTID }]
    };

    //  this.commonService.onFetchUserResp(object).subscribe(response => {
    this.reportService.onGetDynamicReport(object).subscribe(response => {
      let resp = response || [];
      if (resp.ROW !== undefined) {
        localStorage.setItem(this.userInfo.NTID + "_responsibilities", JSON.stringify(resp));
        let responsibilities = JSON.parse(localStorage.getItem(this.userInfo.NTID + "_responsibilities"));
        this.loadAllOperations(responsibilities)
      } else {

      }
    }, error => {
    });
  }

  loadAllOperations(resp) {
    if (this.userInfo !== null) {
      let role = (resp && resp.ROW) ? resp.ROW.filter(e => e.TYPE == "USER_TYPE") : 0;
      if (role.length > 0) {
        this.userRole = this.constantData.roles[role[0].FUNCTION_ID];
        localStorage.setItem(this.userInfo.NTID + "_userRole", this.userRole);
        localStorage.setItem(this.userInfo.NTID + "_functionId", role[0].FUNCTION_ID);
      } else {
        localStorage.setItem(this.userInfo.NTID + "_userRole", "COMCAST TECH USER IIP");
        // localStorage.setItem(this.userInfo.NTID + "_functionId", '99');
        localStorage.setItem(this.userInfo.NTID + "_functionId", '143');
      }

      this.getAnnoucements();
    }
  }

  getAnnoucements() {
    this.loader = true;
    var flashCardsInput = {
      "ReportId": "1112",
      "ParametersInput": [
        { "Name": "P_USER_NAME", "Value": this.userInfo.NTID },
        { "Name": "APPLICATION_ID", "Value": 1 },
        { "Name": "USER_ROLE", "Value": this.userRole },
        { "Name": "P_DASHBOARD", "Value": "Y" }
      ]
    };
    this.reportService.onGetDynamicReport(flashCardsInput).subscribe(response => {
      if (response.ROW !== undefined && response.ROW !== null) { 
        this.announcements = response.ROW;
        this.announcements.forEach((item, idx) => {
          if (item.MESSAGE_TYPE == "RIBBON") {
            this.announcements.unshift(  
              this.announcements.splice(idx, 1)[0]
            )
          }
        });
       // this.announcements = this.sampleTickerData;
        this.loader = false;
        this.openIonModal(this.announcements)
      } else {
        this.announcements = [];
        this.loader = false;
      }
    }, error => {
    });
  }

  openIonModal(data) { 
    
    var response = data;
    var sliderHtml = "";
    if (response) {
      var inc = 0;
      var annArray = [];
      if (response.length > 0) {
     
        response.forEach(function (item, index) {
          var newImgSrc = "../../assets/images/no-image.jpg";
          var msgContent = "";

          var type = item.MESSAGE_TEXT;
          var msgId = item.MESSAGE_ID;
          var contentChk = /<[a-z/][\s\S]*>/i.test(type);
          //console.log("item",type,contentChk)
          var noOfLikes = item.LIKES || 0;
          var button = 'See More';
          var disableButton;

          if (item.USER_LIKES > 0) {
            disableButton = true;
          }
          else {
            disableButton = false;
          }
          if (contentChk == false) {
            msgContent = type;

          }
          else {
            msgContent = (item.MESSAGE_TEXT).replace(/<img[^>]*>/g, "");

            var parser = new DOMParser();
            var doc = parser.parseFromString(item.MESSAGE_TEXT, 'text/html');

            if (doc.body.getElementsByTagName('img').length > 0) {
              newImgSrc = doc.body.getElementsByTagName('img')[0].getAttribute("src");
              //console.log("item"+item+newImgSrc)
            }
          }
          annArray.push({ "newImgSrc": newImgSrc, "msgId": msgId, "noOfLikes": noOfLikes, "flag": "",
          "msgContent": msgContent, "button": button, "disableButton": disableButton, "msgType": item.MESSAGE_TYPE})
        });

      }
      this.annoucementArray = annArray; 
      this.messageService.sendRibbonMessage(this.annoucementArray);
      this.tickerData.emit(this.annoucementArray)
      
      if (!sessionStorage.getItem("flashCardPopupRendered")) {
        this.openModelPopup(); 
      } 
    }

  }

  openannouncemetPopup(data) {
    //console.log("data",data)
  }

  openAnnoucementModalpopup(data) {
    this.contentModel = data;
    const dialogRef = this.dialog.open(AnnouncementPopupComponent,
      {
        width: '800px',
        // height:'400px',
        panelClass: 'annu-dialog',

        data: data
      });
    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        if (result === 'show') {
          sessionStorage.setItem("showPopup", "yes");
        } else if (result === 'nice') {
          sessionStorage.setItem("showPopup", "no");
        }
      }
    })
  }


  openModelPopup() {
    this.annoucementDetails.emit(this.annoucementArray);
  }
  updateLike(msgId, noOfLikes, i) {
    //console.log("updateLike",msgId, noOfLikes);
    for (let item of this.contentModel) {
      if (item.msgId == msgId) {
        item.noOfLikes = noOfLikes + 1;
        item.disableButton = true;
        //console.log("item.enableButton",item.disableButton)

      }
    }
    //this.disable=false;

  }
}
