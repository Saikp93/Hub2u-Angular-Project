import { Component, OnInit } from '@angular/core';
import { ReportsService, ConstantData } from 'hub2ushared';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  userInfo: any = {};
  userRole: any = '';

  constructor(private reportService: ReportsService,private constantData: ConstantData) { }


  orderCount: any;
  recentOrder: any;
  frequentOrder: any;
  userProfile: any;
  announcements: any;
  functionId: string;
  ngOnInit() {
    // this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    // this.userRole = localStorage.getItem('userrole'); 
    // this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.onInitialLoad();
    // this.getRecentOrderCount();
    // this.getRecentOrders();
    // this.getFrequestOrders();
    // this.getMyDetails();
    // this.getAnnoucements();

  }

  async onInitialLoad() {
    this.userInfo = await JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');
    console.log("getting user role in home", this.userRole);
  }
  
  getRecentOrderCount() {
    // var recentOrder = this.constantData.recentOrderId[this.constantData.roles[this.userRole]];
    var functionId;
    Object.keys(this.constantData.roles).forEach((key) => {
      if (this.constantData.roles[key].toUpperCase() == this.userRole.toUpperCase()) {
        functionId = key;
      }
    })
    var orderGroupInput = {
      "ReportId": this.constantData.recentOrderId[functionId],
      "ParametersInput": [
        { "Name": "USER_NAME", "Value": this.userInfo.NTID } //MMCGIN143
      ]
    }
    this.reportService.onGetDynamicReport(orderGroupInput).subscribe(response => {
      if (response.ROW !== undefined) {
        this.orderCount = response.ROW[0];
      } else {
        this.orderCount = [];
      }
    }, error => {

    });
  }
  getRecentOrders() {
    var dataInput = { "ReportId": this.constantData.dynamicrecentOrderId[this.functionId], 
    "ParametersInput": 
                  [{ "Name": "REQUESTOR", 
                  "Value": this.userInfo.NTID 
                  }] 
 }
    this.reportService.onGetDynamicReport(dataInput).subscribe(response => {
      if (response.ROW !== undefined) {
        this.recentOrder = response.ROW;
      } else {
        this.recentOrder = [];
      }
    }, error => {
    });
  }

  getFrequestOrders() {
    var freqOrdersInput = {
      "ReportId": "1114",
      "ParametersInput": [
        { "Name": "USER_NAME", "Value": this.userInfo.NTID } //MMCGIN143
      ]
    }
    this.reportService.onGetDynamicReport(freqOrdersInput).subscribe(response => {
      if (response.ROW !== undefined) {
        this.frequentOrder = response.ROW;
      }
    }, error => {
    });
  }

  getMyDetails() {
    var settingsInput = { 
      // ReportId: 7001,
      // "ReportId": "112",
      ReportId:this.constantData.userprofileData[this.functionId], 
    "ParametersInput": [{ "Name": "USER_NAME", "Value": this.userInfo.NTID }] };
    this.reportService.onGetDynamicReport(settingsInput).subscribe(response => {

      if (response.ROW !== undefined) {
        this.userProfile = response.ROW[0];
      } else {
        this.userProfile = [];
      }
    }, error => {
    });
  }

  // getAnnoucements() {
  //   var flashCardsInput = {
  //     "ReportId": "1112",
  //     "ParametersInput": [
  //       { "Name": "P_USER_NAME", "Value": this.userInfo.NTID },
  //       { "Name": "APPLICATION_ID", "Value": 1 },
  //       { "Name": "USER_ROLE", "Value": this.userRole },
  //       { "Name": "P_DASHBOARD", "Value": "Y" }
  //     ]
  //   };
  //   this.reportService.onGetDynamicReport(flashCardsInput).subscribe(response => {
  //     if (response.ROW !== undefined) {
  //       this.announcements = response.ROW;
  //     } else {
  //       this.announcements = [];
  //     }
  //   }, error => {
  //   });
  // }
  checkResponsibilityAccess(id) {
    var data = JSON.parse(localStorage.getItem(this.userInfo.NTID + "_responsibilities"));
    var check = false;
    if (data !== null && data.EXC_DB_FETCH_USER_RESPOutput !== undefined) {
      data.EXC_DB_FETCH_USER_RESPOutput.forEach(function (responsibility) {
        if (id === responsibility.FUNCTION_ID) {
          check = true;
        }
      });
    }
    return check;
  }


}
