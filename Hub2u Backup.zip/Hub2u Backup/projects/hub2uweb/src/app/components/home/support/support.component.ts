import { Component, Inject, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog'
import { ReportsService } from 'hub2ushared';
import { EventService } from '../../../shared/event.service';
import { CommonWebService } from '../../../shared/common-web.service';
import { Router } from '@angular/router';
import html2canvas from 'html2canvas';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SnackbarComponent } from '../../snackbar/snackbar.component';
@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.scss'],
})
export class SupportComponent implements OnInit {
  @ViewChild('callHelpPreview') callHelpPreview: TemplateRef<any>;
  userInfo: any = {};
  userRole: any = '';
  supportDataSource: any[] = [];
  feedbackLink;
  nodata = false;
  loadSpinner: boolean;
  constructor(@Inject('environment') private env: any, private _snackBar: MatSnackBar, private router: Router, private commonWebService: CommonWebService, private dialog: MatDialog, private reportService: ReportsService, private eventService: EventService) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');

    //this.feedbackLink = this.env.feedbackformURL + "?appId=1&token=" + this.commonWebService.getToken();
  }

  openFeedbackForm() {
    let feedbackLink = this.env.feedbackformURL + "?appId=1&token=" + this.userInfo.access_token;

    window.open(feedbackLink, '_blank');
  }
  openHelpPreview() {
    this.eventService.showSpinner();
    this.supportDataSource = [];
    var input = {
      "ReportId": "1008",
      "ParametersInput": [
        { "Name": "LOOKUP_TYPE", "Value": 'XXCMST_HUB2U_HELP_SECTION' }
      ]
    }
    this.reportService.onGetDynamicReport(input).subscribe(response => {
      if (response.ROW !== undefined) {
        if (this.userRole !== undefined || this.userRole !== '') {
          var data = response.ROW.filter(item => item.MEANING.toUpperCase() == this.userRole.toUpperCase());
          let dialogRef = this.dialog.open(this.callHelpPreview, {
            width: '800px'
          });
          // this.dialog.open(this.help, {
          //   width: '800px'
          // });
          if (data.length > 0) {
            this.nodata = false
            for (let item of data) {
              this.supportDataSource.push({ "label": item.ATTRIBUTE1, "val": item.LATTRIBUTE1, "type": item.ATTRIBUTE2 })
            }

            dialogRef.afterClosed().subscribe(result => {
              if (result !== undefined) {
                if (result === 'yes') {
                } else if (result === 'no') {
                }
              }
            })
          }
          else {
            this.nodata = true
          }
        }
      }
      this.eventService.hideSpinner();
    }, error => {
      this.nodata = true
      this.eventService.hideSpinner();
    });

  }

  // navigateToItSupport() {
  //   if (this.router.url != '/hub2u/itsupport') {
  //     let responsedata = {
  //       message: 'Taking a screenshot',
  //       status: 'WARNING'
  //     }
  //     this._snackBar.openFromComponent(SnackbarComponent, {
  //       data: responsedata,
  //       duration: 1500
  //     });
  //   }

  //   html2canvas(document.body).then(canvas => {
  //     var data
  //     var screenshot = null;
  //     try {
  //       screenshot = canvas.toDataURL("image/jpeg");
  //     } catch (e) {
  //       console.log(e);
  //     }
  //     data =
  //     {
  //       "REQUESTOR_NTID": this.userInfo.NTID,
  //       "CATEGORY": "HUB2U",
  //       "PRIORITY": "High",
  //       "DetailsInput": [{
  //         "PROBLEM_CODE": "47060",
  //         "PROBLEM_DETAILS": "::" + window.location.href + "::" + "Provide Additional details here. At present ignore this ticket. This ticket is created from finsysSR application for testing.",
  //         "ContactEmail": "",
  //         "ContactName": "",
  //         "ContactPhone": "",
  //         "AttachmentList": [{
  //           "DocumentName": "Screenshot",
  //           "DocumentDescription": "Screenshot captured automatically",
  //           "Document": screenshot
  //         }
  //         ]
  //       }],
  //       "TOKEN": sessionStorage.getItem('id_token')
  //     }

  //     this.router.navigate(['hub2u/itsupport'], { state: { data: data } });
  //   });
  //   this.loadSpinner = false;
  //   this.eventService.hideSpinner();
  // }

  /**Temporary change  */
  navigateToItSupport() {
    //let itsupport = this.env.itsupportticket + "?appId=1&token=" + this.userInfo.access_token;
    let itsupport = this.env.itsupportticket
    window.open(itsupport, '_blank');
  }

}
