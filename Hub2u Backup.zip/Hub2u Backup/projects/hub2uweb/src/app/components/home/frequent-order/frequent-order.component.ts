import { Component, OnInit, VERSION, Inject, ViewEncapsulation, ViewChild, TemplateRef } from '@angular/core';
import { ReportsService, ProductService, CommonService, ConstantData, GetimageService } from 'hub2ushared';
import { HttpClient } from '@angular/common/http';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog'
import { Router } from '@angular/router';
import { CommonWebService } from '../../../shared/common-web.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-frequent-order',
  templateUrl: './frequent-order.component.html',
  styleUrls: ['./frequent-order.component.scss'],
  providers: [NgbCarouselConfig],
  encapsulation: ViewEncapsulation.None,
})
export class FrequentOrderComponent implements OnInit {
  userInfo: any = {};
  userRole: any = '';
  functionId = '';
  frequentOrder = [];
  frequentOrder1 = [];
  loader: boolean = false;
  noOrderData = false;
  previewImage;
  attr6: any;
  needbyDate: any;
  loaderFavorite: any[] = [];
  @ViewChild('callImagePreview') callImagePreview: TemplateRef<any>;
  sourceOrg: any;
  subInv: any = "";
  constructor(@Inject('environment') private env: any, private commonWebService: CommonWebService, private router: Router, private dialog: MatDialog, private commonService: CommonService, private reportService: ReportsService, private productService: ProductService, private GetimageService: GetimageService, private http: HttpClient, config: NgbCarouselConfig, private constantData: ConstantData, public datepipe: DatePipe) {
    config.interval = 2000;
    config.keyboard = true;
    config.pauseOnHover = true;
    config.showNavigationIndicators = true;
    config.showNavigationArrows = true;
  }

  slides: any = [[]];
  chunk(arr, chunkSize, length) {
    let R = [];
    for (let i = 0, len = length; i < len; i += chunkSize) {
      //  console.log("i=>",i,"len=>",len,"i += chunkSize",chunkSize)
      R.push(arr.slice(i, i + chunkSize));

    }
    // console.log("R=>",R)
    return R;
  }
  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.onInitialLoad();
    this.onSwitchNPID();
    this.getPreferenceData();
  }
  onSwitchNPID() {
    this.commonService.switchNPID.subscribe(data => {
      this.onInitialLoad();
    })
  }
  async onInitialLoad() {
    let userInfo = await localStorage.getItem("userDetails");
    this.userInfo = JSON.parse(userInfo);
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');
    await this.getFrequestOrders();
  }

  getPreferenceData() {
    let request = {
      ParametersInput: [
        { Name: "USER_NAME", Value: this.userInfo.NTID },
      ],
      // ReportId: "112"
      // ReportId: "7001"
      ReportId:this.constantData.userprofileData[this.functionId]
    }
    this.reportService.onGetDynamicReport(request).subscribe(response => {
      if (response != undefined && response.ROW != undefined) {
        this.needbyDate = response.ROW[0].NEED_BY_DATE_TIME;
        this.attr6 = response.ROW[0].ATTRIBUTE5
        this.sourceOrg = response.ROW[0].SOURCE_LOCATION
        this.subInv = response.ROW[0].SUBINVENTORY
      }
    }, error => {
      console.log(error);
    })
  }

  getDefaultOrderType() {
    if (this.functionId == '50' || this.functionId == '57' || this.functionId == '58' || this.functionId == '63') {
      return "INVENTORY"
    }
    // if (this.functionId == '51') {
    if (this.functionId == '136') {
      return "FULFILLMENT"
    }
    // if (this.functionId == '99' && (!this.attr6 || this.attr6 == "null")) {
      if (this.functionId == '143' && (!this.attr6 || this.attr6 == "null")) {
      return 'PROJECT'
    }
    //if (this.functionId != '47' && this.functionId != '99' && this.functionId != '51' && this.functionId != '50' && this.functionId != '57' && this.functionId != '58' && this.functionId != '63') {
    if (this.functionId != '47' && this.functionId != '143' && this.functionId != '136' && this.functionId != '50' && this.functionId != '57' && this.functionId != '58' && this.functionId != '63') {
      return "PROJECT"
    }
  }

  addToCart(favItem) {
    let attribut6 = this.getDefaultOrderType();
    this.loader = true;
    //console.log("DATE",this.datepipe.transform(new Date(new Date().getTime() + (1 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),)
    //favItem.loading = true;
    var attributeFourval = '';
    if (this.functionId == '58' || this.functionId == '60') {
      attributeFourval = favItem.ATTRIBUTE4;
    }
    // var cartInputData1 = {
    //   "shoppingCartUpsertData": [{
    //     "cifaItemNumber": favItem.CIFA_ITEM_NUMBER,
    //     "itemDescription": favItem.ITEM_DESCRIPTION,
    //     "itemCategory": favItem.ITEM_CATEGORY,
    //     "quantity": favItem.MIN_ORD_QTY,
    //     "needByDate": this.needbyDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needbyDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (1 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),
    //     "userName": this.userInfo.NTID,
    //     "regionName": favItem.REGION_NAME || favItem['Region Name'],
    //     "regionTemplate": favItem.TEMPLATE_NAME || favItem['Template Name'],
    //     "vendorItemNumber": favItem.MANUFACTURER_PART_NUM,
    //     "attribute4": attributeFourval,
    //     "sourceSubInventory": (this.sourceOrg == (favItem['ORGANIZATION_CODE'] || favItem.SOURCE_ORGANIZATION_CODE)) && this.functionId == '99' ? (this.subInv !== "" ? this.subInv : favItem['SOURCE_SUBINVENTORY']) : favItem['SOURCE_SUBINVENTORY'],
    //     "sourceOrganizationCode": (this.functionId == '57' ? "" : favItem.SOURCE_ORGANIZATION_CODE || favItem.ORGANIZATION_CODE),
    //     "attribute3": this.userRole.toUpperCase(),
    //     "attribute6": this.attr6 && this.attr6 != 'null' ? this.attr6 : attribut6,
    //   }]
  var cartInputData = {
    "profile":this.userRole.toUpperCase(),
      "shoppingCartUpsertData": [{
        "quantity": favItem.MIN_ORD_QTY,
        "kitQty": " ",
        "requestorName": this.userInfo.NTID,
        "profileType": this.userRole.toUpperCase(),
        "orderType": this.attr6 && this.attr6 != 'null' ? this.attr6 : attribut6,
        // "deliveryLocationCode": this.getLocCode(),
        "needByDate": this.needbyDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needbyDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (1 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),
        "cifaItemNumber": favItem.CIFA_ITEM_NUMBER,
        "itemDesc": favItem.ITEM_DESCRIPTION,
        "sourceOrganizationCode": (this.functionId == '57' ? "" : favItem.SOURCE_ORGANIZATION_CODE || favItem.ORGANIZATION_CODE),
        // "customer": this.functionId == '136' ? (this.storeBusinessObj ? this.storeBusinessObj.CUSTOMER : this.catalogObj['LOOKUP_CODE']) : '',
        "regionName": favItem.REGION_NAME || favItem['Region Name'],
        "templateName": favItem.TEMPLATE_NAME || favItem['Template Name'],
        // "attribute13": item['ATTRIBUTE13'],
      }]
    }  // }
    

    this.productService.addToCart(cartInputData).subscribe(response => {
      console.log("frequent-order response add to cart",response)
      if (response['status'] == "SUCCESS") {
        this.commonService.updatedCart(true);
        this.commonService.refreshWidgetCount(true);
        favItem.loading = false;
      }
      else {
        favItem.loading = false;
      }
      this.loader = false;
      this.commonWebService.openSnackBar(response['statusMessage'], response['status'])
    }, error => {
      this.loader = false;
      favItem.loading = false;
    });

  }

  getFrequestOrders() {
    this.loader = true;
    this.noOrderData = false;

    var freqOrdersInput = {
      "ReportId": this.constantData.frequestOrdersId[this.functionId],
      "ParametersInput": [{ "Name": "USER_NAME", "Value": this.userInfo.NTID }]
    }

    this.reportService.onGetDynamicReport(freqOrdersInput).subscribe(response => {

      if (response.ROW !== undefined) {
        this.frequentOrder = response.ROW;

        this.slides = this.chunk(this.frequentOrder, this.frequentOrder.length < 4 ? this.frequentOrder.length : 4, this.frequentOrder.length > 4 ? this.frequentOrder.length : 4);
        this.loader = false;
      } else {
        this.loader = false;
        this.noOrderData = true;
      }
    }, error => {
      this.loader = false;
      this.noOrderData = true;
    });
  }
  // getImage(cardDetails) {
  //   let cifaItem = cardDetails.CIFA_ITEM_NUMBER ? cardDetails.CIFA_ITEM_NUMBER : cardDetails.MANUFACTURER_PART_NUM.replace(/ /g, "-")
  //   console.log("cifaItem",cifaItem)    
  //   return this.imageURL + cifaItem + ".jpg";
  //  }

  /**SOA TO JAVA */
  getImage(item) {
    let image = this.GetimageService.getImage(item)
    return image;
  }

  errorHandler(event) {
    // console.debug(event);
    event.target.src = "../../../../assets/images/no-image.jpg";
  }
  openPreview(imagePath) {
    this.previewImage = imagePath
    let dialogRef = this.dialog.open(this.callImagePreview);
    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        if (result === 'yes') {
        } else if (result === 'no') {
        }
      }
    })
  }

  // onAddToFavorites(item: any, index) {
  //   //item['favorite'] = 'yes';
  // let request = {
  //   "REQUESTOR_USER_NAME": this.userInfo.NTID,
  //   "CIFA_ITEM_NUMBER": item.CIFA_ITEM_NUMBER || item['CIFA#'],
  //   "CATEGORY": item.ITEM_CATEGORY,
  //   "ITEM_DESCRIPTION": item.ITEM_DESCRIPTION,
  //   "REGION_NAME": item.REGION_NAME,
  //   "TEMPLATE_NAME": item.TEMPLATE_NAME,
  //   "ADD_TO_FAV": 'Y',
  //   "VENDOR_ITEM_NUMBER": item.MANUFACTURER_PART_NUM,
  //   "MFG_PART_NUMBER": item.MANUFACTURER_PART_NUM || item['Model#'],
  //   "INVENTORY_ITEM_ID": item['INVENTORY_ITEM_ID']
  // };
  //   if (this.functionId == '61')
  //     request['MFG_PART_NUMBER'] = item.MANUFACTURER_PART_NUM
  //   this.loaderFavorite[index] = true;

  //   this.productService.addToFavorite(request).subscribe(response => {
  //     this.loaderFavorite[index] = false;


  //     let resp = response['InsertFavoriteOutput'] || [];
  //     let message = resp['STATUS_MESSAGE'] || '';

  //     if (resp['STATUS'] === 'SUCCESS') {
  //       this.commonService.refreshWidgetCount(true);
  //       item['ADD_TO_FAV'] = 'Y';
  //     }
  //     if (resp['STATUS'] === 'ERROR') {
  //       this.commonWebService.openSnackBar(message, "WARNING")
  //       item['ADD_TO_FAV'] = 'N';
  //     }
  //   }, error => {
  //     item['ADD_TO_FAV'] = 'N';
  //     this.loaderFavorite[index] = false;
  //     this.commonWebService.openSnackBar("Something went wrong", "ERROR")
  //   })
  // }


  onAddToFavorites(item: any, index) {
    let request = {
      "profile":this.userRole.toUpperCase(),
      "requestorUserName": this.userInfo.NTID,
      "cifaItemNumber": item.CIFA_ITEM_NUMBER || item['CIFA#'],
      "category": item.ITEM_CATEGORY,
      "itemDescription": item.ITEM_DESCRIPTION,
      "regionName": item.REGION_NAME || item['Region Name'],
      "templateName": item.TEMPLATE_NAME || item['Template Name'],
      "addToFav": 'Y',
      "vendorItemNumber": item.MANUFACTURER_PART_NUM,
      "mfgPartNumber": item.MANUFACTURER_PART_NUM || item['Model#'],
      "inventoryItemId": item['INVENTORY_ITEM_ID']
    };
    if (this.functionId == '61')
      request['mfgPartNumber'] = item.MANUFACTURER_PART_NUM
    this.loaderFavorite[index] = true;
    this.productService.addToFavorite(request).subscribe(response => {
      this.loaderFavorite[index] = false;
      let resp = response['favoriteOutput'] || [];
      let message = resp['statusMessage'] || '';
      if (resp['status'] === 'SUCCESS') {
        this.commonService.refreshWidgetCount(true);
        this.commonWebService.openSnackBar(message, "SUCCESS")
        item['ADD_TO_FAV'] = 'Y';
      } else {
        this.commonWebService.openSnackBar(message, "ERROR")
        item['ADD_TO_FAV'] = 'N';
      }

    }, error => {
      item['ADD_TO_FAV'] = 'N';
      this.loaderFavorite[index] = false;
      this.commonWebService.openSnackBar("Something went wrong", "ERROR")
    })
  }

  openItemDetails(item) {
    this.router.navigate(['hub2u/item_details/'], { state: { item: item } })
  }
  getTempName(temp: string) {
    let tempNew = temp;
    if (temp) {
      if (temp.indexOf("_") > -1) {
        tempNew = temp.replace("_", " ")
      }
    }
    return tempNew;
  }
}
