import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MessageService } from 'hub2ushared';

@Component({
  selector: 'app-ribbon-announcement',
  templateUrl: './ribbon-announcement.component.html',
  styleUrls: ['./ribbon-announcement.component.scss'],
})
export class RibbonAnnouncementComponent implements OnInit {

  @Input() ribbonData;
  @Output() onViewMore = new EventEmitter();
  sampleTickerData =[
    {
        "APPLICATION_ID": 1,
        "MESSAGE_ID": 47082,
        "MESSAGE_TYPE": "FLASH CARDS",
        "CREATION_DATE": 1689056416000,
        "CREATED_BY": "VTALAU187",
        "REGION_NAME": null,
        "MESSAGE_TEXT": "<p>TEST ANNAOUNCEMENT&nbsp;</p>",
        "START_DATE": 1689056380000,
        "EXPIRES_ON": 1696832380000,
        "PUBLISHED": "Y",
        "ACKNOWLEDGEMENT_REQ": "N",
        "ATTRIBUTE1": "COMCAST TECH USER IIP, COMCAST STORE USER, COMCAST BUSINESS SERVICES USER",
        "ATTRIBUTE2": null,
        "ATTRIBUTE3": null,
        "ATTRIBUTE4": null,
        "ATTRIBUTE5": null,
        "USER_LIKES": 0,
        "LIKES": 0,
        "@num": 1
    },
    {
        "APPLICATION_ID": 1,
        "MESSAGE_ID": 47085,
        "MESSAGE_TYPE": "RIBBON",
        "CREATION_DATE": 1689060823000,
        "CREATED_BY": "VTALAU187",
        "REGION_NAME": null,
        "MESSAGE_TEXT": "<p>Old UI test Announcement&nbsp;</p>",
        "START_DATE": 1689060780000,
        "EXPIRES_ON": 1696836780000,
        "PUBLISHED": "Y",
        "ACKNOWLEDGEMENT_REQ": "N",
        "ATTRIBUTE1": "COMCAST TECH USER IIP, COMCAST STORE USER, COMCAST BUSINESS SERVICES USER",
        "ATTRIBUTE2": null,
        "ATTRIBUTE3": null,
        "ATTRIBUTE4": null,
        "ATTRIBUTE5": null,
        "USER_LIKES": 0,
        "LIKES": 0,
        "@num": 2
    },
    {
      "APPLICATION_ID": 1,
      "MESSAGE_ID": 47085,
      "MESSAGE_TYPE": "FLASH CARDS",
      "CREATION_DATE": 1689060823000,
      "CREATED_BY": "VTALAU187",
      "REGION_NAME": null,
      "MESSAGE_TEXT": "<p>Old UI test Announcement&nbsp;</p>",
      "START_DATE": 1689060780000,
      "EXPIRES_ON": 1696836780000,
      "PUBLISHED": "Y",
      "ACKNOWLEDGEMENT_REQ": "N",
      "ATTRIBUTE1": "COMCAST TECH USER IIP, COMCAST STORE USER, COMCAST BUSINESS SERVICES USER",
      "ATTRIBUTE2": null,
      "ATTRIBUTE3": null,
      "ATTRIBUTE4": null,
      "ATTRIBUTE5": null,
      "USER_LIKES": 0,
      "LIKES": 0,
      "@num": 3
  },
  {
    "APPLICATION_ID": 1,
    "MESSAGE_ID": 47085,
    "MESSAGE_TYPE": "FLASH CARDS",
    "CREATION_DATE": 1689060823000,
    "CREATED_BY": "VTALAU187",
    "REGION_NAME": null,
    "MESSAGE_TEXT": "<p>Old UI test Announcement&nbsp;</p>",
    "START_DATE": 1689060780000,
    "EXPIRES_ON": 1696836780000,
    "PUBLISHED": "Y",
    "ACKNOWLEDGEMENT_REQ": "N",
    "ATTRIBUTE1": "COMCAST TECH USER IIP, COMCAST STORE USER, COMCAST BUSINESS SERVICES USER",
    "ATTRIBUTE2": null,
    "ATTRIBUTE3": null,
    "ATTRIBUTE4": null,
    "ATTRIBUTE5": null,
    "USER_LIKES": 0,
    "LIKES": 0,
    "@num": 4
}
  
  ]

  constructor(private messageService: MessageService) { }

  ngOnInit() { 
    console.log(this.ribbonData);

    this.messageService.getRibbonMessage().subscribe({
      next: (message) => {
        this.ribbonData = message.filter(item => item.msgType == 'RIBBON')
    }
    })
  }
  
  openAnnoucementModalpopup(){
    this.onViewMore.emit();
  }
}
