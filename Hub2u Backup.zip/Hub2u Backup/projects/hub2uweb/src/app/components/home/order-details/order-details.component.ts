import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ReportsService, ConstantData, CommonService } from 'hub2ushared';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.scss'],
})
export class OrderDetailsComponent implements OnInit {
  userInfo: any = {};
  userRole: any = '';
  orderCount: any = [];
  noOftemplates: number = 0;
  noOfOrders: number = 0;
  noOfFavs: number = 0;
  noOfItemsCart: number=0;
  functionId = '';
  projectCountStop: any;
  constructor(private reportService: ReportsService, private constantData: ConstantData, private router: Router,
    private commonService: CommonService) { }


  ngOnInit() { 
    this.onInitialLoad();
    this.onSwitchNPID();
    this.onGetWidget()
  }
  onSwitchNPID() {
    this.commonService.switchNPID.subscribe(data => {
      this.onInitialLoad();
    })
  }
  async onInitialLoad() {
    let userInfo = await localStorage.getItem("userDetails");
    this.userInfo = JSON.parse(userInfo);
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');
    await  this.getOrderDetails();
  }
    
  getOrderDetails() {
    var widgetCountInput = { 
      "ReportId": this.constantData.orderdetailsId[this.functionId],
      "ParametersInput": [
        { "Name": "USER_NAME", "Value": this.userInfo.NTID },
        { "Name": "USER_ROLE", "Value": this.userRole ? this.userRole.toUpperCase() : this.userRole}
      ]
    }
    this.reportService.onGetDynamicReport(widgetCountInput).subscribe(response => {
      if (response.ROW !== undefined) {
        this.orderCount = response.ROW[0];
        // this.orderCountStop();
      } else {
        this.orderCount = [];
      }
    }, error => {

    });
  }

  onGetWidget() {
    this.commonService.widgetUpdate.subscribe(data => {
      this.getOrderDetails();
    })
  }

  viewMyOrders() {
    this.router.navigate(['hub2u/myorders/']);
  }

  viewCatalogs() {
    this.router.navigate(['hub2u/catalog/']);
  }

  viewFavCatalogs() {
    this.router.navigate(['hub2u/catalog/'],  { state: { favorites : 'Favorites'}});
  }

  viewCart() {
    this.router.navigate(['/hub2u/catalog/cart'])
  }
  
}
