import { Component, OnInit } from '@angular/core';
import { ReportsService, ProductService, ConstantData, CommonService } from 'hub2ushared';
import { DatePipe } from '@angular/common';
import { EventService } from '../../../shared/event.service';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { CheckStatusComponent } from './check-status/check-status.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { CommonWebService } from '../../../shared/common-web.service';
import { CancelOrderComponent } from '../../order-details/cancel-order/cancel-order.component';
import { ClearCartComponent } from '../../order-details/clear-cart/clear-cart.component';
@Component({
  selector: 'app-recent-order',
  templateUrl: './recent-order.component.html',
  styleUrls: ['./recent-order.component.scss'],
  providers: [DatePipe]
})
export class RecentOrderComponent implements OnInit {
  userInfo: any = {};
  userRole = '';
  orderCount = [];
  backcount: number = 0;
  backOrderCount: number = 0;
  recentOrder = [];
  verifyStatus = [];
  functionId = '';
  myArray: number[] = [11, 22, 33, 44, 55, 66, 77, 88];
  loader = false;
  storeOrder: any = '';
  statusLoading = false;
  projectCountStop: any;
  cancelledCount: number = 0;
  inprocesscount: number = 0;
  shippedCount: number = 0;

  constructor(private reportService: ReportsService, private productService: ProductService, private commonWebService: CommonWebService, private constantData: ConstantData,
    private bottomSheet: MatBottomSheet, private router: Router, private route: ActivatedRoute,
    private commonService: CommonService, private spinner: NgxSpinnerService, private eventService: EventService,
    public datepipe: DatePipe, public _dialog: MatDialog,) { }

  ngOnInit() {
    this.onInitialLoad();
    this.onSwitchNPID();
  }
  onSwitchNPID() {
    this.commonService.switchNPID.subscribe(data => {
      this.onInitialLoad();
    })
  }
  async onInitialLoad() {
    let userInfo = await localStorage.getItem("userDetails");
    this.userInfo = JSON.parse(userInfo);
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');
    await this.getRecentOrderCount();
    await this.getRecentOrders();
  }


  getRecentOrderCount() {
    // var recentOrder = this.constantData.recentOrderId[this.constantData.roles[this.userRole]];
    let functionId;

    Object.keys(this.constantData.roles).forEach((key) => {
      if (this.constantData.roles[key].toUpperCase() == (this.userRole ? this.userRole.toUpperCase() : this.userRole)) {
        functionId = key;
      }
    })
    let orderGroupInput = {
      "ReportId": this.constantData.recentOrderId[functionId],
      "ParametersInput": [
        { "Name": "USER_NAME", "Value": this.userInfo.NTID } //MMCGIN143
      ]
    }
    this.reportService.onGetDynamicReport(orderGroupInput).subscribe(response => {
      if (response.ROW !== undefined) {
        this.orderCount = response.ROW;
      } else {
        this.orderCount = [];
      }
    }, error => {

    });
  }

  statusColor(status) {
    if (status) {
      status = status.toUpperCase();
      if (this.constantData.statusColors[status] === undefined)
        return this.constantData.statusColors['OTHERS'];
      else
        return this.constantData.statusColors[status]
    }
    return this.constantData.statusColors['OTHERS'];
  }
  getFormattedDate(date) {
    return this.datepipe.transform(date, 'dd MMM yyyy');
  }

  newTrack: any = [];
  trackLength: number = 0;
  httpVal: boolean = false;
  getTrackingNo(trackingNo, report) {
    // getTrackingNo(trackingNo) {
    this.newTrack = [];
    this.trackLength = 0
    if (trackingNo != undefined && trackingNo != null && trackingNo.toString().startsWith("https")) {
      let no = trackingNo.split('>')[1];
      this.httpVal = true;
      this.newTrack.push(no);
      this.trackLength = this.newTrack.length;
      return this.newTrack;
      // this.trackLength = this.newTrack.length;
      // return no;
    } else if (trackingNo != undefined && trackingNo != null && trackingNo.includes(',')) {
      this.httpVal = false;
      this.newTrack = trackingNo.split(',');
      this.trackLength = this.newTrack.length;
      report['TrackLength'] = this.trackLength;
      return this.newTrack;
    }
    else {
      this.httpVal = false;
      this.newTrack.push(trackingNo);
      this.trackLength = this.newTrack.length;
      return this.newTrack;
    }
    // else {
    //   return trackingNo;
    // }
  }

  trackNumber(track_number, report) {
    if (track_number.startsWith("https")) {
      window.open(track_number, '_blank')
    } else if (track_number != undefined && track_number != null && track_number.includes(',')) {
      // this.httpVal = false;
      this.newTrack = track_number.split(',');
      this.trackLength = this.newTrack.length;
      report['TrackLength'] = this.trackLength;
      this.router.navigate(['hub2u/trackorder/'], { state: { trackNo: this.newTrack, redirect: 'fromHomePage' } })
    }
    else {
      this.router.navigate(['hub2u/trackorder/'], { state: { trackNo: track_number, redirect: 'fromHomePage' } })
    }
  }

  trackOrder(trackNo) {
    trackNo = trackNo.trim();
    if (trackNo.startsWith("https")) {
      window.open(trackNo, '_blank')
    } else {
      this.router.navigate(['hub2u/trackorder/'], { state: { trackNo: trackNo, redirect: 'fromHomePage' } })
    }
  }

  repeatOrder(val) {
    this.storeOrder = val;
    val.loaderOrderitem = true;
    let req_num = val['Order No.'];

    var dataInput = {
      // "requestorId": this.userInfo.NTID,
      "requestorName": this.userInfo.NTID,
      "requisitionNumber": req_num,
      "profile":this.userRole.toUpperCase()

    };

    this.productService.repeatOrder(dataInput).subscribe(response => {
      let resp = response || {};
      //  console.log("resp===>", resp)
      let msg = resp['STATUS_MESSAGE'] || resp['statusMessage'] || '';
      if (resp['status'] == 'SUCCESS') {
        this.commonService.updatedCart(true);
        this.commonWebService.openSnackBar(msg, "SUCCESS")
      }
      if (resp['status'] == 'FAILED') {
        if (resp['statusMessage'].includes('items in the cart already added')) {
          this.openclearCartDialog();
        }
        this.commonService.updatedCart(true);
        this.commonWebService.openSnackBar(msg, "ERROR")
      }
      val.loaderOrderitem = false;
    }, error => {
      this.commonWebService.openSnackBar("There is some error in repeating the order", "ERROR")
      //this.eventService.hideSpinner();
      val.loaderOrderitem = false;
    });
  }

  openclearCartDialog(): void {
    const dialogRef = this._dialog.open(ClearCartComponent, {
      // data: { option: 'discardCart' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.onClearCart();
      }
    });
  }

  onClearCart() {
    // let object = { requestorId: this.userInfo.NTID, operation: "Clear" };
    let object = { requestorName: this.userInfo.NTID, operation: "Clear",profile: this.userRole.toUpperCase()};
    this.loader = true;
    this.productService.clearCart(object).subscribe(response => {
      this.loader = false;
      let resp = response || [];
      if (resp != undefined) {
        let message = resp['STATUS_MESSAGE'] || resp['statusMessage'] || '';
        if (resp['status'] == 'SUCCESS') {
          this.commonWebService.openSnackBar(message, resp['status']);
          this.repeatOrder(this.storeOrder);
        } else {
          this.commonWebService.openSnackBar('Error while clearing the Cart, hence the new item is not added.', 'WARNING')
        }
      } else {
        this.loader = false;
      }
      this.commonService.updatedCart(true);
    }, error => {
      this.loader = false;
      this.commonWebService.openSnackBar('Something went wrong.Can you please try later', 'WARNING')
    })
  }

  getRecentOrders() {
    this.loader = true;
    var dataInput = {
      "ReportId": this.constantData.dynamicrecentOrderId[this.functionId],
      "ParametersInput": [{ "Name": "REQUESTOR", "Value": this.userInfo.NTID }]
    }


    this.reportService.onGetDynamicReport(dataInput).subscribe(response => {

      if (response.ROW !== undefined) {
        this.recentOrder = response.ROW;
        this.loader = false;
      } else {
        this.recentOrder = [];
        this.loader = false;
      }
    }, error => {
      this.loader = false;
    });
  }

  checkStatus(order, content) {
    //this.eventService.showSpinner();
    order.loaderOrderitem = true;
    var dataInput;
    var locationQuery = JSON.parse(sessionStorage.getItem('locationDynamicQuery'));
    let attrReq = this.recentOrder.filter(element => element.REQUISITION_NUMBER === order.REQUISITION_NUMBER)

    let attributeVal = ''
    if (attrReq.length > 0) {
      attributeVal = attrReq[0].ATTRIBUTE2
    }
    //if (this.constantData.orderStatusParam[this.functionId] !== undefined && this.functionId != "51") {
    if (this.constantData.orderStatusParam[this.functionId] !== undefined && this.functionId != "136") {
      dataInput = {
        "ReportId": this.constantData.checkStatus[this.functionId], "ParametersInput": [
          { "Name": "P_ORDER_NUMBER", "Value": order.REQUISITION_NUMBER ? order.REQUISITION_NUMBER : order['Order No.'] },
          { "Name": "P_MODULE", "Value": this.constantData.orderStatusParam[this.functionId] }
        ]
      }
    } else if (locationQuery != null || locationQuery != undefined) {
      //if (locationQuery.userGroups === "NONCPE" && this.functionId != "51") {
      if (locationQuery.userGroups === "NONCPE" && this.functionId != "136") {
        dataInput = {
          "ReportId": this.constantData.checkStatus[this.functionId], "ParametersInput": [
            { "Name": "P_ORDER_NUMBER", "Value": order.REQUISITION_NUMBER ? order.REQUISITION_NUMBER : order['Order No.'] },
            { "Name": "P_MODULE", "Value": "NONCPE" }]
        }
      }
    } else {
      dataInput = {
        "ReportId": this.constantData.checkStatus[this.functionId], "ParametersInput": [
          { "Name": "P_ORDER_NUMBER", "Value": order.REQUISITION_NUMBER ? order.REQUISITION_NUMBER : order['Order No.'] },
          { "Name": "P_MODULE", "Value": attributeVal !== null ? attributeVal : 'null' }]
      }
    }

    this.reportService.onGetDynamicReport(dataInput).subscribe(response => {
      if (response.ROW !== undefined) {
        this.verifyStatus = response.ROW;

        this._dialog.open(content, {
          width: '1100px',
          panelClass: 'full-panel-modal'
        });

        // this.bottomSheet.open(CheckStatusComponent, {
        //   data: this.verifyStatus
        // });
        this.statusLoading = false;
        order.checkstatus = false;
      } else {
        this.verifyStatus = [];
        this.statusLoading = false;
        order.checkstatus = false;
        this.commonWebService.openSnackBar("No Data Found", "WARNING")
      }
      order.loaderOrderitem = false;
      //this.eventService.hideSpinner();
    }, error => {
      order.loaderOrderitem = false;
      //this.eventService.hideSpinner();
    });
  }

  viewMyOrders() {
    this.router.navigate(['hub2u/myorders/']);
  }

  viewOrderDetails(order) {
    localStorage.setItem("reqData", JSON.stringify(order));
    this.router.navigate(['hub2u/requisitionDetail/']);
    // this.router.navigate(['hub2u/requisitionDetail/'], { state: { order: order } });
    // this.router.navigate(['hub2u/requisitionDetail/'], { queryParams: {order: JSON.stringify(order)} });
  }

}
