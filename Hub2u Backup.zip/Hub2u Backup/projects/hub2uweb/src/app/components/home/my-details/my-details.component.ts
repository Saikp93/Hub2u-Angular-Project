import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ReportsService, ConstantData } from 'hub2ushared';
import { Router } from '@angular/router';
@Component({
  selector: 'app-my-details',
  templateUrl: './my-details.component.html',
  styleUrls: ['./my-details.component.scss'],
})
export class MyDetailsComponent implements OnInit {
  userInfo: any = {};
  userRole = '';
  orderCount = [];
  recentOrder = [];
  functionId = '1';
  userProfile: any = [];
  userDetails: any = [];
  address: any;
  sourcelocation: any;
  deliverId : any;
  deliverlocation : any;
  sourceSiteId : any;
  sourclocation : any;
  loader = false;
  mailTo;
  isMyDetailShow = 'N'
  @Output() showMyDetails = new EventEmitter();
  constructor(private reportService: ReportsService, private constantData: ConstantData, private router: Router) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.getMyDetails();
    this.getPreferenceData();
  }

  getPreferenceData(){
    let request = {
      ParametersInput: [
        { Name: "USER_NAME", Value: this.userInfo.NTID },
        { Name: "USER_TYPE", Value: this.constantData.userRoles.techUser }
      ],
      ReportId: "50043"
    }
    this.reportService.onGetDynamicReport(request).subscribe(response => {
      if(response != undefined && response.ROW != undefined){
        console.log("response home",response);
        this.userDetails = response.ROW[0];
        this.deliverId = this.userDetails.DELIVERY_ID
        this.deliverlocation = this.userDetails.DELIVERY_TO_LOCATION
        this.sourceSiteId = this.userDetails.SITE_ID
        this.sourclocation = this.userDetails.SOURCE_LOCATION
      }
    }, error => {
      console.log(error);
    })
  }

  getMyDetails() {
    this.loader = true;
    var settingsInput = { 
      // "ReportId": "112",
      // "ReportId": "7001",
      ReportId:this.constantData.userprofileData[this.functionId],
       "ParametersInput": [{ "Name": "USER_NAME", "Value": this.userInfo.NTID }] };
    this.reportService.onGetDynamicReport(settingsInput).subscribe(response => {

      if (response.ROW !== undefined) {
        this.userProfile = response.ROW[0];
        this.isMyDetailShow = this.userProfile.ENABLE_FLAG;
        this.showMyDetails.emit(this.isMyDetailShow);
        this.mailTo = this.userProfile.SUPERVISOR_EMAIL;
        if (this.userProfile.DELIVERY_TO_LOCATION != null || this.userProfile.DELIVERY_TO_LOCATION != undefined) {
          if (this.userProfile.DELIVERY_TO_LOCATION.includes('|') && this.functionId == '58') {
            this.address = this.userProfile.DELIVERY_TO_LOCATION
            this.sourcelocation = this.userProfile.DELIVERY_TO_LOCATION.split('|')[1]
          }
          //else if (this.userProfile.DELIVERY_TO_LOCATION.includes('|') && this.functionId == '51') {
            else if (this.userProfile.DELIVERY_TO_LOCATION.includes('|') && this.functionId == '136') {
            this.address = this.userProfile.DELIVERY_TO_LOCATION.split('|')[2]
            this.sourcelocation = this.userProfile.DELIVERY_TO_LOCATION.split('|')[1]
          }
          else {
            this.address = this.userProfile.DELIVERY_TO_LOCATION
            this.sourcelocation = '-'
          }
        }
        this.loader = false;
      } else {
        this.userProfile = [];

        this.loader = false;
      }
    }, error => {
    });
  }

  editLocation() {
    // console.log("i am")
    this.router.navigate(['hub2u/settings/']);
  }

}
