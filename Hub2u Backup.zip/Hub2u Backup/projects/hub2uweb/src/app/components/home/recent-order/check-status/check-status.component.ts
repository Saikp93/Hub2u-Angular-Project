import { Component, OnInit, Inject, ViewEncapsulation, Input, OnChanges } from '@angular/core';
import { MatBottomSheet, MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material/bottom-sheet';
import { AuthService, CommonService, ReportsService } from 'hub2ushared';
import { DatePipe } from '@angular/common';
// import { MAT_DIALOG_DATA } from '@angular/material/dialog';
// import { DialogData } from '../../../template-management/template-management.component';

@Component({
  selector: 'app-check-status',
  templateUrl: './check-status.component.html',
  styleUrls: ['./check-status.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [DatePipe]
})

export class CheckStatusComponent implements OnInit, OnChanges {
  imageSource: any[] = [];
  groupSource: any[] = [];
  moduleSource: any[] = [];
  actionDate: any;
  pendingDays = 0;
  userImg: any;
  userInfo: any = {};
  userRole: any;
  functionId: any;
  @Input() data: any;

  dataItemSource = {
    regionalApprover: [],
    groupApprover: [],
    moduleApprover: [],
    requestor: {}
  };
  profileImg: string | ArrayBuffer;

  constructor(
    private authService: AuthService,
    public datepipe: DatePipe,
    // @Inject(MAT_BOTTOM_SHEET_DATA) public data1: any
  ) {

  }

  ngOnChanges() {
  //   if (this.data) {
  //     this.data.forEach(x => {
  //       if (x['APPROVER_TITLE'] === 'Regional Approver') {
  //         this.dataItemSource.regionalApprover.push(x);
  //       }
  //       if (x['APPROVER_TITLE'] === 'Group Approval') {
  //         this.dataItemSource.groupApprover.push(x);
  //       }
  //       if(x['APPROVER_TITLE']==='Module Approver'){
  //         this.dataItemSource.moduleApprover.push(x);
  //       }
  //     });
  //   }
 
  //   this.dataItemSource.requestor = this.data[0] || {};

  //   this.updateUserImage();
  //   console.log(this.data);
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.getImagePath(this.userInfo.NTID)
    if(this.data != undefined){
    if (this.data[0].ACTION_DATE != null || this.data[0].ACTION_DATE != undefined) {
      this.actionDate = new Date(this.data[0].ACTION_DATE);
      var Time = new Date().getTime() - this.actionDate.getTime();
      var Days = Time / (1000 * 3600 * 24); //Diference in Days
      this.pendingDays = Math.floor(Days);
    }
    //console.log("check status",this.data);
    if (this.data) {
      this.data.forEach(x => {
        if (x['APPROVER_TITLE'] === 'Regional Approver' || x['APPROVER_TITLE'] === 'Regional Approver'.toUpperCase()) {
          this.dataItemSource.regionalApprover.push(x);
        }
        if (x['APPROVER_TITLE'] === 'Group Approval' || x['APPROVER_TITLE'] === 'Group Approval'.toUpperCase()) {
          this.dataItemSource.groupApprover.push(x);
        }
        if(x['APPROVER_TITLE']==='Module Approver' || x['APPROVER_TITLE'] === 'Module Approver'.toUpperCase()){
          this.dataItemSource.moduleApprover.push(x);
        }
      });
    }
 
    this.dataItemSource.requestor = this.data[0] || {};

    this.updateUserImage();
  }
  }

  updateUserImage() {
    console.log(this.dataItemSource.regionalApprover, this.dataItemSource.groupApprover)
    for (let item of this.dataItemSource.regionalApprover) {
      this.imageSource.push({
        "NTID": item.APPROVER, "Img": "",
        "APPROVER_TITLE": item.APPROVER_TITLE,
        "FULL_NAME": item.FULL_NAME,
        "APPROVER_DESIGNATION": item.APPROVER_DESIGNATION,
        "ACTION_DATE": item.ACTION_DATE,
        "STATUS": item.STATUS,
        "NOTE": item.NOTE
      });
    }

    for (let item of this.dataItemSource.groupApprover) {
      this.groupSource.push({
        "NTID": item.APPROVER, "Img": "",
        "APPROVER_TITLE": item.APPROVER_TITLE,
        "FULL_NAME": item.FULL_NAME,
        "APPROVER_DESIGNATION": item.APPROVER_DESIGNATION,
        "ACTION_DATE": item.ACTION_DATE,
        "STATUS": item.STATUS,
        "NOTE": item.NOTE
      });
    }

    for (let item of this.dataItemSource.moduleApprover) {
      this.moduleSource.push({
        "NTID": item.APPROVER, "Img": "",
        "APPROVER_TITLE": item.APPROVER_TITLE,
        "FULL_NAME": item.FULL_NAME,
        "APPROVER_DESIGNATION": item.APPROVER_DESIGNATION,
        "ACTION_DATE": item.ACTION_DATE,
        "STATUS": item.STATUS,
        "NOTE": item.NOTE
      });
    }

    this.updateImgeSrc(this.imageSource);
    this.updateImgeSrc(this.groupSource);
    this.updateImgeSrc(this.moduleSource);

    console.log(this.groupSource, this.imageSource)
  }

  closeSheet() {
    // this.bottomSheetRef.dismiss();
  }

  updateImgeSrc(data) {
    for (let item of data) {
      this.authService.onGetProfileImage(item.NTID ? item.NTID.toUpperCase() : '').subscribe(response => {
        const reader = new FileReader();
        reader.addEventListener('load', () => {
          item.Img = reader.result;
        }, false);
        if (response) {
          reader.readAsDataURL(response);
        }
      }, error => {

      });
    }
  
  }

  getImagePath(APPROVER) {
    this.authService.onGetProfileImage(APPROVER ? APPROVER.toUpperCase() : '').subscribe(response => {
      this.onCreateImageFromBlob(response);
    }, error => {

    });
  }

  getFormattedDate(date) {
    return this.datepipe.transform(date, 'dd MMM yyyy');
  }

  onCreateImageFromBlob(image: Blob) {
    const reader = new FileReader();
    reader.addEventListener('load', () => {
      //this.userImg = reader.result;
      this.profileImg = reader.result;
    }, false);
    if (image) {
      reader.readAsDataURL(image);
    }
  }
}
