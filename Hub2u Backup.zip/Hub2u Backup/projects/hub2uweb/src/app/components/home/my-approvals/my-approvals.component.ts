import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { ReportsService,CommonService } from 'hub2ushared'

@Component({
  selector: 'app-my-approvals',
  templateUrl: './my-approvals.component.html',
  styleUrls: ['./my-approvals.component.scss'],
})
export class MyApprovalsComponent implements OnInit {

  constructor(private reportService: ReportsService,private commonService: CommonService, private router: Router,) { }
  userInfo: any = {};
  userRole: any = '';
  @Output() showMyApproval = new EventEmitter();
  myApproval = [];
  len = 0; 
  loader = false; 
  ngOnInit() {
    this.onInitialLoad();
    this.onSwitchNPID();  
  } 
  onSwitchNPID() {
    this.commonService.switchNPID.subscribe(data => {
      this.onInitialLoad();
    })
  }
  async onInitialLoad() { 
    let userInfo = await localStorage.getItem("userDetails");
    this.userInfo = JSON.parse(userInfo);
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole'); 
    await  this.getMyApprovers();
  }

  appprovalStatus(text) {
    
    switch (text) {
      case 'Pending Approval':
        return '#d0d005';
      case 'Approved':
        return '#A3DB61';
      case 'Rejected':
        return '#ff7b7b';
    
    }
  }

  getMyApprovers() {
    this.loader = true;
    var approverWidgetInput = {
      "ReportId": "10090",
      "ParametersInput": [{
        "Name": "P_APPROVER", "Value": this.userInfo.NTID
      },
      {
        "Name": "P_CATALOG", "Value": this.userRole
      }]
    }
    this.reportService.onGetDynamicReport(approverWidgetInput).subscribe(response => {
      //console.log("my-approvals",response)
      if (response.ROW !== undefined) {
        this.myApproval = response.ROW;
        this.len = this.myApproval.length;
        this.showMyApproval.emit(this.len);
        this.loader = false; 
      } else {
        this.myApproval = [];
        this.loader = false;
        this.showMyApproval.emit(this.len);
      }
    }, error => {

    });
  }

  approvalHistory(item){
   // console.log("approvalHistory",item);
    this.router.navigate(['hub2u/myapprovals']);

  }

}
