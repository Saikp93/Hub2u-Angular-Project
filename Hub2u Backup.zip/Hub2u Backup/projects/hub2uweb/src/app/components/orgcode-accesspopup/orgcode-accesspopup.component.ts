import { SelectionModel } from '@angular/cdk/collections';
import { Component, Inject, Input, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatDialogRef, MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ConstantData, ReportsService } from 'hub2ushared';
import { error } from 'selenium-webdriver';
// import { SourceData } from '../settings/ware-house/ware-house.component';
import { WmsComponent } from '../wms/wms.component';
import { CommonSettingService } from '../../shared/common-settings.service';

@Component({
  selector: 'app-orgcode-accesspopup',
  templateUrl: './orgcode-accesspopup.component.html',
  styleUrls: ['./orgcode-accesspopup.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class OrgcodeAccesspopup implements OnInit {

  @Input() size: any;
  @Input() cssClass: any;
  loadSpinner: boolean = false;
  orgCodeDetails: any[] = [];
  userInfo: any = {};
  noData = false;
  selectedCardData: any;
  userRole = 'COMCAST TECH USER IIP'
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  loader;
  closeFlag
  person_id: any;
  functionId: string;

  constructor(@Inject(MAT_DIALOG_DATA) public data: WmsComponent, private router: Router, private reportService: ReportsService,
    private comSettingService: CommonSettingService, public dialog: MatDialog, public dialogRef: MatDialogRef<WmsComponent>,private constantData: ConstantData,) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.fetchPersonId();
    this.getOrgCodeList();

  }

  displayedColumns = ['selected', 'ORGANIZATION_CODE', 'ORGANIZATION_ID', 'ORGANIZATION_NAME'];

  selection: SelectionModel<SourceData> = new SelectionModel<SourceData>(false, []);

  dataSource: MatTableDataSource<any>;

  getOrgCodeList() {
    this.loadSpinner = true;
    let req = {
      "ReportId": "10054",
      "ParametersInput": [
        {
          "Name": "REQUESTOR_NT_ID",
          "Value": this.userInfo.NTID
        },
        {
          "Name": "ORGANIZATION_CODE",
          "Value": ""
        }
      ]
    }
    this.reportService.onGetDynamicReport(req).subscribe(response => {
      this.loadSpinner = false;
      if (response.ROW !== undefined) {
        this.orgCodeDetails = response.ROW;
        this.orgCodeDetails.map(function (material) {
          material.selected = "false",
            material.selectable = "true"
        });
        this.dataSource = new MatTableDataSource<any>(this.orgCodeDetails);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.noData = false;
      } else {
        this.loadSpinner = false;
        this.noData = true;
      }
    }, error => {
      this.loadSpinner = false;
      this.noData = true;
    });

  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  selectedRow(row) {
    this.dataSource.filteredData.forEach((row) => {
      if (row.selected == true) {
        row.selected = false;
      }
    });
    row.selected = true;
    this.selection.select(row);
    this.selectedCardData = row;
  }

  isValid() {
    let flag = true;
    if (this.selectedCardData) {
      if (this.selectedCardData.length != 0) {
        flag = false
      }
      else {
        flag = true;
      }
    }
    else {
      flag = true;
    }
    return flag
  }

  fetchPersonId() {
    let request = {
      // ReportId: 112, //this.userValues[0].reportId
      // ReportId: "7001",
      ReportId:this.constantData.userprofileData[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        },
        
      ]
    };

    this.reportService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW !== undefined) {

        this.person_id = response.ROW[0].PERSON_ID
      } else {
        this.loader = false;
      }
    }, error => {
      this.loader = false;
    });

  }

  // onDoneClick() {
  //   this.comSettingService.setWareHouseCode(this.selectedCardData);
  //   localStorage.removeItem(this.userInfo.NTID + "_OpenPO");
  //   this.loadSpinner = true;
  //   let req = {
  //     "TechMobilePref": {
  //       "attribute3": this.userRole,
  //       "personId": this.person_id,
  //       "username": this.userInfo.NTID,
  //       "sourceLocation": this.selectedCardData.ORGANIZATION_CODE,
  //       "Defaultbusinessuser": "",
  //       "deliveryToLocation": "",
  //       "attribute5": "INVOPS",
  //       "needByDateTime": "",
  //       "projectNumber": "",
  //       "subinventory": ""
  //     }
  //   }

  //   this.reportService.onSaveSettings(req).subscribe(response => {
  //     if (response) {
  //       console.log("onSaveSettings", response)
  //       if (response.STATUS == 'Success') {
  //         this.closeFlag = 'Success'
  //         this.dialogRef.close('Success')
  //         //this.commonService.updateSourceOrg(true);
  //       }
  //       else {
  //         this.closeFlag = 'error'
  //         this.dialogRef.close('error')
  //       }
  //     }
  //   }, error => {
  //     this.loader = false;
  //     this.noData = true;

  //   });

  // }

  /*SOA TO JAVA*/

  onDoneClick() {
    this.comSettingService.setWareHouseCode(this.selectedCardData);
    localStorage.removeItem(this.userInfo.NTID + "_OpenPO");
    this.loadSpinner = true;
    // let req = {
    //   "preferencesUpsertDetails": {
    //     "attribute3": this.userRole,
    //     "expenditureOrgId": "",
    //     "expenditureOrg": "S56",
    //     "personId": '',
    //     "userName": this.userInfo.NTID,
    //     "sourceLocation": this.selectedCardData.ORGANIZATION_CODE,
    //     "Defaultbusinessuser": "N",
    //     "deliveryToLocation": "",
    //     "attribute5": "INVOPS",
    //     "needByDateTime": "",
    //     "projectNumber": "",
    //     "subinventory": "",



    //   }
    // }


    let req = {
      "profile":this.userRole.toUpperCase(),
      "preferencesUpsertDetails": {
        "profileType": this.userRole,
        "expenditureOrgId": "",
        "expenditureOrg": "S56",
        "personId": '',
        "userName": this.userInfo.NTID,
        "sourceLocation": this.selectedCardData.ORGANIZATION_CODE,
        "Defaultbusinessuser": "N",
        "deliveryToLocation": "",
        "attribute5": "INVOPS",
        "needByDateTime": "",
        "projectNumber": "",
        "subinventory": "",

}
    }
    this.reportService.onSaveSettings(req).subscribe(response => {
      if (response) {
        console.log("onSaveSettings", response)
        if (response.status == 'SUCCESS') {
          this.closeFlag = 'Success'
          this.dialogRef.close('Success')
          //this.commonService.updateSourceOrg(true);
        }
        else {
          this.closeFlag = 'error'
          this.dialogRef.close('error')
        }
      }
    }, error => {
      this.loader = false;
      this.noData = true;

    });

  }

}










export interface SourceData {
  ORGANIZATION_CODE: string;
  ORGANIZATION_ID: number;
}


