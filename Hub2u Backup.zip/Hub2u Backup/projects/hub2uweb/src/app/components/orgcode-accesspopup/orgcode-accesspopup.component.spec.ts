import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { OrgcodeAccesspopup } from './orgcode-accesspopup.component';

describe('OrgcodeAccesspopupComponent', () => {
  let component: OrgcodeAccesspopup;
  let fixture: ComponentFixture<OrgcodeAccesspopup>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ OrgcodeAccesspopup ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(OrgcodeAccesspopup);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
