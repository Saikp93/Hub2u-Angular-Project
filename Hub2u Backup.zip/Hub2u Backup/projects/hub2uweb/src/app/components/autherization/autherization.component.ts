import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-autherization',
  templateUrl: './autherization.component.html',
  styleUrls: ['./autherization.component.scss'],
})
export class AutherizationComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
