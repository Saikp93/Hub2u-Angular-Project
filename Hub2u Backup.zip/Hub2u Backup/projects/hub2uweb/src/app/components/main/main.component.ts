import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventService } from '../../shared/event.service';
import { CommonSettingService } from '../../shared/common-settings.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss'],
})
export class MainComponent implements OnInit {
  loader: boolean = false;
  showAlerts: boolean = false;
  shouldShowBreadcrumb: boolean = false;
  role;
  constructor(private cdr: ChangeDetectorRef, private eventService: EventService, private alertService: CommonSettingService,
    private router: Router) { }

  ngOnInit() {
    this.eventService.onLoader$.subscribe(x => {
      this.loader = x;
    });

    this.router.events.subscribe((val) => {
      this.shouldShowBreadcrumb = (this.router.url.includes('home'));
    });

  }
  ngAfterViewChecked() {
    let userInfo = JSON.parse(localStorage.getItem('userDetails'));
    if (userInfo !== undefined && userInfo !== null) {
      // console.log("chechRole - ngAfterViewChecked", localStorage.getItem(userInfo.NTID + "_userRole"))
      this.role = localStorage.getItem(userInfo.NTID + "_userRole");
    }
    this.cdr.detectChanges();
  }

  ngDoCheck() {
    this.showAlerts = this.alertService.getAlerts();
  }
}
