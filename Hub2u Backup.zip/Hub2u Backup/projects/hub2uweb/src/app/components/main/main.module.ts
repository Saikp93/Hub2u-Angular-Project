import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Hub2usharedModule, SwitchNtidComponent, ErrorComponent, AuthGuardService } from 'hub2ushared';
import { MatSnackBarModule, MatSnackBarRef, MAT_SNACK_BAR_DATA } from '@angular/material/snack-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatRadioModule } from '@angular/material/radio';
import { MainComponent } from './main.component';
import { HeaderComponent } from '../header/header.component';
import { SnackbarComponent } from '../snackbar/snackbar.component';
import { FooterComponent } from '../footer/footer.component';
import { AutherizationComponent } from '../autherization/autherization.component';
import { NotificationsComponent } from '../notifications/notifications.component';
import { BreadcrumbsComponent } from '../breadcrumbs/breadcrumbs.component';
import { SearchpopupComponent } from '../searchpopup/searchpopup.component';
import { OrgcodeAccesspopup } from '../orgcode-accesspopup/orgcode-accesspopup.component';
import { IonicStorageModule, Storage } from '@ionic/storage-angular';
import { NgxSpinnerModule } from 'ngx-spinner';


const routes: Routes = [
  {
    path: '',
    component: MainComponent,
    children: [
      {
        path: '',
        //loadChildren: () => import('../home/home.module').then(m => m.HomeModule),
        loadChildren: () => import('../../shared/reader-handler.module').then(m => m.ReaderHandlerModule),
        canActivate: [AuthGuardService]
        //loadChildren: () => import('../wms/wms.module').then(m => m.WmsModule)
      },
      {
        path: 'reports',
        loadChildren: () => import('../reports/reports.module').then(m => m.ReportsModule),
        canActivate: [AuthGuardService]
      }, {
        path: 'home',
        loadChildren: () => import('../home/home.module').then(m => m.HomeModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'catalog',
        loadChildren: () => import('../catalogs/catalogs.module').then(m => m.CatalogsModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'settings',
        loadChildren: () => import('../settings/settings.module').then(m => m.SettingsModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'announcements',
        loadChildren: () => import('../announcements/announcements.module').then(m => m.AnnouncementsModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'myorders',
        loadChildren: () => import('../my-orders/my-orders.module').then(m => m.MyOrdersModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'myapprovals',
        loadChildren: () => import('../approvalsdetails/approvalsdetails.module').then(m => m.ApprovalsDetailsModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'bulkupload',
        loadChildren: () => import('../bulkupload/bulkupload.module').then(m => m.BulkuploadModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'itsupport',
        loadChildren: () => import('../itsupport/itsupport.module').then(m => m.ItsupportModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'trackorder',
        loadChildren: () => import('../track-order-details/track-order-details.module').then(m => m.trackOrderModule),
        canActivate: [AuthGuardService]
      },
      // {
      //   path: 'trackorder',
      //   loadChildren: () => import('../track-order-details/track-order-details.module').then(m => m.trackOrderModule)
      // },
      {
        path: 'wms',
        loadChildren: () => import('../wms/wms.module').then(m => m.WmsModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'requisitionDetail',
        loadChildren: () => import('../order-details/order-details.module').then(m => m.OrderDetailsModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'item_details',
        loadChildren: () => import('../item-details/item-details.module').then(m => m.ItemDetailsModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'select_source',
        loadChildren: () => import('../select-source/select-source.module').then(m => m.SelectSourceModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'administration',
        loadChildren: () => import('../administration/administration.module').then(m => m.AdministrationModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'bu-administration',
        loadChildren: () => import('../bu-administration/bu-administration.module').then(m => m.BUAdministrationModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'template-management',
        loadChildren: () => import('../template-management/template-management.module').then(m => m.TemplatemanagementModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'template-maintenance',
        loadChildren: () => import('../template-maintenance/template-maintenance.module').then(m => m.TemplateMaintenanceModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'intransit',
        loadChildren: () => import('../intransit/intransit.module').then(m => m.IntransitModule),
        canActivate: [AuthGuardService]
      },
      {
        path: 'authorize',
        component: AutherizationComponent,
        canActivate: [AuthGuardService]
      },
      {
        path: 'switchntid',
        component: SwitchNtidComponent,
        canActivate: [AuthGuardService]
      },
      {
        path: 'error',
        component: ErrorComponent,
        canActivate: [AuthGuardService]
      }
    ]
  }
];

@NgModule({
  declarations: [MainComponent, HeaderComponent, FooterComponent,
    NotificationsComponent, SnackbarComponent, BreadcrumbsComponent,
    SearchpopupComponent, OrgcodeAccesspopup, AutherizationComponent],
  imports: [
    CommonModule,
    Hub2usharedModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    MatMenuModule,
    MatSelectModule,
    MatDialogModule,
    MatButtonModule,
    MatPaginatorModule,
    MatSortModule,
    MatTableModule,
    MatRadioModule,
    MatInputModule,
    MatSidenavModule,
    MatToolbarModule,
    MatCardModule,
    MatSnackBarModule,
    NgxSpinnerModule,
    RouterModule.forChild(routes),
    IonicStorageModule.forRoot()
  ],
  entryComponents: [OrgcodeAccesspopup,],
  providers: [
    {
      provide: MatSnackBarRef,
      useValue: {}
    },
    {
      provide: MAT_SNACK_BAR_DATA,
      useValue: {}
    }, Storage
  ],
})
export class MainModule { }
