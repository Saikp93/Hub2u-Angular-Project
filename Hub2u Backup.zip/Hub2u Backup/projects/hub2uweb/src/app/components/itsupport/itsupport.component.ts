import { Component, ElementRef, Inject, OnInit, Renderer2, ViewChild } from '@angular/core';
import { SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ReportsService, clientInfo } from 'hub2ushared';
import { SnackbarComponent } from '../snackbar/snackbar.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonWebService } from '../../shared/common-web.service';
import { Overlay, BlockScrollStrategy } from '@angular/cdk/overlay';
import { MAT_SELECT_SCROLL_STRATEGY } from '@angular/material/select';
export function scrollFactory(overlay: Overlay): () => BlockScrollStrategy {
  return () => overlay.scrollStrategies.block();
}

@Component({
  selector: 'app-itsupport',
  templateUrl: './itsupport.component.html',
  styleUrls: ['./itsupport.component.scss'],
  providers: [
    { provide: MAT_SELECT_SCROLL_STRATEGY, useFactory: scrollFactory, deps: [Overlay] }
  ]
})
export class ItsupportComponent implements OnInit {
  iframeHeight: number = 0;
  url: SafeResourceUrl;
  userInfo: any = {};
  isInited: boolean;
  data;
  checkedFlag = false;
  picToView;
  file;
  filearray = [];
  imagebinary;
  textdata;
  screenWidth;
  screenHeight;
  uploadfilesobj = { uploadFiles: [] }
  browserName = '';
  browserVersion = '';
  platform
  loader: boolean;
  clientInfo: any = {};
  dataList
  uploadFiles = [];
  imageUrl
  categorydropdown;
  tasklist;
  submitted = false;
  filearrayobj = { filearray: [] }
  itSupportForm = new FormGroup({});
  constructor(private router: Router, @Inject('environment') private env: any, private sanitizer: DomSanitizer, private _formbuilder: FormBuilder, private reportService: ReportsService,
    private renderer: Renderer2, private _snackBar: MatSnackBar, private clientinfo: clientInfo, private commonWebService: CommonWebService) {
    if (this.router.getCurrentNavigation().extras.state != undefined) {
      this.data = this.router.getCurrentNavigation().extras.state.data;
    }
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.clientInfo.browserVersion = this.clientinfo.detectBrowserVersion();
    this.clientInfo.browserName = this.clientinfo.detectBrowserName();
    this.clientInfo.screensize = this.clientinfo.detectScreendetails();
    let osData = this.clientinfo.detectOs().split(" ");
    this.clientInfo.os = osData[0];
    this.clientInfo.osVersion = osData[1];
    this.itSupportForm = this._formbuilder.group({
      requestor: ['', Validators.required],
      application: ['', Validators.required],
      category: [null, Validators.required],
      task: [null, Validators.required],
      addInfo: ['', Validators.required],
      ProvideDetails: ['', Validators.required],
      checked: false
    })
    console.log(this.itSupportForm)
    this.fetchdropdown()
  }

  fetchdropdown() {
    let reqobj = {
      "ReportId": "10131",
      "ParametersInput": [{
        Name: "APPLICATION_NAME", Value: "HUB2U"

      }]
    }
    this.reportService.onGetDynamicReport(reqobj).subscribe(res => {
      this.dataList = res.ROW
      this.categorydropdown = [...new Set(this.dataList.map(item => item.CATEGORY))];
    })
  }
  getTaskdrop(c) {
    this.tasklist = this.dataList.filter(item => {
      return item.CATEGORY == c
    }).map(item => item.DESCRIPTION)
  }
  ngAfterViewInit() {
    this.setDetails()
  }

  backpage() {
    this.router.navigate(['/hub2u']);

  }
  setDetails() {
    this.textdata = { "Screen": 1720 }
    this.itSupportForm.controls["requestor"].setValue(this.data.REQUESTOR_NTID)
    this.itSupportForm.controls["application"].setValue('HUB2U')
    this.itSupportForm.get('requestor')['disable']();
    this.itSupportForm.get('addInfo')['disable']();
    this.itSupportForm.get('application')['disable']();
    if (this.data.DetailsInput[0].AttachmentList[0].Document) {
      this.itSupportForm.controls["checked"].setValue(true)
      this.checkedFlag = true
      this.picToView = this.data.DetailsInput[0].AttachmentList[0].Document
      this.filearrayobj.filearray.push({
        "DocumentName": "Screenshot",
        "DocumentDescription": "Screenshot captured automatically",
        "Document": this.picToView
      });
    }
  }
  enableUploadbtn() {
    if (this.itSupportForm.controls.checked.value == true) {
      this.checkedFlag = true
    }
    else {
      this.checkedFlag = false
    }
  }



  // submitForm() {
  //   this.loader = true
  //   this.submitted = true
  //   let taskdetails = this.itSupportForm.controls.task.value
  //   let providedetails = this.itSupportForm.controls.ProvideDetails.value

  //   var data = {
  //     "SourceSystem": this.itSupportForm.controls.application.value,
  //     "UserName": this.itSupportForm.controls.requestor.value,
  //     "DetailsInput": [
  //       {
  //         "ProblemCode": "47060",
  //         "Details": "\nScreen : 1280 x 720 , OS: Windows , OS Version: 10 , Browser: Chrome , Browser Version: 98.0.4758.102 ,Environment URL:  ,ERROR: ," + "TaskDetails:" + taskdetails + ",ProvideDetails:" + providedetails,
  //         "ContactEmail": "",
  //         "ContactName": "",
  //         "ContactPhone": "",
  //         "AttachmentList": this.filearrayobj.filearray
  //       }
  //     ]
  //   }
  //   let responsedata = {}
  //   this.reportService.submitTicket(data).subscribe(response => {
  //     this.loader = false
  //     if (response.ServiceTicketOutput != undefined) {
  //       if (response.STATUS == 'SUCCESS') {
  //         responsedata = {
  //           message: 'Ticket created succesfully with ServiceRequestId -' + response.ServiceTicketOutput[0].ServiceRequestId,
  //           status: 'SUCCESS'
  //         }
  //         this.itSupportForm.reset();
  //         Object.keys(this.itSupportForm.controls).forEach(key => {
  //           this.itSupportForm.controls[key].setErrors(null)
  //         });
  //         this.itSupportForm.controls["requestor"].setValue(this.data.REQUESTOR_NTID)
  //         this.itSupportForm.controls["application"].setValue('HUB2U')
  //         this.filearrayobj.filearray = [];
  //       }
  //       else {
  //         responsedata = {
  //           message: 'Error in creating ticket ',
  //           status: 'ERROR'
  //         }
  //       }
  //       this.commonWebService.openSnackBar(responsedata['message'], responsedata['status'])
  //     }
  //     else {
  //       this.commonWebService.openSnackBar("Error in creating ticket", "ERROR")
  //     }
  //   }, error => {
  //     this.loader = false;
  //     responsedata = {
  //       message: 'Error in creating ticket ',
  //       status: 'ERROR'
  //     }
  //     this.commonWebService.openSnackBar(responsedata['message'], responsedata['status'])
  //   }
  //   )
  // }

  /**SOA TO JAVA */
  submitForm() {
    this.loader = true
    this.submitted = true
    let taskdetails = this.itSupportForm.controls.task.value
    let providedetails = this.itSupportForm.controls.ProvideDetails.value

    var data = {
      "SourceSystem": this.itSupportForm.controls.application.value,
      "UserName": this.itSupportForm.controls.requestor.value,
      "DetailsInput": [
        {
          "ProblemCode": "47060",
          "Details": "\nScreen : 1280 x 720 , OS: Windows , OS Version: 10 , Browser: Chrome , Browser Version: 98.0.4758.102 ,Environment URL:  ,ERROR: ," + "TaskDetails:" + taskdetails + ",ProvideDetails:" + providedetails,
          "ContactEmail": "",
          "ContactName": "",
          "ContactPhone": "",
          "AttachmentListType": this.filearrayobj.filearray
        }
      ]
    }
    let responsedata = {}
    this.reportService.submitTicket(data).subscribe(response => {
      this.loader = false
      if (response.number != undefined && response.number != "") {
        responsedata = {
          message: 'Ticket created succesfully with ServiceRequestId -' + response.number,
          status: 'SUCCESS'
        }
        this.itSupportForm.reset();
        // Object.keys(this.itSupportForm.controls).forEach(key => {
        //   this.itSupportForm.controls[key].setErrors(null)
        // });
        this.itSupportForm.controls["requestor"].setValue(this.data.REQUESTOR_NTID)
        this.itSupportForm.controls["application"].setValue('HUB2U')
        this.filearrayobj.filearray = [];
        this.commonWebService.openSnackBar(responsedata['message'], 'SUCCESS')

      }
      else {
        this.commonWebService.openSnackBar("Failed to Create Ticket", "ERROR")
      }
    }, error => {
      this.loader = false;

      this.commonWebService.openSnackBar('Error in creating ticket', 'ERROR')
    }
    )
  }

  onFileSelected(event) {
    this.file = event.target.files[0];
    let reader = new FileReader();
    reader.readAsDataURL(this.file);
    reader.onload = () => {
      this.imageUrl = reader.result;
      // this.filearrayobj.filearray.push({ file: this.file, imageUrl: this.imageUrl });
      this.filearrayobj.filearray.push({
        "DocumentName": "Screenshot",
        "DocumentDescription": "Screenshot captured automatically",
        "Document": this.imageUrl
      });
    };
    reader.onerror = function (error) {
    };
    this.imagebinary = reader.result;
  }

  deleteImage(file) {
    let index = this.filearrayobj.filearray.findIndex(doc => doc.Document === file.Document)
    this.filearrayobj.filearray.splice(index, 1)
  }
}
