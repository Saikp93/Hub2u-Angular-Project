import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ItsupportComponent } from './itsupport.component';
import { RouterModule, Routes } from '@angular/router';
import { MatInputModule } from '@angular/material/input';
import { ReactiveFormsModule} from '@angular/forms';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { Hub2usharedModule } from 'hub2ushared'; 
import {MatButtonModule} from '@angular/material/button';
import { NgxSpinnerModule } from 'ngx-spinner';

const routes: Routes = [
  {
    path: '',
    component: ItsupportComponent
  }
];

@NgModule({
  declarations: [ItsupportComponent],
  imports: [
    CommonModule,
    MatInputModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    MatSelectModule,
    MatIconModule,
    Hub2usharedModule,
    MatButtonModule,
    NgxSpinnerModule,
    RouterModule.forChild(routes)
  ]
})
export class ItsupportModule { }
