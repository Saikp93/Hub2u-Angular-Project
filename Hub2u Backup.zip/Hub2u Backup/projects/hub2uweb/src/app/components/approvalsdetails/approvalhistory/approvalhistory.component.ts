import { Component, Inject, Input, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthService, HomeService, PagerComponent, GetimageService, ReportsService } from 'hub2ushared';
import { element } from 'protractor';
import { CommonWebService } from '../../../shared/common-web.service';


@Component({
  selector: 'app-approvalhistory',
  templateUrl: './approvalhistory.component.html',
  styleUrls: ['./approvalhistory.component.scss'],
})
export class ApprovalhistoryComponent implements OnInit {
  @Input() selectedTab: any;
  @Input() aprrovalsResponse: any = [];
  @Input() nodata: boolean;
  nodatafound: boolean = false;

  @Input() pendingApprovalData: any;
  userInfo: any;
  userRole: any;
  values;
  functionId: any;
  loadSpinner: boolean = false;
  approve: boolean = false;
  ntId: any;
  textData;
  detailsResponse: any = [];
  viewDetailsResponse: any = [];
  viewDetailsHeaderResponse: any = [];
  public isCollapsed: boolean[] = [true];
  currentlyOpenedItemIndex = -1;
  myObject = new Map();
  ItemPerPage = 5;
  pageSizes = [5, 10, 15, 20];
  pagedItems = [];
  pageNumber = 1;
  pager: any = {};
  newDetails = [];

  @ViewChild('confirmOrder') confirmOrder: TemplateRef<any>;
  @ViewChild('PagerComponent') pagerComponent: PagerComponent;
  constructor(@Inject('environment') private env: any, private reports: ReportsService, private homeService: HomeService,
    private _snackBar: MatSnackBar, public commonWebService: CommonWebService, public dialog: MatDialog, private GetimageService: GetimageService) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
  }

  viewDetails(item) {
    this.newDetails = [];
    if (this.userInfo != undefined) {
      this.ntId = this.userInfo.NTID;
    }
    this.loadSpinner = true;
    let req = {
      ReportId: "10091",
      ParametersInput: [
        {
          Name: "REQUESTOR",
          Value: item.FROM_USER
        },
        {
          Name: "REQUISITION_NUMBER",
          Value: item['Order Number']
        },
        {
          Name: "P_CATALOG",
          Value: this.userRole.toUpperCase()
        }
      ]
    }
    this.reports.onGetDynamicReport(req).subscribe(response => {
      if (response.ROW !== undefined) {
        let details = response.ROW;
        this.detailsResponse = response.ROW;
        this.viewDetailsResponse = this.OrganizedCart(details, 'LINE_COLUMNS');
        this.values = Object.values(this.viewDetailsResponse);
        // let newArr = [];
        // for(let item of this.values){
        //   this.detailsResponse.forEach(element => {
        //     newArr[item] = element[item]
        //   });
        // }

        response.ROW.forEach(row => {
          let myMap = new Map();
          let lineCols = row['LINE_COLUMNS'].split(',')
          lineCols.forEach(col => {
            myMap.set(col, row[col])
          })
          this.newDetails.push(myMap)
        })

        // let newsKeys= Object.keys(newArr);
        // let newVals = Object.values(newArr)
        // for (let i = 0; i < newsKeys.length; i++) {
        //   this.myObject.set(newsKeys[i], newVals[i]);
        // }
        this.viewDetailsHeaderResponse = this.OrganizedCart(details, 'HEADER_COLUMNS');
        this.loadSpinner = false;
        this.nodatafound = false;
      } else {
        this.loadSpinner = false;
        this.nodatafound = true;
      }
    }, error => {
      this.loadSpinner = false;
      this.nodatafound = true;
    })

  }

  asIsOrder(a, b) {
    return 1;
  }

  setPage($event) {
    if ($event !== undefined) {
      this.pagedItems = $event.pagedItems;
      this.pageNumber = $event.pageNumber;
      this.ItemPerPage = $event.itemsPerPage;
    }
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
    }
    return col;
  }

  OrganizedCart(resp, col) {
    let cart = [];
    let display_column = [];
    if (resp[0][col] !== undefined) {
      display_column = this.convertToArray(resp[0][col]);
    }
    return display_column
  }

  isAvailable(key, data) {
    let dataToSearch = [];
    if (data == 'pendingData') {
      dataToSearch = this.pendingApprovalData
    } else if (data == 'viewDetailsHeaderData') {
      dataToSearch = this.viewDetailsHeaderResponse
    } else if (data == 'viewDetailsData') {
      dataToSearch = this.viewDetailsResponse
    }
    if (dataToSearch != undefined) {
      return dataToSearch.includes(key);
    }
  }

  popupconfirmOrder(item, i) {
    if (this.functionId == '61') {
      let dialogRef = this.dialog.open(this.confirmOrder);
      dialogRef.afterClosed().subscribe(result => {
        if (result !== undefined) {
          if (result === 'submit') {
            item.NOTE = this.textData;
            this.rejectItem(item, i)
          }
          else if (result === 'cancel') {
            // console.log("i am in", 'cancel')
          }
          this.textData = '';
        }
      })
    } else {
      this.rejectItem(item, i)
    }

  }


  approveItem(item, i) {
    this.approve = true;
    this.approvalStatus(item, i);
  }

  rejectItem(item, i) {
    this.approve = false;
    this.approvalStatus(item, i);
  }

  approvalStatus(item, i) {
    item.loading = true;
    if (this.userInfo != undefined) {
      this.ntId = this.userInfo.NTID;
    }

    let action = (this.approve === true) ? "APPROVE" : "REJECT";
    let req = {
      "action": action,
      "approvalTypeLookupCode": item.APPROVAL_TYPE_LOOKUP_CODE,

      "approvalActionInput": [{
        "notificationId": item.NOTIFICATION_ID,
        "comments": item.NOTE,
      }],
      "ntId": this.ntId.toUpperCase(),
    }
    this.homeService.getApprovalDetails(req).subscribe(response => {

      if (response !== undefined) {
        let appovalresp = response;
        item.loading = false;
        let message = appovalresp['statusMessage'] || '';

        if (appovalresp['status'] === 'SUCCESS') {
          this.pagedItems.splice(i, 1);
          this.commonWebService.openSnackBar(message, "SUCCESS");
        }
        if (appovalresp['status'] === 'FAILED') {
          this.commonWebService.openSnackBar(message, "ERROR");
        }
      } else {
        item.loading = false;
      }
    }, error => {
      item.loading = false;
      this.commonWebService.openSnackBar('Something went wrong. Please try again later', "ERROR");
    })
  }

  setOpened(itemIndex) {
    this.currentlyOpenedItemIndex = itemIndex;
  }

  setClosed(itemIndex) {
    if (this.currentlyOpenedItemIndex === itemIndex) {
      this.currentlyOpenedItemIndex = -1;
    }
  }

  // getImage(item) {
  //   let imageSrc;
  //   imageSrc = (item.get('CIFA#') ? this.imageURL + item.get('CIFA#') : this.imageURL + (item.get('MODEL#') ? item.get('MODEL#').replace(/ /g, "-") : item.get('MODEL#'))) + '.jpg'
  //   return imageSrc;
  // }

  /**SOA TO JAVA */
  getImage(item) {
    let imageSrc;
    imageSrc = (item.get('CIFA#') ? item.get('CIFA#') : (item.get('MODEL#') ? item.get('MODEL#').replace(/ /g, "-") : item.get('MODEL#')))
    let image = this.GetimageService.getImagefromcifa(imageSrc)
    //console.log("image ApprovalhistoryComponent ", image)
    return image;
  }

}
