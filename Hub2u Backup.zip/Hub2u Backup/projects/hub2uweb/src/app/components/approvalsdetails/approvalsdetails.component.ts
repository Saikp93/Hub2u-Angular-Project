import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService, ReportsService } from 'hub2ushared';
import { EventService } from '../../shared/event.service';

@Component({
  selector: 'app-approvalsdetails',
  templateUrl: './approvalsdetails.component.html',
  styleUrls: ['./approvalsdetails.component.scss'],
})
export class ApprovalsdetailsComponent implements OnInit {

  userInfo: any;
  userRole: any;
  functionId: any;
  selectedTab = '';
  reportId: any;
  errMsg: any;
  ntId: any;
  dynamicReq: any;
  aprrovalsResponse: any = [];
  pendingApprovalData = [];
  nodata: boolean = false;
  loadSpinner: boolean = false;

  constructor(private router: Router, private reports: ReportsService, private eventService: EventService, private authService: AuthService) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.selectedTab = '0';
    this.reportId = "10088";
    this.getDynamicReport();
  }

  tabChanged(event) {
    if (event.index == 0) {
      this.reportId = "10088";
      this.selectedTab = '0';
      this.getDynamicReport();
    }
    else if (event.index == 1) {
      this.reportId = "10089";
      this.selectedTab = '1';
      this.getDynamicReport();
    }
  }

  getDynamicReport() {
    if (this.userInfo != undefined) {
      this.ntId = this.userInfo.NTID;
    }
    this.loadSpinner = true;
    this.dynamicReq = {
      ParametersInput: [
        {
          Name: "P_APPROVER",
          Value: this.ntId
        },
        {
          Name: "P_CATALOG",
          Value: this.userRole.toUpperCase()
        }
      ],
      ReportId: this.reportId
    }
    this.reports.onGetDynamicReport(this.dynamicReq).subscribe(response => {
      if (response != undefined) {
        if (response.ROW != undefined) {
          this.loadSpinner = false;
          this.nodata = false;
          this.aprrovalsResponse = response.ROW || [];
          this.updateImgeSrc(this.aprrovalsResponse);
          this.pendingApprovalData = this.OrganizedCart(this.aprrovalsResponse, 'DISPLAY_COLUMNS');
        } else if (response.ROW == null || response.ROW == undefined) {
          this.loadSpinner = false;
          this.nodata = true;
        }
      } else if (response == undefined || response == null) {
        this.loadSpinner = false;
        this.nodata = true;
      }
    }, error => {
      console.log(error);
      this.loadSpinner = false;
      this.nodata = true;
    })

  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
    }
    return col;
  }

  OrganizedCart(resp, col) {
    let cart = [];
    let display_column = [];
    if (resp[0][col] !== undefined) {
      display_column = this.convertToArray(resp[0][col]);
    }

    return display_column
  }

  updateImgeSrc(data) {
    for (let item of data) {
      this.authService.onGetProfileImage(item.FROM_USER ? item.FROM_USER.toUpperCase() : '').subscribe(response => {
        const reader = new FileReader();
        reader.addEventListener('load', () => {
          item.Img = reader.result;
        }, false);
        if (response) {
          reader.readAsDataURL(response);
        }
      }, error => {

      });
    }

  }

  goBack() {
    this.router.navigate(['hub2u/home']);
    // window.history.back();
  }

}
