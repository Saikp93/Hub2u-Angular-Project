import { SelectionModel } from '@angular/cdk/collections';
import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { AnnouncementsService } from 'hub2ushared';
import { CommonWebService } from '../../../shared/common-web.service';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-view-announcements',
  templateUrl: './view-announcements.component.html',
  styleUrls: ['./view-announcements.component.scss'],
})
export class ViewAnnouncementsComponent implements OnInit {

  dataSource: MatTableDataSource<any>;
  selection = new SelectionModel<any>(true, []);
  displayedColumns: string[] = ['select', 'alertType', 'effectiveStartDate', 'alertMessage', 'acknowledge'];
  userInfo: any;
  userRole: string;
  functionId: string;
  announcementsForUsers: any;
  loader: boolean = false
  showTable: boolean = false;
  nodata: boolean = false;
  deletedList: any;
  isButtonEnable:boolean = true;

  constructor(private announcementService: AnnouncementsService,public datepipe: DatePipe,private commonWebService: CommonWebService,
    private sanitizer: DomSanitizer,) {
    this.selection.changed.subscribe(item=>{
      this.isButtonEnable = this.selection.selected.length == 0;
    })
   }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    // this.loader = true;
    this.showTable = false;
    this.fetchAnnouncements();
  }

  public newform: FormGroup = new FormGroup({
    html: new FormControl('', Validators.required)
  });
  
  get sanitizedHtml() {
    return this.sanitizer.bypassSecurityTrustHtml(this.newform.get('html').value);
  }

  fetchAnnouncements() {
    this.loader = true;
    let request = {
      applicationId: 1,
      ntAccount: this.userInfo.NTID
    };
    this.announcementService.getAnnouncementsForUserList(request).subscribe(response => {
      if (response != undefined) {
        this.announcementsForUsers = response.announcementsForUserListOut;
        this.loader = false;
        if (this.announcementsForUsers != undefined && this.announcementsForUsers.length > 0) {
          this.nodata = false
          this.showTable = true;
          this.dataSource = new MatTableDataSource<any>(this.announcementsForUsers);
        } else {
          this.nodata = true;
          this.showTable = false;
        }
      } else {
        this.loader = false;
        this.nodata = true;
        this.showTable = false;
      }
    }, error => {
      console.log(error);
      this.loader = false;
      this.nodata = true;
      this.showTable = false;
    });
    // }

  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }
    this.selection.select(...this.dataSource.data);
  }

  removeSelectedRows() {
    this.loader = true;
    let inputDelete = [];
    for (let item of this.selection.selected) {
      let request = {
        "APPLICATION_ID": item.applicationId,
        "ATTRIBUTE1": item.attribute1,
        "CREATED_BY": item.createdBy,
        "MESSAGE_ID": item.messageId,
        "OPERATION": "REVOKE"
      }

      inputDelete.push(request);
    }
    this.announcementService.revokeAnnouncement(inputDelete).subscribe(response => {
      if(response !== undefined){
        this.deletedList = response;
        this.commonWebService.openSnackBar(this.deletedList.message, this.deletedList.status);
        this.fetchAnnouncements();
      }else{
        this.loader = false;
      }      
    }, error => {
      this.loader = false;
      this.commonWebService.openSnackBar("Something went wrong.Can you please try later", "ERROR")
    })
    this.selection.clear();
  }

}
