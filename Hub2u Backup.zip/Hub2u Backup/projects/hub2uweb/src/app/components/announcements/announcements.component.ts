import { Component, OnInit } from '@angular/core';
import { AnnouncementsService } from 'hub2ushared';


@Component({
  selector: 'app-announcements',
  templateUrl: './announcements.component.html',
  styleUrls: ['./announcements.component.scss'],
})
export class AnnouncementsComponent implements OnInit {

  selectedTab = '1';
  view: boolean = false;
  manage: boolean = false;
  accountId: string;

  constructor(private announcementService: AnnouncementsService) { }

  ngOnInit() {
    this.view = true;
    // this.accountId = localStorage.getItem('currentUser');
  }

  viewNotifications() {
    this.view = true;
    this.manage = false;
  }

  manageNotifications() {
    this.manage = true;
    this.view = false;

  }
}
