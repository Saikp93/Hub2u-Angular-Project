import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { DatePipe } from '@angular/common'
import { AnnouncementsService } from 'hub2ushared';
import { NotifierService } from 'projects/hub2ushared/src/lib/services/notifier.service';
import { CommonWebService } from '../../../shared/common-web.service';
import { Subscription } from 'rxjs';
import { AnnouncementPopupComponent } from '../../home/announcement-popup/announcement-popup.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-manage-announcements',
  templateUrl: './manage-announcements.component.html',
  styleUrls: ['./manage-announcements.component.scss'],
})
export class ManageAnnouncementsComponent implements OnInit {

  private paginator: MatPaginator;
  private sort: MatSort;
  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.setDataSourceAttributes();
  }
  @ViewChild(MatSort) set matSort(ms: MatSort) {
    this.sort = ms;
    this.setDataSourceAttributes();
  }

  setDataSourceAttributes() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }


  public userProfileData: Array<any> = [
    // {
    //   'checked': false,
    //   'id': 'Business User',
    //   'value': 'COMCAST BUSINESS SERVICES USER',
    // },
    {
      'checked': false,
      'id': 'Business User',
      'value': 'COMCAST BUSINESS SERVICES USER IIP',
    },
    {
      'checked': false,
      'id': 'ESA User',
      'value': 'Comcast ESA User',
    },
    {
      'checked': false,
      'id': 'Store User',
      'value': 'COMCAST STORE USER',
    },
    {
      'checked': false,
      'id': 'Tech User',
      'value': 'COMCAST TECH USER IIP'
    }
  ]; 
  selectedOptions: any = '';
  userInfo: any = {};
  userRole: any = '';
  functionId = '1';
  announcementsForUsers: any;
  announcementsType: any[] = [];
  regionNames: any[] = [];
  // users = ["Tech User", "Store User", "Business User", "ESA User"];
  announcementType: any;
  annType: any[] = [];
  availableRegionList: any;
  htmlContent = '';
  public clientForm: FormGroup;
  showAddForm: boolean = false;
  showTable: boolean = false;
  public editorDisabled = false;
  dataSource: MatTableDataSource<any>;
  selection = new SelectionModel<any>(true, []);
  displayedColumns: string[] = ['select', 'messageType', 'startDate', 'published', 'messageText', 'revoke', 'edit'];
  // requestName: string;
  hideRegion: boolean = false;
  hideProfile: boolean = false;
  disablePreview: boolean = false;
  loader: boolean = false;
  nodata: boolean = false;
  isButtonEnable: boolean = true;

  constructor(private announcementService: AnnouncementsService, public form: FormBuilder,
    private dialog: MatDialog, private sanitizer: DomSanitizer, public datepipe: DatePipe,
    private notifierService: NotifierService, private commonWebService: CommonWebService) {
    this.dataSource = new MatTableDataSource(this.annType);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.selection.changed.subscribe(item => {
      this.isButtonEnable = this.selection.selected.length == 0;
    })
  }

  date = new FormControl(new Date());
  minCurrentDate = new Date();
  maxNewDate = new Date();
  minDate = this.minCurrentDate;
  maxDate = this.maxNewDate.setDate(this.maxNewDate.getDate() + 89);
  newMaxDate;
  mesageId: any;

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    // this.loader = true;
    this.onInitialLoad();
    this.getAnnouncementsType();
    this.fetchRegUsingRep();
    this.fetchAdminAnnouncements();
    this.showTable = false;
    this.newMaxDate = this.datepipe.transform(this.maxDate, 'yyyy-MM-ddTHH:mm:ss');
  }

  async onInitialLoad() {
    this.userInfo = await JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.initialFormControl();
  }

  initialFormControl() {
    this.clientForm = this.form.group({
      requestorName: [''],
      messageType: ['', Validators.required],
      regionName: [null],
      messageId: [null],
      htmlContent: [''],
      expDate: [this.newMaxDate + "Z"],
      ackChecked: [false],
      checkBoxValue: new FormArray([]), 
      startDate: new FormControl(new Date()),
    });
    this.clientForm.controls["requestorName"].setValue(this.userInfo.NTID);
  } 
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }
    this.selection.select(...this.dataSource.data);
  }  
  fetchAdminAnnouncements() {
    this.loader = true;
    let request = {
      applicationId: 1,
      userNtid: this.userInfo.NTID
    };
    this.announcementService.getAnnouncementsForAdminList(request).subscribe(response => {
      if (response != undefined) {
        this.announcementType = response;
        this.annType = this.announcementType;
        this.loader = false
        if (this.annType != undefined && this.annType.length > 0) {
          this.dataSource = new MatTableDataSource<any>(this.annType);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.showTable = true;
          this.nodata = false;
        } else {
          this.nodata = true;
          this.showTable = false;
        }
      } else {
        this.loader = false;
        this.nodata = true;
        this.showTable = false;
      }
    }, error => {
      console.log(error);
      this.loader = false;
      this.nodata = true;
      this.showTable = false;
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  getAnnouncementsType() {
    this.announcementService.announcementsType().subscribe(response => {
      this.announcementType = response;
      if (this.announcementType != null || this.announcementType != undefined) {
        for (let announceType of this.announcementType) {
          // announceType = announceType.MEANING;
          announceType = announceType;
          this.announcementsType.push(announceType);
        }
      }
      // console.log("this.announcementsType",this.announcementsType)
    }, error => {
      console.log(error);
    });
  }

  fetchRegUsingRep() {
    let request = {
      // applicationId: 1,
      applicationId: 7,
      functionId: 13,
    }
    this.announcementService.regUsingResp(request).subscribe(data => {
      this.availableRegionList = data;
      for (let regName of this.availableRegionList.regionLookUp) {
        regName = regName.meaning;
        this.regionNames.push(regName);
      }
    }, error => {
      console.log(error);
    })
  }

  public newform: FormGroup = new FormGroup({
    html: new FormControl('', Validators.required)
  });

  public config: any = {
    airMode: false,
    tabDisable: true,
    popover: {
      table: [
        ['add', ['addRowDown', 'addRowUp', 'addColLeft', 'addColRight']],
        ['delete', ['deleteRow', 'deleteCol', 'deleteTable']]
      ],
      image: [
        ['image', ['resizeFull', 'resizeHalf', 'resizeQuarter', 'resizeNone']],
        ['float', ['floatLeft', 'floatRight', 'floatNone']],
        ['remove', ['removeMedia']]
      ],
      link: [['link', ['linkDialogShow', 'unlink']]],
      air: [
        [
          'font',
          [
            'bold',
            'italic',
            'underline',
            'strikethrough',
            'superscript',
            'subscript',
            'clear'
          ]
        ]
      ]
    },
    height: '200px',
    toolbar: [
      ['style', ['style']],
      ['font', ['bold', 'italic', 'underline', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style0', 'ul', 'ol', 'paragraph', 'height']],
      ['insert', ['table', 'picture']],
      ['view', ['fullscreen', 'codeview', 'help']]
    ],
    fontSizes: ['8', '9', '10', '11', '12', '14', '18', '24', '36'],
    fontNames: ['Open sans', 'Arial', 'Times New Roman', 'Inter', 'Comic Sans MS', 'Courier New', 'Roboto'],
    codeviewFilter: true,
    codeviewFilterRegex: /<\/*(?:applet|b(?:ase|gsound|link)|embed|frame(?:set)?|ilayer|l(?:ayer|ink)|meta|object|s(?:cript|tyle)|t(?:itle|extarea)|xml|.*onmouseover)[^>]*?>/gi,
    codeviewIframeFilter: true
  };

  get sanitizedHtml() {
    return this.sanitizer.bypassSecurityTrustHtml(this.newform.get('html').value);
  }

  public enableEditor() {
    this.editorDisabled = false;
  }

  public disableEditor() {
    this.editorDisabled = true;
  }

  public onBlur() {
    // console.log('Blur');
  }

  public onDelete(file) {
    console.log('Delete file', file.url);
  }

  public summernoteInit(event) {
    console.log(event);
  }

  enableSave: boolean = false;
  changeDashboard(selectedType) {
    if (selectedType.value == "ENHANCEMENT" || selectedType.value == "MAINTENANCE"
      || selectedType == "ENHANCEMENT" || selectedType == "MAINTENANCE") {
      this.hideRegion = true;
      this.hideProfile = true;
      this.disablePreview = true;
      this.enableSave = true;
    } else if (selectedType.value == "FLASH CARDS" || selectedType == "FLASH CARDS") {
      this.hideRegion = false;
      this.hideProfile = false;
      this.disablePreview = false;
      this.enableSave = true;
    } else if (selectedType.value == "REGIONAL" || selectedType == "REGIONAL") {
      this.hideRegion = false;
      this.hideProfile = true;
      this.disablePreview = true;
      this.enableSave = true;
    }
  }

  previewAnnouncement() {
    this.openIonModal(this.clientForm.value);
  }

  openIonModal(data) {
    var response = data;
    var annArray = [];

    var newImgSrc = "../../assets/images/no-image.jpg";
    var msgContent = "";

    var type = response.htmlContent;
    var msgId = response.messageId;
    var contentChk = /<[a-z/][\s\S]*>/i.test(type);
    //console.log("item",type,contentChk)
    var noOfLikes = response.LIKES || 0;
    var button = 'See More';
    var disableButton;

    if (response.USER_LIKES > 0) {
      disableButton = true;
    }
    else {
      disableButton = false;
    }
    if (contentChk == false) {
      msgContent = type;

    }
    else {
      msgContent = (response.htmlContent).replace(/<img[^>]*>/g, "");

      var parser = new DOMParser();
      var doc = parser.parseFromString(response.htmlContent, 'text/html');

      if (doc.body.getElementsByTagName('img').length > 0) {
        newImgSrc = doc.body.getElementsByTagName('img')[0].getAttribute("src");
      }
    }

    annArray.push({ "newImgSrc": newImgSrc, "msgId": msgId, "noOfLikes": noOfLikes, "msgContent": msgContent, "button": button, "disableButton": disableButton, "flag": "preview", "disableNiceButton": true })

    // if (!sessionStorage.getItem("flashCardPopupRendered")) {
    this.openAnnoucementModalpopup(annArray);
    // } 
  }

  openAnnoucementModalpopup(data) {
    const dialogRef = this.dialog.open(AnnouncementPopupComponent,
      {
        width: '800px',
        panelClass: 'annu-dialog',
        data: data
      });
    dialogRef.afterClosed().subscribe(result => {
      sessionStorage.setItem("flashCardPopupRendered", "Y");
      if (result !== undefined) {
        if (result === 'show') {
          sessionStorage.setItem("showPopup", "yes");
        } else if (result === 'nice') {
          sessionStorage.setItem("showPopup", "no");
        }
      }
    })
  }

  strtDate;
  endedDate;
  dateFormatter() {
    var dateobj = new Date(this.clientForm.get("startDate").value);
    var newdate = new Date(dateobj.getTime() + (5 * 60 + 30) * 60000);
    this.strtDate = newdate.toISOString();

    var enddateobj = new Date(this.clientForm.get("expDate").value);
    var newenddate = new Date(enddateobj.getTime() + (5 * 60 + 30) * 60000);
    this.endedDate = newenddate.toISOString();
  }
  addItem() {
    if (this.loader == false) {
      this.nodata = false;
      this.isEdit = false;
      this.hideRegion = false;
      this.hideProfile = false;
      this.showAddForm = true;
      this.showTable = false;
      this.enableSave = false;
      this.clientForm.reset();
      this.initialFormControl();
    }
  }

  msgTxt: any;
  msgId: any;
  availableList: any;
  deletedList: any;
  showMsgId: boolean = false;
  isEdit: boolean = false;
  imageCont1: any;
  imageCont2: any;
  src;
  onSaveAnnouncement(event) {
    this.dateFormatter();
    this.loader = true;

    let tmp = document.createElement('div');
    tmp.innerHTML = this.clientForm.get("htmlContent").value;
    if (tmp.querySelector('img') != null) {
      this.src = tmp.querySelector('img').getAttribute('src');
      // console.log("test img bypass: ", URL.createObjectURL(this.src));
    }
    // console.log("src & cleanText",tmp.innerHTML)

    if (this.isEdit == false) {
      let saveannouncement =
        [{
          ACKNOWLEDGEMENT_REQ: this.clientForm.get("ackChecked").value == false ? "N" : "Y",
          APPLICATION_ID: "1",
          ATTRIBUTE1: this.selectedOptions,
          CREATED_BY: this.userInfo.NTID,    // this.accountId;
          EXPIRES_ON: this.endedDate,
          IMAGE_CONTENT: this.src,
          MESSAGE_TEXT: tmp.innerHTML,
          MESSAGE_TYPE: this.clientForm.get("messageType").value,
          OPERATION: "SAVE",
          PUBLISHED: (event == "publish") ? "Y" : "N",
          REGION_NAME: this.clientForm.get("regionName").value,
          START_DATE: this.strtDate,
        }]
      this.announcementService.saveAnnouncement(saveannouncement).subscribe(resp => {
        if (resp != undefined) {
          this.availableList = resp;
          this.msgId = this.availableList.messageId;
          this.commonWebService.openSnackBar(this.availableList.message, this.availableList.status);
          // this.notifierService.showNotification(this.availableList.message);

          // if (this.src != null || this.src != undefined) {
          //   let imgUpload = {
          //     applicationId: "1",
          //     messageId: this.msgId ? this.msgId : this.clientForm.get("messageId").value,
          //     scanImageFile: this.src
          //   }
          //   this.announcementService.imageUpload(imgUpload).subscribe(respnse => {
          //     // this.fetchAdminAnnouncements();
          //   }, error => {
          //     this.loader = false;
          //     console.log(error);
          //   })
          // } else {
          //   this.loader = false;
          //   // this.fetchAdminAnnouncements();
          // }
          this.showAddForm = false;
          // this.showTable = true;
          this.isEdit = false;
          this.fetchAdminAnnouncements();
          this.clientForm.reset();
        }
      }, error => {
        this.loader = false;
        console.log(error);
      });

      // console.log(saveannouncement);
    }
    else {
      let editannouncement =
        [{
          ACKNOWLEDGEMENT_REQ: this.clientForm.get("ackChecked").value == false ? "N" : "Y",
          APPLICATION_ID: "1",
          ATTRIBUTE1: this.selectedOptions,
          CREATED_BY: this.userInfo.NTID,    // this.accountId;
          EXPIRES_ON: this.endedDate,
          MESSAGE_ID: this.clientForm.get("messageId").value,
          IMAGE_CONTENT: this.src,
          MESSAGE_TEXT: tmp.innerHTML,
          MESSAGE_TYPE: this.clientForm.get("messageType").value,
          OPERATION: "SAVE",
          PUBLISHED: (event == "publish") ? "Y" : "N",
          REGION_NAME: this.clientForm.get("regionName").value,
          START_DATE: this.strtDate,
        }]
      this.announcementService.saveAnnouncement(editannouncement).subscribe(resp => {
        if (resp != undefined) {
          this.availableList = resp;
          this.msgId = this.availableList.messageId;
          this.commonWebService.openSnackBar(this.availableList.message, this.availableList.status);

          if (this.src != null || this.src != undefined) {
            let imgUpload = {
              applicationId: "1",
              messageId: this.msgId ? this.msgId : this.clientForm.get("messageId").value,
              scanImageFile: this.src
            }
            this.announcementService.imageUpload(imgUpload).subscribe(respnse => {
              this.fetchAdminAnnouncements();
            }, error => {
              this.loader = false;
              console.log(error);
            })
          } else {
            this.fetchAdminAnnouncements();
          }
          this.showAddForm = false;
          this.showTable = true;
          this.isEdit = false;
        }
      }, error => {
        this.loader = false;
        console.log(error);
      });
      // console.log(editannouncement);
    }
  }
  onCheckChange(event) {
    const formArray: FormArray = this.clientForm.get('checkBoxValue') as FormArray;
    /* Selected */
    if (event.target.checked) {
      formArray.push(new FormControl(event.target.value));
    }
    /* unselected */
    else {
      let i: number = 0;
      formArray.controls.forEach((ctrl: FormControl) => {
        if (ctrl.value == event.target.value) {
          // Remove the unselected element from the arrayForm
          formArray.removeAt(i);
          return;
        }
        i++;
      });
    }
  }
  edit(value) { 
    this.isEdit = true;
    this.showAddForm = true;
    this.showTable = false;
    this.showMsgId = true;
    // this.mesageId = this.clientForm.get("messageId").value;
    const formArray: FormArray = this.clientForm.get('checkBoxValue') as FormArray;
    if (value.attribute1 !== null && value.attribute1 !== undefined && value.attribute1 !== '') {
      let user = value.attribute1.split(',');
      user.forEach(function (obj) {
        formArray.push(new FormControl(obj));
      });
      for (let checkVal of this.clientForm.value.checkBoxValue) {
        this.userProfileData.forEach(element => {
          if (element.value == checkVal) {
            element.checked = true;
          }
        });
      }
    } 
   
    this.clientForm.controls["messageId"].setValue(value.messageId);
    this.clientForm.controls["requestorName"].setValue(value.createdBy);
    // this.clientForm.controls["messageType"].setValue(value.MESSAGE_TYPE);
    this.clientForm.controls["messageType"].setValue(value.messageType);
    this.clientForm.controls["regionName"].setValue(value.regionName);
    // this.clientForm.controls["checkBoxValue"].setValue(value.MESSAGE_TYPE);
    this.clientForm.controls["htmlContent"].setValue(value.messageText);
    this.clientForm.controls["startDate"].setValue(value.startDate);
    this.clientForm.controls["expDate"].setValue(value.expiresOn);
    this.clientForm.controls["ackChecked"].setValue((value.acknowledgementReq == "N") ? false : true);
    this.changeDashboard(value.messageType);
  }

  setCheckBoxVal(attribute1) {
    let arr = [];
    arr.push(attribute1)
    //['COMCAST BUSINESS SERVICES USER']
    return arr;
  }

  delete(value) {
    this.loader = true;
    let inputDelete = [];
    let request = {
      // "ACKNOWLEDGEMENT_REQ": value.acknowledgementReq,
      "APPLICATION_ID": '1',
      "CREATED_BY": value.createdBy,
      "MESSAGE_ID": value.messageId,
      "OPERATION": "REVOKE",
      "PUBLISHED": value.published,
    }
    inputDelete.push(request);

    this.announcementService.revokeAnnouncement(inputDelete).subscribe(response => {
      if (response != undefined) {
        this.deletedList = response;
        this.notifierService.showNotification(this.deletedList.message);
        this.fetchAdminAnnouncements();
      } else {
        this.loader = false;
      }
    }, error => {
      this.loader = false;
      console.log(error);
    })
  }

  removeSelectedRows() {
    let inputDelete = [];
    this.loader = true;
    for (let item of this.selection.selected) {
      let request = {
        "ACKNOWLEDGEMENT_REQ": item.acknowledgementReq,
        "APPLICATION_ID": '1',
        "CREATED_BY": item.createdBy,
        "MESSAGE_ID": item.messageId,
        // "MESSAGE_TEXT": item.messageText,
        // "MESSAGE_TYPE": item.messageType,
        "OPERATION": "REVOKE",
        "PUBLISHED": item.published,
      }

      inputDelete.push(request);
    }
    this.announcementService.revokeAnnouncement(inputDelete).subscribe(response => {
      if (response != undefined) {
        this.deletedList = response;
        this.commonWebService.openSnackBar(this.deletedList.message, this.deletedList.status);
        this.fetchAdminAnnouncements();
      } else {
        this.loader = false;
      }
    }, error => {
      this.loader = false;
      console.log(error);
    })
    this.selection.clear();
  }

  onCancelClick() {
    this.fetchAdminAnnouncements();
    this.showAddForm = false;
    // this.showTable = true;
  }

}
