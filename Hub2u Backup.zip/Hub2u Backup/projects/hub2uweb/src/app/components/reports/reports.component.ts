import { Component, OnInit } from '@angular/core';
import { ReportsService, ConstantData } from 'hub2ushared';
import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss'],
  providers: [
    DatePipe,
  ]
})
export class ReportsComponent implements OnInit {

  reportFields: any;
  reportForm = new FormGroup({});
  reportNames: any;
  reportId: any;
  userInfo: any;
  userRole: any;
  functionId: any;
  reportOutput: any;
  status: String = "";
  selectedTab = '';
  isLoading = false;
  searchReports: boolean = false;
  title: String = "";
  mainTabVisible: boolean = true;
  backIcon: boolean = false;
  displayDynamicForm: boolean = false;
  loader: boolean;
  reportLoader: any;
  reportsList: any;
  displayTable: any;
  displayList: any;
  dynamicReportList: any;
  showReportGroup: boolean;
  emittedList: any;
  showdynamicReportList: boolean;
  subtitle: any;
  reloadPage: any;
  setReportTitle: any;
  opt: string;
  userDBDetails: any;
  csvList: any;
  person_id: any;

  constructor(
    private reports: ReportsService,
    private constantData: ConstantData
  ) { }

  ngOnInit() {
    this.onInitialLoad();
    this.getDynamicReportsList();
  }

  async onInitialLoad() {
    this.initializeReportForm();
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.getPersonID()
    //this.userRole = this.constantData.roles[58];    // Cpe user
    //this.userInfo.NTID = 'ngumma901'
  }

  configureReportFields(event) {
    this.reportFields = event;
  }

  configureValues(event) {
    this.loader = event.isLoading;
    this.mainTabVisible = event.mainTabVisible;
    this.backIcon = event.backIcon;
    this.reportId = event.reportId;
    this.reportNames = event.reportNames;
    this.title = event.title;
    this.displayDynamicForm = event.displayDynamicForm;
    this.showdynamicReportList = false;
  }

  initializeReportForm() {
    this.reportForm = new FormGroup({
      orderNo: new FormControl('',),
      internalSalesOrderNo: new FormControl(''),
      status: new FormControl(''),
      startDate: new FormControl('', Validators.required,),
      endDate: new FormControl('', Validators.required,),
      description: new FormControl('')
    });
  }

  getPersonID() {
    let request = {
      // ReportId: 112,
      // ReportId: "7001",
      ReportId:this.constantData.userprofileData[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    }
    this.reports.onGetDynamicReport(request).subscribe(response => {
      if (response) {
        if (response.ROW != undefined) {
          this.person_id = response.ROW[0].PERSON_ID;
        }
      }
    })
  }

  getDynamicReportsList() {
    //this.onFetchReport();
    this.reportOutput = null;
    this.mainTabVisible = true;
    this.displayList = false;
    this.reportLoader = false;


    this.showReportGroup = true;

    // if(this.setReportTitle == "dynamic_reports" && this.opt == 'backIcon'){
    //   this.showdynamicReportList = false;
    //   this.opt = '';
    // }
    // else
    //   this.showdynamicReportList = true;

    if (this.reloadPage == true && this.setReportTitle != "dynamic_reports") {
      this.showdynamicReportList = true;
      //this.reloadPage = false;
    }
    else if (this.reloadPage == true) {
      this.showdynamicReportList = false;
      //this.reloadPage = false;
    }
    // else if(this.subtitle == "")
    //   this.showdynamicReportList = false;
    else
      this.showdynamicReportList = true;
  }
  getReports() {
    this.reportFields = null;
    this.showdynamicReportList = false;


    this.showReportGroup = false;
  }

  setSubTab(opt, title) {
    if (opt == 'backIcon') {
      this.opt = 'backIcon';
      this.backIcon = false;
      this.searchReports = false;
      this.selectedTab = '0';
      this.displayTable = false;
      this.reportsList = null;
      this.reportLoader = false;
      this.displayList = false;
      this.isLoading = true;
      //this.subtitle = "";
      this.setReportTitle = title;
      this.getDynamicReportsList();
    }
  }

  // // fetch reports details 
  // fetchReports(request) {
  //   setTimeout(() =>
  //     this.reports.getReportValues(request).subscribe(response => {
  //       this.reportOutput = response.ReportOutput;
  //       this.isLoading = false;
  //     }, error => {
  //       console.log(error);
  //     })
  //   );
  // }

  dateFormatter(date) {
    if (date === "" || date === undefined) {
      return "";
    }
    var tempDate = date;
    if (date.replace != undefined) {
      tempDate = new Date(date.replace(/-/g, '/').replace('T‌​', ' ').replace(/\..*|\+.*/, ""));
    }
    var month = ("0" + (tempDate.getMonth() + 1)).slice(-2);
    var day = ("0" + tempDate.getDate()).slice(-2);
    var displayDate = tempDate.getFullYear() + "-" + month + "-" + day;
    return displayDate;
  }

  changeDtFormat(dateObj) {
    let datePipe = new DatePipe('en-US');
    let date = new Date(dateObj).toISOString().substring(0, 10);
    return (datePipe.transform(date, 'MM/dd/yyyy'));
  }

  goBack() {
    window.history.back();
  }

  reportOutputEvent(event) {
    this.reportOutput = event;
  }

  loaderEvent(event) {
    this.reportLoader = event.isLoading;
    this.displayList = event.displayList;
  }

  emitLoader(event) {
    this.reportLoader = event.isLoading;
    this.displayTable = event.displayTable;
  }

  emitReportsGroupLoader(event) {
    this.isLoading = event.isLoading;
    this.reloadPage = event.reloadPage;
  }

  reportsListEvent(event) {
    this.reportsList = event;
  }

  userDBDetailsEvent(event) {
    this.userDBDetails = event;
  }

  dynamicReportNames(event) {
    this.dynamicReportList = event;
    this.showdynamicReportList = true;
  }

  setSubTitle(event) {
    this.subtitle = event;
  }

  sendCSVReport(event) {
    this.csvList = event;
  }

  tabChanged(event) {
    if (event.index == 1) {
      this.getReports();
    }
    if (event.index == 0) {
      this.getDynamicReportsList();
    }
  }

}
