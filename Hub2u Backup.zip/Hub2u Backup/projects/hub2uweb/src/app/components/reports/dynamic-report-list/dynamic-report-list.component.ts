import { animate, style, transition, trigger } from '@angular/animations';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ReportsService } from 'hub2ushared';
import { ConstantData } from 'projects/hub2ushared/src/public-api';

@Component({
  selector: 'app-dynamic-report-list',
  templateUrl: './dynamic-report-list.component.html',
  styleUrls: ['./dynamic-report-list.component.scss'],
  animations: [
    trigger(
      'enterAnimation', [
      transition(':enter', [
        style({ transform: 'translateY(100%)', opacity: 0 }),
        animate('500ms', style({ transform: 'translateY(0)', opacity: 1 }))
      ]),
      transition(':leave', [
        style({ transform: 'translateY(0)', opacity: 1 }),
        animate('500ms', style({ transform: 'translateY(100%)', opacity: 0 }))
      ])
    ]
    )
  ]
})
export class DynamicReportListComponent implements OnInit {
  selectedIndex: any;
  reportDropDown: any[];
  functionId: string;
  userInfo: any;
  userRole: string;
  reportingGroup: any;

  constructor(private reportService: ReportsService, private formBuilder: FormBuilder, private constantData: ConstantData) { }

  reportFields: any;
  isLoading: boolean;
  reportId: any;
  dynamicForm: FormGroup;
  displayDynamicForm: boolean;
  displayLoader: boolean;
  dropdownReportGroup: any = [];
  reportGroupdetails;
  loader;

  @Input() setReportTitle;
  @Input() title;

  @Output() configureValues: EventEmitter<any> = new EventEmitter();
  @Output() emitLoader: EventEmitter<any> = new EventEmitter();
  @Output() subTitle: EventEmitter<any> = new EventEmitter();
  @Output() dynamicReportNames: EventEmitter<any> = new EventEmitter();

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    // if(this.functionId == '99') {
      if(this.functionId == '143') {
      this.getReportingGroup()
    } else {
      this.getReportGroup();
    }
    this.isLoading = true
    this.emitLoader.emit({
      isLoading: true })
    // this.loader = true;
  }

  getReportingGroup() {
    let request1 = {
      // ReportId: 112,
      // ReportId: "7001",
      ReportId:this.constantData.userprofileData[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
       ]
    };
    this.reportService.onGetDynamicReport(request1).subscribe(response => {
      if (response.ROW !== undefined) {
        if(response.ROW[0]['REPORTING_GROUP']) {
          this.reportingGroup = response.ROW[0]['REPORTING_GROUP']
        } else {
          this.reportingGroup = ""
        }
      }
      this.getReportGroup();
    })
  }

  getReportGroup() {
    let temp;
    let deleteObject;
    let commaGroup;
    let request ;
    if(this.functionId == '61') {
      request = {
        "ReportId":  this.constantData.dynamicReports[this.functionId],
        "ParametersInput":[{"Name":"SYSTEM","Value":"HUB2U"}, {"Name":"USER_PROFILE","Value":"COMCAST ESA USER"}]}
    }
    // else if(this.functionId == '51') {
      else if(this.functionId == '136') {
      request = {
        "ReportId":  this.constantData.dynamicReports[this.functionId],
        "ParametersInput":[{"Name":"SYSTEM","Value":"HUB2U"}, {"Name":"USER_PROFILE","Value":"Comcast Business Services User iip"}]}
    }
    else if(this.functionId == '58') {
      request = {
        "ReportId":  this.constantData.dynamicReports[this.functionId],
        "ParametersInput":[{"Name":"SYSTEM","Value":"HUB2U"}, {"Name":"USER_PROFILE","Value":"Comcast CPE User"}]}
    }
    else if(this.functionId == '57') {
      request = {
        "ReportId":  this.constantData.dynamicReports[this.functionId],
        "ParametersInput":[{"Name":"SYSTEM","Value":"HUB2U"}, {"Name":"USER_PROFILE","Value":"Prepaid Dealer"}]}
    }
    else if(this.functionId == '50') {
      request = {
        "ReportId":  this.constantData.dynamicReports[this.functionId],
        "ParametersInput":[{"Name":"SYSTEM","Value":"HUB2U"}, {"Name":"USER_PROFILE","Value":"Comcast Store User"}]}
    }
    else if(this.functionId == '63') {
      request = {
        "ReportId":  this.constantData.dynamicReports[this.functionId],
        "ParametersInput":[{"Name":"SYSTEM","Value":"HUB2U"}, {"Name":"USER_PROFILE","Value":"Comcast NONCPE User"}]}
    }
    else if(this.functionId == '64') {
      request = {
        "ReportId":  this.constantData.dynamicReports[this.functionId],
        "ParametersInput":[{"Name":"SYSTEM","Value":"HUB2U"}, {"Name":"USER_PROFILE","Value":"XM Supply Chain"}]}
    }
    else if(this.functionId == '66') {
      request = {
        "ReportId":  this.constantData.dynamicReports[this.functionId],
        "ParametersInput":[{"Name":"SYSTEM","Value":"HUB2U"}, {"Name":"USER_PROFILE","Value":"Comcast 5G User"}]}
    }
    // else if(this.functionId == '99') {
      else if(this.functionId == '143') {
      request = {
        "ReportId": this.constantData.dynamicReports[this.functionId],
        "ParametersInput":[{"Name":"SYSTEM","Value":"HUB2U"}, {"Name":"USER_PROFILE", "Value":"COMCAST TECH USER IIP"}, {"Name":"REPORTING_GROUP","Value": this.reportingGroup}]
      }
    }
    else {
      request = {
        "ReportId": this.constantData.dynamicReports[this.functionId],
        "ParametersInput":[{"Name":"SYSTEM","Value":"HUB2U"}]
      }
    }
    this.reportService.onGetDynamicReport(request).subscribe(
      resp => {
        this.isLoading = false;
        this.emitLoader.emit({
          isLoading: this.isLoading,
          reloadPage: true});
        if (resp.STATUS == 'SUCCESS') {
          if (resp.ROW != undefined) {
            this.reportGroupdetails = resp.ROW;
            temp = resp.ROW
            this.reportGroupdetails.map(element => {
              if (element.REPORT_GROUP === null || element.REPORT_GROUP === '' || element.REPORT_GROUP === undefined) element.REPORT_GROUP = 'Others';
              return this.reportGroupdetails;
            });

            this.reportGroupdetails.map(element => {
              if (element.REPORT_GROUP.indexOf(',') > -1) {
                deleteObject = element.REPORT_GROUP
                commaGroup = element.REPORT_GROUP.split(',')
                commaGroup.forEach(e => {
                  var newReport = Object.create(element);
                  newReport.REPORT_GROUP = e
                  this.reportGroupdetails.push(newReport)
                });
                this.reportGroupdetails = this.reportGroupdetails.filter((item) => item.REPORT_GROUP !== deleteObject.toString())
              }
            });
            var output = Object.values(this.reportGroupdetails.reduce((obj, { REPORT_GROUP }) => {
              if (obj[REPORT_GROUP] === undefined)
                obj[REPORT_GROUP] = { REPORT_GROUP: REPORT_GROUP, occurrences: 1 };
              else
                obj[REPORT_GROUP].occurrences++;
              return obj;
            }, {}));
            this.dropdownReportGroup = output
           
          }

          if(this.setReportTitle) {
            let i = this.dropdownReportGroup.findIndex(i => i.REPORT_GROUP == this.setReportTitle);
            this.changeColor(i)
          }
          if (resp.ROW == undefined) {
      
          }
        }
      },
      error => {
      }
    );

  }

  changeColor(i) {
    this.selectedIndex = i;
  }

  getReports(reportName) {
    this.reportDropDown = [];
    this.title = reportName
    this.subTitle.emit(reportName);
    var reportGroup = reportName;
    if (reportGroup != null) {
      var reportsDetails = this.reportGroupdetails.filter(rep => rep.REPORT_GROUP == reportGroup);
      // this.getUserDetailsDB()
      this.reportDropDown = reportsDetails.map(({ RECORD_ID, REPROT_NAME, REPORT_TYPE, REPORT_FAV, REP_DESCRIPTION }) => ({ RECORD_ID, REPROT_NAME, REPORT_TYPE, REPORT_FAV, REP_DESCRIPTION }));
      // if (this.storedFav !== null && this.storedFav !== undefined) {
      //   this.reportDropDown.forEach(item => {
      //     this.storedFav.forEach(element => {
      //       if (item.RECORD_ID === element.id) {
      //         return (item.REPORT_FAV = true)
      //       }
      //     });
      //   });
      // }
      this.reportDropDown.forEach(element => {
        if (element.REPORT_FAV == undefined) {
          return element.REPORT_FAV = false
        }
      })
      this.reportDropDown.sort(function (a, b) { return b.REPORT_FAV - a.REPORT_FAV });
      this.dynamicReportNames.emit(this.reportDropDown);
    }
  }

  // onSelectingReport(reportId, reportName) {
  //   this.configureValues.emit({
  //     isLoading: true,
  //     reportId: reportId,
  //     reportNames: null,
  //     title: reportName,
  //     backIcon: true,
  //     displayDynamicForm: true,
  //     mainTabVisible: false,
  //   })
  // }
}
