import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ReportsComponent } from './reports.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatBadgeModule } from '@angular/material/badge';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTabsModule } from '@angular/material/tabs';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { DynamicReportComponent } from './dynamic-report/dynamic-report.component';
import { DynamicReportListComponent } from './dynamic-report-list/dynamic-report-list.component';
import { DynamicReportsTableComponent } from './dynamic-reports-table/dynamic-reports-table.component';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatSortModule} from '@angular/material/sort';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatTooltipModule} from '@angular/material/tooltip';
import { TableUtil } from '../../shared/tableUtils';
import { Hub2usharedModule } from 'hub2ushared';
import { OrderHistoryListModule } from '../order-history-list/order-history-list.module';
import { ReportNamesComponent } from './report-names/report-names.component';
import {DragDropModule} from '@angular/cdk/drag-drop';
import {ScrollingModule} from '@angular/cdk/scrolling';
import {CdkTableModule} from '@angular/cdk/table';
import {CdkTreeModule} from '@angular/cdk/tree';
import {A11yModule} from '@angular/cdk/a11y';
import {MatMenuModule} from '@angular/material/menu';
import { NgxSpinnerModule } from 'ngx-spinner';

const routes: Routes = [
  {
    path: '',
    component: ReportsComponent,data: {
      breadcrumb: 'REPORTS'},
  }
];

@NgModule({

  declarations: [ReportsComponent, ReportNamesComponent, OrderHistoryComponent, DynamicReportComponent, DynamicReportListComponent, DynamicReportsTableComponent],
  imports: [
    OrderHistoryListModule,
    CommonModule,
    Hub2usharedModule,
    NgxSpinnerModule,
    FormsModule,
    ReactiveFormsModule,
    MatMenuModule,
    DragDropModule,
    ScrollingModule,
    CdkTableModule,
    CdkTreeModule,
    A11yModule,
    MatTabsModule,
    MatTooltipModule,
    MatDividerModule,
    MatSnackBarModule,
    MatSortModule,
    MatProgressSpinnerModule,
    MatPaginatorModule,
    MatTableModule,
    MatToolbarModule,
    MatBadgeModule,
    MatButtonModule,
    MatSelectModule,
    MatCardModule,
    MatFormFieldModule,
    MatExpansionModule,
    MatInputModule,
    MatDatepickerModule,
    MatGridListModule,
    MatNativeDateModule,
    MatIconModule,
    MatTabsModule,
    RouterModule.forChild(routes)
  ],
  providers: [
    TableUtil
  ]
})
export class ReportsModule { }
