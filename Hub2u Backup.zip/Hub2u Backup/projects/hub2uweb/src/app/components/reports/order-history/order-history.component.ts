import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ReportsService } from 'hub2ushared';
import { CommonWebService } from '../../../shared/common-web.service';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.scss'],
  // providers: [
  //   DatePipe,
  // ]
})
export class OrderHistoryComponent implements OnInit {

  reportOutput: any;
  isLoading = false;
  searchReports: boolean = false;
  reportForm = new FormGroup({});
  displayError : boolean = false;
  errorMessage : boolean = false;
  disabled: boolean = false;
  currentDate = new Date()

  constructor(private reportService: ReportsService, private commonWebService: CommonWebService, public datepipe: DatePipe,) { }

  @Input() initializeReportForm: () => void;
  @Input() userInfo : any;
  @Output() reportOutputEvent = new EventEmitter();
  @Output() loaderEvent = new EventEmitter();
  
  ngOnInit() {
    this.initializeReportForm();
    this.setDefaultDate();
  }
  setDefaultDate() {
    this.reportForm.patchValue({
      //new Date(date.setMonth(date.getMonth()+8))
      startDate: new Date(this.currentDate.setMonth(this.currentDate.getMonth() - 3)),
      endDate: new Date()
    })
  }

  clear(field : string) {
    this.reportForm.get(field).reset();
  }

  // fetch reports details 
  fetchReports(request) {
    // setTimeout(() =>
    //   this.reportService.getReportValues(request).subscribe(response => {
    //     this.reportOutput = response.ReportOutput;
    //     this.reportOutputEvent.emit(this.reportOutput);
    //     this.isLoading = false;
    //     this.loaderEvent.emit({
    //       isLoading: this.isLoading,
    //       displayList: true});
    //     this.searchReports = true;
    //   }, error => {
    //     this.isLoading = false;
    //     this.loaderEvent.emit({ 
    //       isLoading: this.isLoading,
    //       displayList: false});
    //       this.commonWebService.openSnackBar(error.error.status,"ERROR");
    //   })
    // );
  }

  submitForm() {
    this.isLoading = true;
    this.loaderEvent.emit({
      isLoading: this.isLoading,
      displayList: false});
      let request = {
        END_DATE: (this.reportForm.value.endDate) == "" ? "" : this.datepipe.transform(this.reportForm.value.endDate , 'MM/dd/yyyy'),
        ISO_ORDER_NUMBER: this.reportForm.value.internalSalesOrderNo,
        REQUISITION_NUMBER: this.reportForm.value.orderNo,
        REQ_HEADER_DESCRIPTION: this.reportForm.value.description,
        START_DATE: (this.reportForm.value.startDate) == "" ? "" : this.datepipe.transform(this.reportForm.value.startDate , 'MM/dd/yyyy'),
        STATUS: this.reportForm.value.status,
        requestor: this.userInfo.NTID
      }
    // this.fetchReports(request);
  }

  changeDtFormat(dateObj) {
    let datePipe = new DatePipe('en-US');
    let date = new Date(dateObj).toISOString().substring(0, 10);
    return (datePipe.transform(date, 'MM/dd/yyyy'));
  }

}
