import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ReportsService } from 'hub2ushared';
import { DatePipe } from '@angular/common';
import { StorePreferenceDbService } from 'projects/hub2ushared/src/lib/services/store-preference-db.service';
import { CommonWebService } from '../../../shared/common-web.service';
import { StorePreferenceService } from '../../../shared/store-preference.service';
import { ConstantData } from 'projects/hub2ushared/src/public-api';
import { Overlay, BlockScrollStrategy } from '@angular/cdk/overlay';
import { MAT_SELECT_SCROLL_STRATEGY } from '@angular/material/select';
import { MAT_DATEPICKER_SCROLL_STRATEGY } from '@angular/material/datepicker';
export function scrollFactory(overlay: Overlay): () => BlockScrollStrategy {
  return () => overlay.scrollStrategies.block();
}

@Component({
  selector: 'app-dynamic-report',
  templateUrl: './dynamic-report.component.html',
  styleUrls: ['./dynamic-report.component.scss'],
  providers: [
    { provide: MAT_DATEPICKER_SCROLL_STRATEGY, useFactory: scrollFactory, deps: [Overlay] },
    { provide: MAT_SELECT_SCROLL_STRATEGY, useFactory: scrollFactory, deps: [Overlay] }
  ]
})
export class DynamicReportComponent implements OnInit {

  dynamicForm = new FormGroup({});
  reportsList: any;
  reportFields: any;
  showResult: boolean = false;
  isLoading: boolean;
  disableGenerateBtn: boolean;
  userDBDetails: any;
  functionId: string;
  exportQuery: any;

  constructor(private formBuilder: FormBuilder, public datepipe: DatePipe, private storePreferenceDbService: StorePreferenceDbService, private constantData : ConstantData, private storePreferenceService : StorePreferenceService,  private reportService: ReportsService, private commonWebService: CommonWebService) { }

  @Input() dateFormatter: (args: any) => void;
  @Input() userInfo: any;
  @Input() mainTabVisible: any;
  @Input() reportId: any;
  @Input() loader: boolean;
  @Input() person_id: any;

  @Output() emitLoader: EventEmitter<any> = new EventEmitter();
  @Output() reportsListEvent: EventEmitter<any> = new EventEmitter();
  @Output() userDBDetailsEvent: EventEmitter<any> = new EventEmitter();
  @Output() sendCSVReport: EventEmitter<any> = new EventEmitter();

  ngOnInit() {
    this.loadinitialData();
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
  }
  
  loadinitialData() {
    let request;
    if (this.reportId == '3' || this.reportId == '110' || this.reportId == '111') {
      request = {
        ReportId: this.reportId
      }
    }
    else {
      request = {
        "ReportId": this.reportId,
        "ParametersInput": [
          {
            "Name": "REQUESTOR_NAME",
            "Value": this.userInfo.NTID
          }
        ]
      }
    }
    this.getReportFields(request);
  }
  getReportFields(request) {
    this.reportService.getReportDisplayFields(request).subscribe(response => {
      this.reportFields = response.ReportDisplayFieldsOutput;
      this.dynamicForm = this.createDynamicForm(); 
      if(this.dynamicForm.controls['REQUESTOR_NAME']) {
        this.dynamicForm.controls['REQUESTOR_NAME'].setValue(this.userInfo.NTID)  
      }    
      this.loader = false;
    }, error => {
      this.loader = false;
      this.disableGenerateBtn = true;
      this.commonWebService.openSnackBar(error.error.status,"ERROR");
    });
  }

  createDynamicForm() {
    let dynamicForm = this.formBuilder.group({});
    this.reportFields.forEach(control => {
      dynamicForm.addControl(control.name, this.formBuilder.control('')); 
      if(control.name == 'REQUESTOR_NAME'){
        dynamicForm.controls['REQUESTOR_NAME'].setValue(this.userInfo.NTID)    
        control.value =  this.userInfo.NTID;
      }
    }); 
    return dynamicForm;
  }

  submitDynamicForm() { 
    this.isLoading = true;
    this.emitLoader.emit({
      isLoading: this.isLoading,
      displayTable: false})
    let request = {
      "ReportId": this.reportId,
      "ParametersInput": []
    }
    var formData = this.dynamicForm.value;
    for (var key in formData) {
      if (formData.hasOwnProperty(key)) {
        if (key == "REQUESTOR_NAME") {
          request.ParametersInput.push({
            "Name": key,
            "Value": this.userInfo.NTID
          })
        }
        else {
          if (key == "P_FROM_DATE" || key == "P_TO_DATE" || key == "FROM_DATE" || key == "TO_DATE" || key == "ORDER_DATE_FROM" || key == "ORDER_DATE_TO") {
            formData[key] = this.datepipe.transform(formData[key] , 'yyyy-MM-dd')
          } else if (this.reportId == '50020' && this.functionId == '57' && key == 'REQUESTOR_NTID') {
            formData[key] = this.person_id
          }
          request.ParametersInput.push({
            "Name": key,
            "Value": formData[key] == "" || formData[key] == null ? "" : formData[key].toString()
          })
        }
      }
    }
    this.fetchDynamicReport(request);
  }

  fetchDynamicReportForExporting(request) {
    this.reportService.onGetDynamicReport(request).subscribe(response => {
      this.sendCSVReport.emit(response.ROW);
    })
  }

  fetchDynamicReport(request) {
    this.reportService.onGetDynamicReport(request).subscribe(response => {
      this.reportsList = response.ROW;
      if(this.reportsList && this.reportsList.length > 0) {
        this.exportQuery = this.reportsList[0]['EXPORT_QUERY'];
        request["ReportId"] = this.exportQuery;
        this.sendCSVReport.emit(request);
      }

      this.isLoading = false;
      this.emitLoader.emit({
        isLoading: this.isLoading,
        displayTable: true})
        
      this.reportsListEvent.emit(this.reportsList);
      this.showResult = true;
    }, error => {
      this.isLoading = false;
      this.emitLoader.emit({
        isLoading: this.isLoading,
        displayTable: false})
        this.commonWebService.openSnackBar("Sorry! Something went wrong. ","ERROR");
    })
  }

  getPreferenceFromDB() {
    var inputData = {
          "applicationName": "HUB2U",
          "userName": this.userInfo.NTID
        }
    let promise = this.storePreferenceDbService.getPreferencefromDB(inputData).toPromise();
    promise.then((data) => {
      this.userDBDetails = data[0]
      this.userDBDetailsEvent.emit(this.userDBDetails);
      this.isLoading = false;
      this.emitLoader.emit({
        isLoading: this.isLoading,
        displayTable: true})
    }).catch((error) => {
      this.isLoading = false;
      this.emitLoader.emit({
        isLoading: this.isLoading,
        displayTable: false})
    });
  }
}
