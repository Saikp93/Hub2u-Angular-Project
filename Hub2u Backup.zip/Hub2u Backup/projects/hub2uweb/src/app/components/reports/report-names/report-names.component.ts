import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-report-names',
  templateUrl: './report-names.component.html',
  styleUrls: ['./report-names.component.scss'],
})
export class ReportNamesComponent implements OnInit {

  displayDynamicForm: boolean;
  @Input() dynamicReportList;
  @Input() userInfo: any;
  @Input() mainTabVisible: any;
  @Input() reportNames;
  @Input() backIcon;
  @Input() title;
  @Output() configureValues: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit() {}

  onSelectingReport(reportId, reportName) {
    //this.dynamicReportList = null;
    this.configureValues.emit({
      isLoading: true,
      reportId: reportId,
      reportNames: null,
      title: reportName,
      backIcon: true,
      displayDynamicForm: true,
      mainTabVisible: false,
    })
  }

}
