import { AfterViewInit, OnChanges, Component, Input, OnInit, ViewChild } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { CdkDragDrop, CdkDragStart, CdkDropList, moveItemInArray } from '@angular/cdk/drag-drop';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { FormControl, FormGroup } from '@angular/forms';
import { TableUtil } from '../../../shared/tableUtils';
import { AbstractControl, FormBuilder } from '@angular/forms';
import { StorePreferenceService } from '../../../shared/store-preference.service';
import { EventService } from '../../../shared/event.service';
import { StorePreferenceDbService } from 'projects/hub2ushared/src/lib/services/store-preference-db.service';
import { I } from '@angular/cdk/keycodes';
import { ReportsService, ConstantData } from 'hub2ushared';
import { CommonWebService } from '../../../shared/common-web.service';
import { Overlay, BlockScrollStrategy } from '@angular/cdk/overlay';
import { MAT_SELECT_SCROLL_STRATEGY } from '@angular/material/select';
import { MatExpansionPanel } from '@angular/material/expansion';
export function scrollFactory(overlay: Overlay): () => BlockScrollStrategy {
  return () => overlay.scrollStrategies.block();
}

const getFileName = (name: string) => {
  let timeSpan = new Date().toISOString();
  let sheetName = name || "ExportResult";
  let fileName = `${sheetName}-${timeSpan}`;
  return {
    sheetName,
    fileName
  };
};


@Component({
  selector: 'app-dynamic-reports-table',
  templateUrl: './dynamic-reports-table.component.html',
  styleUrls: ['./dynamic-reports-table.component.scss'],
  providers: [
    { provide: MAT_SELECT_SCROLL_STRATEGY, useFactory: scrollFactory, deps: [Overlay] }
  ],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
    trigger('detailExpand1', [
      state('collapsed1', style({ height: '0px', minHeight: '0' })),
      state('expanded1', style({ height: '*' })),
      transition('expanded1 <=> collapsed1', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class DynamicReportsTableComponent implements OnInit, AfterViewInit {

  @Input() reportsList: any;
  @Input() subtitle: any;
  @Input() reportId: any;
  @Input() csvList: any;
  @Input() userDBDetails: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild("disabledPanel") disabledPanel

  dataSource: MatTableDataSource<any>;
  displayedColumns: string[] = [];
  headers: string[] = [];
  expandedElement: any;
  expandedSerialElement: any;
  tableData = [];
  pageName = "Hub2u_Report"
  reportType = "dynamicreports"
  filterValues = {};
  previousIndex: number;
  columns: string[];
  columnDef: string[];
  dbColumns: any;
  userInfo: any;
  functionId: string;
  lineDetails = [];
  expandLine: any[] = [];
  expandSerial: any[] = [];
  loader: boolean;
  lineDetailsReportId: any;
  serialDetails = [];
  csvLoader: boolean;
  serialDetailsWithinLine: any[] = [];
  serialLoader: boolean;
  expandSerialWithinLine: any[] = [];
  request: any = null;
  request1: any = null;
  pageIndex = 0;

  constructor(private tableUtil: TableUtil, private eventService: EventService, private storePreferenceDbService: StorePreferenceDbService,
    private storePreferenceService: StorePreferenceService, private reportsService: ReportsService, private commonWebService: CommonWebService,
    private constantData: ConstantData,) {
  }

  ngAfterViewInit() {
    this.call();
  }

  call() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.dataSource.filterPredicate = this.createFilter();
  }

  sortData(event) {
    for (let i = 0; i < this.tableData.length; i++) {   // for closing all the expanded rows
      this.expandLine[i] = false;
      this.expandSerial[i] = false;
    }
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.setUserDBColumns();
    this.getColumns();
  }

  getColumns() {
    this.reportsList.forEach(data => {
      const eachData = {};
      let lines = []
      for (const key in data) {
        if (`${key}`.startsWith('@'))
          break;
        eachData[key] = data[key];
        if (this.reportsList.indexOf(data) == 0) {
          this.displayedColumns.push(`${key}`);
        };
        // if(`${key}` == "LINE_DETAILS") {
        //   let fields = data[key].split(';');
        //   //console.log(fields);
        //   fields.forEach(data => {
        //     let lineDetails = []
        //     let arr = data.split("~");
        //     arr.forEach(item => {
        //       let field = item.split(":")[0];
        //       let value = item.split(":")[1];
        //       lineDetails.push({
        //        "key": field,
        //        "value": value
        //       })
        //     })
        //     lines.push(lineDetails)
        //   })
        // }
      }

      eachData['lines'] = lines
      // console.log(eachData)
      this.tableData.push(eachData);
    });
    this.dataSource = new MatTableDataSource<any>(this.tableData);
    this.expandedElement = this.tableData;
    this.expandedSerialElement = this.tableData;
    // if(this.displayedColumns.includes('LINE_DETAILS')) {
    //   let index = this.displayedColumns.findIndex(element => element == "LINE_DETAILS");
    //   this.displayedColumns.splice(index, 1);
    //   this.displayedColumns.splice(0, 0, 'LINE_DETAILS');
    //   this.headers.splice(0, 0, '');
    // }

    if (this.displayedColumns.includes('DRILL_DOWN')) {
      let index = this.displayedColumns.findIndex(element => element == "DRILL_DOWN");
      this.displayedColumns.splice(index, 1);
      this.displayedColumns.splice(0, 0, 'LINE_DETAILS');
      this.headers.splice(0, 0, '');
    }
    if (this.displayedColumns.includes('SERAIL_DETAILS')) {
      let index = this.displayedColumns.findIndex(element => element == "SERAIL_DETAILS");
      this.displayedColumns.splice(index, 1);
      this.displayedColumns.splice(1, 0, 'SERIAL_DETAILS');
      this.headers.splice(1, 0, '');
    }
    if (this.displayedColumns.includes('EXPORT_QUERY')) {
      let index = this.displayedColumns.findIndex(element => element == "EXPORT_QUERY");
      this.displayedColumns.splice(index, 1);
      this.headers.splice(index, 1);
    }

    this.columns = this.displayedColumns;
    this.columnDef = this.displayedColumns;
    if (this.dbColumns && this.dbColumns.length > 0) {
      this.displayedColumns = this.dbColumns;
      this.columns = this.dbColumns;
    }
  }

  fetchLineDetails(index, data) {
    if (this.request) {
      this.request.unsubscribe();
    }
    this.expandLine[index] = !this.expandLine[index];
    for (let i = 0; i < this.tableData.length; i++) {
      this.expandSerial[i] = false;
      if (i !== index)
        this.expandLine[i] = false;
    }
    for (let i = 0; i < this.lineDetails.length; i++) {
      this.expandSerialWithinLine[i] = false;
    }
    if (this.expandLine[index] == true) {
      this.lineDetails = [];
      this.loader = true;
      let request = {
        "ReportId": data['DRILL_DOWN'],
        "ParametersInput": []
      };
      if (this.functionId != '64') {
        request.ParametersInput.push(
          { "Name": "ORDER_NUMBER", "Value": data['ORDER_NUMBER'] ? data['ORDER_NUMBER'].toString() : '' }
        )
      } else {
        request.ParametersInput.push(
          { "Name": "3PL_ORDER_NUMBER", "Value": data['3PL_ORDER_NUMBER'] ? data['3PL_ORDER_NUMBER'].toString() : '' }
        )
      }
      if(this.functionId == '58' || this.functionId == '63') {
        request.ParametersInput.push(
        { "Name": "P_REQ_NUMBER", "Value": data['REQUISITION_NUMBER'] ? data['REQUISITION_NUMBER'].toString() : ''  } )
      }
      this.request = this.reportsService.onGetDynamicReport(request).subscribe(response => {
        this.lineDetails = [];
        this.loader = false;
        if (response && response.ROW) {
          let lines = response.ROW
          lines.forEach(line => {
            let map = new Map();
            if (line['DISPLAY_COLUMNS']) {
              let displayCols = [];
              displayCols = line['DISPLAY_COLUMNS'].split(",")
              displayCols.forEach(col => {
                map.set(col, line[col])
              })
              map.set('LINE_ID', line['LINE_ID'])
              //map.set('DRILL_DOWN', line['DRILL_DOWN'])
              this.lineDetails.push(map)
            } else {
              let map = new Map();
              let labels = Object.keys(line)
              labels.forEach(label => {
                map.set(label, line[label])
              })
              this.lineDetails.push(map)
            }
          })
        }
        this.request = null;
      }, error => {
        this.request = null;
        this.loader = false;
        //this.commonWebService.openSnackBar("Sorry! There was some problem loading the records","ERROR");
      })
    }
  }

  expandSerialDetailsWithinLine(orderNo, field, index) {
    if (this.request1) {
      this.request1.unsubscribe();
    }
    this.expandSerialWithinLine[index] = !this.expandSerialWithinLine[index];
    for (let i = 0; i < this.lineDetails.length; i++) {
      if (i !== index)
        this.expandSerialWithinLine[i] = false;
    }
    if (!this.expandSerialWithinLine[index]) {
      return;
    }
    this.serialLoader = true;
    let lineId = field.get('LINE_ID')
    let reportId = field.get('DRILL_DOWN')
    let request = {
      "ReportId": reportId,
      "ParametersInput":
        [
          { "Name": "ORDER_NUMBER", "Value": orderNo },
          { "Name": "LINE_ID", "Value": lineId },
        ]
    };
    this.request1 = this.reportsService.onGetDynamicReport(request).subscribe(response => {
      this.serialLoader = false;
      this.serialDetailsWithinLine = []
      if (response.ROW) {
        let lines = response.ROW
        lines.forEach(line => {
          let map = new Map();
          let labels = Object.keys(line)
          labels.forEach(label => {
            map.set(label, line[label])
          })
          this.serialDetailsWithinLine.push(map)
        })
      }
      this.request1 = null;
    }, error => {
      this.loader = false;
      this.request1 = null;
    })
  }

  onPaginateChange(event) {
    if (this.pageIndex !== event.pageIndex) {
      for (let i = 0; i < this.tableData.length; i++) {
        this.expandLine[i] = false;
      }
      for (let i = 0; i < this.lineDetails.length; i++) {
        this.expandSerialWithinLine[i] = false;
      }
      this.pageIndex = event.pageIndex;
    }
  }

  fetchSerialDetails(index, data) {
    this.expandSerial[index] = !this.expandSerial[index];
    for (let i = 0; i < this.tableData.length; i++) {
      this.expandLine[i] = false;
      if (i !== index)
        this.expandSerial[i] = false;
    }
    if (this.expandSerial[index] == true) {
      this.lineDetails = [];
      this.loader = true;
      let request = {
        "ReportId": data['SERAIL_DETAILS'],
        "ParametersInput":
          [{ "Name": "P_ORDER_NUMBER", "Value": data['ORDER_NUMBER'] }]
      };
      this.reportsService.onGetDynamicReport(request).subscribe(response => {
        this.serialDetails = []
        this.loader = false;
        if (response.ROW) {
          let lines = response.ROW
          lines.forEach(line => {
            let map = new Map();
            let labels = Object.keys(line)
            labels.forEach(label => {
              map.set(label, line[label])
            })
            this.serialDetails.push(map)
          })
        }
      }, error => {
        this.loader = false;
        //this.commonWebService.openSnackBar("Sorry! There was some problem loading the records","ERROR");
      })
    }
  }

  asIsOrder(a, b) {
    return 1;
  }

  setUserDBColumns() {
    let subtitle = this.subtitle.toLowerCase().replace(/ /g, "-");
    let checkCol = this.storePreferenceService.getCol(this.userDBDetails, this.reportType, subtitle, this.reportId);
    if (checkCol.length > 0) {
      this.dbColumns = checkCol;
    }
  }

  tableDrop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.displayedColumns, event.previousIndex, event.currentIndex);
    this.dataSource = new MatTableDataSource<any>(this.tableData);
    this.call();
  }

  getValue(column, event) {
    for (let i = 0; i < this.tableData.length; i++) {   // for closing all the expanded rows
      this.expandLine[i] = false;
      this.expandSerial[i] = false;
    }
    this.filterValues[column] = event.target.value;
    this.dataSource.filter = JSON.stringify(this.filterValues);
  }

  createFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data, filter): boolean {

      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      // for (const col in searchTerms) {
      //   if (searchTerms[col].toString() !== '') {
      //     isFilterSet = true;
      //   } else {
      //     delete searchTerms[col];
      //   }
      // }

      for (const [key, value] of Object.entries(searchTerms)) {
        if (`${value}` !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[`${key}`];
        }
      }

      let len = Object.keys(searchTerms).length;
      let searchArray = [];

      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            let valueFlag;
            let word = searchTerms[col].trim().toLowerCase()
            // searchTerms[col].trim().toLowerCase().split(' ').forEach(word => {
            if (data[col] !== null) {
              if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                searchArray.push(true);
                found = len === searchArray.length;
              }
            }
            //})
          }
          return found;
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction;
  }

  setupFilter(column: string) {
    this.dataSource.filterPredicate = (d, filter: string) => {
      const textToSearch = (typeof (d[column])) == 'number' ? d[column].toString() : d[column] && d[column].toLowerCase() || '';
      return textToSearch.indexOf(filter) !== -1;
    };
  }

  applyFilter(filterValue) {
    this.dataSource.filter = filterValue.target.value.trim().toLowerCase();
  }

  fetchDynamicReportForExporting(request) {
    if (!request['ReportId']) {
      this.tableUtil.exportTableToCsv(this.tableData, this.pageName);
      this.csvLoader = false;
    } else {
      let excel;
      this.reportsService.onGetDynamicReport(request).subscribe(response => {
        if (response) {
          if (response.ROW != undefined) {
            this.csvLoader = false;
            excel = response.ROW;
            excel.forEach(data => {
              delete data['@num'];
            })
            this.tableUtil.exportTableToCsv(excel, this.pageName);
          }
          else {
            this.csvLoader = false;
            this.commonWebService.openSnackBar("Sorry! There was some problem exporting the records", "ERROR");
            //this.tableUtil.exportTableToCsv( this.tableData , this.pageName); 
          }
        }
        else {
          this.csvLoader = false;
          this.commonWebService.openSnackBar("Sorry! There was some problem exporting the records", "ERROR");
          //this.tableUtil.exportTableToCsv( this.tableData , this.pageName);
        }
      }, error => {
        this.csvLoader = false;
        this.commonWebService.openSnackBar("Sorry! There was some problem exporting the records", "ERROR");
        //this.tableUtil.exportTableToCsv( this.tableData , this.pageName); 
      })
    }
  }

  exportToCsv() {
    this.csvLoader = true;
    this.fetchDynamicReportForExporting(this.csvList)
  }

  selectedValue(event) {
    this.displayedColumns = event.value;
  }

  storePreference() {
    let subtitle = this.subtitle.toLowerCase().replace(/ /g, "-");
    this.eventService.showSpinner();
    this.storePreferenceService.storePreference(this.userDBDetails, this.reportType, subtitle, this.reportId, this.displayedColumns)
    setTimeout(() => {
      this.eventService.hideSpinner();
    }, 4000);

  }

  clearPreference() {
    let subtitle = this.subtitle.toLowerCase().replace(/ /g, "-");
    this.eventService.showSpinner();
    this.storePreferenceService.clearPreference(this.userDBDetails, this.reportType, subtitle, this.reportId, this.displayedColumns)
    setTimeout(() => {
      this.eventService.hideSpinner();
    }, 4000);
    this.columns = this.columnDef;
    this.displayedColumns = this.columnDef;
  }
}