import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-orderfileupload',
  templateUrl: './orderfileupload.component.html',
  styleUrls: ['./orderfileupload.component.scss'],
})
export class OrderfileuploadComponent {

  @Input() mode
  @Input() names
  @Input() url
  @Input() method
  @Input() multiple
  @Input() disabled
  @Input() accept;
  @Input() maxFileSize
  @Input() auto = true
  @Input() withCredentials
  @Input() invalidFileSizeMessageSummary
  @Input() invalidFileSizeMessageDetail
  @Input() invalidFileTypeMessageSummary
  @Input() invalidFileTypeMessageDetail
  @Input() previewWidth
  @Input() chooseLabel = 'Choose'
  @Input() uploadLabel = 'Upload'
  @Input() cancelLabel = 'Cance'
  @Input() customUpload
  @Input() showUploadButton
  @Input() showCancelButton
  @Input() dataUriPrefix
  @Input() deleteButtonLabel
  @Input() deleteButtonIcon = 'close'
  @Input() showUploadInfo;
  @Output() getUploadedFiles = new EventEmitter<any>();
  @Output() submitFileEvent = new EventEmitter<any>();
  @Output() cancelFileEvent = new EventEmitter<any>();
  @ViewChild('fileUpload')
  fileUpload: ElementRef
  @ViewChild('el') el: ElementRef
  inputFileName: string
  fileTypeCsvCheck: boolean;
  @Input()
  files: File[] = [];
  disableUploadBtn : boolean = true;
  constructor(private sanitizer: DomSanitizer) {

  }

  onClick(event) {
    if (this.fileUpload)
      this.fileUpload.nativeElement.click()
  }

  onInput(event) {

  }

  onFileSelected(event) {
    let files = event.dataTransfer ? event.dataTransfer.files : event.target.files;

    for (let i = 0; i < files.length; i++) {
      let file = files[i];
      if (this.validateExtention(file.name)) {
        file.objectURL = this.sanitizer.bypassSecurityTrustUrl((window.URL.createObjectURL(files[i])));

        if (!this.isMultiple()) {
          this.files = []
        }
        this.files.push(files[i]);
      }
    }
    if(this.files.length > 0) {
      this.fileTypeCsvCheck = false;
      this.disableUploadBtn = false;
    }
    else{
      this.fileTypeCsvCheck = true;
      this.disableUploadBtn = true;
    }
    this.getUploadedFiles.emit(this.files);
  }

  removeFile(event, file) {
    let ix
    if (this.files && -1 !== (ix = this.files.indexOf(file))) {
      this.files.splice(ix, 1);
      this.disableUploadBtn = true;
      this.clearInputElement();
    }
  }

  validate(file: File) {
    if (this.validateExtention(file.name)) {
      return false;
    }
    return true
  }
  submitFile() {
   this.submitFileEvent.emit();
   this.files.splice(0,1); 
   this.clearInputElement() 
  }
  cancelFile() {
    this.cancelFileEvent.emit()
    this.files.splice(0,1);
    this.clearInputElement()
  }
  validateExtention(fileName) {
    let allowExtention;
    if (this.accept == ".csv") {
      allowExtention = /(\.csv)$/i;
    }
    if (this.accept == ".txt") {
      allowExtention = /(\.txt)$/i;
    }
    if (!allowExtention.exec(fileName)) {
      this.fileTypeCsvCheck = false;
    } else {
      this.fileTypeCsvCheck = true;
    } 
    return this.fileTypeCsvCheck;
  }

  clearInputElement() {    
    this.fileUpload.nativeElement.value = ''
  }


  isMultiple(): boolean {
    return this.multiple
  }

}
