import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ProductService, ReportsService, GetimageService } from 'hub2ushared';

@Component({
  selector: 'app-source',
  templateUrl: './source.component.html',
  styleUrls: ['./source.component.scss'],
})
export class SourceComponent implements OnInit {
  @Input() seletedItem: any;
  @Input() userInfo: any;
  @Input() cartLoader: boolean = false;
  @Input() sourceOrg: any;
  @Input() subInv: any;
  @Output() addToCart = new EventEmitter<any>();

  DataItemSource: any[] = [];
  loaderAddToCart: any[] = [];
  sourceLoader: boolean = false;
  findIndex: number = 0;
  functionId: string;

  constructor(private reportsService: ReportsService, private productsService: ProductService, private GetimageService: GetimageService
  ) { }

  ngOnInit() {
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.onGetSource();
  }

  ngOnChanges() {
    if (!this.cartLoader) {
      this.loaderAddToCart[this.findIndex] = false;
    }
  }

  onGetSource() {
    let skuNumber = [];
    if (this.functionId == '60' || this.functionId == '58') {
      skuNumber.push(this.seletedItem['CIFA#'].replace(/^0+/, ''))
    }
    else {
      skuNumber.push(this.seletedItem['CIFA_ITEM_NUMBER'].replace(/^0+/, ''))
    }
    let object = {
      bucketId: "",
      lastArchived: true,
      locatorId: "",
      siteId: this.seletedItem['SITE_ID'],
      siteType: "",
      skuNumber: skuNumber,
      skuType: "",
      source: this.seletedItem['DESTINATION_SYSTEM']
    }

    // let object = {
    //   ReportId: 1081,
    //   ParametersInput: [
    //     {
    //       Name: "ITEM_NUMBER",
    //       Value: this.seletedItem['CIFA_ITEM_NUMBER']
    //     },
    //     {
    //       Name: "USERNAME",
    //       Value: this.userInfo.NTID
    //     }
    //   ]
    // };
    // this.sourceLoader = true;
    // this.reportsService.onGetDynamicReport(object).subscribe(response => {
    //   this.sourceLoader = false;
    //   this.DataItemSource = response['ROW'] || [];
    // }, error => {
    //   this.sourceLoader = false;
    // });

    this.sourceLoader = true;
    this.productsService.details(object).subscribe(response => {
      this.sourceLoader = false;
      this.DataItemSource = response['details'] || [];
    }, error => {
      this.sourceLoader = false;
    });

  }

  onAddToCart(item, index) {
    let object = Object.assign({}, this.seletedItem);
    object['ORGANIZATION_CODE'] = item['ORGANIZATION_CODE'];
    // object['SOURCE_SUBINVENTORY'] = (this.sourceOrg == (item['ORGANIZATION_CODE'] || item['SOURCE_ORGANIZATION_CODE'])) && this.functionId == '99' ? (this.subInv !== "" ? this.subInv : item['SOURCE_SUBINVENTORY']) : item['SOURCE_SUBINVENTORY'];
    object['SOURCE_SUBINVENTORY'] = (this.sourceOrg == (item['ORGANIZATION_CODE'] || item['SOURCE_ORGANIZATION_CODE'])) && this.functionId == '143' ? (this.subInv !== "" ? this.subInv : item['SOURCE_SUBINVENTORY']) : item['SOURCE_SUBINVENTORY'];
    this.loaderAddToCart[index] = true;
    this.findIndex = index;
    this.addToCart.emit(object);
  }
  getImage(cifaItem) {
    let image = cifaItem ? this.GetimageService.getImagefromcifa(cifaItem) : 'assets/images/no-image.jpg'
    //console.log("image SourceComponent ", image)
    return image
  }

}
