import { DatePipe, ViewportScroller } from '@angular/common';
import { ChangeDetectorRef, Component, EventEmitter, Inject, OnInit, Output, TemplateRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router, Scroll } from '@angular/router';
import { ProductService, ReportsService, CommonService, ConstantData, RequestObject, FilterpipePipe, GetimageService, SearchPipe } from 'hub2ushared';
import { CommonSettingService } from '../../../shared/common-settings.service';
import { StorePreferenceDbService } from 'projects/hub2ushared/src/lib/services/store-preference-db.service';
import { filter } from 'rxjs/operators';
import { CommonWebService } from '../../../shared/common-web.service';
import { EventService } from '../../../shared/event.service';
import { Overlay, BlockScrollStrategy } from '@angular/cdk/overlay';
import { MAT_SELECT_SCROLL_STRATEGY } from '@angular/material/select';
import { Subject } from 'rxjs/internal/Subject';
import { switchMap } from 'rxjs/operators';
import { FormBuilder, FormGroup } from '@angular/forms';
import { StorePreferenceService } from '../../../shared/store-preference.service';
import { MatDialog } from '@angular/material/dialog';
import { SelectSourceComponent } from '../../select-source/select-source.component';
export function scrollFactory(overlay: Overlay): () => BlockScrollStrategy {
  return () => overlay.scrollStrategies.block();
}

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [FilterpipePipe, SearchPipe,
    { provide: MAT_SELECT_SCROLL_STRATEGY, useFactory: scrollFactory, deps: [Overlay] }
  ]
})
export class ProductsComponent implements OnInit {
  userInfo: any = {};
  userRole = '';
  catalogList: any[] = [];
  catalogListOriginal: any[] = [];
  dataToSearch: any[] = [];
  loaderAddToCart: any[] = [];
  loaderFavorite: any[] = [];
  tagsList: any[] = [];
  cartItems: any[] = [];
  storeBusinessObj: any;
  sortByFilter = [];
  title: string = '';
  description: string = '';
  logoImg: any;
  singleProductTitle: string = '';
  isFilterTab: boolean = true;
  loader: boolean = false;
  singleProductView: boolean = false;
  selectSource: boolean = false;
  favLoader: boolean = false;
  cartLoader: boolean = false;
  isFavorite: boolean = false;
  isDataLoaded = false;
  seletedItem: any = {};
  searchOptions: any = {
    view: '',
    search: '',
    sortBy: '',
    pageSize: ''
  };
  muteText = true;
  changeSize: boolean = false;
  size: number = 1;
  itemType: any;
  deliverToSite: any;
  deliverToSiteId: any;
  siteAdress: any;
  retainUsrData: any;
  functionId: string;
  subtitle: string;
  typeArr = []
  region: any;
  imageURL = this.env.baseIMGUrlJAVA;
  headerCartLoader: boolean;
  searchValue: any;
  ItemPerPage = 15;
  pageSizes = [5, 10, 15, 20];
  pagedItems = [];
  pageNumber = 1;
  refreshData: boolean = false;
  storeQuantity = [];
  previousUrl = ""
  userDBDetails: any;
  catalogListWithTags: any = [];
  attribute6: any;
  attr6: any;
  needbyDate: any;
  callCount: any;
  multiCall: any;
  totalCount: any;
  list: any;
  replacedCatalogList: any;
  lookupCode: any;
  countInList: any;
  showAll: boolean = false;
  apiCall: any;
  private submitSource: Subject<void> = new Subject();
  request: any = null;
  fullRequest: any = null;
  setFlag: boolean = true;
  loadingPercent = 0;

  searchText = '';
  searchForm: FormGroup;
  name: any = "catalogs";
  throttle = 30;
  scrollDistance = 1;
  sum = 10;
  pagerList = [];
  isStart: boolean = false;
  intervalId = {} as any;
  sourceOrg: any;
  transferEnabled: boolean;
  catalogObj: any;
  deliverLabel;
  cifaSubsList: any;
  @ViewChild('openCifaSubstitute') openCifaSubstitutePopup: TemplateRef<any>;
  @ViewChild('openConfirmation') openConfirmationPopup: TemplateRef<any>;
  subinvFlag: boolean;
  subInv: any = "";
  popupMsg: any = "";
  searchColsArray = ["ITEM_CATEGORY", "ITEM_DESCRIPTION", "Item Description", "CIFA_ITEM_NUMBER", "CIFA#", "MANUFACTURER_PART_NUM", "MODEL#", "Model#", "FG#", "Forecast Group#",
  "ATTRIBUTE8", "UNIT_OF_MEASURE", "REGION_NAME", "TEMPLATE_NAME", "OUTOFSTOCK", "MAX_ORD_QTY", "MIN_ORD_QTY", "FIXED_LOT_QTY", "SUBSTITUTE_FLAG", "SELECT_SOURCE",
  "ADD_TO_FAV", "Title", "SUBSTITUTE_FLAG_MESSAGE", "QUANTITY"]

  constructor(private route: Router, @Inject('environment') private env: any, private reportsService: ReportsService, private eventService: EventService, private comSettingService: CommonSettingService,
    private productService: ProductService, private commonService: CommonService, public datepipe: DatePipe,
    public router: ActivatedRoute, private filterpipe: FilterpipePipe, private searchpipe: SearchPipe, private dialog: MatDialog, private constantData: ConstantData, private requestObject: RequestObject,
    private commonWebService: CommonWebService, private storePreferenceDbService: StorePreferenceDbService, private fb: FormBuilder, private storePreferenceService: StorePreferenceService, private GetimageService: GetimageService
  ) {
    if (this.route.getCurrentNavigation().extras.state && this.route.getCurrentNavigation().extras.state.page == 'selectSource') {
      this.searchOptions.view = this.route.getCurrentNavigation().extras.state.view;
      this.isFavorite = this.route.getCurrentNavigation().extras.state.favPage
    }
    if (this.route.getCurrentNavigation().extras.state && this.route.getCurrentNavigation().extras.state.businessUsrObj) {
      this.storeBusinessObj = this.route.getCurrentNavigation().extras.state.businessUsrObj;
      this.retainUsrData = this.storeBusinessObj;
      this.searchOptions.view = this.route.getCurrentNavigation().extras.state.view;
      this.previousUrl = "settings"
    } else if (this.route.getCurrentNavigation().extras.state && this.route.getCurrentNavigation().extras.state.catalogObj) {
      this.catalogObj = this.route.getCurrentNavigation().extras.state.catalogObj;
      this.retainUsrData = this.catalogObj
      this.searchOptions.view = this.route.getCurrentNavigation().extras.state.view;
      this.previousUrl = "settings"
    }
    if (this.route.getCurrentNavigation().extras.state && this.route.getCurrentNavigation().extras.state.favorite) {
      this.isFavorite = this.route.getCurrentNavigation().extras.state.favorite;
      if (this.route.getCurrentNavigation().previousNavigation.finalUrl.toString().indexOf("settings") > -1) {
        this.previousUrl = "settings"
      }
    }
    if (this.route.getCurrentNavigation().extras.state && this.route.getCurrentNavigation().extras.state.favorites) {
      this.isFavorite = true;
    }
  }

  ngOnInit() {
    let userInfo = localStorage.getItem("userDetails");
    this.userInfo = JSON.parse(userInfo);
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.onSwitchNPID();
    this.onInitialLoad();
    this.initForm();
    this.getPreferenceData();

    if (window.screen.availWidth < 769) {
      this.isFilterTab = false;
    }
    if (!this.isFavorite) {
      this.checkIfDataInStorage();
    }
    // this.deliverLabel = (this.functionId == '51' || this.functionId == '61' || this.functionId == '58') ? "DELIVERY TO SITE" : "DELIVERY TO LOCATION"
    this.deliverLabel = (this.functionId == '136' || this.functionId == '61' || this.functionId == '58') ? "DELIVERY TO SITE" : "DELIVERY TO LOCATION"
  }

  initForm() {
    this.searchForm = this.fb.group({
      search: [''],
      sortBy: [''],
      pageSize: ['total'],
      view: this.searchOptions.view,
      deliverySite: this.deliverToSite
    });
    this.searchForm.disable();
  }

  checkIfDataInStorage() {
    if (sessionStorage.getItem(this.userInfo.NTID + "businessUsrObj") && sessionStorage.getItem(this.userInfo.NTID + "businessUsrObj") != "") {
      let obj = sessionStorage.getItem(this.userInfo.NTID + "businessUsrObj");
      this.storeBusinessObj = JSON.parse(obj)
      this.retainUsrData = this.storeBusinessObj;
    }
    if (sessionStorage.getItem(this.userInfo.NTID + "catalogObj") && sessionStorage.getItem(this.userInfo.NTID + "catalogObj") != "") {
      let obj = sessionStorage.getItem(this.userInfo.NTID + "catalogObj");
      this.retainUsrData = JSON.parse(obj);
    }
    if (this.retainUsrData) {
      if (sessionStorage.getItem(this.userInfo.NTID + "Quantity")) {
        let obj = sessionStorage.getItem(this.userInfo.NTID + "Quantity");
        this.storeQuantity = JSON.parse(obj)
      }
    }
  }

  onSwitchNPID() {
    this.commonService.switchNPID.subscribe(data => {
      this.comSettingService.setdeliverSite(null)
      this.comSettingService.setdelLocCode(null)
      this.onInitialLoad();
    })
  }
  async onInitialLoad() {
    this.getViewPreference();
    this.checkDetailsIfAvailable();
    this.loader = true;
    if (this.isFavorite) {
      // if (this.functionId == '51')
      if (this.functionId == '136')
        this.onfetchReport('Favorites', '', this.userRole);
      this.loader = true;
    }
  }

  getViewPreference() {
    if (!this.searchOptions.view) {
      let flag = false;
      var inputData = {
        "applicationName": "HUB2U",
        "userName": this.userInfo.NTID
      }
      let promise = this.storePreferenceDbService.getPreferencefromDB(inputData).toPromise();
      promise.then((data) => {
        this.userDBDetails = data[0]
        this.userDBDetails.pageDetails.forEach(page => {
          if (page.name == "catalogs") {
            flag = true;
            this.searchOptions.view = page.columns
          }
        })
      }).catch((error) => {
      });
      if (flag == false) {
        if (this.constantData.catalogsGridView[this.functionId] == true)
          this.searchOptions.view = 'grid'
        else
          this.searchOptions.view = 'list'
      }
    }
  }

  setPage($event) {
    if ($event !== undefined) {
      this.pagedItems = $event.pagedItems;
      this.pageNumber = $event.pageNumber;
      this.ItemPerPage = $event.itemsPerPage;
      if (this.multiCall != 'Y' || this.pageNumber != 1) {
        document.body.scrollTop = 0; // For Safari
        document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
      }
    }
  }

  checkDetailsIfAvailable() {
    if (this.storeBusinessObj) {
      this.onProductReload(this.storeBusinessObj);
    }
    if (this.comSettingService.getdeliverSite()) {
      this.deliverToSite = this.comSettingService.getdeliverSite().SITE_ID;
      this.deliverToSiteId = this.comSettingService.getdeliverSite().ADDRESS;
      this.siteAdress = this.comSettingService.getdeliverSite().SITE_DESCRIPTION;
    } else if (this.comSettingService.delLocCode) {
      this.deliverToSite = this.comSettingService.delLocCode.LOCATION_CODE;
      // this.deliverToSiteId = this.comSettingService.delLocCode.ADDRESS;
    }
  }

  test(favItem) {
    var tempArray = favItem.ATTRIBUTE10 ? favItem.ATTRIBUTE10.split(',') : '';
    var selectArray = [];
    if (this.typeArr.length != 0)
      this.typeArr = [];
    tempArray.forEach(item => {
      var reqCheck = item.split('|');
      let reqLblId = reqCheck[1];
      let reqSelect = {
        [reqLblId]: reqCheck[0]
      }
      selectArray.push(reqSelect);
    });

    let keys = [];
    for (let i = 0; i < selectArray.length; i++) {
      keys.push(Object.keys(selectArray[i]).toString())
    }
    let uniqueKeys = keys.filter((v, i, a) => a.indexOf(v) === i);

    for (let key of uniqueKeys) {
      let arr = [];
      for (let j = 0; j < selectArray.length; j++) {
        if (key == Object.keys(selectArray[j]))
          arr.push(Object.values(selectArray[j]).toString().replace('#', ''));
      }
      this.typeArr.push({
        key: key,
        values: arr,
        keyName: this.removeSpace(key),
      })
    }
    this.setCatalogsList();
  }
  removeSpace(key) {
    let newKey = key;
    if (key !== undefined && key !== null) {
      newKey = key.replace(' ', '_');
    }
    return newKey

  }
  addAllItem(event) {
    let obj = {}
    this.size = event;
    this.changeSize = true;
    for (let item of this.catalogList) {
      if (parseInt(item.FIXED_LOT_QTY) == 0 && parseInt(item.MAX_ORD_QTY) == 0 && parseInt(item.MIN_ORD_QTY) == 0) {     // when all are 0
        item.QUANTITY = event;
      }
      else if (item.MIN_ORD_QTY && (parseInt(item.MIN_ORD_QTY) == 1)) {
        if (event >= parseInt(item.MIN_ORD_QTY) && event <= parseInt(item.MAX_ORD_QTY))
          item.QUANTITY = event;
        else if (event < parseInt(item.MIN_ORD_QTY))
          item.QUANTITY = parseInt(item.MIN_ORD_QTY)
        else if (event > parseInt(item.MAX_ORD_QTY) && parseInt(item.MAX_ORD_QTY) != 0)    // when max = 0
          item.QUANTITY = parseInt(item.MAX_ORD_QTY)
        else          // for MAX = NA
          item.QUANTITY = event
      }
      else {
        let qty = event * parseInt(item.MIN_ORD_QTY);
        if (qty >= parseInt(item.MIN_ORD_QTY) && qty <= parseInt(item.MAX_ORD_QTY))
          item.QUANTITY = qty;
        else if (qty < parseInt(item.MIN_ORD_QTY))
          item.QUANTITY = parseInt(item.MIN_ORD_QTY)
        else if (qty > parseInt(item.MAX_ORD_QTY) && parseInt(item.MAX_ORD_QTY) != 0)    // when max is 0
          item.QUANTITY = parseInt(item.MAX_ORD_QTY)
        else
          item.QUANTITY = qty
      }

      if (this.storeQuantity.length != 0) {
        this.storeQuantity.forEach(element => {
          element[item.RECORD_ID] = item.QUANTITY
          element["quantity"] = event
        })
      }
      else {  // when length == 0
        obj[item.RECORD_ID] = item.QUANTITY
        obj["quantity"] = event
      }
    }
    if (this.storeQuantity.length == 0)
      this.storeQuantity.push(obj)
    // if (this.functionId == '51')
    if (this.functionId == '136')
      sessionStorage.setItem(this.userInfo.NTID + "Quantity", JSON.stringify(this.storeQuantity));
  }

  retainQuantity() {
    for (let item of this.catalogList) {
      for (let qtyObj of this.storeQuantity) {
        if (item.RECORD_ID) {
          if (Object.keys(qtyObj).includes(item.RECORD_ID.toString())) {
            item.QUANTITY = qtyObj[item.RECORD_ID]
            this.size = qtyObj["quantity"]
          }
          else {
            this.storeQuantity = [];
            sessionStorage.setItem(this.userInfo.NTID + "Quantity", "");
          }
        }
      }
    }
  }

  alterSize(item) {
    let obj = {}
    if (item.QUANTITY)
      return item.QUANTITY
    else {
      if (parseInt(item.MIN_ORD_QTY) != 0) {
        item['QUANTITY'] = parseInt(item.MIN_ORD_QTY)
      }
      else {
        item['QUANTITY'] = 1
      }
    }

    // if (this.functionId == '51') {
    if (this.functionId == '136') {
      if (this.storeQuantity.length != 0) {
        this.storeQuantity.forEach(element => {
          element[item.RECORD_ID] = item.QUANTITY
        })
      }
      else {  // when length == 0
        obj[item.RECORD_ID] = item.QUANTITY
      }
      if (this.storeQuantity.length == 0)
        this.storeQuantity.push(obj)
      sessionStorage.setItem(this.userInfo.NTID + "Quantity", JSON.stringify(this.storeQuantity));
    }

    return item.QUANTITY;
  }

  getLogoImage() {
    let imageSrc;
    imageSrc = this.logoImg;
    return imageSrc;
  }

  /**SOA TO JAVA */
  getImage(item) {
    let imageSrc;
    if (item.DOCUMENT_COLLECTION_ID && item.DOCUMENT_ID) {
      if (item['CIFA#']) {
        imageSrc = this.imageURL + '/api/sync/download-file/document-collections/' + item.DOCUMENT_COLLECTION_ID + '/documents/' + item.DOCUMENT_ID + '/itemNumber/' + item['CIFA#']
      }
      else if (item['CIFA_ITEM_NUMBER']) {
        imageSrc = this.imageURL + '/api/sync/download-file/document-collections/' + item.DOCUMENT_COLLECTION_ID + '/documents/' + item.DOCUMENT_ID + '/itemNumber/' + item['CIFA_ITEM_NUMBER']

      }
      else if (item['MODEL#'] || item['Model#']) {
        let itemNo = (item['MODEL#'] || item['Model#']).replace(/ /g, "-")
        imageSrc = this.imageURL + '/api/sync/download-file/document-collections/' + item.DOCUMENT_COLLECTION_ID + '/documents/' + item.DOCUMENT_ID + '/itemNumber/' + itemNo
      }
      else if (item['MODEL_NUMBER']) {
        let itemNo = item['MODEL_NUMBER'].replace(/ /g, "-")
        imageSrc = this.imageURL + '/api/sync/download-file/document-collections/' + item.DOCUMENT_COLLECTION_ID + '/documents/' + item.DOCUMENT_ID + '/itemNumber/' + itemNo
      }
      else if (item['MANUFACTURER_PART_NUM']) {
        let itemNo = item['MANUFACTURER_PART_NUM'].replace(/ /g, "-")
        imageSrc = this.imageURL + '/api/sync/download-file/document-collections/' + item.DOCUMENT_COLLECTION_ID + '/documents/' + item.DOCUMENT_ID + '/itemNumber/' + itemNo
      }
    }
    else {
      imageSrc = this.GetimageService.getImage(item)
    }

    return imageSrc;
  }

  async receiveFilter($event) {
    this.onBack();
    if ($event.value) {
      if ($event.value.CALL_COUNT == 0 || $event.value.CALL_COUNT) {
        this.getCallCount($event.value)
      }
    }
    let type = $event.type;
    this.itemType = ($event.nav ? $event.nav.itemType : '');
    this.itemType ? (this.itemType == 'Regional' ? this.isFavorite = false : this.isFavorite = true) : '';
    this.searchValue = this.itemType;
    let lookupCode = ($event.value ? $event.value.LOOKUP_CODE : '')
    let regionCode = ($event.value ? $event.value.REGION_NAME : '')

    if ($event.value == 'initialLoad') {
      this.loader = false;
    }

    if ($event.value == 'null') {
      this.tagsList = []
      this.catalogList.length = 0;
      this.title = "";
      this.description = "";
      this.logoImg = "";
      this.subtitle = "";
      this.singleProductTitle = "";
      this.catalogList = [];
      this.pagedItems = [];
      this.retainUsrData = null;
      this.storeBusinessObj = null;
      this.searchForm.disable();
      this.searchOptions.search = '';
      this.searchOptions.sortBy = '';
      this.searchForm.get("search").setValue('');
      this.searchForm.get("sortBy").setValue('');
      return;
    }
    if (type === 'form') {
      if (this.itemType !== 'Favorites') {
        this.checkIfDataInStorage();
      }
      // if(this.functionId !== '51') {
      if (this.functionId !== '136') {
        this.catalogObj = $event.value
      }
      this.catalogList = []
      this.pagedItems = [];
      this.searchOptions.search = '';
      this.searchOptions.sortBy = '';
      this.searchForm.get("search").setValue('');
      this.searchForm.get("sortBy").setValue('');
      this.setFlag = true
      this.sum = 10;
      if (this.request) {
        this.request.unsubscribe();
        this.onfetchReport($event.nav.itemType, lookupCode, this.userRole, regionCode);
      }
      else {
        this.onfetchReport($event.nav.itemType, lookupCode, this.userRole, regionCode);
      }
    }
    if (type === 'category') {
      this.sum = 10;
      this.setFlag = true
      this.searchOptions.search = '';
      this.searchOptions.sortBy = '';
      this.searchForm.enable();
      this.searchForm.get("search").setValue('');
      this.searchForm.get("sortBy").setValue('');
      // if(this.functionId !== '51') {
      if (this.functionId !== '136') {
        this.catalogObj = $event.value
      }
      if (this.request) {
        this.request.unsubscribe();
        this.onfetchReport($event.nav.itemType, lookupCode, this.userRole, regionCode);
      }
      else {
        if (this.fullRequest) {
          this.catalogList = [];
          this.pagedItems = [];
          this.fullRequest.unsubscribe();
          this.onfetchReport($event.nav.itemType, lookupCode, this.userRole, regionCode);
        }
        else {
          this.onfetchReport($event.nav.itemType, lookupCode, this.userRole, regionCode);
        }
      }
    }

    if (type === 'tags') {
      this.onFilterTags($event.value);
    }

    if (type === 'filterBy') {
      if ($event.close) {
        this.tagsList = [];
        this.catalogList = [];
        this.pagedItems = [];
        this.catalogListOriginal = [];
        this.title = "";
        this.description = "";
        this.logoImg = "";
        this.subtitle = "";
        this.searchForm.disable();
        this.searchOptions.search = '';
        this.searchOptions.sortBy = '';
        this.searchForm.get("search").setValue('');
        this.searchForm.get("sortBy").setValue('');
      }
    }
  }

  onProductReload(event) {
    // if (this.comSettingService.getdeliverSite() == null) {
    //   this.deliverToSiteId = null;
    //   this.deliverToSite = null;
    //   this.siteAdress = null;
    // }
    this.changeSize = false;
    this.size = 1;
    this.storeBusinessObj = Object.assign({}, event);

    // if(this.userRole === 'Comcast Business Services User' && !event.CUSTOMER){
    if (this.userRole === 'Comcast Business Services User iip' && !event.CUSTOMER) {
      this.onfetchReport('Regional', event.LOOKUP_CODE, this.userRole);
      this.catalogObj = event;
    } else {
      this.onfetchReport('Regional', event, this.userRole);
    }
  }

  onfetchReport(type, value, role, regionCode?) {
    if (!value.CUSTOMER) {
      this.storeBusinessObj = null;
      this.transferEnabled = true
    } else {
      this.transferEnabled = false
    }
    this.loader = true;
    this.isDataLoaded = false;
    this.pageNumber = 1
    this.typeArr = []
    this.showAll = false;
    this.lookupCode = value;
    this.isFavorite = type === 'Regional' ? false : true;
    let object = {};
    if (type === 'Regional' && (role ? role.toUpperCase() === 'COMCAST TECH USER IIP' : '')) {
      object = Object.assign({}, this.requestObject.catalogTechUser);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
      object['ParametersInput'][1]['Value'] = regionCode ? regionCode : (this.region ? this.region : this.userInfo['region']);
      object['ParametersInput'][2]['Value'] = value;
      object['ParametersInput'][3]['Value'] = this.countInList;
    }

    if (type === 'Regional' && (role ? role.toUpperCase() === 'XM SUPPLY CHAIN' : '')) {
      object = Object.assign({}, this.requestObject.catalogXmSupplyChain);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
      object['ParametersInput'][1]['Value'] = regionCode ? regionCode : (this.region ? this.region : this.userInfo['region']);
      object['ParametersInput'][2]['Value'] = value;
      object['ParametersInput'][3]['Value'] = this.countInList;
    }

    if (type === 'Regional' && (role ? role.toUpperCase() === 'COMCAST ESA USER' : '')) {
      object = Object.assign({}, this.requestObject.catalogRegionalESA);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
      object['ParametersInput'][1]['Value'] = this.region ? this.region : this.userInfo['region'];
      object['ParametersInput'][2]['Value'] = value;
    }

    if (type === 'Regional' && (role ? role.toUpperCase() === 'COMCAST 5G USER' : '')) {
      object = Object.assign({}, this.requestObject.catalogRegional5G);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
      object['ParametersInput'][1]['Value'] = this.region ? this.region : this.userInfo['region'];
      object['ParametersInput'][2]['Value'] = value;
      // object['ParametersInput'][3]['Value'] = this.countInList;
    }

    if ((type === 'Favorites' && (role ? role.toUpperCase() === 'COMCAST 5G USER' : ''))) {
      object = Object.assign({}, this.requestObject.catalog5GFav);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
    }

    if ((type === 'Favorites' && (role ? role.toUpperCase() === 'COMCAST TECH USER IIP' : ''))) {
      object = Object.assign({}, this.requestObject.catalogTechFav);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
    }

    if ((type === 'Favorites' && (role ? role.toUpperCase() === 'COMCAST ESA USER' : ''))) {
      object = Object.assign({}, this.requestObject.catalogESAUserFav);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
    }

    // if (type === 'Regional' && !value.CUSTOMER && (role ? role.toUpperCase() === 'COMCAST BUSINESS SERVICES USER' : '')) {
    if (type === 'Regional' && !value.CUSTOMER && (role ? role.toUpperCase() === 'COMCAST BUSINESS SERVICES USER IIP' : '')) {
      // if (this.storeBusinessObj) {
      object = Object.assign({}, this.requestObject.catalogTransferBSU);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
      object['ParametersInput'][1]['Value'] = value;
      // }
      // else {
      //   this.catalogList = []
      //   this.catalogList.length = 0;
      //   return;
      // }
    }

    // if (type === 'Regional' && (value && value.CUSTOMER) && (role ? role.toUpperCase() === 'COMCAST BUSINESS SERVICES USER' : '')) {
    if (type === 'Regional' && (value && value.CUSTOMER) && (role ? role.toUpperCase() === 'COMCAST BUSINESS SERVICES USER IIP' : '')) {
      if (this.storeBusinessObj) {
        object = Object.assign({}, this.requestObject.catalogBusinessUser);
        object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
        object['ParametersInput'][1]['Value'] = this.storeBusinessObj['CUSTOMER'];
        object['ParametersInput'][2]['Value'] = this.storeBusinessObj['MEANING'];
      }
      else {
        this.catalogList = []
        this.catalogList.length = 0;
        return;
      }
    }

    if (type === 'Favorites' && (role ? role.toUpperCase() === 'COMCAST BUSINESS SERVICES USER IIP' : '')) {
      object = Object.assign({}, this.requestObject.catalogBusinessUserFav);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
    }

    if (type === 'Regional' && (role ? role.toUpperCase() === 'COMCAST CPE USER' : '')) {
      object = Object.assign({}, this.requestObject.catalogCPEUserRegional);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
      object['ParametersInput'][1]['Value'] = value ? value : '';
    }

    if (type === 'Regional' && (role ? role.toUpperCase() === 'COMCAST NONCPE USER' : '')) {
      object = Object.assign({}, this.requestObject.catalogNonCpeUser);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
      object['ParametersInput'][1]['Value'] = this.region ? this.region : this.userInfo['region'];
      object['ParametersInput'][2]['Value'] = value ? value : '';
      object['ParametersInput'][3]['Value'] = this.countInList;
    }

    if (type === 'Favorites' && (role ? role.toUpperCase() === 'COMCAST CPE USER' : '')) {
      object = Object.assign({}, this.requestObject.catalogCPEUserFav);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
    }

    if (type === 'Favorites' && (role ? role.toUpperCase() === 'COMCAST NONCPE USER' : '')) {
      object = Object.assign({}, this.requestObject.catalogNonCpeFav);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
    }

    if (type === 'Favorites' && (role ? role.toUpperCase() === 'XM SUPPLY CHAIN' : '')) {
      object = Object.assign({}, this.requestObject.catalogXmSupplyChainFav);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
    }

    if (type === 'Regional' && (role ? role.toUpperCase() === 'COMCAST STORE USER' : '')) {
      object = Object.assign({}, this.requestObject.storeUserRegional);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
      object['ParametersInput'][1]['Value'] = this.region ? this.region : this.userInfo['region'];
      object['ParametersInput'][2]['Value'] = value ? value : '';
    }

    if (type === 'Favorites' && (role ? role.toUpperCase() === 'COMCAST STORE USER' : '')) {
      object = Object.assign({}, this.requestObject.catalogStoreFav);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
    }

    if (type === 'Regional' && (role ? role.toUpperCase() === 'PREPAID DEALER' : '')) {
      object = Object.assign({}, this.requestObject.PrepaidDealerRegional);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
      object['ParametersInput'][1]['Value'] = this.region ? this.region : this.userInfo['region'];
      object['ParametersInput'][2]['Value'] = value ? value : '';
    }

    if (type === 'Favorites' && (role ? role.toUpperCase() === 'PREPAID DEALER' : '')) {
      object = Object.assign({}, this.requestObject.catalogPrepaidFav);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
    }

    if (type === 'Regional' && (role ? role.toUpperCase() === 'COMCAST CNA USER' : '')) {
      object = Object.assign({}, this.requestObject.catalogCNAuser);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
      object['ParametersInput'][1]['Value'] = value ? value : '';
    }

    if (type === 'Favorites' && (role ? role.toUpperCase() === 'COMCAST CNA USER' : '')) {
      object = Object.assign({}, this.requestObject.catalogCPEUserFav);
      object['ParametersInput'][0]['Value'] = this.userInfo.NTID;
    }

    this.request = this.reportsService.onGetDynamicReport(object).subscribe(response => {
      this.replacedCatalogList = []
      this.list = response.ROW || [];
      this.searchOptions.search = '';
      this.searchOptions.sortBy = '';
      this.searchForm.enable();
      this.searchForm.get("search").setValue('');
      this.searchForm.get("sortBy").setValue('');
      this.setOperations();

      if (this.multiCall == 'Y' && !this.isFavorite) {
        this.countInList = this.totalCount;
        object['ParametersInput'][3]['Value'] = this.countInList;
        this.startLoading()
        this.fullRequest = this.reportsService.onGetDynamicReport(object).subscribe(response => {
          this.fullRequest = null;
          // this.loadingPercent = 100
          this.setFlag = false;
          this.replacedCatalogList = response.ROW || [];
          this.loadFullData();
          return;
        }, error => {
          this.fullRequest = null;
        })
      }

      this.request = null;
    }, error => {
      this.catalogList.length = 0;
      this.loader = false;
      this.isDataLoaded = false;
      this.request = null;
      this.pagedItems = [];
      this.catalogList = [];
      this.searchForm.disable();
    });
    this.refreshData = false
  }

  startLoading() {
    this.loadingPercent = 0;
    if (this.intervalId)
      clearInterval(this.intervalId);
    let interval
    this.countInList > 500 ? interval = 3 : interval = 7
    this.intervalId = setInterval(() => {
      if (this.loadingPercent < 100) {
        this.loadingPercent += interval;
        this.loadingPercent > 100 ? this.loadingPercent = 100 : '';
      }
    }, 500);
  }

  setOperations() {
    this.refreshData = true;
    this.loader = false;
    this.isDataLoaded = true;
    // this.catalogList = this.list;
    this.catalogList = [...this.list];
    if (this.replacedCatalogList == undefined || this.replacedCatalogList.length == 0) {
      this.pagedItems = [];
      this.appendItems(0, this.sum);
    }
    this.catalogListOriginal = this.list;

    this.catalogList.length == 0 ? this.searchForm.disable() : this.searchForm.enable()
    // if (this.functionId == '51' && this.storeQuantity.length > 0 && this.previousUrl == "settings") {
    if (this.functionId == '136' && this.storeQuantity.length > 0 && this.previousUrl == "settings") {
      this.retainQuantity();
    }
    else {
      this.size = 1;
      this.storeQuantity = [];
      if (sessionStorage.getItem(this.userInfo.NTID + "Quantity"))
        sessionStorage.setItem(this.userInfo.NTID + "Quantity", "");
    }
    if (this.functionId == '58' && this.catalogList.length > 0) {
      this.test(this.catalogList[0]);
    }
    this.sortByFilter = [];
    this.sortByFilter.push({ key: 'Select', value: "" })

    let isCifaItem = this.catalogList.filter(item => (item.CIFA_ITEM_NUMBER))
    if (isCifaItem.length == 0) {
      isCifaItem = this.catalogList.filter(item => (item['CIFA#']))
      if (isCifaItem.length > 0) {
        this.sortByFilter.push({ key: 'CIFA Item', value: 'CIFA#' })
      }
    }
    else {
      if (isCifaItem.length > 0) {
        this.sortByFilter.push({ key: 'CIFA Item', value: 'CIFA_ITEM_NUMBER' })
      }
    }
    let isCategory = this.catalogList.filter(item => item.ITEM_CATEGORY)

    let isItemDescription = this.catalogList.filter(item => (item.ITEM_DESCRIPTION))
    if (isItemDescription.length == 0) {
      let arr = this.catalogList.filter(item => (item['Item Description']))
      if (arr.length != 0) {
        this.sortByFilter.push({ key: 'Description', value: 'Item Description' })
      }
    } else {
      this.sortByFilter.push({ key: 'Description', value: 'ITEM_DESCRIPTION' })
    }

    if (this.functionId != '58' && isCategory.length > 0) {
      this.sortByFilter.push({ key: 'Category', value: 'ITEM_CATEGORY' })
    }

    let forecastGroup = this.catalogList.filter(item => item['Forecast Group#'])
    let model = this.catalogList.filter(item => item['Model#'])

    if (this.functionId == '58' && forecastGroup.length > 0) {
      this.sortByFilter.push({ key: 'Forecast Group', value: 'Forecast Group#' })
    }
    if (this.functionId == '58' || this.functionId == '66' && model.length > 0) {
      this.sortByFilter.push({ key: 'Model', value: 'Model#' })
    }

    if (!this.isFavorite) {
      let newTagList = [];
      let eventList = [...new Set(this.catalogListOriginal.map(item => item['TAG'] ? item['TAG'].toUpperCase() : ""))];
      eventList.forEach(item => {
        (item != null && item != "") ? newTagList.push({
          selected: false,
          name: item,
          value: this.count(item)
        }) : false
      })

      let obj = sessionStorage.getItem(this.userInfo.NTID + "catalogObj");
      let retainData;
      if (obj) {
        retainData = JSON.parse(obj);
      }
      if (obj && retainData && retainData['TAGS'] && retainData['TAGS'].length > 0) {
        let tags = retainData['TAGS'];
        newTagList.forEach(x => {
          tags.forEach(y => {
            if (x.name == y.name) {
              x.selected = true
            }
          })
        })
      }
      newTagList.sort((a, b) => {
        return a.value - b.value;
      });
      this.tagsList = newTagList.reverse();
    }
  }

  loadFullData() {
    this.list = this.replacedCatalogList;
    this.setFlag = null;
    this.showAll = true;
    this.setOperations();
  }

  setMin(item) {
    let qty;
    qty = (item.MIN_ORD_QTY != '0' ? item.MIN_ORD_QTY : 1)
    return qty
  }

  setCatalogsList() {
    let catalogLst = this.catalogList;
    catalogLst.forEach(item => {
      for (let type of this.typeArr) {
        item[type.keyName] = type.values[0];
      }
    });
  }
  getItemName() {
    let defaultCol = '';
    if (this.functionId == '61') {
      defaultCol = 'MANUFACTURER_PART_NUM';
    }
    // if (this.functionId == '99') {
    //   defaultCol = 'CIFA_ITEM_NUMBER';
    // }
    if (this.functionId == '143') {
      defaultCol = 'CIFA_ITEM_NUMBER';
    }

    return defaultCol;
  }
  count(item) {
    let counter = 0;
    for (const obj of this.catalogListOriginal) {
      if (obj['TAG'] != "" && obj['TAG'] != null) {
        if (obj['TAG'].toLowerCase() === item.toLowerCase())
          counter++;
      }
    }
    return counter;
  }

  receiveTitle(event) {
    this.onBack();
    this.title = event.title;
    this.description = event.description;
    this.logoImg = event.logo;
    this.subtitle = event.subtitle ? '<font>' + ' - ' + event.subtitle + '</font>' : '';
  }

  async searchFilter($event) {
    if ($event.search !== this.searchOptions.search) {
      await this.onSearchItem($event.search ? ($event.search).toLowerCase() : $event.search);
    }
    if ($event.sortBy !== this.searchOptions.sortBy) {
      await this.onSortByItems($event.sortBy);
    }
    if ($event.pageSize !== this.searchOptions.pageSize) {
      await this.onPageSize($event);
      //this.itemPerPage = $event.pageSize;
    }
    let searchTemp = {
      view: '',
      search: '',
      sortBy: '',
      pageSize: ''
    };
    searchTemp.view = $event.view;
    searchTemp.search = $event.search;
    searchTemp.sortBy = $event.sortBy;
    searchTemp.pageSize = $event.pageSize;
    this.searchOptions = searchTemp //security checkmark fix by Supriya;
  }

  onSearchItem(text) {
    if (this.catalogListWithTags.length != 0) {
      this.catalogList = this.filterpipe.transform(this.catalogListWithTags, text);
    }
    else {
      //this.catalogList = this.filterpipe.transform(this.catalogListOriginal, text);
      // console.log(this.dataToSearch)
      // let lst = this.dataToSearch.filter(item => item.searchableString.toLowerCase().indexOf(text) > -1);
      this.catalogList = this.search(text);
      //this.search(text);
    }
    this.pageNumber = 1;
    this.pagedItems = [...this.catalogList]
    this.appendItems(0, this.sum);
  }

  searchData() {
    if (this.itemType != 'Favorites' && this.catalogListWithTags.length != 0) {
      // this.catalogList = this.filterpipe.transform(this.catalogListWithTags, this.searchForm.value.search);
      this.catalogList = this.searchpipe.transform(this.catalogListWithTags, this.searchForm.value.search, this.searchColsArray)
    }
    else {
      this.catalogList = this.search(this.searchForm.value.search);
    }
    let searchTemp = {
      view: '',
      search: '',
      sortBy: '',
      pageSize: ''
    };
    searchTemp.view = this.searchForm.value.view;
    searchTemp.search = this.searchForm.value.search;
    searchTemp.sortBy = this.searchForm.value.sortBy;
    searchTemp.pageSize = this.searchForm.value.pageSize;
    this.searchOptions = searchTemp;

    this.pageNumber = 1;
    this.appendItems(0, this.sum);
    // this.catalogList = this.search(this.searchText);
  }

  setView(event) {
    if (event == 'list') {
      this.searchForm.get("view").setValue('list');
    }
    else if (event == 'grid') {
      this.searchForm.get("view").setValue('grid');
    }
    let searchTemp = {
      view: '',
      search: '',
      sortBy: '',
      pageSize: ''
    };
    searchTemp.view = this.searchForm.value.view;
    searchTemp.search = this.searchForm.value.search;
    searchTemp.sortBy = this.searchForm.value.sortBy;
    searchTemp.pageSize = this.searchForm.value.pageSize;
    this.searchOptions = searchTemp
    this.appendItems(0, this.sum);
  }
  storePreference() {
    let con = this.storePreferenceService.storePreference(this.userDBDetails, this.name, "", "", this.searchOptions.view)
    // console.log(con);
  }

  clearPreference() {
    this.storePreferenceService.clearPreference(this.userDBDetails, this.name, "", "", this.searchOptions.view)
  }

  search(value): any[] {
    let filtered = [];
    if (value == "") {
      filtered = this.catalogListOriginal
    } else {
        // var pattern = new RegExp(value, "gi");
        var tempData = this.catalogListOriginal;

        // filtered = this.filterpipe.transform(tempData, value)
        filtered = this.searchpipe.transform(tempData, value, this.searchColsArray)

        // filtered = tempData.filter(function (data) {
        //   return (
        //     pattern.test(data['ITEM_CATEGORY']) ||
        //     pattern.test(data['ITEM_DESCRIPTION']) ||
        //     pattern.test(data['Item Description']) ||
        //     pattern.test(data['CIFA_ITEM_NUMBER']) ||
        //     pattern.test(data['CIFA#']) ||
        //     pattern.test(data['MANUFACTURER_PART_NUM']) ||
        //     pattern.test(data['MODEL#']) ||
        //     pattern.test(data['Model#']) ||
        //     pattern.test(data['FG#']) ||
        //     pattern.test(data['Forecast Group#']) ||
        //     pattern.test(data['ATTRIBUTE8']) ||
        //     pattern.test(data['UNIT_OF_MEASURE']) ||
        //     pattern.test(data['REGION_NAME']) ||
        //     pattern.test(data['TEMPLATE_NAME']) ||
        //     pattern.test(data['OUTOFSTOCK']) ||
        //     pattern.test(data['MAX_ORD_QTY']) ||
        //     pattern.test(data['MIN_ORD_QTY']) ||
        //     pattern.test(data['FIXED_LOT_QTY']) ||
        //     pattern.test(data['SUBSTITUTE_FLAG']) ||
        //     pattern.test(data['SELECT_SOURCE']) ||
        //     pattern.test(data['ADD_TO_FAV']) ||
        //     pattern.test(data['Title']) ||
        //     pattern.test(data['SUBSTITUTE_FLAG_MESSAGE']) ||
        //     pattern.test(data['QUANTITY'])
        //   );
        // });
    }
    return filtered;
  }

  onSortByItems(sortBy) {
    let listArr = this.catalogList
    // if(this.catalogListWithTags.length != 0) {
    //   listArr = this.catalogListWithTags
    // }
    this.catalogList = listArr.sort((a, b) => {
      var nameA = a[sortBy] ? a[sortBy].toUpperCase() : '';
      var nameB = b[sortBy] ? b[sortBy].toUpperCase() : '';
      if (nameA < nameB) {
        return -1;
      }
      if (nameA > nameB) {
        return 1;
      }
      return 0;
    });
    let list = []
    if (this.catalogList.length > this.ItemPerPage) {
      for (let i = 0; i < this.ItemPerPage; i++) {
        list.push(this.catalogList[i])
      }
    }
    else {
      list = this.catalogList
    }
    let event = {
      pagedItems: list,
      pageNumber: 1,
      itemsPerPage: this.ItemPerPage
    }
    this.setPage(event)
    this.appendItems(0, this.sum);
    //this.pagedItems = this.catalogList
  }

  onPageSize(event) {
    if ((this.catalogList.length !== parseInt(event.pageSize)) && event.pageSize !== 'total') {
      if (event.search == '') {
        this.catalogList = this.catalogListOriginal.slice(0, parseInt(event.pageSize));
      }
      else {
        this.catalogList = this.catalogList.slice(0, parseInt(event.pageSize));
      }
    }
    if ((event.search == '') && (event.pageSize === 'total') && (this.catalogList.length !== this.catalogListOriginal.length)) {
      if (this.catalogListWithTags.length != 0) {
        this.catalogList = this.catalogListWithTags
      }
      else
        this.catalogList = this.catalogListOriginal;
    }
  }

  onFilterTags(tags) {
    this.catalogList = [];
    this.catalogListWithTags = [];
    let tagsList = tags || [];
    if (tagsList.length > 0) {
      this.catalogListOriginal.filter(x => {
        tagsList.forEach(tag => {
          if (x['TAG'] && x['TAG'].toLowerCase() === (tag.name).toLowerCase()) {
            this.catalogList.push(x);
            this.catalogListWithTags.push(x);
          }
        });
      });
    }
    else {
      this.catalogList = this.catalogListOriginal;
    }

    if (this.replacedCatalogList == undefined || this.replacedCatalogList.length == 0) {
      this.appendItems(0, this.sum);
    } else if (tagsList.length > 0) {
      this.appendItems(0, this.sum);
    } else {
      this.onScrollDown()
    }
    this.pageNumber = 1;
    if (this.searchOptions.sortBy != "") {
      this.onSortByItems(this.searchOptions.sortBy);
    }
    if (this.searchOptions.search != "") {
      this.onSearchItem(this.searchOptions.search)
    }
  }

  onBack() {
    if (this.singleProductView) {
      this.singleProductView = !this.singleProductView;
    }
    if (this.selectSource) {
      this.selectSource = !this.selectSource;
    }
  }

  onSingleProduct(item, index) {
    this.changeSize = false;
    item['index'] = index;
    this.singleProductView = !this.singleProductView;
    this.seletedItem = item ? item : null;
    // this.singleProductTitle = (this.seletedItem && item.ITEM_DESCRIPTION) ? '<font>' + item.ITEM_DESCRIPTION.slice(0, 80) + (item.ITEM_DESCRIPTION.length > 80 ? "..." : "") + '</font>' : item.DESCRIPTION;
    this.singleProductTitle = this.seletedItem['Title'] ? this.seletedItem['Title'] : (this.seletedItem && item.ITEM_DESCRIPTION) ? item.ITEM_DESCRIPTION : item['Item Description'];
  }

  onCheckSoruce(item, index) {
    this.dialog.open(SelectSourceComponent, {
      "width": '6000px',
      "maxHeight": '90vh',
      "data": { item: item, favItem: item, view: this.searchOptions.view, favPage: this.isFavorite, sourceOrg: this.sourceOrg, subInv: this.subInv },
      "autoFocus": false
    });
    // this.route.navigate(['hub2u/select_source/'], { state: { item: item, favItem: item, view: this.searchOptions.view, favPage: this.isFavorite } })
  }

  callItSupport() {
    let itsupport = this.env.itsupportticket
    window.open(itsupport, '_blank');
  }

  getPreferenceData() {
    let request = {
      //ReportId: "112" 
      // ReportId: 7001,
      ReportId:this.constantData.userprofileData[this.functionId],
      ParametersInput: [
        { Name: "USER_NAME", Value: this.userInfo.NTID },
      ],

    }
    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      console.log("response",response)
      if (response != undefined && response.ROW != undefined) {
        this.needbyDate = response.ROW[0].NEED_BY_DATE_TIME

        if (this.previousUrl == "settings" && (this.comSettingService.delLocCode || this.comSettingService.getdeliverSite())) {
          // console.log(this.comSettingService.delLocCode)
        } else {            // on first load of the page
          // if(this.functionId != '57' && this.functionId != '51' && this.functionId != '58' && this.functionId != '61') {
          if (this.functionId != '57' && this.functionId != '136' && this.functionId != '58' && this.functionId != '61') {
            response.ROW[0].DELIVERY_TO_LOCATION ? (this.deliverToSite = response.ROW[0].DELIVERY_TO_LOCATION) : this.deliverToSite = ''
          } else {
            response.ROW[0].SITE_ID ? this.deliverToSite = response.ROW[0].SITE_ID : this.deliverToSite = ''
            response.ROW[0].ADDRESS ? this.deliverToSiteId = response.ROW[0].ADDRESS : this.deliverToSiteId = ''
          }
        }
      }
      this.attr6 = response.ROW[0].ATTRIBUTE5
      this.sourceOrg = response.ROW[0].SOURCE_LOCATION
      this.subInv = response.ROW[0].SUBINVENTORY
    }, error => {
      // console.log(error);
    })
  }

  getDefaultOrderType() {
    if (this.functionId == '50' || this.functionId == '57' || this.functionId == '63') {
      return "INVENTORY"
    }
    // if (this.functionId == '51') {
    if (this.functionId == '136') {
      return "FULFILLMENT"
    }
    // if (this.functionId == '99' && (!this.attr6 || this.attr6 == "null")) {
    //   return 'PROJECT'
    // }
    if (this.functionId == '143' && (!this.attr6 || this.attr6 == "null")) {
      return 'PROJECT'
    }
    // if (this.functionId == '99' && this.attr6) {
    //   return this.attr6
    // }
    if (this.functionId == '143' && this.attr6) {
      return this.attr6
    }
    // if (this.functionId != '47' && this.functionId != '99' && this.functionId != '51' && this.functionId != '50' && this.functionId != '57' && this.functionId != '63') {
    if (this.functionId != '47' && this.functionId != '143' && this.functionId != '136' && this.functionId != '50' && this.functionId != '57' && this.functionId != '63') {
      return "PROJECT"
    }
  }

  getAttribute6(event) {
    this.attribute6 = event;
  }

  getLocCode() {
    // if (this.functionId == '51' && (this.storeBusinessObj && this.storeBusinessObj.CUSTOMER)) {
    //   return this.storeBusinessObj.CUSTOMER + "|" + this.deliverToSite + "|" + this.deliverToSiteId + ((this.siteAdress) ? "|" + this.siteAdress : "|" + null)
    // }
    if (this.functionId == '136' && (this.storeBusinessObj && this.storeBusinessObj.CUSTOMER)) {
      return this.storeBusinessObj.CUSTOMER + "|" + this.deliverToSite + "|" + this.deliverToSiteId + ((this.siteAdress) ? "|" + this.siteAdress : "|" + null)
    }
    // else if((this.functionId == '51'|| this.functionId == '61')  && !this.storeBusinessObj) {
    else if ((this.functionId == '136' || this.functionId == '61') && !this.storeBusinessObj) {
      return this.catalogObj['LOOKUP_CODE'] + "|" + this.deliverToSite + "|" + this.deliverToSiteId + ((this.siteAdress) ? "|" + this.siteAdress : "|" + null)
    } else if (this.functionId == '57') {
      return this.catalogObj['LOOKUP_CODE'] + "|" + this.deliverToSite + "|" + this.deliverToSiteId
    } else if (this.functionId == '58') {
      return this.deliverToSite + "|" + this.deliverToSiteId
    } else {
      return this.deliverToSite;
    }

  }

  addToCart(item, index) {
    if (!this.deliverToSite && !this.deliverToSiteId && this.storeBusinessObj && !this.isFavorite) {
      this.commonWebService.openSnackBar("Please select a delivery to site to add items to cart!", "WARNING");
    }
    else {
      this.eventService.showSpinner();
      if (item['SUBSTITUTE_FLAG'] == 'Yes') {
        let object = {
          ReportId: "60206",
          ParametersInput: [
            {
              Name: "INVENTORY_ITEM_ID",
              Value: item.INVENTORY_ITEM_ID
            },
            {
              Name: "SOURCE_ORGANIZATION_CODE",
              // Value: (this.functionId == '99' || this.functionId == '50' || this.functionId == '61' || (this.functionId == '51' && !this.storeBusinessObj) || (this.functionId == '136' && !this.storeBusinessObj)) ? (item['ORGANIZATION_CODE'] ? item['ORGANIZATION_CODE'] : (this.sourceOrg ? this.sourceOrg : '')) : "",
              Value: (this.functionId == '143' || this.functionId == '50' || this.functionId == '61' || (this.functionId == '51' && !this.storeBusinessObj) || (this.functionId == '136' && !this.storeBusinessObj)) ? (item['ORGANIZATION_CODE'] ? item['ORGANIZATION_CODE'] : (this.sourceOrg ? this.sourceOrg : '')) : "",
            }
          ]
        }
        this.reportsService.onGetDynamicReport(object).subscribe(response => {
          if (response && response.ROW) {
            if (response.ROW[0]['SHOW_POPUP'] && response.ROW[0]['SHOW_POPUP'] == "Yes") {
              this.eventService.hideSpinner();
              this.popupMsg = response.ROW[0]['POPUP_MESSAGE']
              let dialogRef = this.dialog.open(this.openConfirmationPopup)
              dialogRef.afterClosed().subscribe(result => {
                if (result === 'Yes') {
                  this.eventService.showSpinner();
                  this.callAddtoCart(item, index)
                } else {
                  return;
                }
              })
            } else {
              this.callAddtoCart(item, index)
            }
          }
        }, error => {
          this.commonWebService.openSnackBar("Sorry! Something went wrong", "ERROR")
        });
      } else {
        this.callAddtoCart(item, index)
      }
    }
  }

  callAddtoCart(item, index) {
    let attribut6 = this.getDefaultOrderType();
    this.cartLoader = index === '-1' ? true : false;
    let catalogs = [];
    if (index == this.catalogList.length) {
      // this.eventService.showSpinner();
      this.headerCartLoader = true
      for (let obj of this.catalogList) {
        let input: any;
        // input = {
        //   cifaItemNumber: obj['CIFA#'] ? obj['CIFA#'] : obj['CIFA_ITEM_NUMBER'],
        //   itemDescription: obj['ITEM_DESCRIPTION'] ? obj['ITEM_DESCRIPTION'] : obj['DESCRIPTION'],
        //   itemCategory: obj['ITEM_CATEGORY'] || item['Forecast Group#'],
        //   deliveryLocationCode: this.getLocCode(),
        //   quantity: (obj.QUANTITY != undefined && obj.QUANTITY != null) ? obj.QUANTITY : obj['MIN_ORD_QTY'],
        //   needByDate: this.needbyDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needbyDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (2 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),
        //   userName: this.userInfo.NTID.toUpperCase(),
        //  // regionTemplate: (this.isFavorite ? item['TEMPLATE_NAME'] : ((this.functionId == '51') ? ((this.storeBusinessObj && this.storeBusinessObj.CUSTOMER) ? this.storeBusinessObj['LOOKUP_CODE'] : item['TEMPLATE_NAME']) : this.title)),
        //   regionTemplate: (this.isFavorite ? item['TEMPLATE_NAME'] : ((this.functionId == '136') ? ((this.storeBusinessObj && this.storeBusinessObj.CUSTOMER) ? this.storeBusinessObj['LOOKUP_CODE'] : item['TEMPLATE_NAME']) : this.title)),
        //   regionName: item['TEMPLATE_NAME'] == "ASSET RECOVERY CENTER" ? "GLOBAL" : (this.region ? this.region : this.userInfo['region']),    // hardcoding the region name particularly for Asset recovery center as required
        //   attribute3: this.userRole.toUpperCase(),
        // //  attribute1: this.functionId == '51' ? this.size : "",
        //   attribute1: this.functionId == '136' ? this.size : "",
        //   attribute5: item['SKU#'],
        //   attribute4: (this.functionId == '58') ? ('Order Level:' + obj['Order_Level'] + "|Item Type:" + obj['Item_Type'] + "|Item Condition:" + obj['Item_Condition']) : null,
        //   attribute6: this.attribute6 && this.attribute6 != 'null' ? this.attribute6 : attribut6,
        //   //sourceOrganizationCode: (this.functionId == '99' || this.functionId == '50' || this.functionId == '61' || (this.functionId == '51' && !this.storeBusinessObj)) ? (obj['ORGANIZATION_CODE'] ? obj['ORGANIZATION_CODE'] : (this.sourceOrg ? this.sourceOrg  : '')) : "",
        //   sourceOrganizationCode: (this.functionId == '99' || this.functionId == '50' || this.functionId == '61' || (this.functionId == '136' && !this.storeBusinessObj)) ? (obj['ORGANIZATION_CODE'] ? obj['ORGANIZATION_CODE'] : (this.sourceOrg ? this.sourceOrg  : '')) : "",
        //   sourceSubInventory: (this.sourceOrg == (obj['ORGANIZATION_CODE'] || obj['SOURCE_ORGANIZATION_CODE'])) && this.functionId == '99' ? (this.subInv !== "" ? this.subInv : obj['SOURCE_SUBINVENTORY']) : obj['SOURCE_SUBINVENTORY'],
        //   vendorItemNumber: obj['MANUFACTURER_PART_NUM'] ? obj['MANUFACTURER_PART_NUM'] : obj['Model#'],
        //   //attribute9: this.functionId == '51' ? (this.storeBusinessObj ? this.storeBusinessObj.CUSTOMER : this.catalogObj['LOOKUP_CODE']) : '',
        //   attribute9: this.functionId == '136' ? (this.storeBusinessObj ? this.storeBusinessObj.CUSTOMER : this.catalogObj['LOOKUP_CODE']) : '',
        //   attribute11: obj['SUBSTITUTE_FLAG'],
        //   attribute12: obj['ATTRIBUTE12'],
        //   attribute13: obj['ATTRIBUTE13'],
        //   attribute14: obj['ATTRIBUTE14'],
        //   attribute15: obj['ATTRIBUTE15'],
        //   attribute16: obj['ATTRIBUTE16'],
        //   attribute17: obj['ATTRIBUTE17'],
        //   attribute18: obj['ATTRIBUTE18'],
        //   attribute19: obj['ATTRIBUTE19'],
        //   attribute20: obj['ATTRIBUTE20'],
        //   attribute21: obj['ATTRIBUTE21'],
        //   attribute22: obj['ATTRIBUTE22'],
        //   attribute23: obj['ATTRIBUTE23'],
        //   attribute24: obj['ATTRIBUTE24'],
        //   attribute25: obj['ATTRIBUTE25'],
        //   attribute26: obj['ATTRIBUTE26'],
        //   attribute27: obj['ATTRIBUTE27'],
        //   attribute28: obj['ATTRIBUTE28'],
        //   attribute29: obj['ATTRIBUTE29'],
        //   attribute30: obj['ATTRIBUTE30'],

        // }
        console.log("this.storeBusinessObj",this.storeBusinessObj)

         input = {
          quantity: (obj.QUANTITY != undefined && obj.QUANTITY != null) ? obj.QUANTITY : obj['MIN_ORD_QTY'],
          kitQty: this.size,
          requestorName: this.userInfo.NTID.toUpperCase(),
          profileType: this.userRole.toUpperCase(),
          orderType: this.attribute6 && this.attribute6 != 'null' ? this.attribute6 : attribut6,
          deliveryLocationCode: this.getLocCode(),
          needByDate: this.needbyDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needbyDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (2 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),
          cifaItemNumber: obj['CIFA#'] ? obj['CIFA#'] : obj['CIFA_ITEM_NUMBER'],
          itemDesc: obj['ITEM_DESCRIPTION'] ? obj['ITEM_DESCRIPTION'] : obj['DESCRIPTION'],
          // sourceOrganizationCode: (this.functionId == '99' || this.functionId == '50' || this.functionId == '61' || (this.functionId == '136' && !this.storeBusinessObj)) ? (obj['ORGANIZATION_CODE'] ? obj['ORGANIZATION_CODE'] : (this.sourceOrg ? this.sourceOrg : '')) : "",
          sourceOrganizationCode: (this.functionId == '143' || this.functionId == '50' || this.functionId == '61' || (this.functionId == '136' && !this.storeBusinessObj)) ? (obj['ORGANIZATION_CODE'] ? obj['ORGANIZATION_CODE'] : (this.sourceOrg ? this.sourceOrg : '')) : "",
          customer:this.functionId == '136' ? (this.storeBusinessObj ? this.storeBusinessObj.CUSTOMER : this.catalogObj['LOOKUP_CODE']) : '' ,
          regionName: item['TEMPLATE_NAME'] == "ASSET RECOVERY CENTER" ? "GLOBAL" : (this.region ? this.region : this.userInfo['region']),    // hardcoding the region name particularly for Asset recovery center as required
          templateName: (this.isFavorite ? item['TEMPLATE_NAME'] : ((this.functionId == '136') ? ((this.storeBusinessObj && this.storeBusinessObj.CUSTOMER) ? this.storeBusinessObj['LOOKUP_CODE'] : item['TEMPLATE_NAME']) : this.title)),
          vendorItemNumber:obj['MANUFACTURER_PART_NUM'] ? obj['MANUFACTURER_PART_NUM'] : obj['Model#'],
          attribute9: obj['ATTRIBUTE9'],
          attribute11: obj['ATTRIBUTE11'],
          attribute12: obj['ATTRIBUTE12'],
          attribute13: obj['ATTRIBUTE13'],

          
        }
        catalogs.push(input);
        
      }
    }
    //
    else {
      // catalogs = [{
      //   cifaItemNumber: item['CIFA#'] ? item['CIFA#'] : item['CIFA_ITEM_NUMBER'],
      //   itemDescription: item['ITEM_DESCRIPTION'] ? item['ITEM_DESCRIPTION'] : item['DESCRIPTION'],
      //   itemCategory: item['ITEM_CATEGORY'] || item['Forecast Group#'],
      //   quantity: (item.QUANTITY != undefined && item.QUANTITY != null) ? item.QUANTITY : this.size,
      //   needByDate: this.needbyDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needbyDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (2 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),
      //   userName: this.userInfo.NTID.toUpperCase(),
      //   regionTemplate: (this.isFavorite ? item['TEMPLATE_NAME'] : ((this.functionId == '51') ? ((this.storeBusinessObj && this.storeBusinessObj.CUSTOMER) ? this.storeBusinessObj['LOOKUP_CODE'] : item['TEMPLATE_NAME']) : this.title)),
      //   deliveryLocationCode: this.getLocCode(),
      //   regionName: item['TEMPLATE_NAME'] == "ASSET RECOVERY CENTER" ? "GLOBAL" : (this.region ? this.region : this.userInfo['region']),    // hardcoding the region name particularly for Asset recovery center as required
      //   attribute3: this.userRole.toUpperCase(),
      //   //attribute1: this.functionId == '51' ? this.size : "",
      //   attribute1: this.functionId == '136' ? this.size : "",
      //   attribute5: item['SKU#'],
      //   attribute4: (this.functionId == '58') ? ('Order Level:' + item['Order_Level'] + "|Item Type:" + item['Item_Type'] + "|Item Condition:" + item['Item_Condition']) : null,
      //   attribute6: this.attribute6 ? this.attribute6 : attribut6,
      //   sourceOrganizationCode: (this.functionId == '99' || this.functionId == '50' || this.functionId == '61' || (this.functionId == '51' && !this.storeBusinessObj)) ? (item['ORGANIZATION_CODE'] ? item['ORGANIZATION_CODE'] : (this.sourceOrg ? this.sourceOrg : '')) : "",
      //   sourceSubInventory: (this.sourceOrg == (item['ORGANIZATION_CODE'] || item['SOURCE_ORGANIZATION_CODE'])) && this.functionId == '99' ? (this.subInv !== "" ? this.subInv : item['SOURCE_SUBINVENTORY']) : item['SOURCE_SUBINVENTORY'],
      //   vendorItemNumber: item['MANUFACTURER_PART_NUM'] ? item['MANUFACTURER_PART_NUM'] : item['Model#'],
      //   // attribute9: this.functionId == '51' ? (this.storeBusinessObj ? this.storeBusinessObj.CUSTOMER : this.catalogObj['LOOKUP_CODE']) : '',
      //   attribute9: this.functionId == '136' ? (this.storeBusinessObj ? this.storeBusinessObj.CUSTOMER : this.catalogObj['LOOKUP_CODE']) : '',
      //   attribute11: item['SUBSTITUTE_FLAG'],
      //   attribute12: item['ATTRIBUTE12'],
      //   attribute13: item['ATTRIBUTE13'],
      //   attribute14: item['ATTRIBUTE14'],
      //   attribute15: item['ATTRIBUTE15'],
      //   attribute16: item['ATTRIBUTE16'],
      //   attribute17: item['ATTRIBUTE17'],
      //   attribute18: item['ATTRIBUTE18'],
      //   attribute19: item['ATTRIBUTE19'],
      //   attribute20: item['ATTRIBUTE20'],
      //   attribute21: item['ATTRIBUTE21'],
      //   attribute22: item['ATTRIBUTE22'],
      //   attribute23: item['ATTRIBUTE23'],
      //   attribute24: item['ATTRIBUTE24'],
      //   attribute25: item['ATTRIBUTE25'],
      //   attribute26: item['ATTRIBUTE26'],
      //   attribute27: item['ATTRIBUTE27'],
      //   attribute28: item['ATTRIBUTE28'],
      //   attribute29: item['ATTRIBUTE29'],
      //   attribute30: item['ATTRIBUTE30'],
      // }]
console.log("this.storeBusinessObj",this.storeBusinessObj)
    catalogs = [{
        quantity: (item.QUANTITY != undefined && item.QUANTITY != null) ? item.QUANTITY : this.size,
        kitQty: this.size,
        requestorName: this.userInfo.NTID.toUpperCase(),
        profileType: this.userRole.toUpperCase(),
        orderType: this.attribute6 ? this.attribute6 : attribut6,
        deliveryLocationCode: this.getLocCode(),
        needByDate: this.needbyDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needbyDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (2 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),
        cifaItemNumber: item['CIFA#'] ? item['CIFA#'] : item['CIFA_ITEM_NUMBER'],
        itemDesc: item['ITEM_DESCRIPTION'] ? item['ITEM_DESCRIPTION'] : item['DESCRIPTION'],
        // sourceOrganizationCode: (this.functionId == '99' || this.functionId == '50' || this.functionId == '61' || (this.functionId == '51' && !this.storeBusinessObj) || (this.functionId == '136' && !this.storeBusinessObj)) ? (item['ORGANIZATION_CODE'] ? item['ORGANIZATION_CODE'] : (this.sourceOrg ? this.sourceOrg : '')) : "",
        sourceOrganizationCode: (this.functionId == '143' || this.functionId == '50' || this.functionId == '61' || (this.functionId == '51' && !this.storeBusinessObj) || (this.functionId == '136' && !this.storeBusinessObj)) ? (item['ORGANIZATION_CODE'] ? item['ORGANIZATION_CODE'] : (this.sourceOrg ? this.sourceOrg : '')) : "",
        customer: this.functionId == '136' ? (this.storeBusinessObj ? this.storeBusinessObj.CUSTOMER : this.catalogObj['LOOKUP_CODE']) : '',
        regionName: item['TEMPLATE_NAME'] == "ASSET RECOVERY CENTER" ? "GLOBAL" : (this.region ? this.region : this.userInfo['region']),    // hardcoding the region name particularly for Asset recovery center as required
        templateName: (this.isFavorite ? item['TEMPLATE_NAME'] : ((this.functionId == '136') ? ((this.storeBusinessObj && this.storeBusinessObj.CUSTOMER) ? this.storeBusinessObj['LOOKUP_CODE'] : item['TEMPLATE_NAME']) : this.title)),
        vendorItemNumber:item['MANUFACTURER_PART_NUM'] ? item['MANUFACTURER_PART_NUM'] : item['Model#'],
        attribute9: item['ATTRIBUTE9'],
        attribute11: item['ATTRIBUTE11'],
        attribute12: item['ATTRIBUTE12'],
        attribute13: item['ATTRIBUTE13'],
        }]
        console.log("catalogs",catalogs)
        
    }

    let object = {
      shoppingCartUpsertData: catalogs,
      sourceSystem: "TECHAPP",
      profile:this.userRole.toUpperCase(),
    };

    this.productService.addToCart(object).subscribe(resp => {
      // this.loaderAddToCart[index] = false;
      this.eventService.hideSpinner();
      this.cartLoader = false;
      this.headerCartLoader = false
      // let resp = response || {};
      let message = resp['STATUS_MESSAGE'] || resp['statusMessage'] || '';
      this.getCartItems();
      if (resp['status'] == 'SUCCESS') {
        this.commonService.updatedCart(true);

      }
      this.commonWebService.openSnackBar(message, resp['status'])
    }, error => {
      this.commonWebService.openSnackBar("Sorry! Something went wrong", "ERROR")
      this.cartLoader = false;
      this.headerCartLoader = false;
      // this.loaderAddToCart[index] = false;
      this.eventService.hideSpinner();
    })
  }

  onDeliverSiteNavigate() {
    // localStorage.setItem("page", 'catalog'); 
    //if(this.functionId == '51' && this.storeBusinessObj) {
    if (this.functionId == '136' && this.storeBusinessObj) {
      this.route.navigate(['hub2u/settings/deliver'], { state: { page: "catalog", view: this.searchOptions.view, businessUsrObj: this.storeBusinessObj, favorite: this.isFavorite ? true : false } });
    }
    //else if(this.functionId == '51' && !this.storeBusinessObj) {
    else if (this.functionId == '136' && !this.storeBusinessObj) {
      this.route.navigate(['hub2u/settings/deliver'], { state: { page: "catalog", view: this.searchOptions.view, catalogObj: this.catalogObj, favorite: this.isFavorite ? true : false } });
    } else if (this.functionId == '61' || this.functionId == '58' || this.functionId == '57') {
      this.route.navigate(['hub2u/settings/deliver'], { state: { page: "catalog", view: this.searchOptions.view, catalogObj: this.catalogObj, favorite: this.isFavorite ? true : false } });
    } else {
      this.route.navigate(['hub2u/settings/deliverToLoc'], { state: { page: "catalog", view: this.searchOptions.view, catalogObj: this.catalogObj, favorite: this.isFavorite ? true : false } });
    }

  }

  getCallCount(event) {
    this.callCount = event['CALL_COUNT']
    this.countInList = this.callCount
    this.multiCall = event['MULTI_CALL']
    this.totalCount = event['CATALOG_CNT']
  }

  checkCifaSubstitute(item) {
    this.eventService.showSpinner();
    let object = {
      ReportId: "60200",
      ParametersInput: [
        {
          Name: "TEMPLATE_NAME",
          Value: item.TEMPLATE_NAME
        },
        {
          Name: "REGION_NAME",
          Value: item.REGION_NAME
        },
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        },
        {
          Name: "CIFA_ITEM_NUMBER",
          Value: item.CIFA_ITEM_NUMBER
        }
      ]
    };
    this.reportsService.onGetDynamicReport(object).subscribe(response => {
      this.eventService.hideSpinner();
      if (response && response.ROW) {
        this.cifaSubsList = response.ROW || []
        this.dialog.open(this.openCifaSubstitutePopup)
      }
    }, error => {
      this.eventService.hideSpinner();
      this.commonWebService.openSnackBar("Sorry! Something went wrong", "ERROR")
    });
  }

  getCartItems() {
    let object = {
      ReportId: this.constantData.cartDynamicId[this.functionId],
      ParametersInput: [
        {
          Name: "REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.onGetDynamicReport(object).subscribe(response => {
      this.cartItems = response.ROW || [];
    }, error => {
    });
  }

  addItem(size: number, item: any) {
    item.QUANTITY = size;

    let obj = {}
    if (this.storeQuantity.length != 0) {
      this.storeQuantity.forEach(element => {
        element[item.RECORD_ID] = item.QUANTITY
      })
    }
    else {  // when length == 0
      obj[item.RECORD_ID] = item.QUANTITY
      this.storeQuantity.push(obj)
    }
    //if (this.functionId == '51')
    if (this.functionId == '136')
      sessionStorage.setItem(this.userInfo.NTID + "Quantity", JSON.stringify(this.storeQuantity));
  }

  receiveRegion(event) {
    this.region = event;
  }

  showHideFilter(event) {
    this.isFilterTab = event;
  }

  // onAddToFavorites(item: any, index) {
  //   //item['favorite'] = 'yes';
  // let request = {
  //   "REQUESTOR_USER_NAME": this.userInfo.NTID,
  //   "CIFA_ITEM_NUMBER": item.CIFA_ITEM_NUMBER || item['CIFA#'],
  //   "CATEGORY": item.ITEM_CATEGORY || item['Forecast Group#'],
  //   "ITEM_DESCRIPTION": item.ITEM_DESCRIPTION,
  //   "REGION_NAME": item.REGION_NAME,
  //   "TEMPLATE_NAME": item.TEMPLATE_NAME,
  //   "ADD_TO_FAV": 'Y',
  //   "VENDOR_ITEM_NUMBER": item.MANUFACTURER_PART_NUM,
  //   "MFG_PART_NUMBER": item.MANUFACTURER_PART_NUM || item['Model#'],
  //   "INVENTORY_ITEM_ID": item['INVENTORY_ITEM_ID'],
  //   "ATTRIBUTE1": this.functionId == '64' ? item['ATTRIBUTE1'] : null,
  //   "ATTRIBUTE2": this.functionId == '64' ? item['ATTRIBUTE8'] : null,
  //   "ATTRIBUTE3": this.functionId == '64' ? item['ATTRIBUTE3'] : null,
  //   "ATTRIBUTE4": this.functionId == '64' ? item['ATTRIBUTE4'] : null,
  //   "ATTRIBUTE5": this.functionId == '64' ? item['ATTRIBUTE5'] : null,
  // };

  //   this.loaderFavorite[index] = true;
  //   this.favLoader = index === '-1' ? true : false;
  //   this.productService.addToFavorite(request).subscribe(response => {
  //     this.loaderFavorite[index] = false;
  //     this.favLoader = false;

  //     let resp = response['InsertFavoriteOutput'] || [];
  //     let message = resp['STATUS_MESSAGE'] || '';
  //     this.eventService.hideSpinner();
  //     if (resp['STATUS'] === 'SUCCESS') {
  //       item['ADD_TO_FAV'] = 'Y';
  //     }
  //     if (resp['STATUS'] === 'ERROR') {
  //       this.commonWebService.openSnackBar(message, "WARNING")
  //       item['ADD_TO_FAV'] = 'N';
  //     }
  //   }, error => {
  //     this.eventService.hideSpinner();
  //     this.loaderFavorite[index] = false;
  //     this.commonWebService.openSnackBar("Something went wrong", "ERROR")
  //   }) 
  // }

  /**SOA TO JAVA */
  onAddToFavorites(item: any, index) {
    //item['favorite'] = 'yes';
    let request = {
      "profile":this.userRole.toUpperCase(),
      "requestorUserName": this.userInfo.NTID,
      "cifaItemNumber": item.CIFA_ITEM_NUMBER || item['CIFA#'],
      "category": item.ITEM_CATEGORY || item['Forecast Group#'],
      "itemDescription": item.ITEM_DESCRIPTION,
      "regionName": item.REGION_NAME,
      "templateName": item.TEMPLATE_NAME,
      "addToFav": 'Y',
      "vendorItemNumber": item.MANUFACTURER_PART_NUM,
      "mfgPartNumber": item.MANUFACTURER_PART_NUM || item['Model#'],
      "inventoryItemId": item['INVENTORY_ITEM_ID'],
      "attribute1": this.functionId == '64' ? item['ATTRIBUTE1'] : null,
      "attribute2": this.functionId == '64' ? item['ATTRIBUTE8'] : null,
      "attribute3": this.functionId == '64' ? item['ATTRIBUTE3'] : null,
      "attribute4": this.functionId == '64' ? item['ATTRIBUTE4'] : null,
      "attribute5": this.functionId == '64' ? item['ATTRIBUTE5'] : null,
    };

    this.loaderFavorite[index] = true;
    this.favLoader = index === '-1' ? true : false;
    this.productService.addToFavorite(request).subscribe(response => {
      this.loaderFavorite[index] = false;
      this.favLoader = false;

      let resp = response['favoriteOutput'] || [];
      let message = resp['statusMessage'] || '';
      this.eventService.hideSpinner();
      if (resp['status'] === 'SUCCESS') {
        item['ADD_TO_FAV'] = 'Y';
      }
      if (resp['status'] === 'FAILED') {
        this.commonWebService.openSnackBar(message, "WARNING")
        item['ADD_TO_FAV'] = 'N';
      }
    }, error => {
      this.eventService.hideSpinner();
      this.loaderFavorite[index] = false;
      this.commonWebService.openSnackBar("Something went wrong", "ERROR")
    })
  }

  // onDeleteFav(item, index) {
  //   if (index == '-1') {
  //     this.singleProductView = !this.singleProductView;
  //     this.loader = true;
  //   }
  //   let object = {
  //     REQUESTOR_USER_NAME: this.userInfo.NTID,
  //     CIFA_ITEM_NUMBER: item['CIFA_ITEM_NUMBER'] || item['CIFA#']
  //   };
  //   if (this.functionId == '61') {
  //     object['MFG_PART_NUMBER'] = item['MANUFACTURER_PART_NUM']
  //   }
  //   this.loaderFavorite[index] = true;
  //   this.productService.onDeleteFavorite(object).subscribe(response => {
  //     this.loaderFavorite[index] = false;
  //     let resp = response['DeleteFavoriteOutput'] || [];
  //     let message = resp['STATUS_MESSAGE'] || '';
  //     this.onfetchReport('Favorites', '', this.userRole);
  //     if (resp['STATUS'] === 'SUCCESS') {
  //       this.commonWebService.openSnackBar(message, "SUCCESS")
  //     }
  //     if (resp['STATUS'] === 'ERROR') {
  //       this.commonWebService.openSnackBar(message, "ERROR")
  //     }
  //   }, error => {
  //     this.loaderFavorite[index] = false;
  //     this.commonWebService.openSnackBar("Sorry! Something went wrong hence cannot delete the selected item from Favorites.", "ERROR")
  //     if (index == '-1') {
  //       this.onfetchReport('Favorites', '', this.userRole);
  //     }
  //   });
  // }

  /**SOA TO JAVA */
  onDeleteFav(item, index) {
    if (index == '-1') {
      this.singleProductView = !this.singleProductView;
      this.loader = true;
    }
    let object = {
      requestorUserName: this.userInfo.NTID,
      cifaItemNumber: item['CIFA_ITEM_NUMBER'] || item['CIFA#'],
      profile:this.userRole.toUpperCase()
    };
    if (this.functionId == '61') {
      object['mfgPartNumber'] = item['MANUFACTURER_PART_NUM']
    }
    this.loaderFavorite[index] = true;
    this.productService.onDeleteFavorite(object).subscribe(response => {
      this.loaderFavorite[index] = false;
      let resp = response['favoriteOutput'] || [];
      let message = resp['statusMessage'] || '';
      this.onfetchReport('Favorites', '', this.userRole);
      if (resp['status'] === 'SUCCESS') {
        this.commonWebService.openSnackBar(message, "SUCCESS")
      }
      if (resp['status'] === 'FAILED') {
        this.commonWebService.openSnackBar(message, "ERROR")
      }
    }, error => {
      this.loaderFavorite[index] = false;
      this.commonWebService.openSnackBar("Sorry! Something went wrong hence cannot delete the selected item from Favorites.", "ERROR")
      if (index == '-1') {
        this.onfetchReport('Favorites', '', this.userRole);
      }
    });
  }

  onScrollDown() {
    if (this.catalogList == this.pagedItems) {
      return;
    }
    const start = this.sum;
    this.sum += 10;
    this.appendItems(start, this.sum);
  }

  appendItems(startIndex, endIndex) {
    if (startIndex == 0) {
      this.sum = 10
      endIndex = this.sum
    }
    this.addItems(startIndex, endIndex, "push");
  }

  addItems(startIndex, endIndex, _method) {
    let end = endIndex
    if (endIndex >= this.catalogList.length) {
      end = this.catalogList.length
    }
    if (startIndex == 0) {
      this.pagedItems = [];
    }
    for (let i = startIndex; i < end; ++i) {
      this.pagedItems[_method](this.catalogList[i]);
    }
  }

  updateColor() {
    return 'primary';

    //return 'accent';

    //return 'warn';

  }

  // onScroll(): void {
  //   this.commentService
  //     .getCommentaries(++this.page)
  //     .subscribe((commentaries: Comment[]) => {
  //       this.commentaries.push(...commentaries);
  //     });
  // }


}