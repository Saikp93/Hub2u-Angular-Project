import { C } from '@angular/cdk/keycodes';
import { Component, EventEmitter, Input, OnInit, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSelectionList } from '@angular/material/list';
import { MatRadioChange } from '@angular/material/radio';
import { ReportsService, ConstantData, RequestObject, ProductService, FilterpipePipe } from 'hub2ushared';
import { CommonSettingService } from '../../../shared/common-settings.service';
import { StorePreferenceService } from '../../../shared/store-preference.service';
import { StorePreferenceDbService } from 'projects/hub2ushared/src/lib/services/store-preference-db.service';

@Component({
  selector: 'app-filters',
  providers: [FilterpipePipe],
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FiltersComponent implements OnInit {
  @Input() tags: any;
  @Input() userRole: any;
  @Input() retainUsrData: any;
  @Input() isFavorite: any;
  @Input() loader: boolean = true;
  @Output() searchEvent = new EventEmitter<any>();
  @Output() filterEvent = new EventEmitter<any>();
  @Output() onProductReload = new EventEmitter<any>();
  @Output() emitTitle = new EventEmitter<any>();
  @Output() regionOutput = new EventEmitter<any>();
  @Output() filters = new EventEmitter<any>();
  @Output() attribute6 = new EventEmitter<any>();
  @Output() callCount = new EventEmitter<any>();
  panelState: boolean = false;
  filterForm: FormGroup = this.fb.group({
    itemType: ['Regional']
  });;
  Categories: any[] = [];
  subCategories: any[] = [];
  userInfo: any = {};
  kitsLoader = false;
  customerLoader = false;
  catalogLoader = false;
  expand: boolean;
  filterloader = false;
  searchCatalog = new FormControl();
  searchKits = new FormControl('');
  searchCustomers = new FormControl();

  dropdowns = {
    catalogs: [],
    customers: [],
    kits: []
  };

  seletedFilters: any = {
    catalogs: null,
    tags: [],
    kits: [],
    customers: []
  };

  showTotalList: boolean = false;
  selectedCusIndex: any;
  selectedKitIndex: any;
  region: any;
  selectedCatIndex: any;
  selectedChange: { index: null; };
  title: any;
  selected: boolean = false;
  retain: boolean = false;
  toggle: boolean;
  showFilterBar: boolean = false;
  person_id: any;
  functionId;
  expandTags = false;
  dataRetained: boolean = false;
  userDBDetails: any;
  name: any = "catalogs_tags";
  tagsPreference: any = "count";
  constructor(private fb: FormBuilder, private comSettingService: CommonSettingService, private filterpipe: FilterpipePipe, private reportsService: ReportsService, private constantData: ConstantData,
    private productService: ProductService, private requestObject: RequestObject, private storePreferenceService: StorePreferenceService,  private storePreferenceDbService: StorePreferenceDbService) { 
    }
  @ViewChild('catalogs') private catalogs: MatSelectionList;
  @ViewChild('customers') private customers: MatSelectionList;
  @ViewChild('kits') private kits: MatSelectionList;

  ngOnInit() {
    if (sessionStorage.getItem("Prev_Url") == '/hub2u/catalog/cart') {
      this.filterEvent.emit({ value: 'null' });
    }
    this.initialize() 

  }
  async initialize() {
    let userInfo = await localStorage.getItem("userDetails");
    this.userInfo = JSON.parse(userInfo);
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.person_id = sessionStorage.getItem("personId" + this.userInfo.NTID) ? sessionStorage.getItem("personId" + this.userInfo.NTID) : ""
    this.onInitialLoad();
    this.initForm();
    this.filterForm.valueChanges.subscribe(() => {
      this.sendMessage();
    });
    if (!this.retainUsrData) {
      this.checkIfDataInStorage();
    }
    if (this.retainUsrData && !this.isFavorite) {
      this.retain = true;
      if (this.functionId == 51 && this.retainUsrData['CUSTOMER']) {
          if (this.dropdowns.kits.length == 0) {
            this.onkitsDropdown(this.retainUsrData, this.retainUsrData['CUSTOMER']);
            if (this.seletedFilters.kits.length == 0)
              this.seletedFilters.kits.push(this.retainUsrData);
          } else {
            this.selectedCusIndex = this.retainUsrData['CUSTOMER'];
          }
          this.selectedKitIndex = this.retainUsrData['LOOKUP_CODE'];
          this.emitTitle.emit({ title: this.title, description: this.retainUsrData.CATALOG_DESC, logo: this.retainUsrData.CATALOG_IMAGE, subtitle: this.retainUsrData.MEANING });
          this.loadData();
      }
      else {
        let obj = sessionStorage.getItem(this.userInfo.NTID + "catalogObj");
        this.retainUsrData = JSON.parse(obj);
        if (this.retainUsrData != null) {
          this.selectedCatIndex = this.retainUsrData['MEANING'];
          this.emitTitle.emit({ title: this.retainUsrData['LOOKUP_CODE'], description: this.retainUsrData.CATALOG_DESC, logo: this.retainUsrData.CATALOG_IMAGE })
          this.callCount.emit(this.retainUsrData)
          this.seletedFilters.catalogs = this.retainUsrData;
        }
        //this.onTypeChange(this.retainUsrData, this.retainUsrData['CATALOG_INDEX'])
      }
    }

  }

  ngOnChanges() {
    if (this.tags.length > 0 && !this.isFavorite) {
      this.onTagsChange();
      this.expandTags = true;
    }
    else
      this.expandTags = false;
    // this.checkIfDataInStorage();
    // this.initialize() ;
  }

  changeItemType(event) {
    this.filterForm.value.itemType = event.value;
    this.checkIfDataInStorage();
    this.sendMessage();
  }

  checkIfDataInStorage() {
    if (!this.isFavorite) {

      if (sessionStorage.getItem(this.userInfo.NTID + "businessUsrObj") && sessionStorage.getItem(this.userInfo.NTID + "businessUsrObj") != "" && !sessionStorage.getItem(this.userInfo.NTID + "catalogObj")) {
        let obj = sessionStorage.getItem(this.userInfo.NTID + "businessUsrObj");
        this.retainUsrData = JSON.parse(obj)

        this.onkitsDropdown(this.retainUsrData, this.retainUsrData['CUSTOMER']);
        this.selectedKitIndex = this.retainUsrData['LOOKUP_CODE'];
        if (this.seletedFilters.kits.length == 0) {
          this.seletedFilters.kits.push(this.retainUsrData);
        }
        this.emitTitle.emit({ title: this.retainUsrData.CUSTOMER, description: this.retainUsrData.CATALOG_DESC, logo: this.retainUsrData.CATALOG_IMAGE, subtitle: this.retainUsrData.MEANING })
      }

      if (sessionStorage.getItem(this.userInfo.NTID + "catalogObj") && sessionStorage.getItem(this.userInfo.NTID + "catalogObj") != "") {
        let obj = sessionStorage.getItem(this.userInfo.NTID + "catalogObj");
        this.retainUsrData = JSON.parse(obj);
        this.selectedCatIndex = this.retainUsrData['MEANING'];
        this.emitTitle.emit({ title: this.retainUsrData['LOOKUP_CODE'], description: this.retainUsrData.CATALOG_DESC, logo: this.retainUsrData.CATALOG_IMAGE })
        this.callCount.emit(this.retainUsrData)
      }
    }
  }

  async onInitialLoad() {
    this.retain = false;
    if (sessionStorage.getItem("listOfCatalogs" + this.userInfo.NTID)) {        // not for BSU
      let obj = sessionStorage.getItem("listOfCatalogs" + this.userInfo.NTID);
      this.subCategories = JSON.parse(obj);
      this.Categories = JSON.parse(obj);
      if (this.isFavorite) {
        this.filterForm.value.itemType = 'Favorites'
        this.sendMessage();
      } else {
        this.filterForm.value.itemType = 'Regional'
      }
      if (!this.retainUsrData && !this.isFavorite)   // on very first load only
        this.sendMessage();
      else {
        this.loadData();
      }
    } else {
      this.getRequestorId();
      // if(this.functionId == '51')
      if(this.functionId == '136')
        this.onLoadCatalogList();
    }
  }
  filterCatalog(val) {
    this.dropdowns.customers = this.filterpipe.transform(this.dropdowns.customers, val);
  }
  getRequestorId() {
    this.customerLoader = true;
    let request = {
      //ReportId: 112,
      // ReportId: 7001,
      ReportId:this.constantData.userprofileData[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    }
    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response) {
        if (response.ROW != undefined) {
          this.person_id = response.ROW[0].PERSON_ID;
          // if (this.functionId == 99) {
            if (this.functionId == 143) {
            this.attribute6.emit(response.ROW[0].ATTRIBUTE5);
          }
          this.getItems();
        } else {
          this.customerLoader = false;
        }
      }
    })
  }

  getItems() {
    //if (this.userRole === 'Comcast Business Services User ') {
      if (this.userRole === 'Comcast Business Services User iip') {
      
      this.loadRegion();
      this.onLoadDropdownList();
    }
    else
      this.loadRegion();
  }

  initForm() {
    if (this.isFavorite) {
      this.filterForm = this.fb.group({
        itemType: ['Favorites']
      });
    }
    else {
      this.filterForm = this.fb.group({
        itemType: ['Regional']
      });
    }
  }

  openFilter(event) {
    if (event == "open") {
      this.showFilterBar = false;
      this.filters.emit(true);
    }
    else {
      this.showFilterBar = true;
      this.filters.emit(false);
    }
  }

  clearAllFilters() {
    if (sessionStorage.getItem(this.userInfo.NTID + "businessUsrObj"))
      sessionStorage.setItem(this.userInfo.NTID + "businessUsrObj", "");
    if (sessionStorage.getItem(this.userInfo.NTID + "catalogObj"))
      sessionStorage.setItem(this.userInfo.NTID + "catalogObj", "");
    this.retainUsrData = null;
    this.seletedFilters.catalogs = null;
    this.selectedCatIndex = null;
    this.seletedFilters.tags = [];
    this.seletedFilters.kits = [];
    this.seletedFilters.customers = []; 
    this.catalogs.deselectAll();
    this.selectedKitIndex = null;
    this.selectedCusIndex = null;
    this.kits.deselectAll();
    this.tags = [];
    this.dropdowns.kits = [];
    this.selectedChange = undefined;
    this.filterEvent.emit({ value: 'null' });
    this.searchCustomers.setValue('');
    this.searchKits.setValue('');
    this.searchCatalog.setValue('');
  }

  sendMessage() {
    if (this.filterForm.value.itemType == 'Regional') {
      this.isFavorite = false;
    }
    else {
      this.isFavorite = true;
    }
    this.checkIfDataInStorage();
    this.searchKits.setValue('');
    this.searchCustomers.setValue('');
    if (!this.selectedChange && !this.retainUsrData && !this.isFavorite && this.Categories[0]) {   // for first load of page
      this.seletedFilters.catalogs = this.Categories[0];
      this.selectedCatIndex = this.Categories[0]['MEANING'];
      // if (this.functionId != '51' && this.Categories.length > 0) {
        if (this.functionId != '136' && this.Categories.length > 0) {
        this.emitTitle.emit({ title: this.Categories[0]['LOOKUP_CODE'], description: this.Categories[0].CATALOG_DESC, logo: this.Categories[0].CATALOG_IMAGE })
        this.callCount.emit(this.Categories[0])
        this.Categories[0]['CATALOG_INDEX'] = 0;
        sessionStorage.setItem(this.userInfo.NTID + "catalogObj", JSON.stringify(this.Categories[0]));
      }
    }

    if (this.retainUsrData && this.retainUsrData.CUSTOMER && !this.isFavorite) {
      this.onProductReload.emit(this.retainUsrData)
    } else {
      this.selectedChange = { index: this.retainUsrData }
      this.filterEvent.emit({ nav: this.filterForm.value, type: 'form', value: (this.selectedChange && this.selectedChange.index) ? this.selectedChange.index : this.Categories[0] });
    }
  }

  onTypeChange(value, index) {        // Catalogs
    this.selectedChange = { index: value }
    this.seletedFilters.catalogs = value;
    this.selectedCatIndex = value['MEANING'];
    this.tags = [];
    this.selectedCusIndex = null;
    this.selectedKitIndex = null;
    this.seletedFilters.customers = [];
    this.seletedFilters.kits = [];
    this.dropdowns.kits = [];
    value['CATALOG_INDEX'] = index;
    if (this.userInfo.NTID != undefined) {
      sessionStorage.setItem(this.userInfo.NTID + "catalogObj", JSON.stringify(value));
    }
    this.filterEvent.emit({ nav: this.filterForm.value, type: 'category', value: value });
    this.emitTitle.emit({ title: value['LOOKUP_CODE'], description: value.CATALOG_DESC, logo: value.CATALOG_IMAGE })
    this.callCount.emit(value)
  }

  getSubCategories() {
    this.loadCategories();
  }

  loadCategories() {
    let requestObj = {
      "ReportId": this.constantData.catalogs[this.functionId],
      "ParametersInput": [
        { "Name": "REQUESTOR_USER_NAME", "Value": this.userInfo.NTID },
        {
          "Name": "REGION_NAME", "Value": this.region ? this.region : 'null'
        }
      ]
    }
    this.getCatagories(requestObj);
  }

  loadRegion() {
    this.customerLoader = true;
    let request = {
      "ReportId": this.constantData.regionReportId[this.functionId],
      "ParametersInput": [
        {
          "Name": "REQUESTOR",
          "Value": this.userInfo.NTID
        }
      ]
    };
    this.reportsService.onGetDynamicReport(request).subscribe(repsonse => {
      if (repsonse.ROW !== undefined) {
        this.region = repsonse.ROW[0].LOOKUP_CODE;
        this.regionOutput.emit(this.region);
        this.userInfo['region'] = this.region;
        localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
        // if (this.userRole != 'Comcast Business Services User')
        if (this.userRole != 'Comcast Business Services User iip')
          this.getSubCategories();
        // else {
        //   this.loadData();
        // }
      }
      else {
        // if (this.userRole != 'Comcast Business Services User')
        if (this.userRole != 'Comcast Business Services User iip')
          this.getSubCategories();
        // else
        //   this.loadData();
      }
    }, error => {
      this.customerLoader = false;
    });
  }

  getCatagories(object) {
    this.reportsService.onGetDynamicReport(object).subscribe(res => {
      this.Categories = res.ROW || [];
      sessionStorage.setItem("listOfCatalogs" + this.userInfo.NTID, JSON.stringify(this.Categories))
      if (!this.retainUsrData)   // on very first load only
        this.sendMessage();
      else {
        this.loadData();
      }
      //this.subCategories = this.Categories.slice(0, 5);
      this.subCategories = this.Categories
      this.customerLoader = false;
    }, error => {
      this.customerLoader = false;
    })
  }

  loadData() {
    if (this.retainUsrData && !this.isFavorite) {
      this.retain = true;
      if (this.functionId == 51) {
        this.onkitsDropdown(this.retainUsrData, this.retainUsrData['CUSTOMER']);
        this.onselectKit(this.retainUsrData, this.retainUsrData['LOOKUP_CODE']);
      }
      else {
        this.onTypeChange(this.retainUsrData, this.retainUsrData['CATALOG_INDEX'])
      }
      
    }
  }

  onExpandCollapse() {
    this.filterloader = true;
    this.toggle = true;
    if (this.expand == true) {
      this.expand = false;
      this.selected = true;
    }
    else {
      this.expand = true;
      this.selected = false;
    }
    setTimeout(() => {
      this.filterloader = false;
    }, 300);
  }

  onLoadDropdownList() {
    let request = {
      "ReportId": this.functionId == '136'?"7006":"10102",
      // "ReportId": 10102,
      // "ReportId": 7006,
      "ParametersInput": [
        {
          "Name": "REQUESTOR_USER_NAME",
          "Value": this.userInfo.NTID
        },
        {
          "Name": "DELIVERY_TO_LOCATION",
          "Value": "null"
        }]
    };
    this.reportsService.onGetDynamicReport(request).subscribe(x => {
      this.dropdowns.customers = x['ROW'] || [];
      this.customerLoader = false;
    }, error => {
      this.customerLoader = false;
    });

  }

  onLoadCatalogList() {
    this.catalogLoader = true;
    let request = {
      // "ReportId": 10263, 
      "ReportId": 7024, 
      "ParametersInput": [
        {
          "Name": "USER_NAME",
          "Value": this.userInfo.NTID
        }]
    };
    this.reportsService.onGetDynamicReport(request).subscribe(x => {
      if(x['ROW']){
        this.dropdowns.catalogs = x['ROW'] || [];
        let obj = sessionStorage.getItem(this.userInfo.NTID + "catalogObj");
        if(obj && !this.isFavorite) {
          let catalogObj = JSON.parse(obj);
          this.selectedCatIndex = catalogObj['MEANING']
          this.onProductReload.emit(catalogObj);
          this.seletedFilters.catalogs = catalogObj
          this.title = this.selectedCatIndex
          this.emitTitle.emit({ title: this.title })
        }
        let bsuObj = sessionStorage.getItem(this.userInfo.NTID + "businessUsrObj")
        if(!bsuObj && !obj && !this.isFavorite) {                                   // on very first load
          this.selectedCatIndex = x['ROW'][0]['MEANING']
          sessionStorage.setItem(this.userInfo.NTID + "catalogObj", JSON.stringify(x['ROW'][0]));
          this.onProductReload.emit(x['ROW'][0]);
          this.seletedFilters.catalogs = x['ROW'][0]
          this.title = this.selectedCatIndex
          this.emitTitle.emit({ title: this.title })
        } 
        this.catalogLoader = false;
      }else{
        if(!this.isFavorite) {
          this.catalogLoader = false;
          this.filterEvent.emit({ value: 'initialLoad' });
        }
      }            
    }, error => {
      this.catalogLoader = false;
    });

  }

  openPanel() {
    this.selected = false;
  }

  onkitsDropdown(item, index) {     // Customers
    this.selectedCatIndex = null;
    this.seletedFilters.catalogs = null;
    if (sessionStorage.getItem(this.userInfo.NTID + "catalogObj"))
      sessionStorage.setItem(this.userInfo.NTID + "catalogObj", "");

    this.seletedFilters.customers = [];
    this.searchKits.setValue('');
    this.selected = true;
    this.toggle = false;
    this.selectedCusIndex = item['CUSTOMER'];
    this.selectedKitIndex = null;
    this.kitsLoader = true;
    this.seletedFilters.kits = [];
    this.seletedFilters.customers.push(item);
    let request = {
      // "ReportId": 10100,
      // "ReportId":7008,
      "ReportId": this.functionId == '136'?"7008":"10100",
      "ParametersInput": [
        { "Name": "CUSTOMER", "Value": item.CUSTOMER },
        { "Name": "REQUESTOR_USER_NAME", "Value": JSON.parse(localStorage.getItem("userDetails")).NTID }
      ]
    };
    this.dropdowns.kits = [];
    this.reportsService.onGetDynamicReport(request).subscribe(x => {
      let rows = x['ROW'] || [];
      rows.forEach(y => {
        y['CUSTOMER'] = item.CUSTOMER;
      });

      this.dropdowns.kits = rows;
      this.kitsLoader = false;
    }, error => {
      this.kitsLoader = false;
    });
    this.title = item.CUSTOMER
    this.filterEvent.emit({ value: 'null' });
    this.emitTitle.emit({ title: item.CUSTOMER })
  }

  onselectKit(item, index) {      // Kits
    this.seletedFilters.kits = [];
    this.selectedKitIndex = item['LOOKUP_CODE'];
    item['CUSTOMER'] = this.selectedCusIndex;
    item['LOOKUP_CODE'] = this.selectedKitIndex;
    this.seletedFilters.kits.push(item);
    if (this.retain == false) {
      this.comSettingService.setdeliverSite(null);
      this.retain = false;
    }
    this.onProductReload.emit(item);
    if (this.userInfo.NTID != undefined && item.CUSTOMER) {
      sessionStorage.setItem(this.userInfo.NTID + "businessUsrObj", JSON.stringify(item));
    }
    this.emitTitle.emit({ title: this.title, description: item.CATALOG_DESC, logo: item.CATALOG_IMAGE, subtitle: item.MEANING })
  }

  onShowMore() {
    this.showTotalList = !this.showTotalList;
    this.subCategories = this.showTotalList ? this.Categories : this.Categories.slice(0, 5);
  }

  onTagsChange() {      // Tags
    let seletedTags = [];
    this.tags.forEach(x => {
      if (x.selected) {
        seletedTags.push(x);
      }
    });
    this.seletedFilters.tags = seletedTags;
    let obj = sessionStorage.getItem(this.userInfo.NTID + "catalogObj");
    let catalogObj = JSON.parse(obj);
    if (this.tags.length > 0) {
      catalogObj['TAGS'] = seletedTags;
    }
    sessionStorage.setItem(this.userInfo.NTID + "catalogObj", JSON.stringify(catalogObj));
    this.filterEvent.emit({ nav: this.filterForm.value, type: 'tags', value: seletedTags }); 

    this.getTagPreference();
  }

  cancel(type, item) {
    this.retainUsrData = null;
    if (sessionStorage.getItem(this.userInfo.NTID + "businessUsrObj"))
      sessionStorage.setItem(this.userInfo.NTID + "businessUsrObj", "");

    if (type == 'filterBy') {
      this.filterEvent.emit({ type: 'filterBy', close: true });
      this.seletedFilters.catalogs = null;
      this.selectedCatIndex = null;
      this.seletedFilters.tags = [];
      this.tags = [];
      this.catalogs.deselectAll();
      this.selectedChange = undefined;
      if (sessionStorage.getItem(this.userInfo.NTID + "catalogObj"))
        sessionStorage.setItem(this.userInfo.NTID + "catalogObj", "");
    }
    if (type == 'tags') {
      this.tags.forEach(x => {
        if (x.name == item && x.selected) {
          x.selected = false;
        }
      });

      this.seletedFilters.tags = this.seletedFilters.tags.filter(x => x.name != item);
      this.onTagsChange();
      //this.filterEvent.emit({ nav: this.filterForm.value, type: 'tags', value: this.seletedFilters.tags });
    }
    if (type == 'kits') {
      this.seletedFilters.kits = [];
      this.seletedFilters.tags = [];
      this.selectedKitIndex = null;
      this.kits.deselectAll();
      this.tags = [];
      this.filterEvent.emit({ value: 'null' });
    }
    if (type == 'customers') {
      this.seletedFilters.kits = [];
      this.seletedFilters.tags = [];
      this.seletedFilters.customers = [];
      this.selectedKitIndex = null;
      this.selectedCusIndex = null;
      this.kits.deselectAll();
      this.tags = [];
      this.dropdowns.kits = [];
      this.filterEvent.emit({ value: 'null' });
    }
  }

  // handleBookmark(item, orderBy) {
  //   item.ORDER_BY = orderBy;
  //   let actionType = orderBy == 1 ? "I" : "D";
  //   let request = {
  //     Action_Type: actionType,
  //     Inputcollection: [{
  //       Lookup_Code: item.LOOKUP_CODE,
  //       NTID: this.userInfo.NTID,
  //       Region_Name: this.userInfo['region'],
  //       Requestor_Id: this.person_id ? this.person_id.toString() : "",
  //     }]
  //   }
  //   this.productService.favoriteList(request).subscribe(response => {

  //   })
  // }

  /**SOA TO JAVA */
  handleBookmark(item, orderBy) {
    item.ORDER_BY = orderBy;
    let actionType = orderBy == 1 ? "I" : "D";
    let request = {
      actionType: actionType,
      inputCollection: [{
        lookupCode: item.LOOKUP_CODE,
        ntId: this.userInfo.NTID,
        regionName: this.userInfo['region'],
        requestorId: this.person_id ? this.person_id.toString() : "",
      }]
    }
    this.productService.favoriteList(request).subscribe(response => {
      if (response['status'] && response['status'].toLowerCase() == 'success') {
        // if (sessionStorage.getItem("listOfCatalogs" + this.userInfo.NTID)) {
        //   let obj = sessionStorage.getItem("listOfCatalogs" + this.userInfo.NTID);
        //   this.Categories = JSON.parse(obj);
        //   this.Categories.map(obj => {
        //     if (obj.LOOKUP_CODE == item.LOOKUP_CODE) {
        //       obj.ORDER_BY = (obj.ORDER_BY == 1 ? 2 : 1)
        //     }
        //   })
        //   sessionStorage.setItem("listOfCatalogs" + this.userInfo.NTID, JSON.stringify(this.Categories))
        // }
        let requestObj = {
          "ReportId": this.constantData.catalogs[this.functionId],
          "ParametersInput": [
            { "Name": "REQUESTOR_USER_NAME", "Value": this.userInfo.NTID },
            {
              "Name": "REGION_NAME", "Value": this.userInfo['region'],
            }
          ]
        }
        this.reportsService.onGetDynamicReport(requestObj).subscribe(res => {
          let categories = res.ROW || [];
          if(categories && categories.length > 0) {
            sessionStorage.setItem("listOfCatalogs" + this.userInfo.NTID, JSON.stringify(categories))
          }
        }, error => {
        })
      }

    })
  }

  changeTagsPreference() {
    if (this.tagsPreference == "count"){
      this.tags = this.tags.sort((a, b) => b.value - a.value);
    } else {
      this.tags = this.tags.sort((a, b) => a.name.localeCompare(b.name));
    }
  }

  storeTagsPreference() {
    let con = this.storePreferenceService.storePreference(this.userDBDetails, this.name, "", "", this.tagsPreference)
    // console.log(con);
  }

  clearTagsPreference() {
    this.storePreferenceService.clearPreference(this.userDBDetails, this.name, "", "", this.tagsPreference)
  }

  getTagPreference(){
    var inputData = {
      "applicationName": "HUB2U",
      "userName": this.userInfo.NTID
    }

    let promise = this.storePreferenceDbService.getPreferencefromDB(inputData).toPromise();

    promise.then((data) => {
     if(data) {
      this.userDBDetails = data[0];
      if(this.userDBDetails){
        this.userDBDetails.pageDetails.forEach(page => {
          if (page.name == "catalogs_tags"){
            if(page.columns == "alphabetic"){
              this.tagsPreference = "alphabetic"
              this.tags = this.tags.sort((a, b) => a.name.localeCompare(b.name));
            }
          }
        })
      }
     }
    })
  }
}