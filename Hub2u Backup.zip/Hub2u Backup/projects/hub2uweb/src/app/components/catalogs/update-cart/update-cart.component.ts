import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CartComponent } from '../cart/cart.component';
import { CommonSettingService } from '../../../shared/common-settings.service';

@Component({
  selector: 'app-update-cart',
  templateUrl: './update-cart.component.html',
  styleUrls: ['./update-cart.component.scss'],
})
export class UpdateCartComponent implements OnInit {

  projDetails = [{ key: 'Update Project Details', value: 'projectdetails' }, { key: 'Update Other Details', value: 'otherdetails' }];
  projDetail = this.projDetails[0].value;
  fieldDetails = ['Need By Date', 'Expenditure Item Date', 'Source Location', 'Delivery To Location', 'Order Type'];
  fieldDetail = this.fieldDetails[0];
  fieldData: any;
  fieldDate: any;
  projNumber: any;
  needByDate: any;
  expDate: any;
  taskNum: any;
  page: any;

  constructor(private route: Router, private comSettingService: CommonSettingService, public datepipe: DatePipe,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    // if(this.route.getCurrentNavigation().extras.state != undefined){
    //   this.page = this.route.getCurrentNavigation().extras.state.page;
    //   }
  }

  ngOnInit() {
    if (this.comSettingService.getProjCode() != undefined || this.comSettingService.getProjCode() != null) {
      console.log("cart page getProjCode", this.comSettingService.getProjCode().ProjectNumber);
      this.projNumber = this.comSettingService.getProjCode().ProjectNumber;
    }
  }

  onSelection(event) {
    if (event.value == "otherdetails") {
      this.fieldDetail = this.fieldDetails[0];
    }
  }

  onProjNumNavigate() {
    // this.comSettingService.setProjCode(this.projNumber);
    this.route.navigate(['hub2u/settings/search'], {
      state: { page: "cart", data: this.data }
    });
  }
  clickToUpdateCart(colName, event) {
    // console.log(colName, event)
    switch (colName) {
      // case 'Delivery To Location':
      //   this.onDeliverLocNavigate(key, val, index)
      //   break;
      // case 'Source Location':
      //   this.onWareHouseNavigate(key, val, index)
      //   break;
      // case 'Order Type':
      //   this.onDeliverSiteNavigate(key, val, index)
      //   break;
      case 'Need By Date':
        this.needDatValueChange(event)
        break;
      case 'Expenditure Item Date':
        this.expDatValueChange(event)
        break;
    }
  }
  clearOldVal() {
    this.fieldDate = null;
  }
  needDatValueChange(event) {
    this.needByDate = this.datepipe.transform(event, 'yyyy-MM-dd');
    // console.log("event", this.needByDate);
  }

  expDatValueChange(event) {
    this.expDate = this.datepipe.transform(event, 'yyyy-MM-dd');
    // console.log("event", this.expDate);
  }

  toggle(ref) {
    // this.needByDate = this.datepipe.transform(this.needByDate, 'yyyy-MM-dd');
    // console.log(ref.opened, this.needByDate);
  }

  updateDetails() {

    // this.cartDataSource.forEach(x =>{
    //   if(this.needByDate != null || this.needByDate != undefined){
    //     x.NEED_BY_DATE = this.needByDate;
    //   }

    //   if(this.expDate != null || this.expDate != undefined){
    //     x.EXPENDITURE_ITEM_DATE = this.expDate;
    //   }
    // })

    // this.expandMore = false;
    // this.expandLess = true;

  }

}