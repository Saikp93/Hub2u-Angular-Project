import { Component, OnInit, Inject, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReportsService, GetimageService } from 'hub2ushared';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DialogDataComponent } from './dialog-data/dialog-data.component';
import { CommonWebService } from '../../../shared/common-web.service';


@Component({
  selector: 'app-catalog-images',
  templateUrl: './catalog-images.component.html',
  styleUrls: ['./catalog-images.component.scss'],
})
export class CatalogImagesComponent implements OnInit {
  @ViewChild('onImageViewRef') onImageViewRef: TemplateRef<any>;

  loader: boolean = false;

  cifaItem;
  file;
  imagebinary
  imageUrl;
  uploadfilesobj = { uploadFiles: [] }
  filearrayobj = { filearray: [] }
  picToView: string;
  userInfo: any;
  userRole: string;
  functionId: string;
  disableSaveBtn: boolean = true;

  constructor(@Inject('environment') private env: any, public dialog: MatDialog, private reportsService: ReportsService, private GetimageService: GetimageService, private commonWebService: CommonWebService) { }
  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
  }
  getImage() {
    this.loader = true;
    this.disableSaveBtn = true;
    this.filearrayobj.filearray = [];
    let req = { "ReportId": "114", "ParametersInput": [{ "Name": "cifa_item", "Value": this.cifaItem }, { "Name": "source_org", "Value": "NULL" }, { "Name": "itemtypecode", "Value": "NULL" }, { "Name": "ITEM_DESCRIPTION", "Value": "NULL" }, { "Name": "category", "Value": "NULL" }, { "Name": "MFG_PART_NUM", "Value": "NULL" }, { "Name": "p_user", "Value": "NULL" }, { "Name": "p_region", "Value": "NULL" }, { "Name": "p_template", "Value": "NULL" }] }
    this.reportsService.onGetDynamicReport(req).subscribe(res => {
      if (res.ROW[0].TRANSACTION_DATA.ITEMDET !== '') {
        // this.picToView = this.getimageURL + this.cifaItem + ".jpg";
        this.picToView = this.GetimageService.getImagefromcifa(this.cifaItem)
        this.loader = false;
      }
      else {
        this.commonWebService.openSnackBar("Not a valid CIFA number", "WARNING")
        this.loader = false;

      }
    })
  }

  onInputClick(event){
    event.target.value = ''
  }

  onFileSelected(event) {
    this.file = event.target.files[0];
    let reader = new FileReader();
    reader.readAsDataURL(this.file);
    reader.onload = () => {
      this.imageUrl = reader.result;
      this.disableSaveBtn = false
      if(this.filearrayobj.filearray){
        this.filearrayobj.filearray = [];
        this.filearrayobj.filearray.push({ file: this.file, imageUrl: this.imageUrl });
      } 
    };
    reader.onerror = function (error) {
      console.log('Error: ', error);

    };
    setTimeout(() => {
      this.imagebinary = reader.result;
      this.imagebinary = this.imagebinary.split(',')[1]
      this.uploadfilesobj.uploadFiles.push({
        "ImageName": this.cifaItem,
        "ImageBinary": this.imagebinary
      });
    }, 4000);

  }


  uploadToServer() {
    this.loader = true;
    setTimeout(() => {
    let req = {
      // "RequestorName": this.userInfo.NTID,
      "jobName": "ADHOC_CATALOG_UPLOAD",
      "itemNumber": this.cifaItem, 
      "templateType": "Default",
      "image": this.imagebinary
    }

    this.reportsService.uploadCatalogImage(req).subscribe(res => {
      console.log("upload to server==>", res);
      this.disableSaveBtn = true;
      if (res.status == "SUCCESS") {
        // this.loader = false;
        this.commonWebService.openSnackBar(res.message, "SUCCESS");
        this.getImage();
      }
      else if (res.status == "ERROR") {
        this.loader = false;
        this.commonWebService.openSnackBar(res.message, "WARNING")
      }
      else {
        this.loader = false;
        this.commonWebService.openSnackBar('Bad gateway', "ERROR")
      }
    },error => {
      this.loader = false;
      this.disableSaveBtn = true;
      this.commonWebService.openSnackBar('Something went wrong.Can you please try later?', "ERROR")
    })
  }, 4000);


  }

  deletefile(i) {
    // console.log("i", i);
    this.filearrayobj.filearray = this.filearrayobj.filearray.filter(item => item.file.name !== i);
    if(this.filearrayobj.filearray.length == 0){
      this.disableSaveBtn = true;
    }
  }

  onLargePreviewImage(url) {
    //  console.log("onSwitchUserID ",url);
    return this.dialog.open(DialogDataComponent, {
      width: '800px',
      height: '400px',
      data: { name: url },
    });
  }




}