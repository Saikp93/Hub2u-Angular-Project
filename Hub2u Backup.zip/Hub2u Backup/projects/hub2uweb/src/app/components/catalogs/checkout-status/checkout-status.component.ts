import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConstantData, ReportsService } from 'hub2ushared'; 
import { CommonWebService } from '../../../shared/common-web.service';
import { CommonSettingService } from '../../../shared/common-settings.service';

@Component({
  selector: 'app-checkout-status',
  templateUrl: './checkout-status.component.html',
  styleUrls: ['./checkout-status.component.scss'],
})
export class CheckoutStatusComponent implements OnInit {
  statusMessage: any = "";
  orderNumber: any;
  statusMsg: any;
  displayTime: any;
  startTxt: any;
  lastTxt: any;
  cpestartTxt: any;
  cpelastTxt: any;
  orderResp: any;
  homeRedirect: boolean = true;
  reqData: any;
  userInfo: any = {};
  userRole: any = '';
  functionId: string;
  recentOrder = [];
  loader: boolean = false;

  constructor(private router: Router,private commonWebService:CommonWebService, private commonService: CommonSettingService, private constantData: ConstantData, private reportsService: ReportsService,) {
    this.reqData = this.router.getCurrentNavigation().extras.state.order;
  }

  ngOnInit() {
    this.onInitialLoad();
    this.timer(1);
  }

  onInitialLoad() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.orderNumber = this.commonService.getOrderNum();
    this.statusMessage = this.commonService.getStatusMsg();
    this.statusMsg = this.commonService.getStatus();
    if(this.functionId == '58'){
      var cpemsgarray = (this.statusMessage !== "" && this.statusMessage !== null) ? this.statusMessage.split(' & ') : "";
      if (cpemsgarray.length > 0) {
        this.cpestartTxt = (cpemsgarray[0] !== undefined && cpemsgarray[0] !== null) ? cpemsgarray[0].split(/([0-9]+)/) : "";
        this.cpelastTxt = (cpemsgarray[1] !== undefined && cpemsgarray[1] !== null) ? cpemsgarray[1].split(/([0-9]+)/) : "";
      }
    }
    // if (msgarray.length > 0) {
    //   this.startTxt = msgarray[0].trim();
    // }
    // if (msgarray.length > 1) {
    //   this.lastTxt = msgarray[1].trim();
    // }
    // var msgarray = this.statusMessage.split(/([0-9]+)/);
    // if(this.functionId == '51'){
      if(this.functionId == '136'){
      var msgarray =  (this.statusMessage !== "" && this.statusMessage !== null) ?  this.statusMessage.split(':') : "";
    }else{
      var msgarray =  (this.statusMessage !== "" && this.statusMessage !== null) ?  this.statusMessage.split(/([0-9]+)/) : "";
    }
    
    this.startTxt = msgarray.shift();
    this.lastTxt = msgarray.pop();
  }
  goHome() {
    this.homeRedirect = false;
    this.router.navigate(['/hub2u/home'])
      .then(() => {
        window.location.reload();
      });
  }

  timer(minute) {
    // let minute = 1;
    let seconds: number = minute * 30;
    let textSec: any = "0";
    let statSec: number = 30;

    const timer = setInterval(() => {
      seconds--;
      if (statSec != 0) statSec--;
      else statSec = 29;

      if (statSec < 10) {
        textSec = "0" + statSec;
      } else textSec = statSec;

      // this.display = `${prefix}${Math.floor(seconds / 60)}:${textSec}`;
      this.displayTime = `${textSec}s`;

      if (seconds == 0 && this.router.url == '/hub2u/catalog/cart/checkout/checkoutStatus') {
        console.log("finished");
        clearInterval(timer);
        if (this.homeRedirect == true) {
          this.router.navigate(['/hub2u/home'])
            .then(() => {
              window.location.reload();
            });
        } else if(this.router.url != '/hub2u/catalog/cart/checkout/checkoutStatus'){
          clearInterval(timer);
        } else{
          clearInterval(timer);
        }

      }
    }, 1000);
  }

  viewOrderDetails(order) {
    this.loader = true
    var dataInput = {
      "ReportId": this.constantData.dynamicrecentOrderId[this.functionId],
      "ParametersInput": [{ "Name": "REQUESTOR", "Value": this.userInfo.NTID }]
    }
    this.reportsService.onGetDynamicReport(dataInput).subscribe(response => {
      if (response.ROW !== undefined) {
        this.recentOrder = response.ROW;
        this.loader = false;
        let selectedOrder = [];
        selectedOrder = this.recentOrder.filter(x => x['Order No.'] === order);
        if (selectedOrder.length > 0) {
          this.homeRedirect = false;
          localStorage.setItem("reqData", JSON.stringify(selectedOrder.length > 0 ? selectedOrder[0] : selectedOrder));
          this.router.navigate(['hub2u/requisitionDetail/']);
        }else{
          this.commonWebService.openSnackBar("Order Details are not available", 'WARNING');
        }
        // this.router.navigate(['hub2u/requisitionDetail/'], { state: { order: selectedOrder.length > 0 ? selectedOrder[0] : selectedOrder } });
      } else {
        this.loader = false;
        this.recentOrder = [];
      }
    }, error => {
      this.loader = false;
    });
  }

}
