import { DatePipe } from '@angular/common';
import { AfterViewChecked, Component, DoCheck, Inject, OnInit, TemplateRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, NgModel, ValidationErrors, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router, RoutesRecognized } from '@angular/router';
import { HomeService, CommonService, MultipleFilterPipe, ProductService, ReportsService, GetimageService } from 'hub2ushared';
import { ConstantData } from 'projects/hub2ushared/src/public-api';
import { animate, style, transition, trigger } from '@angular/animations';
import { CommonWebService } from '../../../shared/common-web.service';
import { Location } from '@angular/common';
import { BehaviorSubject, of, Subject, Subscription, TimeoutError } from 'rxjs';
import { LoadCartService } from '../../../shared/loadcart.service';
import { SaveCartService } from '../../../shared/savecart.service'
import { catchError, map, startWith } from 'rxjs/operators';
import { element } from 'protractor';
import { EventService } from '../../../shared/event.service';
import { HttpClient } from '@angular/common/http';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { CommonSettingService } from '../../../shared/common-settings.service';
import { MatSelect } from '@angular/material/select';
// function validateEmails(emails: string) {

//   return (emails.split(',')
//     .map(email => Validators.email(<AbstractControl>{ value: email.trim() }))
//     .find(_ => _ !== null) === undefined);
// }

function validateEmails(emails) {

  var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  var invalidEmails = [];
  let email1 = emails.split(',');
  for (let email of email1) {
    if (email.trim() == "" || !regex.test(email.trim())) {
      invalidEmails.push(email.trim());
    }
  }
  return invalidEmails.length > 0 ? false : true;
}

function emailsValidator(control: AbstractControl): ValidationErrors | null {
  if (control.value === '' || !control.value ||
    validateEmails(control.value.trim())) {
    return null
  }
  return { emails: true };
}


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
  providers: [MultipleFilterPipe],
  animations: [
    trigger(
      'slideInOut', [
      transition(':enter', [
        style({ transform: 'translateY(100%)', opacity: 0 }),
        animate('200ms', style({ transform: 'translateY(0)', opacity: 1 }))
      ]),
      transition(':leave', [
        style({ transform: 'translateY(0)', opacity: 1 }),
        animate('200ms', style({ transform: 'translateY(100%)', opacity: 0 }))
      ])
    ]
    )
  ],
  encapsulation: ViewEncapsulation.None,
})

export class CartComponent implements OnInit {
  // @ViewChild(MatAutocompleteTrigger) autocompleteTrigger: MatAutocompleteTrigger;
  @ViewChild('autoCompleteInput', { read: MatAutocompleteTrigger })
  autoComplete: MatAutocompleteTrigger;
  cartEventSubscription: Subscription;
  savecartSubscription: Subscription;
  arr = ['PROJECT', 'INVENTORY'];
  userInfo: any = {};
  loader: boolean = false;
  noCartData: boolean = false;
  alternateAddress = false;
  btnDisabled = false;
  deleteLoader: any[] = [];
  cartDataSource: any[] = [];
  cartData = [];
  additonalCartData = [];
  groupedData = [];
  saveGroupIndex = [];
  editablelCartData = [];
  headerCartData = [];
  noneditableCartData = [];
  mandatoryCartData = [];
  mandatoryInnerCartData = [];
  headerDetails = [];
  lovList = [];
  isDetailsChange = false;
  saveCartColumnMap = [];
  cartOriginalDataSource: any[] = [];
  reportFields: any = [];
  dynamicForm = new FormGroup({});
  cartLinesForm = new FormGroup({});
  userDetails: any = '{}';
  userRole: any = '';
  functionId = '1';
  updateCartLineLoader = false;
  comTechUser: boolean = false;
  storeUser: boolean = false;
  cnaUser: boolean = false;
  prepaidUser: boolean = false;
  isInvalid = false;
  isSettingUrl = false;
  expandMore: boolean = false;
  expandLess: boolean = false;
  hideCart: boolean = true;
  addressList;
  adressDataList;
  countryCodeList = [];
  contryCList;
  addControl: FormControl;
  projDetails = [{ key: 'Update Project Details', value: 'projectdetails' }, { key: 'Update Other Details', value: 'otherdetails' }];
  projDetail: any;
  fieldDetails = [
    { key: 'Project Number', value: '', isProject: 'true' },
    { key: 'Task Number', value: '', isProject: 'true' },
    { key: 'Job ID', value: '', isProject: 'false' },
    { key: 'NEED_BY_DATE', value: '', isProject: 'false' },
    // { key: 'Expenditure Item Date', value: '', isProject: 'false' },
    { key: 'Source Location', value: '', isProject: 'false' },
    { key: 'Delivery To Location', value: '', isProject: 'false' },
    // { key: 'Order Type', value: '', isProject: 'false' }
  ];
  fieldDetail = this.fieldDetails[0];
  feildVal: any;
  fieldData: any;
  fieldDate: any;
  projNumber: any = "";
  projId: any = "";
  projectType: any = "";
  jobIdFlag: any = "N";
  projType: any;
  taskNum: any;
  taskID: any;
  jobId: any = "";
  needByDate: any;
  newRoute: any;
  expDate: any;
  sourceLoc: any;
  person_id: any;
  form: FormGroup;
  data: any;
  previousURL;
  currentRoute;
  projCount = 0;
  invCount = 0;
  projCheck: boolean = false;
  invCheck: boolean = false;
  nextURL = ''
  navigationRow = [];
  minCurrentDate = new Date();
  minDate;
  message = [];
  requestParams: any;
  pageSize: any = 10;
  pageIndex: any = 0;
  date = new FormControl();
  zipcodeReq: any = null;
  @ViewChild('updateCart') updateCart: TemplateRef<any>;
  @ViewChild('warningSave') warningSave: TemplateRef<any>;
  @ViewChild('ref') ref: NgModel;
  @ViewChild('selectElement') selectElement: MatSelect;
  dateInvalid: boolean;
  constructor(private multipleFilterPipe: MultipleFilterPipe, public dialog: MatDialog, private loadCartService: LoadCartService, public saveCartService: SaveCartService,
    private reportsService: ReportsService, private location: Location, private commonService: CommonService,
    private productService: ProductService, public route: Router, public router: ActivatedRoute,
    private constants: ConstantData, private commonWebService: CommonWebService, private homeService: HomeService, private comSettingService: CommonSettingService, private fb: FormBuilder,
    public datepipe: DatePipe, private eventService: EventService, private http: HttpClient, @Inject('environment') private env: any, private GetimageService: GetimageService,
  ) {
    if (this.route.getCurrentNavigation().extras.state != undefined ||
      this.route.getCurrentNavigation().extras.state != null) {
      this.data = this.route.getCurrentNavigation().extras.state.data;
    }
    this.cartEventSubscription = this.loadCartService.getCart().subscribe(() => {
      this.onfetchReport();
      // this.getCheckoutDetails();
    })
    this.route.events.pipe().subscribe((event: NavigationStart) => {
      this.nextURL = event.url
    })
    this.saveCartService.getAfterSaveCart().subscribe(navigationRow => {
      this.navigate(navigationRow);
    })
  }

  ngOnInit() {
    this.expandLess = true;
    this.minCurrentDate.setDate(this.minCurrentDate.getDate() + 1);
    this.minDate = this.minCurrentDate
    this.userDetails = localStorage.getItem('userDetails');
    this.userInfo = JSON.parse(this.userDetails);
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.addControl = new FormControl();
    this.projDetail = this.projDetails[0].value
    this.onInitialLoad();
    this.onSwitchNPID();
  }

  onSwitchNPID() {
    this.commonService.switchNPID.subscribe(data => {
      this.onInitialLoad();
    })
  }

  async onInitialLoad() {
    let userInfo = await localStorage.getItem("userDetails");
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = await localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.userInfo = JSON.parse(userInfo);
    await this.userRoles();
    await this.getCheckoutDetails();
    await this.onfetchReport();
    await this.fetchDynamicReports();
    await this.getLov();
    await this.getSaveCartColMapping();
    this.savecartSubscription = this.saveCartService.getCart().subscribe(() => {
      if (this.isDetailsChange) { this.saveWhileNavigating(); }
      this.isDetailsChange = false;
    })
  }

  needDatValueChange(event) {
    this.needByDate = this.datepipe.transform(event, 'yyyy-MM-dd');
  }

  expDatValueChange(event) {
    this.expDate = this.datepipe.transform(event, 'yyyy-MM-dd');
  }

  toggle(ref) {
    this.needByDate = this.datepipe.transform(this.needByDate, 'yyyy-MM-dd');
  }

  userRoles() {
    // if (this.functionId == "99") {
      if (this.functionId == "143") {
      this.comTechUser = true;
    } else if (this.functionId == "50") {
      this.storeUser = true;
    } else if (this.functionId == "57") {
      this.prepaidUser = true;
    }
  }

  updateDetails() {
    this.cartDataSource.forEach(x => {
      if (this.needByDate != null || this.needByDate != undefined) {
        x.NEED_BY_DATE = this.needByDate;
      }

      if (this.expDate != null || this.expDate != undefined) {
        x.EXPENDITURE_ITEM_DATE = this.expDate;
      }
    })
    this.expandMore = false;
    this.expandLess = true;
  }

  innerLoader: boolean = false;
  innerTaskLoader: boolean = false;
  innerJobLoader: boolean = false;
  headerNoResult: boolean = false;
  headerNoTaskResult: boolean = false
  headerNoJobResult: boolean = false
  searchResults = [];
  headersearchResults = [];
  taskdetails = [];
  headertaskdetails = [];
  jobdetails = [];
  headerjobdetails = [];
  selectedRow: any = [];
  selectedLineTaskRow: any;
  selectedLineJobRow: any;
  selectedTaskNumRow: any;
  selectedJobIdRow: any;
  projNumReq: any = null;
  headerProjNumReq: any = null;
  taskNumReq: any = null;
  headerTaskReq: any = null;
  jobIdRequest: any = null;
  headerJobIdReq: any = null;
  searchProjNum() {
    // if (this.projNumber.length > 2) {
    if (this.projNumber.length > 0 && this.headerProjNumReq) {
      this.headerNoResult = true;
    }
    this.innerLoader = true;
    let req = {
      ReportId: "10187",
      "ParametersInput": [
        { "Name": "PROJECT_NUMBER", "Value": this.projNumber },
      ]
    };
    if (this.headerProjNumReq) {
      this.headerProjNumReq.unsubscribe();
    }
    this.headerProjNumReq = this.reportsService.onGetDynamicReport(req).subscribe(response => {
      if (response.ROW != undefined) {
        this.headersearchResults = response.ROW;
        this.innerLoader = false;
        // this.headerNoResult = false;
        this.headersearchResults.forEach(num => {
          if (this.projNumber != num['Project Number']) {
            this.headerNoResult = true;
          } else if (this.projNumber == num['Project Number']) {
            this.headerNoResult = false;
          }
        })
      } else {
        this.headersearchResults = [];
        this.headerNoResult = true;
        this.innerLoader = false;
      }
    })
    // }
    if (this.projNumber == '' || this.projNumber == null) {
      this.headersearchResults = [];
      this.headerNoResult = false;
      this.innerLoader = false;
    }
  }

  searchLineProjNum(data) {
    if (data['Project Number'] == null || data['Project Number'].length == 0) {
      data.noProjResult = false;
      data.innerLoader = false;
      this.searchResults = [];
      if (this.projNumReq) {
        this.projNumReq.unsubscribe();
      }
    }
    if (data['Project Number'] != null && data['Project Number'].length > 0) {
      data.innerLoader = true;
      let req = {
        ReportId: "10187",
        "ParametersInput": [
          { "Name": "PROJECT_NUMBER", "Value": data['Project Number'] },
        ]
      };
      if (this.projNumReq) {
        this.projNumReq.unsubscribe();
      }
      if (this.searchResults.length == 0) {
        data.noProjResult = true;
      }
      this.projNumReq = this.reportsService.onGetDynamicReport(req).subscribe(response => {
        if (response.ROW != undefined) {
          this.searchResults = response.ROW;
          data.innerLoader = false;
          data.noProjResult = false;
          let isProjectAvailable = this.searchResults.filter(num => data['Project Number'] === num['Project Number']);
          if (isProjectAvailable.length === 0) {
            data.noProjResult = true;
          }
          // this.searchResults.forEach(num => {
          //   if (data['Project Number'] != num['Project Number']) {
          //     data.noProjResult = true;
          //   } else if (data['Project Number'] == num['Project Number']) {
          //     data.noProjResult = false;
          //   }
          // })
        } else {
          this.searchResults = [];
          data.noProjResult = true;
          data.innerLoader = false;
        }
      })
    }
  }
  removeTaskNum(cartObj) {
    cartObj['Task Number'] = '';
    cartObj['Expenditure Type'] = '';
    cartObj['TASK_ID'] = '';
    // cartObj['PROJECT_ID'] = '';
    cartObj['Job ID'] = '';
    cartObj.noTaskResult = false;
    cartObj.noJobResult = false;
  }
  selectedHeaderProjRow(row) {
    let selecteRowJson = JSON.stringify(row);
    this.selectedRow = JSON.parse(selecteRowJson);
    if (this.selectedRow['Project Number'] !== "" && this.selectedRow['Project Number'] !== null) {
      this.projNumber = this.selectedRow['Project Number'];
      this.projId = this.selectedRow.PROJECT_ID;
      this.projType = this.selectedRow['Project Type'];
      row.noProjResult = false;
      this.headerNoResult = false;
    }
    this.comSettingService.setProjCode(this.selectedRow, 'Project Number');

    if (this.projNumReq != null) {
      this.projNumReq.unsubscribe();
      this.searchResults = [];
      this.innerLoader = false;
    }
    // if (this.groupedData[0] != undefined) {
    //   this.groupedData[0].childData.forEach(ele => {
    //     ele['Project Number'] = this.selectedRow['Project Number'];
    //     ele.PROJECT_ID = this.selectedRow.PROJECT_ID;
    //     ele.PROJECT_TYPE = this.selectedRow['Project Type'];
    //     this.getStatus('Job ID', ele);
    //     this.getJobIdStatus('Job ID', ele);
    //   })
    // }
  }

  onKeyCountryFilter(event) {
    // this.selectElement.openedChange.subscribe((isOpen: boolean) => {
    //   if (isOpen) {
    //     const panel = this.selectElement.panel.nativeElement as HTMLDivElement;
    //     panel.scrollTop = 0;
    //   }
    // });
    if (event == '') {
      this.contryCList = this.search('');
    } else {
      this.contryCList = this.search(event.target.value);

    }
  }
  contrySelect(event) {
    //this.contryCList.splice(0, 0, event.value);
  }
  search(value: string) {
    let filter = value.toLowerCase();
    return this.countryCodeList.filter(option =>
      option.toLowerCase().startsWith(filter)
    );
  }

  searchLineTaskNum(data) {
    if (data['Task Number'] == null || data['Task Number'].length == 0) {
      data.noTaskResult = false;
      data.innerTaskLoader = false;
      this.taskdetails = [];
      if (this.taskNumReq) {
        this.taskNumReq.unsubscribe();
      }
    }
    this.requestParams = this.cartDataSource[0];
    data.innerTaskLoader = true;
    let projectId, projectNum;
    if (data['Task Number'] == '') {
      data['Expenditure Type'] = '';
    }

    if (this.selectedRow != undefined && this.selectedRow.length > 0) {
      projectId = data.projId;
      projectNum = data.projNumber;
    } else {
      projectId = data.PROJECT_ID;
      projectNum = data['Project Number'];
    }
    let req = {
      "ReportId": "10193", "ParametersInput": [
        { "Name": "PROJECT_ID", "Value": projectId ? projectId : 'null' },
        { "Name": "BUSINESS_UNIT", "Value": "null" },
        { "Name": "TASK_NUMBER", "Value": data['Task Number'] ? data['Task Number'] : 'null' },
        { "Name": "TASK_NAME", "Value": 'null' },
        { "Name": "PROJECT_NUMBER", "Value": projectNum },
        { "Name": "TASK_TYPE", "Value": this.requestParams != undefined && this.requestParams['attribute1'] != undefined ? this.requestParams['attribute1'] : 'null' },
        { "Name": "EXPENDITURE_TYPE", "Value": "null" },
        { "Name": "REQUESTOR_NAME", "Value": this.userInfo.NTID },
        { "Name": "CIFA_ITEM_NUMBER", "Value": this.requestParams != undefined ? this.requestParams['CIFA#'] : 'null' }
      ]
    }

    if (this.taskNumReq) {
      this.taskNumReq.unsubscribe();
    }
    if (data['Task Number'] != null && data['Task Number'].length > 0 && this.taskNumReq) {
      data.noTaskResult = true;
    }
    this.taskNumReq = this.reportsService.onGetDynamicReport(req).subscribe(res => {
      if (res.ROW != undefined) {
        this.taskdetails = res.ROW;
        data.innerTaskLoader = false;
        data.noTaskResult = false;
        let isTaskAvailable = this.taskdetails.filter(num => data['Task Number'] === num['Task Number']);
        if (isTaskAvailable.length === 0) {
          data.noTaskResult = true;
        }
      } else {
        this.taskdetails = [];
        data.noTaskResult = true;
        data.innerTaskLoader = false;
      }

    })

    if (this.taskNumReq != null) {
      if (data['Task Number'] == '' || data['Task Number'] == null) {
        this.taskNumReq.unsubscribe();
        this.taskdetails = [];
        data.innerTaskLoader = false;
      }
    }
  }

  searchTaskNum() {
    this.requestParams = this.cartDataSource[0];
    // if (this.taskNum.length > 0 && this.headerTaskReq) {
    //   this.headerNoTaskResult = true;
    // }
    this.innerTaskLoader = true;
    let projectId, projectNum;
    if (this.selectedRow != undefined && this.selectedRow.length > 0) {
      projectId = this.selectedRow['PROJECT_ID'];
      projectNum = this.selectedRow['Project Number'];
    } else if (this.comSettingService.projectNum != undefined) {
      projectId = this.comSettingService.projectNum.PROJECT_ID;
      projectNum = this.comSettingService.projectNum['Project Number'];
    }
    let req = {
      "ReportId": "10193", "ParametersInput": [
        { "Name": "PROJECT_ID", "Value": projectId },
        { "Name": "BUSINESS_UNIT", "Value": "null" },
        { "Name": "TASK_NUMBER", "Value": this.taskNum != '' ? this.taskNum : 'null' },
        { "Name": "TASK_ID", "Value": this.taskID ? this.taskID : 'null' },
        { "Name": "TASK_NAME", "Value": 'null' },
        { "Name": "PROJECT_NUMBER", "Value": projectNum },
        { "Name": "TASK_TYPE", "Value": this.requestParams != undefined ? this.requestParams['attribute1'] : 'null' },
        { "Name": "EXPENDITURE_TYPE", "Value": "null" },
        { "Name": "REQUESTOR_NAME", "Value": this.userInfo.NTID },
        { "Name": "CIFA_ITEM_NUMBER", "Value": this.requestParams != undefined ? this.requestParams['CIFA#'] : 'null' }
      ]
    }
    if (this.headerTaskReq) {
      this.headerTaskReq.unsubscribe();
    }

    this.headerTaskReq = this.reportsService.onGetDynamicReport(req).subscribe(res => {
      if (res.ROW != undefined) {
        this.headertaskdetails = res.ROW;
        this.innerTaskLoader = false;
        this.headerNoTaskResult = false;
        this.headertaskdetails.forEach(num => {
          if (this.taskNum != num['Task Number']) {
            this.headerNoTaskResult = true;
          } else if (this.taskNum == num['Task Number']) {
            this.headerNoTaskResult = false;
          }
        })
      } else {
        if (this.taskNum == '' || this.taskNum == null) {
          this.headertaskdetails = [];
          this.headerNoTaskResult = false;
          this.innerTaskLoader = false;
        } else {
          this.headertaskdetails = [];
          this.headerNoTaskResult = true;
          this.innerTaskLoader = false;
        }
      }
    })
  }

  selectedHeaderTaskRow(row) {
    let selectedRowJson = JSON.stringify(row);
    this.selectedTaskNumRow = JSON.parse(selectedRowJson);
    if (this.selectedTaskNumRow['Task Number'] !== "" && this.selectedTaskNumRow['Task Number'] !== null) {
      this.taskNum = this.selectedTaskNumRow['Task Number'];
      this.headerNoTaskResult = false;
    }
    this.comSettingService.setTaskNumber(this.selectedTaskNumRow, 'Task Number');

    if (this.headerTaskReq != null) {
      this.headerTaskReq.unsubscribe();
      this.headertaskdetails = [];
      this.innerTaskLoader = false;
    }
  }

  selectedProjRow(row, cartObj?) {
    let selecteRowJson = JSON.stringify(row);
    this.selectedRow = JSON.parse(selecteRowJson);
    row.noProjResult = false;

    if (cartObj != undefined) {
      cartObj.noProjResult = false;
    }
    if (this.selectedRow['Project Number'] !== "" && this.selectedRow['Project Number'] !== null) {
      cartObj.projNumber = this.selectedRow['Project Number'];
      cartObj.projId = this.selectedRow.PROJECT_ID;
      this.isDetailsChange = true;
      row.noProjResult = false;
    }
    this.comSettingService.setProjCode(this.selectedRow, 'Project Number');
    if (cartObj['Task Number'] == '') {
      cartObj.noTaskResult = false;
    }

    if (this.projNumReq != null) {
      this.projNumReq.unsubscribe();
      this.searchResults = [];
      this.innerLoader = false;
    }

    if (cartObj != undefined) {
      let projFiltered = this.cartDataSource.filter(obj => obj['@num'] == cartObj['@num']);
      this.groupedData[0].childData.forEach(ele => {
        if (ele['@num'] == projFiltered[0]['@num']) {
          ele['Project Number'] = this.selectedRow['Project Number'];
          ele.PROJECT_ID = this.selectedRow.PROJECT_ID;
          ele.PROJECT_TYPE = this.selectedRow['Project Type'];
          ele.JOB_ID_FLAG = cartObj.JOB_ID_FLAG;
        }
        this.getStatus('Job ID', ele);
        this.getJobIdStatus('Job ID', ele);
      })
    }

  }

  selectedTaskRow(row, cartObj?) {
    let selectedTaskRowJson = JSON.stringify(row);
    this.selectedLineTaskRow = JSON.parse(selectedTaskRowJson);

    if (cartObj != undefined) {
      cartObj.noTaskResult = false;
      cartObj['Expenditure Type'] = row.FINAL_EXP;
    }
    if (this.selectedLineTaskRow['Task Number'] !== "" && this.selectedLineTaskRow['Task Number'] !== null) {
      // cartObj.projNumber = this.selectedTaskRow['Project Number'];
      this.taskID = this.selectedRow.TASK_ID;
      this.isDetailsChange = true;
      row.noTaskResult = false;
    }
    if (this.taskNumReq != null) {
      this.taskNumReq.unsubscribe();
      this.taskdetails = [];
      this.innerTaskLoader = false;
    }
  }

  selectedJobRow(row, cartObj?) {
    let selectedJobRowJson = JSON.stringify(row);
    this.selectedLineJobRow = JSON.parse(selectedJobRowJson);

    if (cartObj != undefined) {
      cartObj['Job ID'] = row['Job ID'];
      cartObj.noJobResult = false;
    }
    if (this.selectedLineJobRow['Job ID'] !== "" && this.selectedLineJobRow['Job ID'] !== null) {
      // cartObj.projNumber = this.selectedTaskRow['Project Number'];
      row.noJobResult = false;
      this.isDetailsChange = true
    }

    this.headerNoJobResult = false;
    if (this.jobIdRequest != null) {
      this.jobIdRequest.unsubscribe();
      this.jobdetails = [];
      this.innerJobLoader = false;
    }
  }

  searchJobId() {
    if (this.jobId.length > 0 && this.headerJobIdReq) {
      this.headerNoJobResult = true;
    }
    this.innerJobLoader = true;
    let params;
    params = {
      pageNumber: this.pageIndex,
      pageSize: this.pageSize,
      canonicalId: this.jobId
    }
    if (this.headerJobIdReq) {
      this.headerJobIdReq.unsubscribe();
    }
    if(this.jobId.startsWith('JB') || this.jobId.startsWith('jb')){
      this.headerJobIdReq = this.http.get(this.env.jobIdurl + '/api/pullP2JobDetails?', { params }).subscribe(response => {
        if (response != undefined && response[0].data != undefined && response[0].data.length != 0) {
          this.headerjobdetails = response[0].data;
          this.innerJobLoader = false;
          this.headerNoJobResult = false;
          this.headerjobdetails.forEach(num => {
            if (this.jobId != num['Job ID']) {
              this.headerNoJobResult = true;
            } else if (this.jobId == num['Job ID']) {
              this.headerNoJobResult = false;
            }
          })
        } else {
          this.headerjobdetails = [];
          this.headerNoJobResult = true;
          this.innerJobLoader = false;
        }
      })
    } else{
      this.headerjobdetails = [];
      this.headerNoJobResult = true;
      this.innerJobLoader = false;
    }
    
    if (this.jobId == '' || this.jobId == null) {
      this.headerjobdetails = [];
      this.headerNoJobResult = false;
      this.innerJobLoader = false;
    }
  }

  searchLineJobId(data) {
    if (data['Job ID'] == null || data['Job ID'].length == 0) {
      data.noJobResult = false;
      data.innerJobLoader = false;
      this.jobdetails = [];
      if (this.jobIdRequest) {
        this.jobIdRequest.unsubscribe();
      }
    }

    if (this.jobIdRequest) {
      this.jobIdRequest.unsubscribe();
      // data.innerJobLoader = false;
    }
    if (data['Job ID'] != null && data['Job ID'] != '' && data['Job ID'].length > 0 && (data['Job ID'].startsWith('JB') || data['Job ID'].startsWith('jb'))) {
      data.innerJobLoader = true;
      data.noJobResult = true;
      let params;
      params = {
        pageNumber: this.pageIndex,
        pageSize: this.pageSize,
        canonicalId: data['Job ID'],
        divisions: data['DIVISION']
      }
      if (this.jobIdRequest) {
        this.jobIdRequest.unsubscribe();
        // data.innerJobLoader = false;
      }
      this.jobIdRequest = this.http.get(this.env.jobIdurl + '/api/pullP2JobDetails?', { params }).subscribe(response => {
        if (response != undefined && response[0].data != undefined && response[0].data.length != 0) {
          this.jobdetails = response[0].data;
          data.innerJobLoader = false;
          data.noJobResult = false;
          let isJobIdAvailable = this.jobdetails.filter(num => data['Job ID'] === num['Job ID']);
          if (isJobIdAvailable.length === 0) {
            data.noJobResult = true;
          }
        } else {
          this.jobdetails = [];
          data.noJobResult = true;
          data.innerJobLoader = false;
        }
      })
    } else {
      this.jobdetails = [];
      data.noJobResult = true;
    }
    if (this.jobIdRequest != null) {
      if (data['Job ID'] == '' || data['Job ID'] == null) {
        this.jobIdRequest.unsubscribe();
        data.noJobResult = false;
        data.innerJobLoader = false;
      }
    }
    if (this.jobIdRequest == null) {
      data.innerJobLoader = false;
    }
    // }

  }

  searchDetails(key, event) {
    console.log("key", key, event.target.value);
  }

  updateCartDetails() {
    this.isDetailsChange = true;
    this.updateCartLineLoader = true;
    if (this.cartDataSource.length == 0) {
      this.updateCartLineLoader = false;
      this.commonWebService.openSnackBar("There are no Selected Items to Update", 'WARNING');
      return;
    }
    // if (this.groupedData[0] != undefined) {
    //   this.groupedData[0].childData.forEach(ele => {
    //     ele['Project Number'] = this.selectedRow['Project Number'];
    //     ele.PROJECT_ID = this.selectedRow.PROJECT_ID;
    //     ele.PROJECT_TYPE = this.selectedRow['Project Type'];
    //     this.getStatus('Job ID', ele);
    //     this.getJobIdStatus('Job ID', ele);
    //   })
    // }
    if (this.projDetail !== 'projectdetails') {
      this.fieldDetails.forEach(element => {
        if (element.value !== '' && element.isProject !== 'true') {
          if (this.groupedData.length > 0) {
            for (let item of this.groupedData) {
              if (item.hasOwnProperty(element.key)) {
                item[element.key] = element.value;
              }
              for (let row of item.childData) {
                if (element.key == 'Order Type') {
                  row['ATTRIBUTE6'] = element.value;
                } else if (element.key == 'Job ID') {
                  row['Job ID'] = row['PROJECT_TYPE'] == 'P2' ? element.value : '';
                } else {
                  row[element.key] = element.value;
                }
              }
              this.updateCartLineLoader = false;
            }
          } else {
            this.updateCartLineLoader = false;
          }
        }
      });
      this.resetAll();
    } else {
      let checkTask = this.cartDataSource.filter(element => element.ATTRIBUTE6 == 'PROJECT');
      //let checkTask = [...this.cartDataSource];
      let count = 0;
      for (let item of checkTask) {
        var dataInput = {
          "ReportId": '1086',
          "ParametersInput": [
            { "Name": "PROJECT_ID", "Value": (this.projId != null && this.projId != undefined && this.projId != '') ? this.projId : item.PROJECT_ID },
            { "Name": "LINE_NUMBER", "Value": item.LINE_NUMBER },
            { "Name": "TASK_NUMBER", "Value": this.taskNum ? this.taskNum : 'null' },
            { "Name": "TASK_ID", "Value": this.taskID ? this.taskID : 'null' },
            { "Name": "TASK_NAME", "Value": 'null' },
            { "Name": "PROJECT_NUMBER", "Value": this.projNumber },
            { "Name": "PROJECT_TYPE", "Value": this.projType ? this.projType : 'null' },
            { "Name": "TASK_TYPE", "Value": item.attribute1 ? item.attribute1 : 'null' },
            { "Name": "EXPENDITURE_TYPE", "Value": item['Expenditure Type'] ? item['Expenditure Type'] : 'null' },
            { "Name": "REQUESTOR_NAME", "Value": this.userInfo.NTID },
            { "Name": "CIFA_ITEM_NUMBER", "Value": item['CIFA#'] ? item['CIFA#'] : 'null' }
          ]
        }

        this.reportsService.onGetDynamicReport(dataInput).subscribe(response => {
          if (response.ROW !== undefined) {
            let data = response.ROW;
            let obj = {
              lineNo: item.LINE_NUMBER,
              status: "SUCCESS"
            }
            for (let item of this.groupedData) {
              item.childData.forEach(element => {
                if (element.LINE_NUMBER == data[0].LINE_NUMBER) {
                  element['Project Number'] = data[0].PROJECT_NUMBER;
                  element['Task Number'] = data[0].TASK_NUMBER;
                  element['Job ID'] = this.jobId;
                  element['TASK_ID'] = data[0].TASK_ID;
                  element['Expenditure Type'] = data[0].FINAL_EXP;
                  element['ERROR_MESSAGE'] = null;
                  element['RECORD_STATUS'] = null;
                  element['PROJECT_TYPE'] = this.projType;
                  element['JOB_ID_FLAG'] = this.cartDataSource[0].JOB_ID_FLAG;
                  obj['projectNo'] = data[0].PROJECT_NUMBER;
                  obj['taskNo'] = data[0].TASK_NUMBER
                }
                if (this.projNumber && this.taskNum) {
                  element.isExpand = true;
                  this.getStatus('Job ID', element);
                  this.getJobIdStatus('Job ID', element);
                }
              });
            }
            this.message.push(obj);
          } else {
            let obj = {
              lineNo: item.LINE_NUMBER,
              status: "WARNING"
            }
            for (let obj of this.groupedData) {
              obj.childData.forEach(element => {
                if (element.LINE_NUMBER == item.LINE_NUMBER) {
                  element.error = true
                  if (this.projNumber && this.taskNum) {
                    element.isExpand = true;
                  }
                }
              })
            }
            this.message.push(obj)
          }
          count++;
          if (count == checkTask.length) {
            this.updateMessage();
          }
        }, error => {
          let obj = {
            lineNo: item.LINE_NUMBER,
            status: "ERROR"
          }
          for (let obj of this.groupedData) {
            obj.childData.forEach(element => {
              if (element.LINE_NUMBER == item.LINE_NUMBER) {
                element.error = true
                if (this.projNumber && this.taskNum) {
                  element.isExpand = true;
                }
              }
            })
          }
          this.message.push(obj)
          count++;
          if (count == checkTask.length) {
            this.updateMessage();
          }
        })
      }
    }
  }

  updateMessage() {
    this.updateCartLineLoader = false;
    let details = []
    let msg = "Project/Task Updated. Please verify all the lines"
    let message = this.message;
    let commonStatus;
    if (message.length > 0) {
      for (let i = 0; i < message.length; i++) {
        let obj;
        if (message[i].status == 'SUCCESS') {
          obj = {
            line: "For line No: " + message[i].lineNo,
            message: "Updated Project Number " + message[i].projectNo + " and Task " + message[i].taskNo
          }
          commonStatus = 'SUCCESS'
        } else {
          obj = {
            line: "For line No: " + message[i].lineNo,
            message: "Invalid Project Number and Task to update line"
          }
          commonStatus = 'WARNING'
        }
        details.push(obj)
      }
      this.commonWebService.openSnackBar(msg, 'cart', details);
    }
    this.message = [];
  }

  dateChangeEvent(event, key, cartObj) {
    cartObj[key] = this.datepipe.transform(event.value, 'yyyy-MM-dd');
    this.isDetailsChange = true;

  }
  resetAll() {
    // this.projDetail = this.projDetails[0].value
    this.feildVal = '';
    this.clearSettingData();
    this.fieldDetails.filter(element => element.value = '');
    this.projNumber = '';
    this.taskNum = '';
    this.jobId = '';
    this.headerNoResult = false;
    this.headerNoTaskResult = false;
    this.headerNoJobResult = false;
  }
  expandCart() {
    let dialogRef = this.dialog.open(this.updateCart, {
      // height: '80%',
      width: '30%',
      panelClass: 'custom-modalbox',
      data: "open"
    });
    this.route.events.subscribe(() => {
      dialogRef.close();
    });
  }

  onCloseClick() {
    this.comSettingService.setUpdateCartIndex(0)
    this.dialog.closeAll();
  }

  collapseCart() {
    this.expandLess = true;
    this.expandMore = false;
  }

  fetchDynamicReports() {
    let request = {
      //ReportId: 112,
      // ReportId: 7001,
      ReportId:this.constants.userprofileData[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };

    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW !== undefined) {
        this.person_id = response.ROW[0].PERSON_ID
      }
    })
  }

  getCheckoutDetails() {
    this.loader = true;
    this.reportFields = []
    // let role = this.constants.roles[this.functionId] ? this.constants.roles[this.functionId].toUpperCase() : this.constants.roles[99].toUpperCase()
    let role = this.constants.roles[this.functionId] ? this.constants.roles[this.functionId].toUpperCase() : this.constants.roles[143].toUpperCase()
    let request = {
      ReportId: this.constants.checkoutdetailsId[this.functionId],
      ParametersInput: [
        { "Name": "USER_NAME", "Value": this.userInfo.NTID },
        {
          Name: "PROFILE_TYPE",
          Value: role
        }
      ]
    };

    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW !== undefined) {
        for (let control of response.ROW) {
          this.reportFields.push(control);
        }
        this.dynamicForm = this.createDynamicForm();
      } else {
        this.loader = false;
      }
    }, error => {
      this.loader = false;
    })
  }
  latest_date: any;
  createDynamicForm() {

    let dynamicForm = this.fb.group({});

    this.reportFields.forEach(control => {
      dynamicForm.addControl(control.CHECKOUT_INPUT, this.fb.control(null));
      if (control.MANDATORY == 'Yes') {
        dynamicForm.controls[control.CHECKOUT_INPUT].setValidators([Validators.required])
      }
      if (control.COLUMN_NAME == 'SEND_ORDER_NOTIFICATIONS') {
        dynamicForm.controls[control.CHECKOUT_INPUT].setValidators([emailsValidator])
      }
      if (control.CHECKOUT_INPUT == 'contactNumber') {
        dynamicForm.controls[control.CHECKOUT_INPUT].setValidators([Validators.maxLength(10), Validators.min(0)])
      }
      if (control.COLUMN_NAME == 'NOTE_TO_APPROVER') {
        dynamicForm.controls[control.CHECKOUT_INPUT].setValidators([Validators.maxLength(480), Validators.min(0)])
      }
      if (control.COLUMN_NAME == "ORDER_DESCRIPTION") {
        dynamicForm.controls[control.CHECKOUT_INPUT].setValidators([Validators.required, Validators.maxLength(150), Validators.min(0)])
      }
      if (control.DEFAULT_VALUE) {
        dynamicForm.controls[control.CHECKOUT_INPUT].setValue(control.DEFAULT_VALUE);
      }
      if (control.CHECKOUT_INPUT == 'attribute3') {
        dynamicForm.addControl("country", this.fb.control(null));
        dynamicForm.addControl("zipcode", this.fb.control(null));
        dynamicForm.addControl("city", this.fb.control(null));
        dynamicForm.addControl("state", this.fb.control(null));
        dynamicForm.addControl("address1", this.fb.control(null));
        dynamicForm.addControl("address2", this.fb.control(null));
        dynamicForm.addControl("contactName", this.fb.control(null));
        dynamicForm.addControl("phone", this.fb.control(null));
        dynamicForm.addControl("email", this.fb.control(null, emailsValidator));
        this.getCountryList();
      }
    });
    return dynamicForm;
  }
  getLov() {
    let request = {
      ReportId: this.constants.checkoutdetailsId[this.functionId],
      ParametersInput: [
        {
          Name: "REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.getReportDisplayFields(request).subscribe(response => {

      if (response.ReportDisplayFieldsOutput !== undefined) {
        this.lovList = response.ReportDisplayFieldsOutput;

      }
    }, error => {
      this.loader = false;
    })
  }
  numericOnly(event): boolean { // restrict e,+,-,E characters in  input type number 
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode == 101 || charCode == 69 || charCode == 45 || charCode == 43) {
      return false;
    }
    if (event.target.value.length > 9) {
      return false;
    }
    return true;

  }
  getList(colName) {
    let respOrderList = [];
    for (let item of this.lovList) {
      if (item.name == colName) {
        let orderList = item.options;
        orderList.forEach(x => {
          if (x.value !== undefined) {
            respOrderList.push(x.value)
          }
        });
      }
    }
    return respOrderList;
  }
  getSaveCartColMapping() {
    let request = {
      ReportId: this.constants.cartDynamicId[this.functionId],
      ParametersInput: [
        //{ Name: "PROFILE_TYPE", Value: this.userRole ? this.userRole.toUpperCase() : 'COMCAST TECH USER IIP' },
        {
          Name: "REQUESTOR_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.getReportDisplayFields(request).subscribe(response => {

      if (response.ReportDisplayFieldsOutput !== undefined) {

        for (let item of response.ReportDisplayFieldsOutput) {
          if (item.name == 'MAPPING') {
            let saveCartColumn = item.options;
            saveCartColumn.forEach(x => {
              if (x.text !== undefined) {
                this.saveCartColumnMap.push({ key: x.text, mappingname: x.value })
              }
            });
          }
        }

      }
    }, error => {
      this.loader = false;
    })
  }
  ToggleAddress(toggle) {
    if (toggle === true) {
      this.dynamicForm.controls["country"].setValidators([Validators.required])
      this.dynamicForm.controls["zipcode"].setValidators([Validators.required])
      this.dynamicForm.controls["city"].setValidators([Validators.required])
      this.dynamicForm.controls["state"].setValidators([Validators.required])
      this.dynamicForm.controls["contactName"].setValidators([Validators.required])
      this.dynamicForm.controls["phone"].setValidators([Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
        this.dynamicForm.controls["address1"].setValidators([Validators.required])
      this.dynamicForm.controls["email"].setValidators([Validators.email]);
      this.contryCList = this.countryCodeList;
    } else {
      this.dynamicForm.controls["country"].clearValidators();
      this.dynamicForm.controls["zipcode"].clearValidators();
      this.dynamicForm.controls["zipcode"].setErrors(null);
      this.dynamicForm.controls["city"].clearValidators();
      this.dynamicForm.controls["state"].clearValidators();
      this.dynamicForm.controls["contactName"].clearValidators();
      this.dynamicForm.controls["phone"].clearValidators();
      this.dynamicForm.controls["address1"].clearValidators();
      this.dynamicForm.controls["city"].setErrors(null);
      this.dynamicForm.controls["state"].setErrors(null);
      this.dynamicForm.controls["contactName"].setErrors(null);
      this.dynamicForm.controls["phone"].setErrors(null);
      this.dynamicForm.controls["address1"].setErrors(null);
      this.contryCList = this.countryCodeList;
    }
  }
  getZipCode() {
    let zipcode = this.dynamicForm.get("zipcode").value;
    if (this.zipcodeReq) {
      this.zipcodeReq.unsubscribe();
    }
    if (zipcode) {
      if (zipcode.length >= 4) {
        this.zipcodeReq = this.homeService.getZipCode(this.dynamicForm.get("zipcode").value).subscribe(response => {
          this.dynamicForm.controls["city"].setValue(null);
          this.dynamicForm.controls["state"].setValue(null);
          if (response !== undefined) {
            if (response.result.zipCode !== undefined) {
              this.dynamicForm.controls["city"].setValue(response.result.zipCode.city)
              this.dynamicForm.controls["state"].setValue(response.result.zipCode.state)
            }
          } else {
            this.dynamicForm.controls["city"].setValue(null);
            this.dynamicForm.controls["state"].setValue(null);
          }
        }, error => {
          this.dynamicForm.controls["city"].setValue(null);
          this.dynamicForm.controls["state"].setValue(null);
        })
      }
    }

  }

  getCountryList() {
    let role = this.constants.roles[this.functionId] ? this.constants.roles[this.functionId].toUpperCase() : this.constants.roles[99].toUpperCase()
    let request = {
      ReportId: 60165,
      ParametersInput: [
        { Name: "REQUESTOR_NAME", Value: this.userInfo.NTID },
        { Name: "PROFILE_TYPE", Value: role }
      ]
    };

    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response !== undefined) {
        if (response.ROW !== undefined) {
          response.ROW.forEach(x => {
            if (x.COUNTRY_NAME !== undefined) {
              this.countryCodeList.push(x.COUNTRY_NAME)
            }
          });
          this.contryCList = this.countryCodeList;
          this.dynamicForm.get("country").setValue('United States');
        }
      }
    })

  }
  getAddressList() {
    let address = this.dynamicForm.get("address1").value;
    if (address) {
      if (address.length >= 4) {
        let request = {
          "sourceSystem": null,
          "addressLine": address,
          "addressLine2": "",
          "city": this.dynamicForm.get("city").value,
          "state": this.dynamicForm.get("state").value,
          "zipCode": this.dynamicForm.get("zipcode").value,
          "countryCode": "US"
        };
        this.homeService.getAddress(request).subscribe(response => {
          if (response !== undefined) {
            if (response.candidate !== undefined) {
              if (response.candidate.length > 0) {
                if (response.candidate[0].addressKeyFormat !== undefined) {
                  this.adressDataList = response.candidate[0].addressKeyFormat.addressLine;
                }
              }
            }
          } else {
            this.adressDataList = [];
          }
        }, error => {
          this.adressDataList = [];
        })
      } else {
        return;
      }
    }
  }
  setAddress(event, add) {

    this.dynamicForm.controls["address1"].setValue(add);
  }
  filterAdd(add) {
    return this.adressDataList.filter(address =>
      (address.toLowerCase().indexOf(add.toLowerCase()) === 0))
  }
  isCompulsory() {
    let isCompulsory = false;
    this.mandatoryCartData.forEach(element => {
      for (let item of this.headerDetails) {
        if (!item[element]) {
          isCompulsory = true;
          break;
        }
      }
    });

    return isCompulsory;
  }
  onCheckout() {
    if (!this.dynamicForm.valid) {
      this.isInvalid = true;
      return;
    }
    let comp = false;
    let mandateItems = [];
    let innerMandateItems = [];
    let jobIdMandatory: any;
    if (this.cartDataSource.length == 0) {
      this.commonWebService.openSnackBar("There are no Selected Items to Checkout", 'WARNING');
      return;
    }
    let isJobError = this.groupedData[0].childData.filter(obj => obj['JOB_ID_FLAG'] == 'Y');
    isJobError.forEach(ele => {
      if ((ele['Job ID'] == null || ele['Job ID'] == '') && ele['PROJECT_TYPE'] == 'P2') {
        jobIdMandatory = true;
        innerMandateItems.push('Job ID');
        // this.mandatoryInnerCartData.push('Job ID');
      }
    })
    this.mandatoryCartData.forEach(element => {
      for (let item of this.headerDetails) {
        if (!item[element] || item[element] == '') {
          mandateItems.push(element);
          this.commonWebService.openSnackBar("Please Enter " + mandateItems, 'WARNING');
          comp = true;
          break;
        }
      }
    });
    this.mandatoryInnerCartData.forEach(element => {
      for (let item of this.groupedData) {
        for (let opt of item.childData) {
          if (opt['ATTRIBUTE6'] == 'PROJECT') {
            if (!opt[element] && (opt[element] == '' || opt[element] == null)) {
              innerMandateItems.push(element);
            }
            if (innerMandateItems.length > 0) {
              this.commonWebService.openSnackBar("Please Enter " + innerMandateItems, 'WARNING');
              comp = true;
              break;
            }
            let isProjError = this.cartDataSource.filter(obj => obj.noProjResult == true);
            let isTaskError = this.cartDataSource.filter(obj => obj.noTaskResult == true);
            let isJobIDError = this.cartDataSource.filter(obj => obj.noJobResult == true);
            if (isProjError.length > 0) {
              this.commonWebService.openSnackBar("Please Enter Valid Project Number", 'WARNING');
              comp = true;
            }
            if (isTaskError.length > 0) {
              this.commonWebService.openSnackBar("Please Enter Valid Task Number", 'WARNING');
              comp = true;
            }
            if (isJobIDError.length > 0) {
              this.commonWebService.openSnackBar("Please Enter Valid Job ID", 'WARNING');
              comp = true;
            }
          }
        }
      }
    });
    if (comp) {
      return;
    } else {
      if (this.functionId == '58' && (this.cartDataSource[0]['Source Site'] != undefined && this.cartDataSource[0]['Source Site'].length > 0)
        && (this.cartDataSource[0]['Deliver To Site'] != undefined && this.cartDataSource[0]['Deliver To Site'].length > 0)
        && (this.cartDataSource[0]['Deliver To Site'] == this.cartDataSource[0]['Source Site'])) {
        this.commonWebService.openSnackBar("Source Site cannot be same as Delivery to Site", "WARNING");
        return;
      }

      if (this.isDetailsChange) {
        this.cartDataSource.forEach(function (v) {
          delete v['@num']
        })
        let request: any = {};
        request.SOURCE_SYSTEM = "TECHAPP";
        request.profile=this.userRole.toUpperCase();
        request.shoppingCartUpsertData = this.updateFieldsName(this.cartDataSource);

        this.eventService.showSpinner();
        this.productService.saveCart(request).subscribe(response => {
          if (response !== undefined) {
            let resp = response || [];
            let message = resp['STATUS_MESSAGE'] || resp['statusMessage'] || '';
            if (resp['status'] === 'SUCCESS') {
              this.isDetailsChange = false;
              this.checkout();
              // this.onfetchReport();
              // this.getCheckoutDetails();
              this.commonService.updatedCart(true);
            } else {
              this.commonService.updatedCart(true);
              this.eventService.hideSpinner();
              this.commonWebService.openSnackBar('Save Cart is Failed, can you please try again later', "ERROR")
            }
          }
        }, error => {
          this.eventService.hideSpinner();
          this.commonWebService.openSnackBar('Something went wrong.Can you please try later', 'WARNING')
        })
      } else {
        this.checkout();
      }
    }
  }
  checkout() {
    this.eventService.showSpinner();
    let req;
    let checkoutreq;
    let altAddr = null;


    if (this.alternateAddress) {
      altAddr = 'ADDRESS1.' + this.getVal(this.dynamicForm.get("address1").value) + '|' + 'ADDRESS2.' + this.getVal(this.dynamicForm.get("address2").value) + '|' + 'CITY.' + this.getVal(this.dynamicForm.get("city").value) + '|' + 'STATE.' + this.getVal(this.dynamicForm.get("state").value) + '|' + 'ZIP.' + this.getVal(this.dynamicForm.get("zipcode").value) + '|' + 'COUNTRY.' + this.getVal(this.dynamicForm.get("country").value) + '|' + 'ALT_CONTACT_NAME.' + this.getVal(this.dynamicForm.get("contactName").value) + '|' + 'ALT_PHONE.' + this.getVal(this.dynamicForm.get("phone").value) + '|' + 'ALT_EMAIL.' + this.getVal(this.dynamicForm.get("email").value)
    } else {
      altAddr = '';
      this.dynamicForm.controls["address1"] !== undefined ? this.dynamicForm.controls["address1"].setValue(null) : '';
      this.dynamicForm.controls["address2"] !== undefined ? this.dynamicForm.controls["address2"].setValue(null) : '';
      this.dynamicForm.controls["city"] !== undefined ? this.dynamicForm.controls["city"].setValue(null) : '';
      this.dynamicForm.controls["state"] !== undefined ? this.dynamicForm.controls["state"].setValue(null) : '';
      this.dynamicForm.controls["zipcode"] !== undefined ? this.dynamicForm.controls["zipcode"].setValue(null) : '';
      this.dynamicForm.controls["country"] !== undefined ? this.dynamicForm.controls["country"].setValue(null) : '';
      this.dynamicForm.controls["contactName"] !== undefined ? this.dynamicForm.controls["contactName"].setValue(null) : '';
      this.dynamicForm.controls["phone"] !== undefined ? this.dynamicForm.controls["phone"].setValue(null) : '';
      this.dynamicForm.controls["email"] !== undefined ? this.dynamicForm.controls["email"].setValue(null) : '';
    }
    var formData = this.dynamicForm.value;
    req = {}
    req["action"] = "CREATE";
    // req["requestorId"] = this.person_id ? this.person_id.toString() : (this.functionId == "136" ? this.userInfo.NTID : '');
    req["requestorId"] = this.userInfo.NTID ?this.userInfo.NTID :""
    // if (this.functionId == "136") {
    //   req["profile"] = "COMCAST BUSINESS SERVICES USER IIP"
    // }
    req["profile"]=this.userRole.toUpperCase();
    for (var key in formData) {
      if (key == 'attribute3') {
        req['attribute3'] = altAddr
      }
      if (key == 'attribute2' && this.functionId != "99" && this.functionId != "63") {
        req['attribute2'] = this.datepipe.transform(this.dynamicForm.get("attribute2").value, 'MM/dd/yyyy');
      }
      if (key !== 'attribute3' && key !== 'attribute2') {
        req[key] = formData[key]
      }
    }

    let req1;
    if (this.functionId == "57" || this.functionId == "58" || this.functionId == "50" || this.functionId == "99" || this.functionId == "63") {
      if (this.functionId == "57") {
        req1 = {
          "ATTRIBUTE1": this.dynamicForm.get("attribute2").value ? this.datepipe.transform(this.dynamicForm.get("attribute2").value, 'dd/MM/yyyy') : this.dynamicForm.get("attribute2").value,
          // "ORDER_DESC": this.dynamicForm.get("attribute2").value ? this.datepipe.transform(this.dynamicForm.get("attribute2").value, 'MM/dd/yyyy') : this.dynamicForm.get("attribute2").value,
          "REQUESTOR_ID": this.person_id ? this.person_id.toString() : '',
          "REQ_DESC": this.dynamicForm.get("order_desc").value,
          "REQ_ON_BEHALF": this.dynamicForm.get("attribute1").value,
        }
      } else if (this.functionId == "58") {
        req1 = {
          "ATTRIBUTE1": this.dynamicForm.get("attribute1").value,
          "ATTRIBUTE2": this.dynamicForm.get("attribute2").value ? this.datepipe.transform(this.dynamicForm.get("attribute2").value, 'MM/dd/yyyy') : this.dynamicForm.get("attribute2").value,
          "ATTRIBUTE3": this.dynamicForm.get("attribute3").value,
          "ATTRIBUTE4": this.dynamicForm.get("attribute4").value,
          "ORDER_DESC": "",
          "REQUESTOR_ID": this.person_id ? this.person_id.toString() : '',
          "REQ_DESC": this.dynamicForm.get("req_desc").value,
          "REQ_ON_BEHALF": this.dynamicForm.get("req_on_behalf") ? this.dynamicForm.get("req_on_behalf").value : "",
        }
      } else if (this.functionId == "50") {
        req1 = {
          "REQUESTOR_ID": this.person_id ? this.person_id.toString() : '',
          "REQ_DESC": this.dynamicForm.get("order_desc").value,
          "REQ_ON_BEHALF": this.dynamicForm.get("REQ_ON_BEHALF").value ? this.datepipe.transform(this.dynamicForm.get("REQ_ON_BEHALF").value, 'MM/dd/yyyy') : this.dynamicForm.get("REQ_ON_BEHALF").value,
        }
      } else if (this.functionId == "99") {
        req1 = {
          "ATTRIBUTE2": (this.dynamicForm.get("attribute2") != null && this.dynamicForm.get("attribute2") != undefined) ? this.dynamicForm.get("attribute2").value : '',
          "REQUESTOR_ID": this.person_id ? this.person_id.toString() : '',
          "REQ_DESC": this.dynamicForm.get("order_desc").value,
          "REQ_ON_BEHALF": this.dynamicForm.get("req_on_behalf") ? this.dynamicForm.get("req_on_behalf").value : "",
        }
      } else if (this.functionId == "63") {
        req1 = {
          "ATTRIBUTE1": this.dynamicForm.get("attribute1").value, //note to approver
          "ATTRIBUTE2": this.dynamicForm.get("attribute2").value,
          "ATTRIBUTE3": this.dynamicForm.get("attribute3").value ? this.datepipe.transform(this.dynamicForm.get("attribute3").value, 'MM/dd/yyyy') : this.dynamicForm.get("attribute3").value, // ship by date
          "ATTRIBUTE4": "",
          "REQUESTOR_ID": this.person_id ? this.person_id.toString() : '',
          "REQ_DESC": this.dynamicForm.get("order_desc").value,
          "REQ_ON_BEHALF": this.dynamicForm.get("req_on_behalf") ? this.dynamicForm.get("req_on_behalf").value : "",
        }
      }
      checkoutreq = this.homeService.hub2uOrderJavaApi(req1).subscribe(response => {
        if (response != undefined) {
          this.eventService.hideSpinner();
          this.isDetailsChange = false;
          let orderNum = response.STATUS_MESSAGE.split(/([0-9]+)/);

          this.comSettingService.setOrderNum(orderNum[1]);
          this.comSettingService.setStatusMsg(response.STATUS_MESSAGE);
          this.comSettingService.setStatus(response.STATUS);
          this.commonService.updatedCart(true);
          this.onfetchReport();
          this.route.navigate(['/hub2u/catalog/cart/checkout/checkoutStatus'], { state: { order: req1 } })
        }
      }, catchError((error) => { // Error...
        // Handle 'timeout over' error
        if (error instanceof TimeoutError) {
          checkoutreq.unsubscribe();
          return of('Timeout Exception');
        }
      }))
    } else {
      this.homeService.hub2uOrder(req).subscribe(response => {
        if (response !== undefined) {
          if (response.orderDetailResponse !== undefined) {
            let checkout = response.orderDetailResponse[0];
            this.eventService.hideSpinner();
            this.isDetailsChange = false;
            this.comSettingService.setOrderNum(checkout.orderNumber);
            this.comSettingService.setStatusMsg(checkout.statusMessage);
            this.comSettingService.setStatus(checkout.status);
            this.commonService.updatedCart(true);
            this.onfetchReport();
            this.route.navigate(['/hub2u/catalog/cart/checkout/checkoutStatus'], { state: { order: req } })
          } else {
            this.commonService.updatedCart(true);
            this.eventService.hideSpinner();
            this.commonWebService.openSnackBar('There is some issue in checkout, can you please try again later', "ERROR")
          }
        }
      }), error => {
        // Return other errors
        this.eventService.hideSpinner();
        this.commonWebService.openSnackBar('Order Creation is in process, Please check after sometime', "ERROR")
      }
    }

  }
  getVal(val) {
    return val ? val : ''
  }

  saveField(event, col) {
    this.comSettingService.setUpdateCartIndex(-1);
    if (col == 'projNumber') {
      this.projNumber = event;
      this.taskNum = '';
      // this.jobId = '';
      this.headerNoTaskResult = true;
      // this.headerNoJobResult = true;
      if (this.cartDataSource[0] != undefined) {
        this.jobIdFlag = this.cartDataSource[0].JOB_ID_FLAG;
      }
      if (this.comSettingService.projectNum) {
        this.comSettingService.projectNum['Project Number'] = this.projNumber;
        this.projectType = this.comSettingService.projectNum['Project Type'];
      };
    }
    if (col == 'taskNum') {
      this.taskNum = event;
      if (this.comSettingService.taskNum) {
        this.comSettingService.taskNum['Task Number'] = this.taskNum;
      }
    }
    if (col == 'jobId') {
      this.jobId = event;
      if (this.comSettingService.jobId) {
        this.comSettingService.jobId['Job ID'] = this.jobId['Job ID'];
      }
    }
  }
  onfetchReport() {
    this.loader = true;
    this.headerDetails = [];

    let object = {
      ReportId: this.constants.cartDynamicId[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportsService.onGetDynamicReport(object).subscribe(response => {
      if (response.ROW !== undefined) {
        this.noCartData = false;
        this.hideCart = false;
        let resp = response.ROW || [];
        resp.forEach(x => {
          x.isExpand = false;
        });
        this.cartDataSource = resp;
        this.cartOriginalDataSource = resp;
        this.operations(resp);
      } else {
        this.noCartData = true;
        this.loader = false;
        this.projCheck = false;
        this.invCheck = false;
        this.projCount = 0;
        this.invCount = 0;
        if (this.isDetailsChange == true) {
          this.isDetailsChange = false;
        }
      }
    }, error => {
      this.loader = false;
      this.noCartData = true;
      this.projCheck = false;
      this.invCheck = false;
      this.projCount = 0;
      this.invCount = 0;
      if (this.isDetailsChange == true) {
        this.isDetailsChange = false;
      }
    });
  }

  sourceSiteChange: boolean = false;
  deliverSiteChange: boolean = false;
  showJobId: boolean = false;

  operations(resp) {
    // this.loader = true;
    this.headerDetails.push(resp[0]);
    this.cartData = this.OrganizedCart(resp, 'DISPLAY_COLUMNS');
    this.additonalCartData = this.OrganizedCart(resp, 'ADDITIONAL_COLUMNS');
    this.editablelCartData = this.OrganizedCart(resp, 'EDITABLE_COLUMNS');
    this.headerCartData = this.OrganizedCart(resp, 'HEADER_COLUMNS');
    this.noneditableCartData = this.OrganizedCart(resp, 'NON_EDITABLE_COLUMNS');
    this.mandatoryCartData = this.OrganizedCart(resp, 'MANDATORY_COLUMNS');
    this.mandatoryInnerCartData = this.OrganizedMandatoryCols(resp, 'INNER_MANDATORY_COLUMNS');
    this.pushToHeader(resp);
    this.getCount(resp);
    let deliverySite = resp != undefined && resp != null ? resp.filter(element => element['Deliver To Site'] == "CUSTOMER") : '';
    let toggleBtn = this.reportFields.filter(control => control.CHECKOUT_INPUT == 'attribute3')
    if ((toggleBtn != undefined && toggleBtn.length > 0) && (deliverySite != undefined && deliverySite.length > 0)) {
      this.alternateAddress = true;
      this.btnDisabled = true;
      this.ToggleAddress(true);
    } else if (toggleBtn != undefined && toggleBtn.length > 0) {
      this.alternateAddress = false;
      this.btnDisabled = false;
      this.ToggleAddress(false);
    }

    if (this.projCount > 0) {
      this.projDetails = [{ key: 'Update Project Details', value: 'projectdetails' }, { key: 'Update Other Details', value: 'otherdetails' }];
      this.projDetail = this.projDetails[0].value;
      if (sessionStorage.getItem("Prev_Url") == "/hub2u/settings/jobIdSearch" || sessionStorage.getItem("Prev_Url") == "/hub2u/settings/source" || sessionStorage.getItem("Prev_Url") == "/hub2u/settings/deliverToLoc") {
        this.projDetail = this.projDetails[1].value;
      }
    } else {
      this.projDetails = [{ key: 'Update Other Details', value: 'otherdetails' }];
      this.projDetail = this.projDetails[0].value;
    }

    if (sessionStorage.getItem("Prev_Url").indexOf("settings/") > -1) {
      if (this.comSettingService.updateCartIndex == -1) {
        this.dialog.open(this.updateCart, {
          width: '30%',
          panelClass: 'custom-modalbox',
          data: "open"
        });
        if (this.comSettingService.projectNum !== undefined && this.comSettingService.projectNum !== null) {
          this.projNumber = this.comSettingService.projectNum['Project Number'];
          this.projId = this.comSettingService.projectNum.PROJECT_ID;
          this.projType = this.comSettingService.projectNum['Project Type'];
          this.projectType = this.comSettingService.projectNum['Project Type'];
          let field_temp = this.fieldDetails.filter(element => element.key == 'Project Number');
          field_temp.forEach(element => {
            element.value = this.comSettingService.projectNum['Project Number'];
            if (this.comSettingService.projectNum['Project Type'] == "P2") {
              this.showJobId = true;
            } else {
              this.showJobId = false;
            }

          })
        }
        if (this.comSettingService.taskNum !== undefined && this.comSettingService.taskNum !== null) {
          this.taskNum = this.comSettingService.taskNum['Task Number'];
          let field_temp = this.fieldDetails.filter(element => element.key == 'Task Number');
          field_temp.forEach(element => {
            element.value = this.comSettingService.taskNum['Task Number'];
          })
        }
        if (this.comSettingService.jobId !== undefined && this.comSettingService.jobId !== null) {
          this.jobId = this.comSettingService.jobId['Job ID'];
          let field_temp = this.fieldDetails.filter(element => element.key == 'Job ID');
          //this.projDetail = this.projDetails[0].value
          this.feildVal = this.fieldDetails[2];
          this.fieldDetail = this.fieldDetails[2];
          field_temp.forEach(element => {
            element.value = this.comSettingService.jobId['Job ID'];
          })
        }
        if (this.comSettingService.wareHouseCode !== undefined && this.comSettingService.wareHouseCode !== null) {
          let field_temp = this.fieldDetails.filter(element => element.key == 'Source Location');
          //this.projDetail = this.projDetails[0].value
          this.feildVal = this.fieldDetails[4];
          this.fieldDetail = this.fieldDetails[4];
          field_temp.forEach(element => {
            element.value = this.comSettingService.wareHouseCode.ORGANIZATION_CODE;
          })
        }
        if (this.comSettingService.delLocCode !== undefined && this.comSettingService.delLocCode !== null) {
          let field_temp = this.fieldDetails.filter(element => element.key == 'Delivery To Location');
          //this.projDetail = this.projDetails[0].value;
          this.feildVal = this.fieldDetails[5];
          this.fieldDetail = this.fieldDetails[5];
          field_temp.forEach(element => {
            element.value = this.comSettingService.delLocCode.LOCATION_CODE;
          })
        }

        if (this.projCount > 0) {
          this.projDetails = [{ key: 'Update Project Details', value: 'projectdetails' }, { key: 'Update Other Details', value: 'otherdetails' }];
          this.projDetail = this.projDetails[0].value;
          if (sessionStorage.getItem("Prev_Url") == "/hub2u/settings/jobIdSearch" || sessionStorage.getItem("Prev_Url") == "/hub2u/settings/source" || sessionStorage.getItem("Prev_Url") == "/hub2u/settings/deliverToLoc") {
            this.projDetail = this.projDetails[1].value;
          }
        } else {
          this.projDetails = [{ key: 'Update Other Details', value: 'otherdetails' }];
          this.projDetail = this.projDetails[0].value;
        }

      } else {
        if (this.comSettingService.deliverSite !== undefined && this.comSettingService.deliverSite !== null) {
          this.updateDeliveryToSite();
          this.deliverSiteChange = true;
          // if(this.functionId == '58'){
          //   this.isDetailsChange = this.getChanges(this.comSettingService.columnName);
          // }
        }
        if (this.comSettingService.wareHouseCode !== undefined && this.comSettingService.wareHouseCode !== null) {
          this.updateSourcewareHouse();
        }
        if (this.comSettingService.delLocCode !== undefined && this.comSettingService.delLocCode !== null) {
          this.updateDeliveryToLoc();
        }
        if (this.comSettingService.projectNum !== undefined && this.comSettingService.projectNum !== null) {
          this.updateProjectNum();
        }
        if (this.comSettingService.taskNum !== undefined && this.comSettingService.taskNum !== null) {
          this.updateTaskNum();
        }
        if (this.comSettingService.jobId !== undefined && this.comSettingService.jobId !== null) {
          this.updateJobId();
        }
        if (this.comSettingService.sourceSite !== undefined && this.comSettingService.sourceSite !== null) {
          this.updateSourceSite();
          this.sourceSiteChange = true;
          // if(this.functionId == '58'){
          //   this.isDetailsChange = this.getChanges(this.comSettingService.sourceSiteName);
          // }          
        }
      }
      this.loader = false;
      this.noCartData = false;
      sessionStorage.setItem("Prev_Url", null);
    } else {
      this.clearSettingData();
      this.loader = false;
      this.noCartData = false;
    }
  }
  clearSettingData() {
    this.comSettingService.deliverSite = null;
    this.comSettingService.wareHouseCode = null;
    this.comSettingService.delLocCode = null;
    this.comSettingService.projectNum = null;
    this.comSettingService.grpData = null;
    this.comSettingService.taskNum = null;
    this.comSettingService.jobId = null;
  }
  getUpdatedObj(item, obj) {
    for (let key in obj) {
      obj[key] = item[key]
    }
    return obj
  }

  getCount(resp) {
    let obj = {}
    for (let headerVal of this.additonalCartData) {
      obj[headerVal.trim()] = ''
    }
    let newList = resp.map(item => {
      return this.getUpdatedObj(item, JSON.parse(JSON.stringify(obj)))
    })
    this.projCount = newList != undefined ? newList.filter(element => element.ATTRIBUTE6 == 'PROJECT').length : 0;
    this.invCount = newList != undefined ? newList.filter(element => element.ATTRIBUTE6 == 'INVENTORY').length : 0;
    if (this.projCount > 0) {
      this.projCheck = true;
    } else {
      this.projCheck = false;
    }
    if (this.invCount > 0) {
      this.invCheck = true;
    } else {
      this.invCheck = false;
    }

  }
  pushToHeader(resp) {
    let obj = {}
    for (let headerVal of this.headerCartData) {
      obj[headerVal.trim()] = ''
    }
    let newList = resp.map(item => {
      return this.getUpdatedObj(item, JSON.parse(JSON.stringify(obj)))
    })

    let ind = 0
    newList = this.uniqueArray(newList);
    newList.forEach(element => {
      let data = []
      for (let item of this.cartDataSource) {
        if (this.checkInGroup(item, element, ind)) {
          data.push(item)
        }
      }
      element['childData'] = data;
      ind++
    });
    this.groupedData = newList;
  }
  checkInGroup(row, item, index) {
    let isPresent = true;
    for (let val in item) {
      if (item[val] !== row[val]) {
        isPresent = false;
        break;
      }
    }
    if (isPresent) {
      row.groupIndex = index
    }
    return isPresent;
  }
  uniqueArray(newList) {
    const uniqueArray = newList.filter((thing, index) => {
      const _thing = JSON.stringify(thing);
      return index === newList.findIndex(obj => {
        return JSON.stringify(obj) === _thing;
      });
    });
    return uniqueArray;
  }
  removeDuplicate(arr) {
    return arr.filter((el, i, a) => i === a.indexOf(el))
  }
  OrganizedCart(resp, col) {
    let cart = [];
    let display_column = [];
    if (resp[0][col] !== undefined && resp[0][col] !== null) {
      display_column = this.convertToArray(resp[0][col]);
    }
    return display_column
  }

  OrganizedMandatoryCols(resp, col) {

    let display_column = [];
    for (let item of resp) {
      if (item['ATTRIBUTE6'] == 'PROJECT' && (item[col] !== undefined && item[col] !== null)) {
        display_column = this.convertToArray(item[col]);
        break;
      }
    }
    // if (resp[0][col] !== undefined && resp[0][col] !== null) {
    //   display_column = this.convertToArray(resp[0][col]);
    // }
    return display_column
  }
  OrganizedCart1(resp, col) {
    let display_column = [];
    if (resp !== undefined && resp !== null) {
      for (let item of resp) {
        display_column.push(this.convertToArray(item[col]));
      }
    }
    return display_column
  }

  getheaderIcon(key) {
    let imagepath = '../../../assets/images/';
    let icon = imagepath + 'Source.svg';
    if (key == 'Deliver To Site') {
      icon = imagepath + 'local_shipping.svg'
    }
    return icon
  }
  isAddress(key) {
    let hintCol = '';
    if (key == 'Source Location') {
      hintCol = 'Source Location Address'
    }
    if (key == 'Deliver To Site') {
      hintCol = 'Deliver To Address'
    }
    if (key == 'Source Site') {
      hintCol = 'Source Location Address'
    }
    return hintCol
  }
  isLocation(key) {
    return (key == 'Source Location' || key == 'Deliver To Site' || key == 'Source Site' || key == 'Delivery To Site' || key == 'Delivery To Location')
  }
  isAvailable(key, data, opt?) {
    let dataToSearch = [];
    if (data == 'cartData') {
      dataToSearch = this.cartData
    } else if (data == 'additonalCartData') {
      if (this.functionId == '99') {
        if (opt == "INVENTORY") {
          let arr = this.cartDataSource.filter(val => val['ATTRIBUTE6'] == 'INVENTORY')
          if (arr.length > 0) {
            dataToSearch = arr[0]['ADDITIONAL_COLUMNS']
          }
        }
        else if (opt == "PROJECT") {
          let arrProj = this.cartDataSource.filter(val => val['ATTRIBUTE6'] == 'PROJECT')
          if (arrProj.length > 0) {
            dataToSearch = arrProj[0]['ADDITIONAL_COLUMNS']
          }
        }
      } else {
        dataToSearch = this.additonalCartData
      }
      // dataToSearch = this.additonalCartData
    } else if (data == 'editablelCartData') {
      dataToSearch = this.editablelCartData
    } else if (data == 'headerCartData') {
      dataToSearch = this.headerCartData
    } else if (data == 'noneditableCartData') {
      dataToSearch = this.noneditableCartData
    } else if (data == 'mandatoryCartData') {
      dataToSearch = this.mandatoryCartData
    } else if (data == 'mandatoryInnerCartData') {
      dataToSearch = this.mandatoryInnerCartData
    }
    return dataToSearch.includes(key);
  }
  convertToArray(columns: string) {
    let col;
    if (columns !== '' && columns !== null) {
      if (columns.indexOf(',') == -1) {
        col = [columns];
      }
      else
        if (columns.indexOf(',') > -1) {
          col = columns.split(",")
        }
        else {
          columns = columns + ',';
          col = columns.split(",")
        }
    }
    return col;
  }
  onAddItem(size: number, item: any) {
    item.Qty = size;
    this.isDetailsChange = true;
  }

  onDeleteItem(index, lineNum) {
    //let request = { "requestorId": this.userInfo.NTID, "operation": "delete", "lineNumber": lineNum };
    let request = { "requestorName": this.userInfo.NTID, "operation": "delete", "lineNumber": lineNum, "profile":this.userRole.toUpperCase(),};
    // this.deleteLoader[index - 1] = true;
    this.eventService.showSpinner();
    this.productService.deleteFromCart(request).subscribe(response => {
      // this.deleteLoader[index - 1] = false;
      this.eventService.hideSpinner();
      let resp = response || [];
      let message = resp['STATUS_MESSAGE'] || resp['statusMessage'] || '';
      // this.commonWebService.openSnackBar(message, resp['STATUS'])
      this.commonWebService.openSnackBar(message, resp['status'])
      this.onfetchReport();
      //this.getCheckoutDetails();
      this.commonService.updatedCart(true);
    }, error => {
      // this.deleteLoader[index - 1] = false;
      this.eventService.hideSpinner();
      this.commonWebService.openSnackBar('Something went wrong.Can you please try later', 'WARNING')
    });
  }

  // isChange: boolean;
  // getChanges(key) {
  //   this.isChange = true;
  //   let array1 = this.editablelCartData.filter(val => this.headerCartData.includes(val));
  //   if (array1.indexOf(key) > -1) {
  //     if (array1.length > 1) {
  //       this.isChange = false;
  //     }
  //   }
  //   return this.isChange;
  // }
  navigate(navigationRow) {
    if (navigationRow.length > 0) {
      this.clickToNavigate(navigationRow[0].key, navigationRow[0].val, navigationRow[0].index, navigationRow[0].row, navigationRow[0].innerRowIndex)
    }
  }
  clickToNavigate(key, val, index, row?, innerRowIndex?) {
    // this.autocomplete.closePanel();
    this.navigationRow = [{ key: key, val: val, index: index, row: row, innerRowIndex: innerRowIndex }];
    this.comSettingService.setUpdateCartIndex(index);
    if (this.sourceSiteChange == true || this.deliverSiteChange == true) {
      this.isDetailsChange = false;
    }
    switch (key) {
      case 'Expenditure Item Date':
        break;
      case 'Project Number':
        this.onProjNumNavigate(key, val, index, innerRowIndex);
        break;
      case 'Task Number':
        this.onTaskNumberSearch(key, val, index, row, innerRowIndex);
        break;
      case 'Delivery To Location':
        this.onDeliverLocNavigate(key, val, index)
        break;
      case 'Source Location':
        this.onWareHouseNavigate(key, val, index)
        break;
      case 'Deliver To Site':
        this.onDeliverSiteNavigate(key, val, index)
        break;
      case 'Source Site':
        this.onSourecSiteNavigate(key, val, index)
        break;
      case 'Job ID':
        this.onJobIdNavigate(key, val, index, row, innerRowIndex);
        break;
    }
    this.dialog.closeAll();
  }
  //Navigation methods start//

  onDeliverLocNavigate(key, val, index) {
    let navigateLink = this.prepaidUser ? 'hub2u/settings/deliver' : 'hub2u/settings/deliverToLoc';
    this.route.navigate([navigateLink],
      {
        state: { page: "cart", delLocName: key, delLocVal: val, index: index },
      }
    );
  }
  onWareHouseNavigate(key, val, index) {
    this.route.navigate(['hub2u/settings/source'], {
      state: { page: "cart", sourceSiteName: key, wareHouseindex: index }
    });
  }
  onSourecSiteNavigate(key, val, index) {
    this.route.navigate(['hub2u/settings/sourceSite'], {
      state: { page: "cart", sourceSiteName: key, sourceSiteVal: val, sourceHouseindex: index }
    });
  }
  onDeliverSiteNavigate(key, val, index) {
    this.route.navigate(['hub2u/settings/deliver'], {
      state: { page: "cart", column: key, DelSiteindex: index }
    });
  }
  onProjNumNavigate(key, val, index, innerRowIndex) {
    this.route.navigate(['hub2u/settings/search'], {
      state: { page: "cart", projectColName: key, projectIndex: index, innerRowIndex: innerRowIndex }
    });
  }
  onTaskNumberSearch(key, val, index, row, innertaskRowIndex) {
    if (index == -1 && row == undefined) {
      row = this.cartDataSource[0];
      if (this.projNumber !== "" && this.projId !== "") {
        row['Project Number'] = this.projNumber;
        row['PROJECT_ID'] = this.projId
      } else {
        row['Project Number'] = row.PROJECT_NUMBER;
        row['PROJECT_ID'] = row.PROJECT_ID
        // row.projId
      }

    }
    this.route.navigate(['hub2u/settings/tasknosearch'], {
      state: { page: "cart", row: row, taskColName: key, taskIndex: index, innertaskRowIndex: innertaskRowIndex }
    });
  }
  onJobIdNavigate(key, val, index, row, innertaskRowIndex) {
    if (row != undefined) {
      localStorage.setItem('division', row.DIVISION);
      this.route.navigate(['hub2u/settings/jobIdSearch'], {
        state: { page: "cart", row: row, jobIdName: key, jobIdindex: index, innerJobRowIndex: innertaskRowIndex }
      });
    }
    this.route.navigate(['hub2u/settings/jobIdSearch'], {
      state: { page: "cart", jobIdName: key, jobIdindex: index, innerJobRowIndex: innertaskRowIndex }
    });

  }

  // onSourecSiteNavigate(key, val, index) {
  //   this.route.navigate(['hub2u/settings/sourceSite'], {
  //     state: { page: "cart", sourceSiteName: key, sourceSiteVal: val, sourceHouseindex: index }
  //   });
  // }

  //Navigation methods end//-------------------------//
  //------Update Navigated values start-------------------//
  updateDeliveryToSite() {
    this.isDetailsChange = true;
    let index = this.comSettingService.delSiteindex;
    let groupInd = 0;
    if (this.groupedData.length > 0) {
      for (let item of this.groupedData) {
        if (index == groupInd) {
          item[this.comSettingService.columnName] = this.comSettingService.getdeliverSite().SITE_ID;
          item[this.isAddress(this.comSettingService.columnName)] = this.comSettingService.getdeliverSite().ADDRESS;
          item['ATTRIBUTE8'] = this.comSettingService.getdeliverSite().SITE_DESCRIPTION;
          item['Site Description'] = this.comSettingService.getdeliverSite().SITE_DESCRIPTION;
          let toggleBtn = this.reportFields.filter(control => control.CHECKOUT_INPUT == 'attribute3');
          if ((toggleBtn != undefined && toggleBtn.length > 0) && item[this.comSettingService.columnName] == "CUSTOMER") {
            this.alternateAddress = true;
            this.btnDisabled = true;
            this.ToggleAddress(true);
          } else if (toggleBtn != undefined && toggleBtn.length > 0) {
            this.alternateAddress = false;
            this.btnDisabled = false;
            this.ToggleAddress(false);
          }
          for (let row of item.childData) {
            row[this.comSettingService.columnName] = this.comSettingService.getdeliverSite().SITE_ID;
            row[this.isAddress(this.comSettingService.columnName)] = this.comSettingService.getdeliverSite().ADDRESS;
            row['ATTRIBUTE7'] = this.comSettingService.getdeliverSite().CUSTOMER;
            row['ATTRIBUTE8'] = this.comSettingService.getdeliverSite().SITE_DESCRIPTION;
            row['Site Description'] = this.comSettingService.getdeliverSite().SITE_DESCRIPTION;
          }
          break;
        }
        groupInd++
      }
    }
    this.comSettingService.setGroupData(this.groupedData);
  }
  updateSourcewareHouse() {
    this.isDetailsChange = true;
    let index = this.comSettingService.wareHouseindex;
    let groupInd = 0;
    if (this.functionId == '99') {
      if (this.comSettingService.getGroupData()) {
        this.groupedData = this.comSettingService.getGroupData();
      }
    }
    if (this.groupedData.length > 0) {
      for (let item of this.groupedData) {
        if (index == groupInd) {
          item[this.comSettingService.sourceSiteName] = this.comSettingService.wareHouseCode.ORGANIZATION_CODE;
          item[this.isAddress(this.comSettingService.sourceSiteName)] = this.comSettingService.getWareHouseCode().DESCRIPTION;
          item.SOURCE_ORGANIZATION_ID = this.comSettingService.wareHouseCode.DELIVER_TO_ORG_ID;
          for (let row of item.childData) {
            row[this.comSettingService.sourceSiteName] = this.comSettingService.wareHouseCode.ORGANIZATION_CODE;
            row[this.isAddress(this.comSettingService.sourceSiteName)] = this.comSettingService.getWareHouseCode().DESCRIPTION;
            row.SOURCE_ORGANIZATION_ID = this.comSettingService.wareHouseCode.DELIVER_TO_ORG_ID;
          }
        }
        groupInd++
      }
    }
    this.comSettingService.setGroupData(this.groupedData);
  }
  updateSourceSite() {
    this.isDetailsChange = true;
    if (this.functionId == '99') {
      if (this.comSettingService.getGroupData()) {
        this.groupedData = this.comSettingService.getGroupData();
      }
    }
    this.sourceSiteUpdate(this.comSettingService.sourceSite.SITE_ID, this.comSettingService.sourceSite.ADDRESS)
    this.comSettingService.setGroupData(this.groupedData);
  }

  sourceSiteUpdate(siteId, adress?) {
    let index = this.comSettingService.sourceSiteindex;
    let groupInd = 0;
    if (this.groupedData.length > 0) {
      for (let item of this.groupedData) {
        if (index == groupInd) {
          item[this.comSettingService.sourceSiteName] = siteId;
          item[this.isAddress(this.comSettingService.sourceSiteName)] = adress;
          for (let row of item.childData) {
            row[this.comSettingService.sourceSiteName] = siteId;
            row[this.isAddress(this.comSettingService.sourceSiteName)] = adress;
          }
        }
        groupInd++
      }
    }
  }
  updateDeliveryToLoc() {
    this.isDetailsChange = true;
    if (this.functionId == '99') {
      if (this.comSettingService.getGroupData()) {
        this.groupedData = this.comSettingService.getGroupData();
      }
    }
    this.deliveryToLocUpdate(this.comSettingService.delLocCode)
    this.comSettingService.setGroupData(this.groupedData);
  }

  deliveryToLocUpdate(updateValue) {
    let index = this.comSettingService.index;
    let groupInd = 0;
    if (this.groupedData.length > 0) {
      for (let item of this.groupedData) {
        if (index == groupInd) {
          item[this.comSettingService.delLocName] = updateValue.LOCATION_CODE;
          item.DESTINATION_ORGANIZATION_ID = updateValue.DELIVER_TO_ORG_ID;
          item.DESTINATION_ORGANIZATION_CODE = updateValue.ORGANIZATION_CODE;
          for (let row of item.childData) {
            row[this.comSettingService.delLocName] = updateValue.LOCATION_CODE;
            row.DESTINATION_ORGANIZATION_ID = updateValue.DELIVER_TO_ORG_ID;
            row.DESTINATION_ORGANIZATION_CODE = updateValue.ORGANIZATION_CODE;
            if (this.functionId == '66') {
              row['Deliver To Address'] = updateValue.ADDRESS;
            }
          }
        }
        groupInd++
      }
    }

  }
  updateProjectNum() {
    this.isDetailsChange = true;
    let index = this.comSettingService.projectIndex;
    let innerindex = this.comSettingService.innerRowIndex;
    if (this.functionId == '99') {
      if (this.comSettingService.getGroupData()) {
        this.groupedData = this.comSettingService.getGroupData();
      }
    }
    if (this.groupedData.length > 0) {
      let ind = 0;
      for (let item of this.groupedData) {
        if (ind == index) {
          let rowind = 0;
          for (let row of item.childData) {
            if (rowind == innerindex) {
              row[this.comSettingService.projectColName] = this.comSettingService.projectNum['Project Number'];
              row['PROJECT_NUMBER'] = this.comSettingService.projectNum['Project Number'];
              row['PROJECT_ID'] = this.comSettingService.projectNum['PROJECT_ID'];
              row['PROJECT_TYPE'] = this.comSettingService.projectNum['Project Type'];
              row['Project Number'] = this.comSettingService.projectNum['Project Number'];
              this.removeTaskNum(row);
            }
            rowind++
          }
          let rowSrcind = 0;
          for (let row of this.cartDataSource) {
            if (rowSrcind == innerindex) {
              row[this.comSettingService.projectColName] = this.comSettingService.projectNum['Project Number'];
              row['PROJECT_NUMBER'] = this.comSettingService.projectNum['Project Number'];
              row['PROJECT_ID'] = this.comSettingService.projectNum['PROJECT_ID'];
              row['PROJECT_TYPE'] = this.comSettingService.projectNum['Project Type'];
              row['Project Number'] = this.comSettingService.projectNum['Project Number'];
            }
            rowSrcind++
          }
        }
        ind++
      }
    }

    this.comSettingService.setGroupData(this.groupedData);
  }
  updateTaskNum() {
    this.isDetailsChange = true;
    let index = this.comSettingService.taskIndex;
    let innerindex = this.comSettingService.innertaskRowIndex;
    if (this.functionId == '99') {
      if (this.comSettingService.getGroupData()) {
        this.groupedData = this.comSettingService.getGroupData();
      }
    }
    if (this.groupedData.length > 0) {
      let ind = 0;
      for (let item of this.groupedData) {
        if (ind == index) {
          let rowind = 0;
          for (let row of item.childData) {
            if (rowind == innerindex) {
              row[this.comSettingService.taskColName] = this.comSettingService.taskNum['Task Number'];
              row['TASK_NUMBER'] = this.comSettingService.taskNum['Task Number'];
              row['TASK_ID'] = this.comSettingService.taskNum['TASK_ID'];
              if (this.comSettingService.taskColName.toLowerCase() == "task number" && this.data != undefined) {
                row['Expenditure Type'] = this.data.FINAL_EXP
              }
            }
            rowind++
          }
          let rowSrcind = 0;
          for (let row of this.cartDataSource) {
            if (rowSrcind == innerindex) {
              row[this.comSettingService.taskColName] = this.comSettingService.taskNum['Task Number'];
              row['TASK_NUMBER'] = this.comSettingService.taskNum['Task Number'];
              row['TASK_ID'] = this.comSettingService.taskNum['TASK_ID'];
              if (this.comSettingService.taskColName.toLowerCase() == "task number" && this.data != undefined) {
                row['Expenditure Type'] = this.data.FINAL_EXP
              }
            }
            rowSrcind++
          }
        }
        ind++
      }
    }

    this.comSettingService.setGroupData(this.groupedData);
  }

  updateJobId() {
    this.isDetailsChange = true;
    let index = this.comSettingService.jobIdindex;
    let innerindex = this.comSettingService.innerJobRowIndex;
    if (this.functionId == '99') {
      if (this.comSettingService.getGroupData()) {
        this.groupedData = this.comSettingService.getGroupData();
      }
    }
    if (this.groupedData.length > 0) {
      let ind = 0;
      for (let item of this.groupedData) {
        if (ind == index) {
          let rowind = 0;
          for (let row of item.childData) {
            if (rowind == innerindex) {
              row[this.comSettingService.jobIdName] = this.comSettingService.jobId['Job ID'];
            }
            rowind++
          }
        }
        ind++
      }
    }
    this.comSettingService.setGroupData(this.groupedData);
  }
  //------Update Navigated values end-------------------//

  getJobIdStatus(key, cartObj) {
    let status = true;
    if (key == "Job ID") {
      if (cartObj.PROJECT_TYPE == "P2" && cartObj.ATTRIBUTE6 == 'PROJECT') {
        status = false;
      } else {
        status = true;
      }
    }
    return status
  }
  getStatus(key, cartObj) {
    let status = true;
    if (key == "Job ID") {
      if (cartObj.PROJECT_TYPE == "P2" && cartObj.JOB_ID_FLAG == "Y") {
        status = false;
      } else {
        status = true;
      }
    }
    return status
  }

  saveWhileNavigating() {
    this.loader = true;
    this.cartDataSource.forEach(function (v) {
      delete v['@num']
    })
    let request: any = {};
    request.SOURCE_SYSTEM = "TECHAPP";
    request.profile=this.userRole.toUpperCase();
    request.shoppingCartUpsertData = this.updateFieldsName(this.cartDataSource);
    this.loader = true;
    if (this.cartDataSource.length == 0) {
      this.commonWebService.openSnackBar("There are no Selected Items to Save", 'WARNING');
      this.loader = false;
      return;
    }
    this.productService.saveCart(request).subscribe(response => {
      if (response !== undefined && response !== null) {
        this.loader = false;
        let resp = response || [];
        let message = resp['statusMessage'] || '';
        this.commonWebService.openSnackBar(message, resp['status']);
        this.isDetailsChange = false;
        this.saveCartService.callafterSaveCart(this.navigationRow);
      }
    }, error => {
      this.loader = false;
      this.commonWebService.openSnackBar('Something went wrong.Can you please try later', 'WARNING')
    })
  }

  onSaveCart() {
    let isCompulsory = false;
    let mandateItems = [];
    let innermandateItems = [];
    let jobIdMandatory: any;
    if (this.cartDataSource.length == 0) {
      this.commonWebService.openSnackBar("There are no Selected Items to Save", 'WARNING');
      return;
    }
    let isJobError = this.groupedData[0].childData.filter(obj => obj['JOB_ID_FLAG'] == 'Y');
    isJobError.forEach(ele => {
      if ((ele['Job ID'] == null || ele['Job ID'] == '') && ele['PROJECT_TYPE'] == 'P2') {
        jobIdMandatory = true;
        innermandateItems.push('Job ID');
        // this.mandatoryInnerCartData.push('Job ID');
      }
    })
    this.mandatoryCartData.forEach(element => {
      for (let item of this.groupedData) {
        if (!item[element] || item[element] == '') {
          mandateItems.push(element);
          this.commonWebService.openSnackBar("Please Enter " + mandateItems, 'WARNING');
          isCompulsory = true;
          break;
        }
      }
    });
    this.mandatoryInnerCartData.forEach(element => {
      for (let item of this.groupedData) {
        for (let opt of item.childData) {
          if (opt['ATTRIBUTE6'] == 'PROJECT') {
            if (!opt[element] && (opt[element] == '' || opt[element] == null)) {
              innermandateItems.push(element);
            }
            if (innermandateItems.length > 0) {
              this.commonWebService.openSnackBar("Please Enter " + innermandateItems, 'WARNING');
              isCompulsory = true;
              break;
            }
            let isProjError = this.cartDataSource.filter(obj => obj.noProjResult == true);
            let isTaskError = this.cartDataSource.filter(obj => obj.noTaskResult == true);
            let isJobIDError = this.cartDataSource.filter(obj => obj.noJobResult == true);
            if (isProjError.length > 0) {
              this.commonWebService.openSnackBar("Please Enter Valid Project Number", 'WARNING');
              isCompulsory = true;
            }
            if (isTaskError.length > 0) {
              this.commonWebService.openSnackBar("Please Enter Valid Task Number", 'WARNING');
              isCompulsory = true;
            }
            if (isJobIDError.length > 0) {
              this.commonWebService.openSnackBar("Please Enter Valid Job ID", 'WARNING');
              isCompulsory = true;
            }
          }
        }
      }
    });

    if (isCompulsory) {
      true;
    } else {
      this.cartDataSource.forEach(function (v) {
        v['Ship By Date'] = v['NEED_BY_DATE'];
        delete v['@num']
      })
      let request: any = {};
      request.SOURCE_SYSTEM = "TECHAPP";
      request.profile=this.userRole.toUpperCase();
      request.shoppingCartUpsertData = this.updateFieldsName(this.cartDataSource);
      this.loader = true;
      let delLocVal;
      let sourceSiteVal;
      let sourceSiteAdress;
      this.productService.saveCart(request).subscribe(response => {
        if (response !== undefined && response !== null) {
          this.loader = false;
          let resp = response || [];
          let message = resp['statusMessage'] || '';
          this.commonWebService.openSnackBar(message, resp['status']);

          this.comSettingService.sourceSite = null;
          this.comSettingService.deliverSite = null;
          this.isDetailsChange = false;
          if (resp['status'] == 'SUCCESS') {

            this.onfetchReport();
            //this.getCheckoutDetails();  
          }
          if (resp['status'] == 'FAILED') {
            delLocVal = this.comSettingService.delLocValue;
            sourceSiteVal = this.comSettingService.sourceSiteValue;
            sourceSiteAdress = this.comSettingService.sourceSiteAdress;
          } else {
            if (this.comSettingService.delLocCode !== undefined && this.comSettingService.delLocCode !== null) {
              delLocVal = this.comSettingService.delLocCode.LOCATION_CODE;
            }
            if (this.comSettingService.sourceSite !== undefined && this.comSettingService.sourceSite !== null) {
              sourceSiteVal = this.comSettingService.sourceSite.SITE_ID;
              sourceSiteAdress = this.comSettingService.sourceSite.ADDRESS;
            }
          }
          this.selectedRow = [];
        }
      }, error => {
        this.loader = false;
        this.commonWebService.openSnackBar('Something went wrong.Can you please try later', 'WARNING')
      })
    }
  }
  updateFieldsName(data) {
    this.saveCartColumnMap.forEach(element => {
      // data.forEach(obj => this.addKey(obj, element.key, element.mappingname));
      this.groupedData.forEach(grpobj => {
        for (let item of grpobj.childData) {
          // let filDt =  data.filter(obj =>  item['CIFA#'] === obj['CIFA#']) 
          //this.addKey(filDt, element.key, element.mappingname, item);
          data.forEach(obj => {
            if (item['LINE_NUMBER'] === obj['LINE_NUMBER']) {
              this.addKey(obj, element.key, element.mappingname, item);
            }
          })
        }
      })
    })
    return data;
  }

  // addKey(obj, oldKey, newKey) {
  //   obj[newKey] = obj[oldKey];
  // }
  addKey(obj, oldKey, newKey, item) {
    obj[newKey] = item[oldKey];
  }

  onClearCart() {
    //let object = { requestorId: this.userInfo.NTID, operation: "Clear" };
    let object = { requestorName: this.userInfo.NTID, operation: "Clear",profile:this.userRole.toUpperCase() };
    this.loader = true;
    this.productService.clearCart(object).subscribe(response => {
      this.loader = false;
      this.projCheck = false;
      this.invCheck = false;
      this.projCount = 0;
      this.invCount = 0;
      this.isDetailsChange = false;
      let resp = response || [];
      let message = resp['STATUS_MESSAGE'] || resp['statusMessage'] || '';
      this.commonWebService.openSnackBar(message, resp['status'])
      this.onfetchReport();
      this.commonService.updatedCart(true);
    }, error => {
      this.loader = false;
      this.commonWebService.openSnackBar('Something went wrong.Can you please try later', 'WARNING')
    })
  }

  onCloseUpdateCart() {
    document.getElementById('updateCartClose').click();
  }

  onFilter($event) {
    if ($event.checked && $event.source.value === 'All') {
      this.cartDataSource = this.cartOriginalDataSource;
    } else {
      this.cartDataSource = this.commonService.filter(this.cartOriginalDataSource, 'RECORD_STATUS', $event.source.value);
    }
  }

  onFilterInventory($event) {
    let filters = {};
    if ($event.checked == true && $event.source.value == "PROJECT" && this.projCount > 0) {
      this.projDetails = [{ key: 'Update Project Details', value: 'projectdetails' }, { key: 'Update Other Details', value: 'otherdetails' }];
      this.projDetail = this.projDetails[0].value;
      this.projCheck = true;
    } else if ($event.checked == false && $event.source.value == "PROJECT") {
      this.projCheck = false;
      this.projDetails = [{ key: 'Update Other Details', value: 'otherdetails' }];
      this.projDetail = this.projDetails[0].value;
    }
    if ($event.checked) {
      this.arr.push($event.source.value)
    } else { this.arr.splice(this.arr.indexOf($event.source.value), 1) }
    filters["ATTRIBUTE6"] = this.arr;
    this.cartDataSource = this.multipleFilterPipe.transform(this.cartOriginalDataSource, filters);
    if (this.cartDataSource.length == 0) {
      this.projCheck = false;
      this.invCheck = false;
    }
    if (filters["ATTRIBUTE6"].length == 0) {
      this.cartDataSource = [];
    }
    this.pushToHeader(this.cartDataSource);
  }

  onSubmit() {
    this.route.navigate(['/hub2u/catalog/cart/checkout'])
  }
  /* Update Cart lINE */
  clearOldVal(event) {
    this.fieldDetail = event.value;
    this.fieldDetails.filter(element => element.value = '');
    this.fieldDate = null;
    this.jobId = '';
    this.headerNoJobResult = false;
  }
  clearOldUpdate(evt) {
    if (evt.value == 'otherdetails') {
      this.projNumber = '';
      this.taskNum = '';
      this.jobId = '';
      this.headerNoTaskResult = false;
      this.headerNoResult = false;
      this.headerNoJobResult = false;
    } else {
      this.resetAll()
    }
  }

  clickToUpdateDate(fieldDetail, event) {
    fieldDetail.value = this.datepipe.transform(event.value, 'yyyy-MM-dd');
  }
  isLen(str) {
    if (str) {
      return str.length > 50
    } else {
      return false;
    }
  }

  ngOnDestroy() {
    if (this.projNumReq != null) {
      this.projNumReq.unsubscribe();
      this.innerLoader = false;
    }
    if (this.taskNumReq != null) {
      this.taskNumReq.unsubscribe();
      this.innerTaskLoader = false;
    }
    if (this.jobIdRequest) {
      this.jobIdRequest.unsubscribe();
      this.innerJobLoader = false;
    }
  }

  /**SOA TO JAVA */
  getImage(item) {
    let image
    if (item) {
      image = this.GetimageService.getImage(item)
      //console.log("image Cartcomponent ", image)
    }
    else {
      image = 'assets/images/no-image.jpg'
    }
    return image;
  }
}
