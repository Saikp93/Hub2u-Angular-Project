import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-update-cart-lines',
  templateUrl: './update-cart-lines.component.html',
  styleUrls: ['./update-cart-lines.component.scss'],
})
export class UpdateCartLinesComponent implements OnInit {
  @Output() close = new EventEmitter<any>();

  constructor() { }

  ngOnInit() { }

  onClose() {
    this.close.emit('');
  }

}
