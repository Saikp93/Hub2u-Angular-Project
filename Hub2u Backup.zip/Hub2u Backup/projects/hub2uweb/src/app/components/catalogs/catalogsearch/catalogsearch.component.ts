import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Inject, OnDestroy, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { DateAdapter } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
//import { CommonSettingService } from 'projects/hub2ushared/src/lib/services/common-settings.service';
import { ReportsService, ProductService, CommonService, ConstantData, MessageService, GetimageService } from 'hub2ushared';
import { Subscription } from 'rxjs';
import { CommonWebService } from '../../../shared/common-web.service';
import { EventService } from '../../../shared/event.service';
import { CommonSettingService } from '../../../shared/common-settings.service';

@Component({
  selector: 'app-catalogsearch',
  templateUrl: './catalogsearch.component.html',
  styleUrls: ['./catalogsearch.component.scss'],
})
export class CatalogsearchComponent implements OnInit, OnDestroy {

  searchInpt: any;
  showMatCard: boolean = false;
  searchResults: any[] = [];
  functionId = '';
  loader: boolean = false;
  userInfo: any = {};
  userRole: any = '';
  list: any[] = ["Everything", "CIFA Item", "Category", "Description", "EIS Model Number"];
  searchPlaceholder: string;
  defSearch: any;
  loaderAddToCart: any[] = [];
  cartLoader: boolean = false;
  cartItems: any[] = [];
  attr6: any;
  needbyDate: any;

  minCurrentDate = new Date();
  maxNewDate = new Date();
  minDate = this.minCurrentDate;
  maxDate = this.maxNewDate.setDate(this.maxNewDate.getDate() + 1);
  needByDate;


  message: any;
  subscription: Subscription;
  searchList: any[];

  @ViewChild('callImagePreview') callImagePreview: TemplateRef<any>;
  previewImage: any;
  subInv: any = "";
  sourceOrg: any;

  constructor(@Inject('environment') private env: any, private searchService: CommonSettingService, private reportService: ReportsService,
    private messageService: MessageService, public datepipe: DatePipe, private commonService: CommonService,
    private productService: ProductService, private commonWebService: CommonWebService, private activatedRoute: ActivatedRoute,
    private alertService: CommonSettingService, private eventService: EventService, private router: Router,
    private constantData: ConstantData, private dialog: MatDialog, private GetimageService: GetimageService) {

    this.subscription = this.messageService.getMessage().subscribe(message => {
      this.message = message;
      this.searchResults = this.message.text;
    });
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.searchInpt = this.searchService.getSearchInput();
    this.activatedRoute.queryParams.subscribe(params => {
      this.searchInpt = params.searchData;
      this.defSearch = params.defSearch;
    });
    this.getPreferenceData();
  }

  onAddItem(size: number, item: any) {
    item.QUANTITY = size;
  }

  get(data) {
    if (data === "Everything") {
      this.searchPlaceholder = "Search by item,category,description...";
    } else if (data === "Category") {
      this.searchPlaceholder = "Search by category...";
    } else if (data === "CIFA Item") {
      this.searchPlaceholder = "Search by cifa item...";
    } else if (data === "Description") {
      this.searchPlaceholder = "Search by item description...";
    } else {
      this.searchPlaceholder = "Search by model number..";
    }

  }

  /**SOA TO JAVA */

  onAddToFavorites(item: any) {
    // this.eventService.showSpinner();
    item['favloading'] = true;
    let request = {
      "profile":this.userRole.toUpperCase(),
      "requestorUserName": this.userInfo.NTID,
      "mfgPartNumber": item.MANUFACTURER_PART_NUM,
      "inventoryItemId": item.INVENTORY_ITEM_ID,
      "cifaItemNumber": item['CIFA#'] ? item['CIFA#'] : item.CIFA_ITEM_NUMBER,
      "category": item['Category'] ? item['Category'] : item.ITEM_CATEGORY,
      "itemDescription": item['Item Description'] ? item['Item Description'] : item.ITEM_DESCRIPTION,
      "regionName": item['Region Name'] ? item['Region Name'] : item.REGION_NAME,
      "templateName": item['Template Name'] ? item['Template Name'] : item.TEMPLATE_NAME,
    };
    this.productService.addToFavorite(request).subscribe(response => {
      let resp = response['favoriteOutput'] || [];
      let message = resp['statusMessage'] || '';

      if (resp['status'] === 'SUCCESS') {
        this.commonWebService.openSnackBar(message, "SUCCESS")
      }
      else if (resp['status'] === 'FAILED') {
        this.commonWebService.openSnackBar(message, "ERROR")
      }
      // this.eventService.hideSpinner();
      item['favloading'] = false;
    }, error => {
      this.commonWebService.openSnackBar("Something went wrong", "ERROR")
      item['favloading'] = false;
    })
  }

  getDefaultOrderType() {
    if (this.functionId == '50' || this.functionId == '57' || this.functionId == '58' || this.functionId == '63') {
      return "INVENTORY"
    }
    //if (this.functionId == '51') {
      if (this.functionId == '136') {
      return "FULFILLMENT"
    }
    if (this.functionId == '99' && (!this.attr6 || this.attr6 == "null")) {
      return 'PROJECT'
    }
    // if (this.functionId != '47' && this.functionId != '99' && this.functionId != '51' && this.functionId != '50' && this.functionId != '57' && this.functionId != '58' && this.functionId != '63') {
      if (this.functionId != '47' && this.functionId != '99' && this.functionId != '136' && this.functionId != '50' && this.functionId != '57' && this.functionId != '58' && this.functionId != '63') {
      return "PROJECT"
    }
  }

  addtoCartResp: any;
  addToCart(cartItem, index) {
    this.eventService.showSpinner();
    // cartItem['cartloading'] = true;
    var attributeFourval = '';
    if (this.functionId == '58' || this.functionId == '60') {
      attributeFourval = cartItem.ATTRIBUTE4;
    }
    // this.loaderAddToCart[index] = true;
    // this.cartLoader = index === '-1' ? true : false;
    if (cartItem.MIN_ORD_QTY == null) {
      cartItem.MIN_ORD_QTY = 1
    }
    let attribut6 = this.getDefaultOrderType();
    var cartInputData = {
      "profile":this.userRole.toUpperCase(),
      "shoppingCartUpsertData": [{
        "attribute3" : this.userRole.toUpperCase(),
        "attribute6": this.attr6 && this.attr6 != 'null' ? this.attr6 : attribut6,
        "cifaItemNumber": cartItem.CIFA_ITEM_NUMBER ? cartItem.CIFA_ITEM_NUMBER : cartItem['CIFA#'],
        "itemDescription": cartItem.ITEM_DESCRIPTION ? cartItem.ITEM_DESCRIPTION : cartItem['Item Description'],
        "itemCategory": cartItem.ITEM_CATEGORY ? cartItem.ITEM_CATEGORY : cartItem['Category'],
        "quantity": cartItem.QUANTITY ? cartItem.QUANTITY : cartItem.MIN_ORD_QTY,
        "needByDate": this.needByDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needByDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (2 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),
        "userName": this.userInfo.NTID,
        "sourceSubInventory": (this.sourceOrg == (cartItem['ORGANIZATION_CODE'] || cartItem['SOURCE_ORGANIZATION_CODE'])) && this.functionId == '99' ? (this.subInv !== "" ? this.subInv : cartItem['SOURCE_SUBINVENTORY']) : cartItem['SOURCE_SUBINVENTORY'],
        "sourceOrganizationCode": cartItem.SOURCE_ORGANIZATION_CODE,
        "regionTemplate": cartItem.TEMPLATE_NAME ? cartItem.TEMPLATE_NAME : cartItem['Template Name'],
        "vendorItemNumber": cartItem.MANUFACTURER_PART_NUM ? cartItem.MANUFACTURER_PART_NUM : cartItem['MODEL#'],
      }]
    }
    this.productService.addToCart(cartInputData).subscribe(response => {
      this.addtoCartResp = response;
      this.getCartItems();
      if (response['status'] == "SUCCESS") {
        this.commonService.updatedCart(true);
      }
      this.cartLoader = false;
      if (this.addtoCartResp.status === "SUCCESS") {
        this.commonWebService.openSnackBar(this.addtoCartResp.statusMessage, "SUCCESS")
      } else if (this.addtoCartResp.status === "FAILED") {
        this.commonWebService.openSnackBar(this.addtoCartResp.statusMessage, "ERROR")
      }
      this.eventService.hideSpinner();
      // cartItem['cartloading'] = false;     
    }, error => {
      this.eventService.hideSpinner();
      // cartItem['cartloading'] = false;
      // this.loaderAddToCart[index] = false;
    });
  }

  getPreferenceData() {
    let request = {
      ParametersInput: [
        { Name: "USER_NAME", Value: this.userInfo.NTID },
        { Name: "USER_TYPE", Value: this.constantData.userRoles.techUser }
      ],
      ReportId: "112"
    }
    this.reportService.onGetDynamicReport(request).subscribe(response => {
      if (response != undefined && response.ROW != undefined) {
        this.needbyDate = response.ROW[0].NEED_BY_DATE_TIME
        this.attr6 = response.ROW[0].ATTRIBUTE5
        this.sourceOrg = response.ROW[0].SOURCE_LOCATION
        this.subInv =  response.ROW[0].SUBINVENTORY 
      }
    }, error => {
      console.log(error);
    })
  }

  getCartItems() {
    let object = {
      ReportId: "115",
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        }
      ]
    };
    this.reportService.onGetDynamicReport(object).subscribe(response => {
      this.cartItems = response.ROW || [];
    }, error => {
    });
  }

  goBack() {
    window.history.back();
  }

  selectSource(sourceItem) {
    this.router.navigate(['hub2u/select_source/'], { state: { item: sourceItem, favItem: sourceItem } })
  }

  onCatalogSearch(searchInput) {
    this.searchResults = null;
    this.alertService.setSearchInput(searchInput);

    if ((searchInput != undefined) && searchInput.length >= 3) {
      this.loader = true;
      var input = {
        "ReportId": this.constantData.dynamicSearchId[this.functionId],
        "ParametersInput": [
          { "Name": "USER_NAME", "Value": this.userInfo.NTID },
          { "Name": "ONE_INPUT", "Value": searchInput },
          { "Name": "ITEM_CATALOG", "Value": "Y" }]
      }
      this.reportService.onGetDynamicReport(input).subscribe(response => {
        if (response != undefined && response.ROW != undefined) {
          this.searchResults = response.ROW;
          this.loader = false;
          this.messageService.sendMessage(this.searchResults);
        } else {
          this.loader = false;
        }
      })
    }
  }

  // getImage(item) {
  //   let imageSrc;

  //   if (this.functionId == '61' || this.functionId == '51' || this.functionId == '58' || this.functionId == '99') {
  //     imageSrc = (item['CIFA#']) ? this.imageURL + item['CIFA#'] + '.jpg' : this.imageURL + (item['MANUFACTURER_PART_NUM'] ? item['MANUFACTURER_PART_NUM'].replace(/ /g, "-") : item['Model Number']) + '.jpg'
  //   }
  //   else
  //     imageSrc = (item['CIFA_ITEM_NUMBER']) ? this.imageURL + item['CIFA_ITEM_NUMBER'] + '.jpg' : this.imageURL + (item['MODEL#'] ? item['MODEL#'].replace(/ /g, "-") : item['MODEL#']) + '.jpg'
  //   return imageSrc;
  // }
  /**SOA TO JAVA */
  getImage(item) {
    let image = this.GetimageService.getImage(item)
    return image;
  }
  openPreview(imagePath) {
    this.previewImage = imagePath
    let dialogRef = this.dialog.open(this.callImagePreview);
    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        if (result === 'yes') {
        } else if (result === 'no') {
        }
      }
    })
  }

  // getLargeImage(cifaItem) {
  //   let img;
  //   img = cifaItem ? this.imageURL + cifaItem.replace(/ /g, "-") + ".jpg" : 'assets/images/no-image.jpg';
  //   return img;
  // }

  /**SOA TO JAVA */
  getLargeImage(cifaItem) {
    let item = cifaItem.replace(/ /g, "-")
    let image = this.GetimageService.getImagefromcifa(item)
    return image;
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
