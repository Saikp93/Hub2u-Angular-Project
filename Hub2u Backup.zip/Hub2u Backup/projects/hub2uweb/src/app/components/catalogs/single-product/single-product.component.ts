import { Component, EventEmitter, Inject, Input, OnInit, Output } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService, ProductService, GetimageService } from 'hub2ushared'

@Component({
  selector: 'app-single-product',
  templateUrl: './single-product.component.html',
  styleUrls: ['./single-product.component.scss'],
})
export class SingleProductComponent implements OnInit {
  @Input() seletedItem: any;
  @Input() favLoader: boolean = false;
  @Input() cartLoader: boolean = false;
  @Input() itemType: any;
  @Input() storeQuantity: any;

  @Output() selectSource = new EventEmitter<any>();
  @Output() addToFavorites = new EventEmitter<any>();
  @Output() addToCart = new EventEmitter<any>();
  @Output() deleteFav = new EventEmitter<any>();
  @Output() checkSubstitute = new EventEmitter<any>();
  @Output() raiseTicketEMit = new EventEmitter<any>();
  functionId: string;
  //imageURL = this.env.baseIMGUrl;

  constructor(@Inject('environment') private env: any, private productService: ProductService, private commonService: CommonService, private _snackBar: MatSnackBar, private GetimageService: GetimageService) { }
  userInfo: any = {};
  ngOnInit() {
    window.scrollTo(0, 0)
    this.onInitialLoad();
  }

  async onInitialLoad() {
    let userInfo = await localStorage.getItem("userDetails");
    this.userInfo = JSON.parse(userInfo);
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
  }

  onAddToCart(item) {
    this.addToCart.emit(item);
  }

  onDeleteFav(item) {
    this.deleteFav.emit(item);
  }

  onAddItem(size: number, item: any) {
    item.QUANTITY = size;

    let obj = {}
    if (this.storeQuantity.length != 0) {
      this.storeQuantity.forEach(element => {
        element[item.RECORD_ID] = item.QUANTITY
      })
    }
    else {  // when length == 0
      obj[item.RECORD_ID] = item.QUANTITY
      this.storeQuantity.push(obj)
    }
    sessionStorage.setItem(this.userInfo.NTID + "Quantity", JSON.stringify(this.storeQuantity));
  }

  onAddToFavorites(item: any) {
    this.addToFavorites.emit(item);
  }

  checkCifaSubstitute(item) {
    this.checkSubstitute.emit(item)
  }

  raiseTicket(item) {
    this.raiseTicketEMit.emit(item)
  }

  onSelectSource() {
    this.selectSource.emit(this.seletedItem);
  }

  // getImage(item) {
  //   let imageSrc;
  //   if(item['CIFA#']) {
  //     imageSrc = this.imageURL + item['CIFA#'] + '.jpg' 
  //   }
  //   else if (item['CIFA_ITEM_NUMBER']) {
  //     imageSrc = this.imageURL + item['CIFA_ITEM_NUMBER'] + '.jpg' 
  //   }
  //   else if(item['MODEL#']) {
  //     imageSrc = this.imageURL + item['MODEL#'].replace(/ /g, "-") + '.jpg' 
  //   }
  //   else if(item['MODEL_NUMBER']) {
  //     imageSrc = this.imageURL + item['MODEL_NUMBER'].replace(/ /g, "-") + '.jpg' 
  //   }
  //   else if (item['MANUFACTURER_PART_NUM']) {
  //     imageSrc = this.imageURL + item['MANUFACTURER_PART_NUM'].replace(/ /g, "-") + '.jpg' 
  //   }
  //   return imageSrc;
  // }

  /**SOA TO JAVA */
  getImage(item) {
    let image = this.GetimageService.getImage(item)
    //console.log("image SingleProductComponent ", image)
    return image;
  }

  alterSize(item) {
    if (item.QUANTITY)
      return item.QUANTITY
    else {
      if (parseInt(item.MIN_ORD_QTY) != 0)
        return parseInt(item.MIN_ORD_QTY)
      else
        return 1;
    }
  }
}
