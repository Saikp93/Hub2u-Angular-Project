import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { MatListModule } from '@angular/material/list';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Hub2usharedModule } from 'hub2ushared';
import { DeactivateGuard } from '../../shared/deactivate-guard';
import { CatalogsComponent } from './catalogs.component';
import { ProductsComponent } from './products/products.component';
import { FiltersComponent } from './filters/filters.component';
import { SearchComponent } from './search/search.component';
import { SingleProductComponent } from './single-product/single-product.component';
import { CartComponent } from './cart/cart.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { UpdateCartLinesComponent } from './update-cart-lines/update-cart-lines.component';
import { CatalogImagesComponent } from './catalog-images/catalog-images.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { SourceComponent } from './source/source.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { CheckoutStatusComponent } from './checkout-status/checkout-status.component';
import { CatalogsearchComponent } from './catalogsearch/catalogsearch.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { UpdateCartComponent } from './update-cart/update-cart.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatBadgeModule } from '@angular/material/badge'
import {MatMenuModule} from '@angular/material/menu';
import { ConfirmationComponent } from '../confirmation/confirmation.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
const routes: Routes = [
  {
    path: '', component: ProductsComponent,
    children: [{
      //  path: '', component: ProductsComponent},

      path: 'cart', component: CartComponent, canDeactivate: [DeactivateGuard],
      children: [
        {
          path: 'checkout', component: CheckoutComponent,
          children: [
            { path: 'checkoutStatus', component: CheckoutStatusComponent }
          ]
        },
      ]
    },
    { path: 'catalogimage', component: CatalogImagesComponent },
    { path: 'catalogsearch', component: CatalogsearchComponent },
    ]
  }];

@NgModule({

  declarations: [CatalogsComponent, ProductsComponent, FiltersComponent, SearchComponent,
    SingleProductComponent, CartComponent, CheckoutComponent, CheckoutStatusComponent, ConfirmationComponent,
    UpdateCartLinesComponent, UpdateCartComponent, CatalogImagesComponent, SourceComponent, CatalogsearchComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    Hub2usharedModule,
    InfiniteScrollModule,
    MatButtonToggleModule,
    MatMenuModule,
    MatIconModule,
    MatButtonModule,
    MatExpansionModule,
    MatCheckboxModule,
    MatRadioModule,
    MatListModule,
    MatAutocompleteModule,
    MatChipsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatTooltipModule,
    MatProgressBarModule,
    MatDatepickerModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    FormsModule,
    MatToolbarModule,
    MatCardModule,
    NgxSpinnerModule,
    MatDialogModule,
    MatBadgeModule,
    RouterModule.forChild(routes)
  ],
  providers: [DeactivateGuard],
  entryComponents: [UpdateCartComponent],
})
export class CatalogsModule { }
