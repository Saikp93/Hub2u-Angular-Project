import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { StorePreferenceDbService } from 'projects/hub2ushared/src/lib/services/store-preference-db.service';
import { StorePreferenceService } from '../../../shared/store-preference.service';
import { Overlay, BlockScrollStrategy } from '@angular/cdk/overlay';
import { MAT_MENU_SCROLL_STRATEGY } from '@angular/material/menu';
export function scrollFactory(overlay: Overlay): () => BlockScrollStrategy {
  return () => overlay.scrollStrategies.block();
}

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
  providers: [
    { provide: MAT_MENU_SCROLL_STRATEGY, useFactory: scrollFactory, deps: [Overlay] }
  ]
})
export class SearchComponent implements OnInit {
  @Input() catalogListLength: any;
  @Input() sortByFilter:any;
  @Input() filterSearch: any;
  @Input() refreshData: any;
  @Input() view : any
  @Input() userDBDetails: any;
  @Output() searchEvent = new EventEmitter<any>();
  @Input() searchValue;
  @Input() isDataLoaded;
  searchForm: FormGroup;
  itemType: any;
  name: any = "catalogs";
  userInfo: any;
  sortBy: any;

  constructor(private fb: FormBuilder, private storePreferenceService : StorePreferenceService,) { }

  ngOnInit() {
    let userInfo = localStorage.getItem("userDetails");
    this.userInfo = JSON.parse(userInfo);
    this.initForm()
  } 

  ngOnChanges(changes: SimpleChanges) {
      if(this.searchForm != undefined) {
        this.sortBy = this.searchForm.value.sortBy
        this.searchForm.get("view").setValue(this.view); 
      }
      if (changes.searchValue !== undefined && !changes.searchValue.firstChange) {
        this.searchForm.get("search").setValue('');
      }
      if(changes.refreshData !== undefined && !changes.refreshData.firstChange) {
        this.searchForm.get("sortBy").setValue('');
        this.sortBy = ""
        this.searchForm.get("search").setValue('');
      }
  }

  initForm() {
    this.searchForm = this.fb.group({
      search: [''],
      sortBy: [''],
      pageSize: ['total'],
      view: this.view
    });
    this.sortBy = ""
  }

  clearSearch() {
    this.searchForm.controls.search.setValue('');
    this.sendMessage();
  }

  changeSortBy() {
    this.sendMessage();
  }

  sendMessage() {
    this.searchForm.value.view = this.view;
    this.searchEvent.emit(this.searchForm.value);
  }

  disable(val) {
    return val;
  }

  setView(event) {
    if(event == 'list') {
      this.searchForm.value.view = "list"
    }
    else if(event == 'grid') {
      this.searchForm.value.view = "grid"
    }
    this.searchEvent.emit(this.searchForm.value);
  }

  storePreference() {
    let con = this.storePreferenceService.storePreference(this.userDBDetails, this.name, "", "", this.searchForm.value.view)
    console.log(con);
  }

  clearPreference() {
    this.storePreferenceService.clearPreference(this.userDBDetails, this.name, "", "", this.searchForm.value.view)
  }
}
