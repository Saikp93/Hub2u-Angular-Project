import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HomeService, ConstantData, CommonService, ProductService, ReportsService, GetimageService } from 'hub2ushared';
import { ErrorStateMatcher } from "@angular/material/core";
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { EventService } from '../../../shared/event.service';
import { CommonSettingService } from '../../../shared/common-settings.service';

export class InstantErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null,
    form: FormGroupDirective | NgForm | null): boolean {
    return control && control.invalid && (control.dirty || control.touched);
  }
}

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss'],
})
export class CheckoutComponent implements OnInit {

  errorStateMatcher = new InstantErrorStateMatcher();
  userInfo: any = {};
  loader: boolean = false;
  deleteLoader: any[] = [];
  cartDataSource: any[] = [];
  cartOriginalDataSource: any[] = [];
  respPayingList = [];
  respCodeList = [];
  respOrderList = [];
  payingList: any[] = [];
  codeList: any[] = [];
  orderList: any[] = [];
  showItems: boolean = false;
  itemMessage: string;
  personId: any;
  public clientForm: FormGroup;
  payList;
  codetransList;
  orderTyp = "Transfer";
  userRole: any = '';
  comTechUser: boolean = false;
  comBusinesServiceUser: boolean = false;
  comCPEUser: boolean = false;
  storeUser: boolean = false;
  cnaUser: boolean = false;
  prepaidUser: boolean = false;
  esaUser: boolean = false;
  checkout: any;
  req: any;
  person_id: string;
  alternateAddress: boolean = false;
  functionId = '1';
  required: boolean = false;

  constructor(private route: Router, private reportsService: ReportsService, private commonService: CommonService,
    private productService: ProductService, private homeService: HomeService, public form: FormBuilder,
    private constants: ConstantData, private sendMsg: CommonSettingService, public datepipe: DatePipe,
    public router: ActivatedRoute, private httpClient: HttpClient, @Inject('environment') private env: any,
    private eventService: EventService, private GetimageService: GetimageService) { }

  minCurrentDate = new Date();
  minNewDate = new Date();
  minDate = this.minCurrentDate;
  minShipDate = this.minNewDate;
  newMinDate = this.minDate.setDate(this.minDate.getDate() + 2);
  newShipDate = this.minShipDate.setDate(this.minShipDate.getDate() + 3);

  ngOnInit() {
    this.onInitialLoad();
    this.onSwitchNPID();
    this.showItems = false;
    this.itemMessage = "Show Items";
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.checkRoles();
    // this.onCodeTransfer();
    // this.onPayingParty();
    // this.fetchOrderType();
    this.clientForm = this.form.group({})
  }

  orderDesc = new FormControl('', [Validators.required]);
  orderNotification = new FormControl('', []);
  payLists = new FormControl('');
  codeLists = new FormControl('', [Validators.required]);
  orderType = new FormControl('');
  needDate = new FormControl(new Date(this.newMinDate), [Validators.required]);
  shipDate = new FormControl(new Date(this.newShipDate), [Validators.required]);
  orderRef = new FormControl('');
  contactNum = new FormControl('');
  notesApprove = new FormControl('', []);
  altAddress = new FormControl('');
  zipcode = new FormControl('', []);
  city = new FormControl('', []);
  state = new FormControl('', []);
  contactName = new FormControl('', []);
  phone = new FormControl('', []);
  email = new FormControl('');
  address1 = new FormControl('', []);
  address2 = new FormControl('');


  checkRoles() {
    // if (this.userRole == this.constants.roles['99']) {
    //   this.comTechUser = true;
    // } 
    if (this.userRole == this.constants.roles['143']) {
      this.comTechUser = true;
    }
    //else if (this.userRole == this.constants.roles['51']) {
      else if (this.userRole == this.constants.roles['136']) {
      this.comBusinesServiceUser = true;
    } else if (this.userRole == this.constants.roles['58']) {
      this.comCPEUser = true;
    } else if (this.userRole == this.constants.roles['50']) {
      this.storeUser = true;
    } else if (this.userRole == this.constants.roles['60']) {
      this.cnaUser = true;
    } else if (this.userRole == this.constants.roles['57']) {
      this.prepaidUser = true;
    } else if (this.userRole == this.constants.roles['61']) {
      this.esaUser = true;
    }
  }
  // public checkError = (controlName: string, errorName: string) => {
  //   return this.clientForm.controls[controlName].hasError(errorName);
  // }

  onSwitchNPID() {
    this.commonService.switchNPID.subscribe(data => {
      this.onInitialLoad();
    })
  }

  async onInitialLoad() {
    let userInfo = await localStorage.getItem("userDetails");
    this.userRole = await localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.userInfo = JSON.parse(userInfo);
    // await this.onfetchReport();
    // await this.fetchDynamicReports();
  }

  // onfetchReport() {
  //   let object = {
  //     ReportId: "115",
  //     ParametersInput: [
  //       {
  //         Name: "USER_NAME",
  //         Value: this.userInfo.NTID
  //       }
  //     ]
  //   };

  //   this.loader = true;
  //   this.reportsService.onGetDynamicReport(object).subscribe(response => {
  //     this.loader = false;
  //     let resp = response.ROW || [];
  //     resp.forEach(x => {
  //       x.isExpand = false;
  //     });
  //     this.cartDataSource = resp;
  //     this.cartOriginalDataSource = resp;
  //   }, error => {
  //     this.loader = false;
  //   });
  // }

  // fetchDynamicReports() {
  //   let request = {
  //     ReportId: 112,
  //     ParametersInput: [
  //       {
  //         Name: "USER_NAME",
  //         Value: this.userInfo.NTID
  //       },
  //       {
  //         Name: "USER_TYPE",
  //         Value: this.userRole
  //       }
  //     ]
  //   };

  //   this.reportsService.onGetDynamicReport(request).subscribe(response => {
  //     this.person_id = response.ROW[0].PERSON_ID
  //     console.log("personId", this.person_id.toString())
  //   })
  // }

  // fetchOrderType() {
  //   if (this.comBusinesServiceUser) {
  //     let request = {
  //       ReportId: 1079,
  //       ParametersInput: [
  //         {
  //           Name: "P_ROLE",
  //           Value: this.userRole
  //         }
  //       ]
  //     };

  //     this.reportsService.onGetDynamicReport(request).subscribe(response => {
  //       this.orderList = response.ROW;
  //       this.orderList.forEach(x => { this.respOrderList.push(x.LOV) });
  //       this.orderTyp = this.respOrderList[0];
  //     })
  //   } else if (this.cnaUser) {
  //     this.respOrderList.push("Fullfillment")
  //     this.orderTyp = "Fullfillment"
  //   }
  //   else {
  //     this.respOrderList.push("Transfer")
  //     this.orderTyp = "Transfer"
  //   }


  // }

  // onCodeTransfer() {
  //   let object = {
  //     ReportId: "10039",
  //     ParametersInput: [
  //       {
  //         Name: "P_CATEGORY",
  //         Value: "REASON_CODE"
  //       }
  //     ]
  //   };

  //   this.reportsService.onGetDynamicReport(object).subscribe(response => {
  //     this.codeList = response.ROW;
  //     this.codeList.forEach(x => { this.respCodeList.push(x.LOV) });
  //   })
  // }

  changed(toggle) {
    if (toggle === true) {
      this.required = true;
      this.zipcode = new FormControl('', [Validators.required]);
      this.city = new FormControl('', [Validators.required]);
      this.state = new FormControl('', [Validators.required]);
      this.contactName = new FormControl('', [Validators.required]);
      this.phone = new FormControl('', [Validators.required]);
      this.address1 = new FormControl('', [Validators.required]);
    } else {
      this.required = false;
      this.zipcode = new FormControl('', []);
      this.city = new FormControl('', []);
      this.state = new FormControl('', []);
      this.contactName = new FormControl('', []);
      this.phone = new FormControl('', []);
      this.address1 = new FormControl('', []);
    }
  }

  zipcodes(event) {
    // console.log("zipcode",this.clientForm.get("zipcode").value);
    var zipValue = this.zipcode.value
    // var result = this.httpClient.get(`https://zip.getziptastic.com/v2/US/`+zipValue);
    //   this.http.get('./app/config/config.json').map((res: Response) => {
    //     this.result = res.json();
    //     return this.result[key];
    // });
    if (zipValue.length == 5) {
      // var response = {
      //   sourceSystem: 'EIS',
      //   addressLine: '1701 JFK',
      //   addressLine2: '',
      //   city: 'Philadelphia',
      //   state: 'PA',
      //   zipCode: null,
      //   countryCode: 'US',
      // };
      // console.log("zipcode length")
      // this.commonService.zipcode(response).subscribe(response => {
      //     console.log("zipcode resp",response);
      //   });
      // this.commonService.zipcode(response).subscribe(response => {
      //       console.log("zipcode resp",response);
      //     });
      // this.reportsService.getZipCode(zipValue).subscribe(response => {
      //   console.log("zipcode resp",response);
      // });
      // this.httpClient.get("https://zip.getziptastic.com/v2/US/" + zipValue).subscribe(response => {
      //   console.log("zipcode resp",response)
      // });
    }
  }

  // onPayingParty() {
  //   let object = {
  //     ReportId: "10039",
  //     ParametersInput: [
  //       {
  //         Name: "P_CATEGORY",
  //         Value: "RESPONSIBLE_PAYING_PARTY"
  //       }
  //     ]
  //   };
  //   this.reportsService.onGetDynamicReport(object).subscribe(response => {
  //     this.payingList = response.ROW;
  //     this.payingList.forEach(x => { this.respPayingList.push(x.LOV) });
  //     this.payList = this.respPayingList[1];
  //   })
  // }

  openItems() {
    this.showItems = !this.showItems;
    if (this.showItems == true) {
      this.itemMessage = "Hide Items"
    } else {
      this.itemMessage = "Show Items"
    }
  }

  onBackToCart() {
    this.route.navigate(['/hub2u/catalog/cart'])
  }

  onCheckout() {
    this.eventService.showSpinner();
    if (!this.comBusinesServiceUser) {
      if (this.comCPEUser || this.cnaUser) {
        this.req = {
          "REQUESTOR_ID": this.person_id ? this.person_id.toString() : '',
          "REQ_DESC": this.orderDesc.value,
          "REQ_ON_BEHALF": this.orderNotification.value,
          "ATTRIBUTE1": this.orderTyp,
          "ATTRIBUTE2": this.datepipe.transform(this.needDate.value, 'MM/dd/yyyy'),
          "ATTRIBUTE3": this.codetransList,
          "ATTRIBUTE4": this.payList,
        }
      } else if (!this.comBusinesServiceUser) {
        this.req = {
          "ORDER_DESC": this.orderDesc.value,
          "REQUESTOR_ID": this.person_id ? this.person_id.toString() : '',
          "REQ_DESC": this.orderDesc.value,
          "REQ_ON_BEHALF": this.orderNotification.value,
        }
      }

      // this.homeService.onProcessCheckOut(this.req).subscribe(response => {
      //   this.checkout = response;
      //   this.eventService.hideSpinner();
      //   this.sendMsg.setOrderNum(this.checkout.ORDER_NUMBER);
      //   this.sendMsg.setStatusMsg(this.checkout.STATUS_MESSAGE);
      //   this.sendMsg.setStatus(this.checkout.STATUS);
      //   this.route.navigate(['/hub2u/catalog/cart/checkout/checkoutStatus'], { state: { order: this.req } })
      // })
    } else if (this.comBusinesServiceUser) {
      // if(this.address1 != "" || this.city != "" || this.state != "" || this.zipcode != ""){}
      let altAddr = 'ADDRESS1.' + this.address1.value + '|' + 'ADDRESS2.' + this.address2.value + '|' + 'CITY.' + this.city.value + '|' + 'STATE.' + this.state.value + '|' + 'ZIP.' + this.zipcode.value + '|' + 'ALT_CONTACT_NAME.' + this.contactName.value + '|' + 'ALT_PHONE.' + this.phone.value + '|' + 'ALT_EMAIL.' + this.email.value
      this.req = {
        "action": "CREATE",
        "attribute1": this.notesApprove.value,
        "attribute2": this.datepipe.transform(this.needDate.value, 'MM/dd/yyyy'),
        "attribute3": altAddr ? altAddr : '',
        "attribute4": this.orderRef.value,
        "contactNumber": this.contactNum.value,
        "orderType": this.orderType.value,
        "emailList": this.orderNotification.value,
        "orderDesc": this.orderDesc.value,
        // "requestorId": this.person_id ? this.person_id.toString() : '',
        "requestorId": this.userInfo.NTID   ,
       "reqDesc": this.orderDesc.value,
        "reqOnBehalf": this.orderNotification.value,
        "profile":this.userRole.toUpperCase()
      }
    } this.homeService.hub2uOrder(this.req).subscribe(response => {
      this.checkout = response.orderDetailResponse[0];
      this.eventService.hideSpinner();
      this.sendMsg.setOrderNum(this.checkout.orderNumber);
      this.sendMsg.setStatusMsg(this.checkout.statusMessage);
      this.sendMsg.setStatus(this.checkout.status);
      this.route.navigate(['/hub2u/catalog/cart/checkout/checkoutStatus'], { state: { order: this.req } })
    }), error => {
      this.eventService.hideSpinner();
    }
  }

  /**SOA TO JAVA */
  getImage(cifaItem) {
    let image = cifaItem ? this.GetimageService.getImagefromcifa(cifaItem) : 'assets/images/no-image.jpg'
    // console.log("image CheckoutComponent ", image)
    return image
  }


}
