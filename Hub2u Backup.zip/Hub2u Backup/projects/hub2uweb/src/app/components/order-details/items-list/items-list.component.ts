import { Component, EventEmitter, Inject, Input, OnChanges, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ConstantData, ReportsService, GetimageService } from 'hub2ushared';
import { MacinfodialogTableComponent } from '../macinfodialog-table/macinfodialog-table.component';

@Component({
  selector: 'app-items-list',
  templateUrl: './items-list.component.html',
  styleUrls: ['./items-list.component.scss'],
})
export class ItemsListComponent implements OnInit {

  @Input() orderDetails: any;
  @Input() reqData: any;
  // @Input() color: any;
  @Input() orderDisplayFields: any;
  @Input() showAckBtn: any;
  @Input() editInfo: any;
  @Input() editBtn: any;
  @ViewChild('callImagePreview') callImagePreview: TemplateRef<any>;
  @Output() cancellableOrders = new EventEmitter<any>();
  serialInfo: any;

  userInfo: any;
  functionId: string;
  userRole: string;
  previewImage;
  imageURL = this.env.baseIMGUrl;
  cancelOrders = [];
  color: any;
  displayFields = [];
  displayLineFields = [];
  loader: any[] = [];

  constructor(@Inject('environment') private env: any, private dialog: MatDialog,
    private constantData: ConstantData, private reportsService: ReportsService, private GetimageService: GetimageService
  ) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
  }
  ngOnChanges() {
    this.displayFields = this.OrganizedCart(this.orderDetails, 'HEADER_COLUMNS');
    this.displayLineFields = this.OrganizedCart(this.orderDetails, 'LINE_COLUMNS');
  }

  OrganizedCart(resp, col) {
    let display_column = [];
    if (resp !== undefined && resp.length !== 0) {
      if (resp[0][col] !== undefined) {
        display_column = this.convertToArray(resp[0][col]);
      }
    }
    return display_column
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
      else {
        col = columns;
      }
    }
    return col;
  }

  isAvailable(key, data) {
    let dataToSearch = [];
    if (data == 'itemListHeader') {
      dataToSearch = this.displayFields
    } if (data == 'itemListLineDetails') {
      dataToSearch = this.displayLineFields
    }
    return dataToSearch.includes(key);
  }

  // getLargeImage(cifaItem) {
  //   let img;
  //   img = cifaItem ? this.imageURL + cifaItem.replace(/ /g, "-") + ".jpg" : 'assets/images/no-image.jpg'; 
  //   return img;
  // }

  getLargeImage(cifaItem) {
    cifaItem = cifaItem.replace(/ /g, "-")
    let image = cifaItem ? this.GetimageService.getImagefromcifa(cifaItem) : 'assets/images/no-image.jpg'
    //console.log("image ItemsListComponent ", image)
    return image
  }
  setVal(event, type) {
    // if(event.target.value == null) {
    //   console.log(event,"'"+event.target.value+"'")
    //   event.target.value = '';
    // }
  }

  statusColor(status) {
    if (status != null)
      status = status.toUpperCase();
    if (this.constantData.statusColors[status] === undefined || status == null) {
      this.color = this.constantData.statusColors.OTHERS;
      return this.constantData.statusColors.OTHERS;
    }
    else {
      this.color = this.constantData.statusColors[status];
      return this.constantData.statusColors[status]
    }
  }

  cancelOrder(order, event) {
    if (event.checked == true) {
      order['checked'] = true;
    }
    else {
      order['checked'] = false;
    }
    // if(event.checked == true) {
    //   if(!(this.cancelOrders.includes(order)))
    //     this.cancelOrders.push(order);
    // }
    // else if(this.cancelOrders.length > 0 && event.checked == false){
    //   if(this.cancelOrders.includes(order)){
    //     let index = this.cancelOrders.indexOf(order);
    //     this.cancelOrders.splice(index, 1);
    //   }
    // }
    // this.cancellableOrders.emit(this.cancelOrders);
  }

  onAddItem(size, order) {
    order['Quantity'] = size;
  }

  toNumber(event) {
    event = parseInt(event);
  }

  openPreview(imagePath) {
    this.previewImage = imagePath
    let dialogRef = this.dialog.open(this.callImagePreview);
    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        if (result === 'yes') {
        } else if (result === 'no') {
        }
      }
    })
  }

  // getImage(item) {
  //   let imageSrc;
  //   if (this.functionId == '60') {
  //     imageSrc = (item['ITEM_NUMBER']) ? this.imageURL + item['ITEM_NUMBER'] + '.jpg' : this.imageURL + (item['MODEL#'] ? item['MODEL#'].replace(/ /g, "-") : item['MODEL#']) + '.jpg'
  //   } else if (this.functionId == '61' || this.functionId == '51' || this.functionId == '58' || this.functionId == '57' || this.functionId == '99' || this.functionId == '63') {
  //     imageSrc = (item['CIFA']) ? this.imageURL + item['CIFA'] + '.jpg' : this.imageURL + (item['Model Number'] ? item['Model Number'].replace(/ /g, "-") : item['Model Number']) + '.jpg'
  //   } else if (this.functionId == '50') {
  //     imageSrc = (item['CIFA#']) ? this.imageURL + item['CIFA#'] + '.jpg' : this.imageURL + (item['MODEL_NUMBER'] ? item['MODEL_NUMBER'].replace(/ /g, "-") : item['MODEL_NUMBER']) + '.jpg'
  //   }
  //   else
  //     imageSrc = (item['ITEM_NUMBER']) ? this.imageURL + item['ITEM_NUMBER'] + '.jpg' : this.imageURL + (item['MODEL_NUMBER'] ? item['MODEL_NUMBER'].replace(/ /g, "-") : item['MODEL_NUMBER']) + '.jpg'
  //   return imageSrc;
  // }

  /**SOA TO JAVA */
  getImage(item) {
    let image = this.GetimageService.getImage(item)
    //console.log("image ItemsListComponent ", image)
    return image;
  }

  // macInfo(item, index){
  //   this.loader[index] = true;
  //   var configReq = {
  //     "ReportId": "10040",
  //     "ParametersInput": [
  //       { "Name": "P_ORDER_NUMBER", "Value": this.reqData.REQUISITION_NUMBER ? this.reqData.REQUISITION_NUMBER : this.reqData['Order No.'] },
  //       // {"Name": "P_LINE_NUMBER", "Value": this.reqData.REQUISITION_NUMBER ? this.reqData.REQUISITION_NUMBER : this.reqData['Order No.']},
  //       // {"Name": "P_INPUT", "Value": item}
  //     ]
  //   }
  //   this.reportsService.onGetDynamicReport(configReq).subscribe(response => {
  //     this.loader[index] = false
  //     this.serialInfo = response; 
  //     this.dialog.open(MacinfodialogTableComponent, 
  //       { panelClass: 'mac-dialog',
  //         height: '65%',
  //         data : this.serialInfo,
  //      }
  //     )
  //   })
  // }

}
