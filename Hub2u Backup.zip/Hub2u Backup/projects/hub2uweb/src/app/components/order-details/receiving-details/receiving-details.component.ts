import { DatePipe } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ProductService } from 'hub2ushared';
import { CommonWebService } from '../../../shared/common-web.service';
import { EventService } from '../../../shared/event.service'

@Component({
  selector: 'app-receiving-details',
  templateUrl: './receiving-details.component.html',
  styleUrls: ['./receiving-details.component.scss'],
})
export class ReceivingDetailsComponent implements OnInit {

  panelOpenState = false;
  @Input() order: any;
  shipmentDetails: any;
  shipmentForm = new FormGroup({});
  loader: boolean;
  disableSubmit: boolean = false;
  date1 : FormControl;
  constructor(private formBuilder: FormBuilder, private commonWebService: CommonWebService, public datepipe: DatePipe, private eventService: EventService, private productService: ProductService) { }

  ngOnInit() {
  }

  createForm() {
    // console.log(this.shipmentDetails);
    let dynamicForm = this.formBuilder.group({});
    this.shipmentDetails.forEach(control => {
      dynamicForm.addControl(control.name, this.formBuilder.control(''));
    })
    return dynamicForm;
  }

  showReceivingDetails() {
    this.panelOpenState = true;
    this.eventService.showSpinner();
    this.getShipmentRest();
  }

  getShipmentRest() {
    let request = {
      requisitionHeaderId: this.order.REQUISITION_HEADER_ID,
      RequisitionLineNumber: this.order.LINE_NUM,
      requisitionNumber: this.order.REQUISITION_NUMBER,
      soLineId: this.order.SO_LINE_ID
    }
    this.productService.getShipmentRest(request).subscribe(response => {
      this.eventService.hideSpinner();
      if(response['requisitionShipmentOutput']) {
        this.shipmentDetails = response['requisitionShipmentOutput'][0];
        if(this.shipmentDetails != undefined){
          this.date1 = new FormControl(new Date(this.shipmentDetails.acknowledgedDate));
          if(this.shipmentDetails.acknowledgedDate != null){
            this.disableSubmit = true;
          }else{
            this.disableSubmit = false;
          }
        }
        //this.shipmentForm = this.createForm(); 
      }
    }, error => {
      console.log(error);
      this.eventService.hideSpinner();
    })
  }

  updatedate(event) { 
    this.shipmentDetails['AcknowledgedDate'] = this.datepipe.transform(event , 'yyyy-MM-dd');
    this.shipmentDetails['acknowledgedDate'] = this.datepipe.transform(event , 'yyyy-MM-dd');    
  }

  insertShipment(shipmentDetails) {
    if(shipmentDetails.acknowledgedQuantity === null || shipmentDetails.acknowledgedDate === null) {
      this.commonWebService.openSnackBar("Please fill Acknowledge Quantity and Acknowledgement Date", "WARNING")
      return;
    }
    this.loader = true;
    let arr = [];
    shipmentDetails['requisitionHeaderId']= this.order.REQUISITION_HEADER_ID;
    shipmentDetails['acknowledgedDate'] = this.datepipe.transform(new Date(shipmentDetails['acknowledgedDate']) , 'MM/dd/yyyy')
    arr.push(shipmentDetails);
    let request = {
      insertRequisitionAckInput: arr
    }
    this.productService.insertShipmentRest(request).subscribe(response => {
      this.loader = false
      if(response['status'] == "SUCCESS") {
        this.commonWebService.openSnackBar(response['statusMessage'], "SUCCESS");
        this.disableSubmit = true;
      }else if(response['status'] == "ERROR") {
        this.commonWebService.openSnackBar(response['statusMessage'], "ERROR");
        this.disableSubmit = false;
      }
      else  {
        this.commonWebService.openSnackBar("Sorry! Something went wrong", "ERROR");
        this.disableSubmit = false;
      }
    }, error => {
      this.loader = false
      this.commonWebService.openSnackBar("Sorry! Something went wrong", "ERROR");
      this.disableSubmit = false;
    })
  }

}
