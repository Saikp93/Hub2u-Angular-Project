import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { AnnouncementsService, CommonService, ConstantData, ProductService, ReportsService } from 'hub2ushared';
import { CommonWebService } from '../../shared/common-web.service';
import { EventService } from '../../shared/event.service';
import { CheckstatuspopupComponent } from '../checkstatuspopup/checkstatuspopup.component';
import { CheckStatusComponent } from '../home/recent-order/check-status/check-status.component';
import { CancelOrderComponent } from './cancel-order/cancel-order.component';
import { DatePipe, Location } from '@angular/common';
import { MacinfodialogTableComponent } from './macinfodialog-table/macinfodialog-table.component';
import { ClearCartComponent } from './clear-cart/clear-cart.component';

@Component({
  selector: 'app-order-history-details',
  templateUrl: './order-history-details.component.html',
  styleUrls: ['./order-history-details.component.scss'],
})
export class OrderDetailsComponent implements OnInit {
  userInfo: any;
  functionId: string;
  userRole: string;
  orderDetails: any;
  orderDetailsResponse: Object;
  regionalAcknowledge: boolean;
  region: string;
  regionalFeedback: boolean;
  statuses = [] = ['All'];
  reqData: any;
  person_id: any;
  color: string;
  verifyStatus = [];
  showFeedbckBtn: boolean = null;
  checked = false;
  indeterminate = false;
  statusCollection = [];
  orderDetailsData: any;
  userConfigs: any;
  contactDetails: any;
  userIconConfig: any;
  ischeckStatus = false;
  showAckBtn: boolean;
  contactInput: boolean;
  contactLabel: boolean;
  altDelivery: boolean;
  showShipToAltInput: boolean;
  editBtn: boolean;
  saveBtn: boolean;
  cancelBtn: boolean;
  visibleLineItems = [];
  orderDisplayFields = [];
  editDate: boolean;
  displayDate: boolean = true;
  editInfo: any;
  needByDate: string;
  altContact: string;
  copyOfOrderDetails: any;
  //cancellableOrderList: any;
  recentOrder = [];
  displayFields = [];
  displayLineFields = [];
  loader: boolean = false;
  infoLoader: boolean = false;
  displayCancelBtn: boolean;
  serialInfo: any;
  prevUrl;
  url: boolean;
  loaderOrderitem: boolean;
  storeOrder: any = '';

  constructor(
    private router: Router,
    private reportsService: ReportsService,
    private eventService: EventService,
    private commonWebService: CommonWebService,
    private constantData: ConstantData,
    private productService: ProductService,
    private announcementsService: AnnouncementsService,
    private bottomSheet: MatBottomSheet,
    public dialog: MatDialog, private commonService: CommonService,
    public date: DatePipe, private _location: Location
  ) {
    // this.reqData = this.router.getCurrentNavigation().extras.state.order;
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.prevUrl = sessionStorage.getItem("Prev_Url");
    this.url = (this.prevUrl == ('/hub2u/catalog/cart/checkout/checkoutStatus')) ? false : true;
    this.reqData = JSON.parse(localStorage.getItem("reqData"));
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.region = this.userInfo.region;

    this.loader = true;
    this.displayFields = this.OrganizedCart(this.reqData, 'HEADER_COLUMNS');
    this.displayLineFields = this.OrganizedCart(this.reqData, 'LINE_COLUMNS');
    this.getRecentOrders();
    this.getConfigurableUIData();
    this.getEditableUIData();
    this.fetchDynamicReports();
    this.fetchOrders();
  }

  OrganizedCart(resp, col) {
    let display_column = [];
    if (resp[col] !== undefined) {
      display_column = this.convertToArray(resp[col]);
    }
    return display_column
  }

  convertToArray(columns: string) {
    let col;
    if (columns !== '') {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",")
      }
      else {
        col = columns;
      }
    }
    return col;
  }

  isAvailable(key, data) {
    let dataToSearch = [];
    if (data == 'orderHistoryDetails') {
      dataToSearch = this.displayFields
    } if (data == 'orderHistoryLineDetails') {
      dataToSearch = this.displayLineFields
    }
    return dataToSearch.includes(key);
  }

  getEditableUIData() {
    let configReq = {
      //"ReportId": "10020",
       "ReportId": "7021",
      "ParametersInput": [
        { "Name": "LOOKUP_TYPE", "Value": "XXCMST_HUB2U_EDIT_FIELDS" }
      ]
    }
    this.reportsService.onGetDynamicReport(configReq).subscribe(response => {
      response.ROW.forEach(item => {
        let obj = {}
        if (this.userRole != null || this.userRole != undefined) {
          if (item.DESCRIPTION === this.userRole.toUpperCase()) {
            //roleEditFieldNames.push(item.MEANING);
            if (item.ATTRIBUTE1) {
              obj = {
                "labelname": item.ATTRIBUTE5,
                //"editFieldName" : item.MEANING,
                "fieldType": item.ATTRIBUTE4,
                "editable": item.ATTRIBUTE3,
                "displayOrNot": item.ATTRIBUTE2,
                "columnName": item.ATTRIBUTE1,
              }
              this.visibleLineItems.push(obj);
            }
          }
        }
      })
      // console.log('Visible Line Items ', this.visibleLineItems);
      this.visibleLineItems.forEach(item => {
        if (item.displayOrNot === 'Y') {
          this.orderDisplayFields.push(item);
        }
      })
      //console.log('Order Display Fields: ', this.orderDisplayFields)
    });
  }

  editOrderFields() {
    this.saveBtn = true;
    this.editInfo = true;
    if (this.userConfigs.ATTRIBUTE13 === "Yes") {
      this.contactInput = true;
      this.contactLabel = false;
    }
    else {
      this.contactLabel = true
      this.contactInput = false;
    }
    if (this.userConfigs.ATTRIBUTE14 === "Yes") {
      this.altDelivery = false;
      this.showShipToAltInput = true;
    }
    else {
      this.altDelivery = true;
      this.showShipToAltInput = false;
    }
    if (this.userConfigs.ATTRIBUTE10 === 'Yes') {
      this.editDate = true;
      this.displayDate = false;
    }
    else {
      this.editDate = false;
      this.displayDate = true;
    }
  }

  dateFormatter(date) {
    if (date === "" || date === undefined) {
      return "";
    }
    var tempDate = date;
    if (date.replace != undefined) {
      tempDate = new Date(date.replace(/-/g, '/').replace('T‌​', ' ').replace(/\..*|\+.*/, ""));
    }
    var month = ("0" + (tempDate.getMonth() + 1)).slice(-2);
    var day = ("0" + tempDate.getDate()).slice(-2);
    // var displayDate = tempDate.getFullYear() + "-" + month + "-" + day;
    var displayDate = month + "/" + day + "/" + tempDate.getFullYear();
    return displayDate;
  }

  getTrackingNo(trackingNo) {
    if (trackingNo != undefined && trackingNo != null && trackingNo.toString().startsWith("https")) {
      let no = trackingNo.split('>')[1]
      return no;
    } else {
      return trackingNo;
    }
  }

  saveDateFormatter(date) {
    if (date === "" || date === undefined) {
      return "";
    }
    var tempDate = date;
    if (date.replace != undefined) {
      tempDate = new Date(date.replace(/-/g, '/').replace('T‌​', ' ').replace(/\..*|\+.*/, ""));
    }
    var month = ("0" + (tempDate.getMonth() + 1)).slice(-2);
    var day = ("0" + tempDate.getDate()).slice(-2);
    var displayDate = tempDate.getFullYear() + "-" + month + "-" + day;
    // var displayDate =  month + "/" + day + "/" + tempDate.getFullYear();
    return displayDate;
  }

  saveNeedByDate(event) {
    // console.log("need by date ", event);
    // let needByDate = this.dateFormatter(event) + "T00:00:00";
    let needByDate = this.dateFormatter(event);
    this.needByDate = needByDate
  }

  saveContact(event) {
    this.altContact = event;
  }

  cancellableOrders(event) {
    //this.cancellableOrderList = event;

  }

  fetchDynamicReports() {
    let request = {
      // ReportId: 112,
      // ReportId: "7001",
      ReportId:this.constantData.userprofileData[this.functionId],
      ParametersInput: [
        {
          Name: "USER_NAME",
          Value: this.userInfo.NTID
        },
        
      ]
    };

    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response.ROW !== undefined) {
        this.person_id = response.ROW[0].PERSON_ID
      }
    })
  }

  saveOrderFields() {
    let saveData: any = [];
    let status: any;
    // let qty : any;
    let editedList: any = [];
    let editContact = [];
    let attr7 = "";
    if (this.orderDetails && this.orderDetails.length > 0) {
      if (this.contactDetails.ATTRIBUTE7) {
        editContact = this.contactDetails.ATTRIBUTE7.split("|");
        if (editContact != undefined || editContact != null) {
          if (editContact[5] != undefined) {
            var contactName = editContact[5].split(".");
            contactName[1] = this.altContact ? this.altContact : contactName[1];
            var newContact = contactName.join(".");
            editContact[5] = newContact;
          } else {
            editContact[5] = this.reqData['CONTACT NAME'] ? this.reqData['CONTACT NAME'] : this.reqData['Contact Name'];
          }
        }
        attr7 = editContact.join("|");
      }
    }

    if (this.needByDate != undefined || this.needByDate != null) {
      this.reqData['Need By Date'] = this.saveDateFormatter(this.needByDate);
    }
    if (this.altContact != undefined || this.altContact != null) {
      this.reqData['Contact Name'] = this.altContact;
    }

    let cancelCount = 0;
    let checkedCount = 0;
    this.orderDetails.forEach(order => {
      if (order.Status != 'Cancelled') {
        cancelCount++;
      }
      if (order.checked && order.checked == true) {
        checkedCount++;
      }
      //console.log("status",qty['Quantity'],qty,editedList,editedList.Quantity)
      saveData.push({
        "attribute1": order.ATTRIBUTE1,
        "attribute2": order.ATTRIBUTE2,
        "attribute3": order.ATTRIBUTE3,
        "attribute4": order.ATTRIBUTE4,
        "attribute5": order.ATTRIBUTE5,
        "attribute6": order.ATTRIBUTE6,
        "attribute7": attr7 ? attr7 : order.ATTRIBUTE7,
        "attribute8": order.ATTRIBUTE8,
        "attribute9": order.ATTRIBUTE9,
        "attribute10": order.ATTRIBUTE10,
        "attribute11": order.ATTRIBUTE11,
        "attribute12": order.ATTRIBUTE12,
        "attribute13": order.ATTRIBUTE13,
        "attribute14": order.ATTRIBUTE14,
        "attribute15": order.ATTRIBUTE15,
        "attribute16": order.ATTRIBUTE16,
        "attribute17": order.ATTRIBUTE17,
        "attribute18": order.ATTRIBUTE18,
        "attribute19": order.ATTRIBUTE19,
        "attribute20": order.ATTRIBUTE20,
        "attribute21": "",
        "attribute22": "",
        "attribute23": "",
        "attribute24": "",
        "attribute25": "",
        "attribute26": "",
        "attribute27": "",
        "attribute28": "",
        "attribute29": "",
        "attribute30": "",
        "attribute31": "",
        "attribute32": "",
        "attribute33": "",
        "attribute34": "",
        "attribute35": "",
        "attribute36": "",
        "attribute37": "",
        "attribute38": "",
        "attribute39": "",
        "attribute40": "",
        "categoryDesc": order.LINE_CATEGORY ? order.LINE_CATEGORY : "",
        "chargeAccountId": "",
        "createdBy": "",
        "createdDate": order.CREATION_DATE ? order.CREATION_DATE : "",
        "customerAccntNum": "",
        "deliveryLocationCode": order.DELIVER_TO_LOCATION ? order.DELIVER_TO_LOCATION : order['Delivery to Site'],
        "deliveryToLocationId": "",
        "destOrgCode": order.DESTINATION_ORG_CODE ? order.DESTINATION_ORG_CODE : "",
        "destOrgId": "",
        "destSubInventory": order.DESTINATION_SUBINVENTORY ? order.DESTINATION_SUBINVENTORY : "",
        "errorMessage": "",
        "expenditureItemDate": order.EXPENDITURE_ITEM_DATE ? order.EXPENDITURE_ITEM_DATE : "",
        "expenditureOrg": order.EXPENDITURE_ORG ? order.EXPENDITURE_ORG : "",
        "expenditureOrgId": "",
        "expenditureType": order.EXPENDITURE_TYPE ? order.EXPENDITURE_TYPE : "",
        "fromStoreId": order.SOURCE_ORG_CODE ? order.SOURCE_ORG_CODE : order['Source Site'],
        "groupId": order.REQUISITION_NUMBER ? order.REQUISITION_NUMBER : order['Order No.'],
        "inventoryItemId": "",
        "itemCategory": order.LINE_CATEGORY ? order.LINE_CATEGORY : "",
        "itemCategoryId": "",
        "itemDesc": order.LINE_DESCRIPTION ? order.LINE_DESCRIPTION : "",
        "justification": "",
        "lastUpdatedBy": "",
        "lastUpdatedDate": order.LAST_UPDATE_DATE ? order.LAST_UPDATE_DATE : "",
        "lineId": order.LINE_NUMBER ? order.LINE_NUMBER : order.LINE_NUM,
        "lineNumber": order.LINE_NUMBER ? order.LINE_NUMBER : order.LINE_NUM,
        "lineTypeId": "",
        "needByDate": this.needByDate ? this.needByDate : order['Need By Date'], //format can be changed
        "noteToApprover": order.NOTE_TO_AGENT ? order.NOTE_TO_AGENT : "",
        "noteToReceiver": order.NOTE_TO_RECEIVER ? order.NOTE_TO_RECEIVER : "",
        "orderSource": order.ORDER_SOURCE ? order.ORDER_SOURCE : "",
        "orderStatus": order.STATUS,
        "projectId": "",
        "projectNumber": order.PROJECT_NUMBER ? order.PROJECT_NUMBER : "",
        "quantity": order.checked ? 0 : order.Quantity,
        "recordStatus": "",
        "regionName": "",
        "reqDistributionId": "",
        "requestId": order.REQUEST_ID,
        "requestorId": order.REQUESTOR_ID ? order.REQUESTOR_ID : "",
        "requisitionHeaderId": order.REQUISITION_HEADER_ID ? order.REQUISITION_HEADER_ID : "",
        "requisitionLineId": order.REQUISITION_LINE_ID ? order.REQUISITION_LINE_ID : "",
        "sourceOrgCode": order.SOURCE_ORG_CODE ? order.SOURCE_ORG_CODE : order['Source Site'],
        "sourceOrgId": "",
        "sourceSubInventory": order.SOURCE_SUBINVENTORY ? order.SOURCE_SUBINVENTORY : "",
        "sourceSystem": "HUB2U",
        "sourceTrxReference": "",
        "taskId": "",
        "taskNumber": order.PROJECT_TASK_NUMBER ? order.PROJECT_TASK_NUMBER : "",
        "templateName": order['KIT Name'] ? order['KIT Name'] : order['Template Name'],
        "toStoreId": order.DELIVER_TO_LOCATION ? order.DELIVER_TO_LOCATION : order['Delivery to Site'],
        "transactionDate": "",
        "transactionType": "ORDER_UPDATE",
        "unitOfMeasure": order.UNIT_TYPE ? order.UNIT_TYPE : "",
        "unitPrice": order.UNIT_PRICE ? order.UNIT_PRICE : "",
        "vendorId": "",
        "vendorItemNumber": order['Model Number'] ? order['Model Number'] : "",
        "vendorSiteId": ""
      });

    });
    this.eventService.showSpinner();
    this.saveBtn = false;
    this.editInfo = false;
    this.displayDate = true;
    this.editDate = false;
    this.contactInput = false;
    this.contactLabel = true;
    this.altDelivery = true;
    this.showShipToAltInput = false;
    let details = [{}]
    if (checkedCount == cancelCount) {
      this.reqData.STATUS = "Cancelled"
      localStorage.setItem("reqData", JSON.stringify(this.reqData))
    }
    let request = {
      action: (checkedCount == cancelCount) ? "CANCEL" : "UPDATE",
      groupId: this.functionId == '63' ? this.reqData['S.O.#:'] : this.reqData['Order No.'],
      porderNo: "",
      // requestorId: this.userInfo.NTID,
      orderDetails: saveData,
      profile:this.userRole.toUpperCase()
    }
    this.productService.hub2uOrder(request).subscribe(response => {
      if (response != undefined) {
        this.orderDetailsResponse = response['orderDetailResponse']
        let message = this.orderDetailsResponse[0].statusMessage;
        if (this.orderDetailsResponse[0].status == 'SUCCESS') {
          this.commonWebService.openSnackBar(message, "SUCCESS")
        } else if (this.orderDetailsResponse[0].status == 'ERROR') {
          this.commonWebService.openSnackBar(message, "ERROR")
        }
      }
      this.eventService.hideSpinner();
      this.fetchDynamicReport();
      this.getRecentOrders();
    }, error => {
      this.commonWebService.openSnackBar("There is some error in updating the order", "ERROR")
      this.fetchDynamicReport();
      this.eventService.hideSpinner();
    });
  }

  getConfigurableUIData() {
    var configReq = {
      //"ReportId": "10020",
     "ReportId": "7021",
      "ParametersInput": [
        { "Name": "LOOKUP_TYPE", "Value": "XXCMST_USERPROFILE_SETTINGS" }
      ]
    }
    this.reportsService.onGetDynamicReport(configReq).subscribe(response => {
      response.ROW.forEach(userConfig => {
        if (userConfig.LOOKUP_CODE === this.userRole.toUpperCase()) {
          this.userConfigs = userConfig;
        }
      });
      this.fetchDynamicReport();
    })
  }

  statusColor(status) {
    if (status != undefined) {
      status = status.toUpperCase();
      if (this.constantData.statusColors[status] === undefined) {
        this.color = this.constantData.statusColors.OTHERS;
        return this.constantData.statusColors.OTHERS;
      }
      else {
        this.color = this.constantData.statusColors[status];
        return this.constantData.statusColors[status]
      }
    }
  }

  validateUserForAcknowledgement() {     // tech user
    // let request = {
    //   BIND_APPLICATIONID: 1,
    //   FUNCTIONID: 7
    // }
    let request = {
      applicationId:7 ,
      functionId: 7,
    }
    this.announcementsService.regUsingResp(request).subscribe(response => {
      this.renderAfterSelectedRegions(response);
    })
  }

  // renderAfterSelectedRegions(data) {
  //   let regions = data;
  //   let t = false;
  //   if ((this.region != null || this.region != undefined) && regions.EXC_DB_REGION_RESP_USAGEOutput) {
  //     regions.EXC_DB_REGION_RESP_USAGEOutput.forEach(item => {
  //       if (this.region != undefined && this.region.indexOf(item.REGION_CODE) > -1) {
  //         t = true;
  //       }
  //     });
  //   }
  //   if (regions != undefined && regions.EXC_DB_REGION_RESP_USAGEOutput != undefined && t) {
  //     this.regionalAcknowledge = true;
  //   } else {
  //     this.regionalAcknowledge = false;
  //   }
  //   this.validateUserForFeedback();
  // }

  renderAfterSelectedRegions(data) {
    console.log("this.region", this.region)
    let regions = data;
    let t = false;
    if ((this.region != null || this.region != undefined) && regions.regionDetailOutput) {
      regions.regionDetailOutput.forEach(item => {
        if (this.region != undefined && this.region.indexOf(item.regionCode) > -1) {
          t = true;
        }
      });
    }
    if (regions != undefined && regions.regionDetailOutput != undefined && t) {
      this.regionalAcknowledge = true;
    } else {
      this.regionalAcknowledge = false;
    }
    this.validateUserForFeedback();
  }

  validateUserForFeedback() {
    // let request = {
    //   BIND_APPLICATIONID: 1,
    //   FUNCTIONID: 8
    // }
    let request = {
      applicationId: 1,
      functionId: 8,
    }
    this.announcementsService.regUsingResp(request).subscribe(response => {
      this.renderAfterFeedbackValidation(response);
    })
  }

  // renderAfterFeedbackValidation(data) {
  //   let orders = this.orderDetails;
  //   let regions = data;
  //   let t = false;
  //   if (this.region !== null && regions.EXC_DB_REGION_RESP_USAGEOutput) {     // check if this is regions output or usage output
  //     regions.EXC_DB_REGION_RESP_USAGEOutput.forEach(item => {
  //       if (this.region.indexOf(item.REGION_CODE) > -1) {
  //         t = true;
  //         // console.log(this.region, item.REGION_CODE);
  //       }
  //     });
  //   }
  //   if (regions != undefined && regions.EXC_DB_REGION_RESP_USAGEOutput != undefined && t) {
  //     this.regionalFeedback = true;
  //   } else {
  //     this.regionalFeedback = false;
  //   }
  //   this.showFeedback();
  //   if(this.functionId != '58' && this.functionId != '60' && this.functionId != '61') {
  //     for (let item = 0; item <orders.length; item++) {
  //       orders[item]['showAckBtn'] = true;
  //     }
  //   }
  // }

  /**SOA TO JAVA */
  renderAfterFeedbackValidation(data) {
    let orders = this.orderDetails;
    let regions = data;
    let t = false;
    if (this.region !== null && regions.regionDetailOutput) {     // check if this is regions output or usage output
      regions.regionDetailOutput.forEach(item => {
        if (this.region.indexOf(item.regionCode) > -1) {
          t = true;
          // console.log(this.region, item.REGION_CODE);
        }
      });
    }
    if (regions != undefined && regions.regionDetailOutput != undefined && t) {
      this.regionalFeedback = true;
    } else {
      this.regionalFeedback = false;
    }
    this.showFeedback();
    if (this.functionId != '58' && this.functionId != '60' && this.functionId != '61') {
      for (let item = 0; item < orders.length; item++) {
        orders[item]['showAckBtn'] = true;
      }
    }
  }

  showFeedback() {
    if (this.reqData.STATUS == "Approved") {
      //if (this.reqData.ISO_ORDER_NUMBER != null && this.regionalFeedback) {
      if (this.reqData['S.O.#:'] != null && this.regionalFeedback) {

        this.showFeedbckBtn = true;
        // this.eventService.hideSpinner();
      }
      //if (this.reqData.ISO_ORDER_NUMBER != null && this.regionalAcknowledge) {
      if (this.reqData['S.O.#:'] != null && this.regionalAcknowledge) {
        this.showAckBtn = true;
        // this.eventService.hideSpinner();
      }
      // else
      // this.eventService.hideSpinner();
    }
    else {
      // this.eventService.hideSpinner();
      this.showFeedbckBtn = false;
    }
  }

  fetchDynamicReport() {
    this.loader = true;
    let req = (this.reqData.REQUISITION_NUMBER !== null && this.reqData.REQUISITION_NUMBER !== undefined) ? this.reqData.REQUISITION_NUMBER : this.reqData['Order No.']
    var request = {
      ParametersInput: [],
      ReportId: this.constantData.dynamicorderDetailsId[this.functionId]
    }
    if (this.functionId == '57') {
      request.ParametersInput.push(
        { Name: "REQUESTOR", Value: this.userInfo.NTID },
        { Name: "REQUISITION_NUMBER", Value: req }
      )
    } else {
      request.ParametersInput.push(
        { Name: "REQUESTOR", Value: this.userInfo.NTID },
        { Name: "REQUISITION_NUMBER", Value: req },
        { Name: "P_CATALOG", Value: this.userRole }
      )
    }
    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      this.loader = false;
      if (response.ROW != undefined) {
        this.orderDetails = response.ROW;
        this.orderDetailsData = this.orderDetails;
        let data = this.orderDetails;
        this.validateUserForAcknowledgement();

        this.orderDetails.forEach(userConfig => {
          this.contactDetails = userConfig;
        })

        if (this.needByDate != undefined || this.needByDate != null) {
          data.forEach(order => {
            order.NEED_BY_DATE = this.needByDate;
          });
        }

        this.copyOfOrderDetails = this.orderDetails;
        this.getFilteringFields();
        // if (this.functionId == '51' || this.functionId == '58' || this.functionId == '64' || this.functionId == '63' || this.functionId == '66') {
        if (this.functionId == '136' || this.functionId == '58' || this.functionId == '64' || this.functionId == '63' || this.functionId == '66') {
          this.showIcons();
        }
        else {
          this.showFields();
        }
      } else {
        this.loader = false;
      }
    }, error => {
      this.loader = false;
      //  console.log(error);
    })
  }

  showIcons() {

    var configReq = {
      //"ReportId": "10055",
      // "ReportId": "7022",
      "ReportId": this.functionId == '136'?"7022":"10055",
      "ParametersInput": [
        { "Name": "P_LOOKUP_TYPE", "Value": "XXCMST_USERPROFILE_SETTINGS" },
        { "Name": "P_PROFILE", "Value": this.userRole ? this.userRole.toUpperCase() : "" },
        { "Name": "P_GROUP_ID", "Value": this.functionId == '63' ? this.reqData['GROUP_ID'] : (this.reqData.REQUISITION_NUMBER ? this.reqData.REQUISITION_NUMBER : this.reqData['Order No.']) }
      ]
    }
    this.reportsService.onGetDynamicReport(configReq).subscribe(response => {
      let editSatusIcon = "";
      let cancelStatucIcon = "";
      if (response != undefined && response != null && response.ROW != undefined) {
        this.userIconConfig = response.ROW[0];

        if (this.userIconConfig.ATTRIBUTE6) {
          editSatusIcon = this.userIconConfig.ATTRIBUTE6.split(",");
        }

        if (this.userIconConfig.ATTRIBUTE15) {
          cancelStatucIcon = this.userIconConfig.ATTRIBUTE15.split(",");
        }

        // if (this.functionId == '51' || this.functionId == '64') {
        if (this.functionId == '136' || this.functionId == '64') {
          if (this.userIconConfig.ATTRIBUTE5 === "Yes" && (editSatusIcon.indexOf(this.reqData.STATUS) >= 0) && this.reqData.STATUS != "CANCELLED") {
            this.editBtn = true;
            this.saveBtn = false;
          }
          else {
            this.editBtn = false;
            this.saveBtn = false;
          }

          if (this.userIconConfig.ATTRIBUTE11 === "Yes" && (cancelStatucIcon.indexOf(this.reqData.STATUS) >= 0)) {
            this.cancelBtn = true
          } else {
            this.cancelBtn = false
          }
        }

        if (this.functionId == '58' || this.functionId == '63') {
          if (this.userIconConfig.ATTRIBUTE11 === "Yes" && (cancelStatucIcon.indexOf(this.reqData.STATUS) >= 0)) {
            this.cancelBtn = true
          } else {
            this.cancelBtn = false
          }
        }

      }
      this.showFields();
    })

  }

  showFields() {
    if (this.orderDetails && this.orderDetails.length > 0) {
      let statusLocksForEdit = "";
      let cancelStatucIcon = "";
      if (this.userIconConfig != undefined) {
        if (this.userConfigs.ATTRIBUTE6) {
          statusLocksForEdit = this.userConfigs.ATTRIBUTE6.split(",");
        }
        if (this.userIconConfig.ATTRIBUTE15) {
          cancelStatucIcon = this.userIconConfig.ATTRIBUTE15.split(",");
        }

        if (this.userIconConfig.ATTRIBUTE5 === "Yes" && (statusLocksForEdit.indexOf(this.reqData.STATUS) >= 0) && this.reqData.STATUS != "CANCELLED") {
          this.editBtn = true;
          this.saveBtn = false;
        }
        else {
          this.editBtn = false;
          this.saveBtn = false;
          this.cancelBtn = false
        }

        if (this.userIconConfig.ATTRIBUTE11 === "Yes" && (cancelStatucIcon.indexOf(this.reqData.STATUS) >= 0)) {
          this.cancelBtn = true;
          if (this.reqData.STATUS == "Cancelled") {
            this.cancelBtn = false;
            this.editBtn = false;
          }
        }
        else {
          this.cancelBtn = false;
          if (this.reqData.STATUS == "Cancelled") {
            this.cancelBtn = false;
            this.editBtn = false;
          }
        }
        let statusLocksForCancel = "";
        if (this.userConfigs.ATTRIBUTE15 != null) {
          statusLocksForCancel = this.userConfigs.ATTRIBUTE15.split(",");
        }
        // if (!(this.functionId == '58') && !(this.functionId == '63') && !(this.functionId == '57') && !(this.functionId == '51') && !(this.functionId == '60')) {
        if (!(this.functionId == '58') && !(this.functionId == '63') && !(this.functionId == '57') && !(this.functionId == '136') && !(this.functionId == '60')) {
          if (this.reqData.CANCELLED_FLAG == "Yes") {
            if (this.userConfigs.ATTRIBUTE11 === "Yes" && !(statusLocksForCancel.indexOf(this.reqData.STATUS) >= 0)) {
              this.cancelBtn = true;
            }
            else {
              this.cancelBtn = false;
            }
          }
          else if (this.reqData.CANCELLED_FLAG == "No") {
            this.cancelBtn = false;
          }
        }
      }
      if (this.functionId == '58' || this.functionId == '63') {
        if (this.userConfigs.ATTRIBUTE11 === "Yes") {
          if (this.reqData.STATUS === 'Pending Approval' || this.reqData.STATUS === 'Sent to Fulfillment Center') {
            this.cancelBtn = true;
          }
          else {
            this.cancelBtn = false;
          }
        }
      }
    }
    this.loader = false;
    this.displayCancelBtn = this.cancelBtn
  }

  getFilteringFields() {
    let data = this.orderDetails;
    this.statusCollection = [{ "name": "All", "selected": true }];
    if (data) {
      data.forEach(order => {
        if (order.LINE_STATUSES != null && !this.statuses.includes(order.LINE_STATUSES)) {
          this.statuses.push(order.LINE_STATUSES);
          this.statusCollection.push(
            {
              "name": order.LINE_STATUSES,
              "selected": true
            }
          )
        }
      });
    }
  }

  statusChecked(event: any, status) {
    this.orderDetailsData = [];
    this.statusCollection.forEach(element => {
      if (element.name === status)
        element.selected = event.checked;
    })
    if (status == 'All' && event.checked == true) {
      for (let i = 1; i < this.statusCollection.length; i++) {
        this.statusCollection[i].selected = true;
      }
      this.orderDetailsData = this.orderDetails;
      return;
    }
    if (status == 'All' && event.checked == false) {
      for (let i = 1; i < this.statusCollection.length; i++) {
        this.statusCollection[i].selected = false;
      }
      this.orderDetailsData = null;
      return;
    }
    if (this.statusCollection.length == 2 && this.statusCollection[1].selected == true) {
      this.statusCollection[0].selected = true;
      this.orderDetailsData = this.orderDetails;
      return;
    }

    let data = this.orderDetails;
    this.statusCollection.forEach(element => {
      if (element.selected === true) {
        data.forEach(order => {
          if (order.LINE_STATUSES == element.name) {
            this.orderDetailsData.push(order);
          }
        });
      }
    })
    if (this.orderDetailsData.length == 0) {
      this.statusCollection.forEach(element => {
        if (element.name == 'All')
          element.selected = false;
      })
    }
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(CancelOrderComponent, {
      // width: '500px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.cancelOrder();
      }
    });
  }

  seperateMethod() {

  }

  updateStatus: any;
  fetchOrders() {
    let request = {
      ParametersInput: [{
        Name: "REQUESTOR",
        Value: this.userInfo.NTID,
      },
      {
        Name: 'P_ORDER_NO',
        Value: this.reqData['Order No.']
      }
      ],
      ReportId: this.constantData.dynamicmyorderId[this.functionId]
    };
    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      // console.log("resp",response.ROW[0].STATUS)
      if (response != undefined && response.ROW != undefined) {
        this.updateStatus = response.ROW[0].STATUS
      }
    })
  }
  cancelOrder() {
    let cancelData: any = [];
    this.orderDetails.forEach(order => {
      console.log("order", order)
      cancelData.push({
        "attribute1": order.ATTRIBUTE1,
        "attribute2": order.ATTRIBUTE2,
        "attribute3": order.ATTRIBUTE3,
        "attribute4": order.ATTRIBUTE4,
        "attribute5": order.ATTRIBUTE5,
        "attribute6": order.ATTRIBUTE6,
        "attribute7": order.ATTRIBUTE7,
        "attribute8": order.ATTRIBUTE8,
        "attribute9": order.ATTRIBUTE9,
        "attribute10": order.ATTRIBUTE10,
        "attribute11": order.ATTRIBUTE11,
        "attribute12": order.ATTRIBUTE12,
        "attribute13": order.ATTRIBUTE13,
        "attribute14": order.ATTRIBUTE14,
        "attribute15": order.ATTRIBUTE15,
        "attribute16": order.ATTRIBUTE16,
        "attribute17": "",
        "attribute18": "",
        "attribute19": "",
        "attribute20": order.ATTRIBUTE20,
        "attribute21": "",
        "attribute22": "",
        "attribute23": "",
        "attribute24": "",
        "attribute25": "",
        "attribute26": "",
        "attribute27": "",
        "attribute28": "",
        "attribute29": "",
        "attribute30": "",
        "attribute31": "",
        "attribute32": "",
        "attribute33": "",
        "attribute34": "",
        "attribute35": "",
        "attribute36": "",
        "attribute37": "",
        "attribute38": "",
        "attribute39": "",
        "attribute40": "",
        "categoryDesc": order.LINE_CATEGORY ? order.LINE_CATEGORY : "",
        "cifaItemNumber": order.CIFA ? order.CIFA : '',
        "chargeAccountId": "",
        "createdBy": "",
        "createdDate": order.CREATION_DATE ? order.CREATION_DATE : "",
        "customerAccntNum": "",
        "deliveryLocationCode": order.DELIVER_TO_LOCATION ? order.DELIVER_TO_LOCATION : order['Delivery to Site'],
        "deliveryToLocationId": "",
        "destOrgCode": order.DESTINATION_ORG_CODE ? order.DESTINATION_ORG_CODE : "",
        "destOrgId": "",
        "destSubInventory": order.DESTINATION_SUBINVENTORY ? order.DESTINATION_SUBINVENTORY : "",
        "errorMessage": "",
        "expenditureItemDate": order.EXPENDITURE_ITEM_DATE ? order.EXPENDITURE_ITEM_DATE : "",
        "expenditureOrg": order.EXPENDITURE_ORG ? order.EXPENDITURE_ORG : "",
        "expenditureOrgId": "",
        "expenditureType": order.EXPENDITURE_TYPE ? order.EXPENDITURE_TYPE : "",
        "fromStoreId": order.SOURCE_ORG_CODE ? order.SOURCE_ORG_CODE : order['Source Site'],
        "groupId": order.REQUISITION_NUMBER ? order.REQUISITION_NUMBER : order['Order No.'],
        "inventoryItemId": "",
        "itemCategory": order.LINE_CATEGORY ? order.LINE_CATEGORY : "",
        "itemCategoryId": "",
        "itemDesc": order.LINE_DESCRIPTION ? order.LINE_DESCRIPTION : this.reqData.Description,
        "justification": "",
        "lastUpdatedBy": "",
        "lastUpdatedDate": order.LAST_UPDATE_DATE ? order.LAST_UPDATE_DATE : "",
        "lineId": order.LINE_NUMBER ? order.LINE_NUMBER : order.LINE_NUM,
        "lineNumber": order.LINE_NUMBER ? order.LINE_NUMBER : order.LINE_NUM,
        "lineTypeId": "",
        "needByDate": this.needByDate ? this.needByDate : this.date.transform(order['NEED_BY_DATE'], 'yyyy-MM-dd'), //format can be changed
        // "needByDate": this.needByDate ? this.needByDate : order['NEED_BY_DATE'],
        "noteToApprover": order.NOTE_TO_AGENT ? order.NOTE_TO_AGENT : null,
        "noteToReceiver": order.NOTE_TO_RECEIVER ? order.NOTE_TO_RECEIVER : null,
        "orderSource": order.ORDER_SOURCE ? order.ORDER_SOURCE : "",
        "orderStatus": order.LINE_STATUSES ? order.LINE_STATUSES : order['Status'],
        "projectId": "",
        "projectNumber": order.PROJECT_NUMBER ? order.PROJECT_NUMBER : null,
        "quantity": order['Quantity'] ? order['Quantity'] : "",
        "recordStatus": "",
        "regionName": order.REGION_NAME ? order.REGION_NAME : "",
        "reqDistributionId": "",
        "requestId": order.REQUEST_ID,
        "requestorId": order.REQUESTOR_ID ? order.REQUESTOR_ID : "",
        "requestorName": this.userInfo.NTID,
        "requisitionHeaderId": order.REQUISITION_HEADER_ID ? order.REQUISITION_HEADER_ID : null,
        "requisitionLineId": order.REQUISITION_LINE_ID ? order.REQUISITION_LINE_ID : null,
        "sourceOrgCode": order.SOURCE_ORG_CODE ? order.SOURCE_ORG_CODE : order['Source Site'],
        "sourceOrgId": "",
        "sourceSubInventory": order.SOURCE_SUBINVENTORY ? order.SOURCE_SUBINVENTORY : "",
        "sourceSystem": "HUB2U",
        "sourceTrxReference": "",
        "taskId": "",
        "taskNumber": order.PROJECT_TASK_NUMBER ? order.PROJECT_TASK_NUMBER : "",
        "templateName": order['KIT Name'] ? order['KIT Name'] : order['Template Name'],
        "toStoreId": order.DELIVER_TO_LOCATION ? order.DELIVER_TO_LOCATION : order['Delivery to Site'],
        "transactionDate": "",
        "transactionType": "ORDER_UPDATE",
        "unitOfMeasure": order.UNIT_TYPE ? order.UNIT_TYPE : "",
        "unitPrice": order.UNIT_PRICE ? order.UNIT_PRICE : "",
        "vendorId": "",
        "vendorItemNumber": order['Model Number'] ? order['Model Number'] : "",
        "vendorSiteId": "",
        "destinationSystem": order.DESTINATION_SYSTEM,
      });

    });
    this.eventService.showSpinner();
    let request = {
      profile:this.userRole.toUpperCase(),
      action: "CANCEL",
      // groupId: this.reqData.REQUISITION_NUMBER,
      groupId: this.functionId == '63' ? this.reqData['S.O.#:'] : this.reqData['Order No.'],
      // requestorId: this.userInfo.NTID,
      // requestorId: this.person_id ? this.person_id.toString() : '',
      orderDetails: cancelData,
      porderNo: this.reqData['S.O.#:'],
    }
    this.productService.hub2uOrder(request).subscribe(response => {
      if (response != undefined) {
        this.orderDetailsResponse = response['orderDetailResponse'];
        // this.fetchOrders();
        if (this.orderDetailsResponse != null && this.orderDetailsResponse != undefined) {
          let message = this.orderDetailsResponse[0].statusMessage;
          if (this.orderDetailsResponse[0].status == 'SUCCESS') {
            // this.reqData.STATUS = this.updateStatus;
            this.reqData.STATUS = "CANCELLED"
            localStorage.setItem("reqData", JSON.stringify(this.reqData))
            this.commonWebService.openSnackBar(message, "SUCCESS")
          } else if (this.orderDetailsResponse[0].status == 'ERROR') {
            if (this.orderDetailsResponse[0].statusMessage.includes("already picked for shipping")) {
              this.reqData.STATUS = "INPROGRESS"
              localStorage.setItem("reqData", JSON.stringify(this.reqData))
            }
            this.commonWebService.openSnackBar(message, "ERROR")
          }
        }
      }
      this.eventService.hideSpinner();
      this.fetchDynamicReport();
      // this.reqData['STATUS'] = "CANCELLED"
      this.saveBtn = false;
      this.editBtn = false;
      this.cancelBtn = false;
      this.displayCancelBtn = this.cancelBtn
    }, error => {
      this.commonWebService.openSnackBar("There is some error in cancelling the order", "ERROR")
      this.eventService.hideSpinner();
      this.fetchDynamicReport();
    });
  }

  goBack() {
    this._location.back();
  }

  getRecentOrders() {

    var dataInput = {
      "ReportId": this.constantData.dynamicrecentOrderId[this.functionId],
      "ParametersInput":
        [{
          "Name": "REQUESTOR",
          "Value": this.userInfo.NTID
        }]
    }

    this.reportsService.onGetDynamicReport(dataInput).subscribe(response => {
      this.loader = false;
      if (response.ROW !== undefined) {
        this.recentOrder = response.ROW;
      } else {
        this.recentOrder = [];
      }
    }, error => {
    });
  }
  checkStatus(order) {
    this.ischeckStatus = true;
    var dataInput;
    var locationQuery = JSON.parse(sessionStorage.getItem('locationDynamicQuery'));
    let attrReq = this.recentOrder.filter(element => element.REQUISITION_NUMBER === order.REQUISITION_NUMBER)

    let attributeVal = ''
    if (attrReq.length > 0) {
      attributeVal = attrReq[0].ATTRIBUTE2
    }
    //if (this.constantData.orderStatusParam[this.functionId] !== undefined && this.functionId != "51") {
    if (this.constantData.orderStatusParam[this.functionId] !== undefined && this.functionId != "136") {
      dataInput = {
        "ReportId": this.constantData.checkStatus[this.functionId], "ParametersInput": [
          { "Name": "P_ORDER_NUMBER", "Value": order.REQUISITION_NUMBER ? order.REQUISITION_NUMBER : order['Order No.'] },
          { "Name": "P_MODULE", "Value": this.constantData.orderStatusParam[this.functionId] }]
      }
    } else if (locationQuery != null || locationQuery != undefined) {
      //if (locationQuery.userGroups === "NONCPE" && this.functionId != "51") {
      if (locationQuery.userGroups === "NONCPE" && this.functionId != "136") {
        dataInput = {
          "ReportId": this.constantData.checkStatus[this.functionId], "ParametersInput": [
            { "Name": "P_ORDER_NUMBER", "Value": order.REQUISITION_NUMBER ? order.REQUISITION_NUMBER : order['Order No.'] },
            { "Name": "P_MODULE", "Value": "NONCPE" }]
        }
      }
    } else {
      dataInput = {
        "ReportId": this.constantData.checkStatus[this.functionId], "ParametersInput": [
          { "Name": "P_ORDER_NUMBER", "Value": order.REQUISITION_NUMBER ? order.REQUISITION_NUMBER : order['Order No.'] },
          { "Name": "P_MODULE", "Value": attributeVal }]
      }
    }
    this.reportsService.onGetDynamicReport(dataInput).subscribe(response => {
      if (response.ROW !== undefined) {
        this.verifyStatus = response.ROW;
        // this.bottomSheet.open(CheckStatusComponent, {
        //   data: this.verifyStatus
        // });
        this.dialog.open(CheckstatuspopupComponent, {
          data: this.verifyStatus,
          width: '1100px',
          panelClass: 'full-panel-modal'
        });
        this.ischeckStatus = false;
      } else {
        this.verifyStatus = [];
        this.commonWebService.openSnackBar("No Data Found", "WARNING");
        this.ischeckStatus = false;
      }
      this.ischeckStatus = false;
    }, error => {
      this.ischeckStatus = false;
    });
  }

  repeatOrder(val) {
    this.storeOrder = val;
    this.loaderOrderitem = true;
    let req_num = val;

    var dataInput = {
      "profile": this.userRole.toUpperCase(),
      // "requestorId": this.userInfo.NTID,
      "requestorName": this.userInfo.NTID,
      "requisitionNumber": req_num
    };

    this.productService.repeatOrder(dataInput).subscribe(response => {
      let resp = response || {};
      //  console.log("resp===>", resp)
      let msg = resp['STATUS_MESSAGE'] || resp['statusMessage'] || '';
      if (resp['status'] == 'SUCCESS') {
        this.commonService.updatedCart(true);
        this.commonWebService.openSnackBar(msg, "SUCCESS")
      }
      if (resp['status'] == 'FAILED') {
        if (resp['statusMessage'].includes('items in the cart already added')) {
          this.openclearCartDialog();
        }
        this.commonService.updatedCart(true);
        this.commonWebService.openSnackBar(msg, "ERROR")
      }
      this.loaderOrderitem = false;
    }, error => {
      this.commonWebService.openSnackBar("There is some error in repeating the order", "ERROR")
      //this.eventService.hideSpinner();
      this.loaderOrderitem = false;
    });
  }

  openclearCartDialog(): void {
    const dialogRef = this.dialog.open(ClearCartComponent, {
      // data: { option: 'discardCart' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        this.onClearCart();
      }
    });
  }

  onClearCart() {
    // let object = { requestorId: this.userInfo.NTID, operation: "Clear" };
    let object = { requestorName: this.userInfo.NTID, operation: "Clear",profile: this.userRole.toUpperCase() };
    this.loader = true;
    this.productService.clearCart(object).subscribe(response => {
      this.loader = false;
      let resp = response || [];
      if (resp != undefined) {
        let message = resp['STATUS_MESSAGE'] || resp['statusMessage'] || '';
        if (resp['status'] == 'SUCCESS') {
          this.commonWebService.openSnackBar(message, resp['status']);
          this.repeatOrder(this.storeOrder);
        } else {
          this.commonWebService.openSnackBar('Error while clearing the Cart, hence the new item is not added.', 'WARNING')
        }
      } else {
        this.loader = false;
      }
      this.commonService.updatedCart(true);
    }, error => {
      this.loader = false;
      this.commonWebService.openSnackBar('Something went wrong.Can you please try later', 'WARNING')
    })
  }

  macInfo() {
    if (this.orderDetails != undefined) {
      this.infoLoader = true;
      var configReq = {
        "ReportId": "10040",
        "ParametersInput": [
          { "Name": "P_ORDER_NUMBER", "Value": this.reqData.REQUISITION_NUMBER ? this.reqData.REQUISITION_NUMBER : this.reqData['Order No.'] }
        ]
      }
      this.reportsService.onGetDynamicReport(configReq).subscribe(response => {
        if (response != undefined) {
          this.infoLoader = false;
          this.serialInfo = response;
          this.dialog.open(MacinfodialogTableComponent,
            {
              panelClass: 'mac-dialog',
              height: '65%',
              data: this.serialInfo,
            })
        }
      }, error => {
        this.infoLoader = false;
        this.commonWebService.openSnackBar('Something went wrong.Can you please try later', 'WARNING');
      })
    } else {
      this.infoLoader = false;
      this.commonWebService.openSnackBar('Something went wrong.Can you please try later', 'WARNING');
    }

  }

}
