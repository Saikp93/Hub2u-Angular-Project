import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
// import { OrderDetailsComponent } from './order-history-details.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { Hub2usharedModule } from 'hub2ushared';
import { MatCardModule } from '@angular/material/card';
import { ItemsListComponent } from './items-list/items-list.component';
import {MatDialogModule} from '@angular/material/dialog';
import {MatChipsModule} from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatBadgeModule} from '@angular/material/badge';
import { MatOptionModule } from '@angular/material/core';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatExpansionModule} from '@angular/material/expansion';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FeedbackComponent } from './feedback/feedback.component';
import { MatButtonModule } from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatPaginatorModule } from '@angular/material/paginator';
import { CancelOrderComponent } from './cancel-order/cancel-order.component';
import { ReceivingDetailsComponent } from './receiving-details/receiving-details.component';
import { OrderDetailsComponent } from './order-history-details.component';
import { MacinfodialogTableComponent } from './macinfodialog-table/macinfodialog-table.component';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { ClearCartComponent } from './clear-cart/clear-cart.component';

const routes: Routes = [
  {
    path: '',
    component: OrderDetailsComponent
  }
];

@NgModule({
  declarations: [OrderDetailsComponent, ItemsListComponent, FeedbackComponent, ClearCartComponent,
    CancelOrderComponent, ReceivingDetailsComponent,MacinfodialogTableComponent],
  providers: [DatePipe],
  imports: [
    CommonModule,
    MatCardModule,
    MatDatepickerModule,
    MatDialogModule,
    MatTooltipModule,
    MatOptionModule,
    MatCheckboxModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule,
    MatBadgeModule,
    MatDialogModule,
    MatPaginatorModule,
    MatTableModule,
    MatSortModule,
    FormsModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatChipsModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatIconModule,
    Hub2usharedModule,
    NgxSpinnerModule,
    RouterModule.forChild(routes)
  ],
  entryComponents: [MacinfodialogTableComponent,],
})
export class OrderDetailsModule { }
