import { Component, Inject, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { TableUtil } from '../../../shared/tableUtils';
import { ItemsListComponent } from '../items-list/items-list.component';

@Component({
  selector: 'app-macinfodialog-table',
  templateUrl: './macinfodialog-table.component.html',
  styleUrls: ['./macinfodialog-table.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class MacinfodialogTableComponent implements OnInit {

  loadSpinner: boolean = false;
  macInfoDetails: any;
  noData = false;
  pageName = "Serial/MacInfo_Report"
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns = [];
  dataSource: MatTableDataSource<any>;
  columns = [];
  headerRow;
  columnsToDisplay = [];

  constructor(@Inject(MAT_DIALOG_DATA) public data: ItemsListComponent, public dialog: MatDialog,private tableUtil : TableUtil) { }

  ngOnInit() {
    this.getMacInfo();
  }

  // displayedColumns = ['Model#', 'CIFA#', 'SERIAL_NUMBER','MAC_ADDRESS'];
  getMacInfo(){
    this.loadSpinner = true;
    this.displayedColumns = [];
    this.columns = [];
    let visibleCols = [];
    if(this.data != undefined){
      this.loadSpinner = false;
      this.macInfoDetails = this.data;
      if(this.macInfoDetails.ROW != undefined){
        this.macInfoDetails.ROW.forEach(data => {
          for (const key in data) {
            if(this.macInfoDetails.ROW.indexOf(data) == 0 ) {
              visibleCols = data['DISPLAY_COLUMNS'].split(',');
            }
          }
        })
        let displayCols = visibleCols;
        if(this.displayedColumns.length == 0){
          displayCols.forEach(col => {
              this.columns.push(col);
              this.displayedColumns.push(col);
          })
        }
        this.dataSource = new MatTableDataSource<any>(this.macInfoDetails.ROW);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.noData = false;
      }else{
        this.loadSpinner = false;
        this.noData = true;
      }
    }else{
      this.loadSpinner = false;
      this.noData = true;
    }
  }

  ngAfterViewInit() {
    if(this.macInfoDetails.ROW != undefined){
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    }
}

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  exportToCsv(){
    let lineCols = [];    
    this.macInfoDetails.ROW.forEach(data => {
      lineCols = data['EXPORT_COLUMNS'].split(',');
      lineCols.forEach(i => delete data[i])
      // delete data['@num'];
      // delete data['LINE_NUMBER'];
    })
    this.tableUtil.exportTableToCsv( this.macInfoDetails.ROW , this.pageName); 

  }

}