import {Component, Inject, OnInit} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-cancel-order',
  templateUrl: './cancel-order.component.html',
  styleUrls: ['./cancel-order.component.scss'],
})
export class CancelOrderComponent implements OnInit {
  
  constructor(
    public dialogRef: MatDialogRef<CancelOrderComponent>,@Inject(MAT_DIALOG_DATA) public data: any,
  ) {}

  ngOnInit() {}

  onNoClick(): void {
    this.dialogRef.close('no');
  }

  yesClicked() {
    this.dialogRef.close('yes');
  }
}
