import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-clear-cart',
  templateUrl: './clear-cart.component.html',
  styleUrls: ['./clear-cart.component.scss'],
})
export class ClearCartComponent implements OnInit {
  
  constructor(
    public dialogRef: MatDialogRef<ClearCartComponent>
  ) {}

  ngOnInit() {}

  onNoClick(): void {
    this.dialogRef.close('no');
  }

  yesClicked() {
    this.dialogRef.close('yes');
  }

}
