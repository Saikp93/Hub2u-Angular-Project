import { Component, Input, OnInit } from '@angular/core';
import { FeedbackService } from 'hub2ushared';
import { CommonWebService } from '../../../shared/common-web.service';
import { EventService } from '../../../shared/event.service';


@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss'],
})
export class FeedbackComponent implements OnInit {

  panelOpenState = false;
  rating: number = 0;
  starCount: number = 5;
  color: string = 'accent';
  ratingArr = [];
  comments = '';
  @Input() orderDetails: any;
  userInfo: any;
  submitbtn: boolean = true;

  constructor(private feedbackService: FeedbackService, private eventService: EventService, private commonWebService: CommonWebService,) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    for (let index = 0; index < this.starCount; index++) {
      this.ratingArr.push(index);
    }
  }

  // showFeedbackArea() {
  //   this.panelOpenState = true;
  //   this.eventService.showSpinner();
  //   // console.log(this.orderDetails);
  //   let input = {
  //     "RequisitionHeaderId": this.orderDetails[0].REQUISITION_HEADER_ID,
  //     "RequisitionNumber": this.orderDetails[0].REQUISITION_NUMBER
  //   };
  //   this.feedbackService.getFeedback(input).subscribe(response => {
  //     this.rating = response.Rating;
  //     this.comments = response.Comments;
  //     this.eventService.hideSpinner();
  //   })
  // }

  /**SOA TO JAVA */
  showFeedbackArea() {
    this.panelOpenState = true;
    this.eventService.showSpinner();
    // console.log(this.orderDetails);
    let input = {
      "reqHeaderId": this.orderDetails[0].REQUISITION_HEADER_ID,
      "requisitionNumber": this.orderDetails[0].REQUISITION_NUMBER
    };
    this.feedbackService.getFeedback(input).subscribe(response => {
      if (response.status == "SUCCESS") {
        this.eventService.hideSpinner();
        if (response.requisitionFeedbacks && response.requisitionFeedbacks.length != 0) {
          this.rating = response.requisitionFeedbacks[0].rating;
          this.comments = response.requisitionFeedbacks[0].comments;
        }

      }
      else {

        this.eventService.hideSpinner();
      }
    }, (error) => {
      this.eventService.hideSpinner();
    });
  }

  onClick(rating: number) {
    this.rating = rating
    this.maketnvisible();
    return false;
  }

  showIcon(index: number) {
    if (this.rating >= index + 1) {
      return 'star';
    } else {
      return 'star_border';
    }
  }

  // launchFeedback() {
  //   let input = {
  //     "REQUISITION_HEADER_ID": this.orderDetails[0].REQUISITION_HEADER_ID,
  //     "RequisitionNumber": this.orderDetails[0].REQUISITION_NUMBER,
  //     "UserName": this.userInfo.NTID,
  //     "Rating": this.rating,
  //     "Comments": this.comments
  //   }
  //   this.feedbackService.insertFeedback(input).subscribe(response => {
  //     //  console.log(response); 
  //   })
  // }

  maketnvisible() {
    if (this.rating !== 0 && this.comments !== '') {
      this.submitbtn = false
    }
    else {
      this.submitbtn = true
    }
  }

  /**SOA TO JAVA */
  launchFeedback() {
    if (this.rating !== 0 && this.comments !== '') {
      let input = {
        "requestor": "",
        "reqHeaderId": this.orderDetails[0].REQUISITION_HEADER_ID,
        "requisitionNumber": this.orderDetails[0].REQUISITION_NUMBER,
        "userName": this.userInfo.NTID,
        "rating": this.rating,
        "comments": this.comments
      }
      this.feedbackService.insertFeedback(input).subscribe(response => {
        //  console.log(response); 
        if (response.status == 'SUCCESS') {
          this.commonWebService.openSnackBar(response.statusMessage, response.status)
          this.submitbtn = true
        }
        else {
          this.commonWebService.openSnackBar(response.statusMessage, response.status)
          this.submitbtn = false
        }

      })
    }

  }
}
export enum StarRatingColor {
  primary = "primary",
  accent = "accent",
  warn = "warn"
}
