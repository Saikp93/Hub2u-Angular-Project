import { Component, Input, OnInit } from '@angular/core';
import { CommonService } from 'projects/hub2ushared/src/lib/services/common.service';
import { EventService } from '../../shared/event.service';
import { CommonSettingService } from '../../shared/common-settings.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss'],
})
export class NotificationsComponent implements OnInit {
  showResponse: any[] = [];
  loadSpinner: boolean = false;
  showNoRecs: boolean = false;
  userInfo: any = {};

  @Input() size: any;
  @Input() cssClass: any;

  constructor(private alertService: CommonSettingService, private commonService: CommonService, private eventService: EventService) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.alertService.getAlerts();
    this.getAnnouncements();
  }

  messageType: string = "";
  showMaintainance: boolean = false;
  checkedItems: any[] = [];
  getAnnouncements() {
    this.loadSpinner = true;
    let request = {
      applicationId: 1,
      ntAccount: this.userInfo.NTID
    }
    this.commonService.onShowAnnouncements(request).subscribe(response => {
      this.showResponse = response.announcementsForUserListOut;
      if (this.showResponse != null || this.showResponse != undefined) {
        this.eventService.onNotifyCount(this.showResponse.length);
        this.loadSpinner = false;
        this.showNoRecs = false;
        for (let prop of Object.keys(this.showResponse)) {
          this.messageType = this.showResponse[prop].messageType;
          this.checkedItems.push(this.messageType);
        }
        this.checkedItems.forEach(item => {
          if (item === "MAINTENANCE") {
            this.showMaintainance = true;
          } else if (item === "NOTIFICATION" || item === "ENHANCEMENT") {
            this.showMaintainance = false;
          }
        });
      } else if (this.showResponse == null || this.showResponse == undefined) {
        this.loadSpinner = false;
        this.showNoRecs = true;
      }
    });

  }

  closeTab() {
    this.alertService.setAlerts(false);
  }

}
