import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { IntransitComponent } from './intransit.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { Hub2usharedModule } from 'hub2ushared';

const routes: Routes = [
  {
    path: '',
    component: IntransitComponent
  }
];

@NgModule({
  declarations: [IntransitComponent], 
  imports: [
    CommonModule,
    NgxSpinnerModule,
    MatTooltipModule,
    MatIconModule,
    MatDialogModule,
    MatButtonModule,
    MatCardModule,
    Hub2usharedModule,
    RouterModule.forChild(routes)
  ]
})
export class IntransitModule { }
