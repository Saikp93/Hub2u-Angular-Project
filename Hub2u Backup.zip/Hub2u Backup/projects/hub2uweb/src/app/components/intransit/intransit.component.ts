import { Component, Inject, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { EventService } from '../../shared/event.service';
import { SourceService, GetimageService } from 'hub2ushared';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-intransit',
  templateUrl: './intransit.component.html',
  styleUrls: ['./intransit.component.scss'],
})
export class IntransitComponent implements OnInit {
  cifaItemNo: any;
  orgCode: any;
  intransitOutput: any;
  //imageURL = this.env.baseIMGUrl;
  previewImage;

  @ViewChild('callImagePreview') callImagePreview: TemplateRef<any>;
  loader: boolean;

  constructor(@Inject('environment') private env: any, private dialog: MatDialog, private router: Router, private sourceService: SourceService, private eventService: EventService, private GetimageService: GetimageService
  ) {
    this.cifaItemNo = this.router.getCurrentNavigation().extras.state.cifaItemNo;
    this.orgCode = this.router.getCurrentNavigation().extras.state.orgCode;
  }

  ngOnInit() {
    //this.eventService.showSpinner();
    this.loader = true;

  }

  openPreview(imagePath) {
    this.previewImage = imagePath
    let dialogRef = this.dialog.open(this.callImagePreview);
    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        if (result === 'yes') {
        } else if (result === 'no') {
        }
      }
    })
  }

  goBack() {
    window.history.back();
  }

  getImage(cifaItem) {
    let image = cifaItem ? this.GetimageService.getImagefromcifa(cifaItem) : 'assets/images/no-image.jpg'
    //console.log("image IntransitComponent ", image)
    return image
  }
}
