import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SelectNtUsernameComponent } from './select-ntusername.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule } from '@angular/material/icon';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';

const routes: Routes = [
  {
    path: '',
    component: SelectNtUsernameComponent
  }
];

@NgModule({
  declarations: [SelectNtUsernameComponent],
  imports: [
    CommonModule,
    MatTooltipModule,
    MatIconModule,
    NgxSpinnerModule,
    MatDialogModule,
    MatButtonModule,
    RouterModule.forChild(routes)
  ]
})
export class SelectNtUsernameModule { }
