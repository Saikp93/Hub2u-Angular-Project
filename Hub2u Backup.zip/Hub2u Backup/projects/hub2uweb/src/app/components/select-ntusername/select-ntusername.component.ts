import { Component, Inject, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CommonService, ProductService, ReportsService, GetimageService } from 'hub2ushared';
import { EventService } from '../../shared/event.service';
import { DatePipe } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonWebService } from '../../shared/common-web.service';

@Component({
  selector: 'app-select-ntusername',
  templateUrl: './select-ntusername.component.html',
  styleUrls: ['./select-ntusername.component.scss'],
})
export class SelectNtUsernameComponent implements OnInit {
  userInfo: any;
  functionId: string;
  userRole: string;
  previewImage;
  //imageURL = this.env.baseIMGUrl;
  item: any;

  @ViewChild('callImagePreview') callImagePreview: TemplateRef<any>;
  inquiryOutput: any;
  favItem: any;

  constructor(@Inject('environment') private env: any, private productService: ProductService, private commonWebService: CommonWebService, private commonService: CommonService, private datePipe: DatePipe, private dialog: MatDialog, private reportsService: ReportsService, private router: Router, private eventService: EventService, private GetimageService: GetimageService
  ) {
    this.item = this.router.getCurrentNavigation().extras.state.item;
    this.favItem = this.router.getCurrentNavigation().extras.state.favItem;
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.eventService.showSpinner();
    this.onInitialLoad();
  }
  onInitialLoad() {
    console.log("Item ", this.item);
    console.log("favItem", this.favItem);
    let request = {       // tech store 
      ReportId: "1081",
      ParametersInput: [
        { Name: "ITEM_NUMBER", Value: this.item.CIFA_ITEM_NUMBER },
        { Name: "USERNAME", Value: this.userInfo.NTID }
      ]
    }
    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      console.log(response);
      this.inquiryOutput = response.ROW;
      this.eventService.hideSpinner();
    }, error => {
      console.log(error);
      this.eventService.hideSpinner();
    })
  }

  // getImage(cifaItem) {
  //   return this.imageURL + cifaItem + ".jpg";
  // }

  getImage(cifaItem) {
    let image = cifaItem ? this.GetimageService.getImagefromcifa(cifaItem) : 'assets/images/no-image.jpg'
    //console.log("image SelectNtUsernameComponent ", image)
    return image
  }


  openPreview(imagePath) {
    this.previewImage = imagePath
    let dialogRef = this.dialog.open(this.callImagePreview);
    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        if (result === 'yes') {
        } else if (result === 'no') {
        }
      }
    })
  }

  getFormattedDate(date) {
    return this.datePipe.transform(date, 'yyyy-M-d');
  }

  addToCart(orgCode, subInventCode) {
    let qty = '1';
    let date = new Date();
    date.setDate(date.getDate() + 1);
    let needbydate = this.getFormattedDate(date);
    this.eventService.showSpinner();
    // let request = {
    //   "SOURCE_SYSTEM": "TECHAPP",
    //   "ShoppingCartUpsertData": [{
    //     "attribute3" : this.userRole.toUpperCase(),
    //     "cifaItemNumber": this.favItem.CIFA_ITEM_NUMBER,
    //     "itemDescription": this.favItem.ITEM_DESCRIPTION,
    //     "itemCategory": this.favItem.ITEM_CATEGORY,
    //     "quantity": qty,
    //     "needByDate": needbydate,
    //     "regionTemplate": this.favItem.TEMPLATE_NAME,
    //     "regionName": this.favItem.REGION_NAME,
    //     // "SOURCE_ORGANIZATION_CODE": ,      check
    //     "userName": this.userInfo.NTID,
    //     "sourceSubInventory": subInventCode,
    //     // "ORGANIZATION_CODE": orgCode,
    //     "sourceOrganizationCode": orgCode,
    //     "attribute4": this.favItem.ATTRIBUTE4
    //   }]
    // }

    let request = {
      "SOURCE_SYSTEM": "TECHAPP",
      "profile":this.userRole.toUpperCase(),
      "ShoppingCartUpsertData": [
        {
          "quantity": qty,
          "kitQty": 1,
          "requestorName": this.userInfo.NTID,
          "profileType": this.userRole.toUpperCase(),
          // "orderType": "FULFILLMENT",
          "deliveryLocationCode": "Pizza Hut|PH-034737| 743 S LEWIS ST, , METTER, GA, 30439, United States|Pizza Hut - PH#034737",
          "needByDate": needbydate,
          "cifaItemNumber": this.favItem.CIFA_ITEM_NUMBER,
          "itemDesc": this.favItem.ITEM_DESCRIPTION,
          // "sourceOrganizationCode": "Y96",
          // "customer": "Pizza Hut",
          "regionName": this.favItem.REGION_NAME,
          "templateName": this.favItem.TEMPLATE_NAME,
          // "attribute13": "MES"
        }
      ]
    }
    this.productService.addToCart(request).subscribe(response => {
      this.commonService.updatedCart(true);
      let message = response['STATUS_MESSAGE'] || '';
      if (response['STATUS'] === 'SUCCESS') {
        this.commonWebService.openSnackBar(message, "SUCCESS")
      }
      if (response['STATUS'] === 'ERROR') {
        this.commonWebService.openSnackBar(message, "ERROR")
      }
      this.eventService.hideSpinner()
    }, error => {
      this.commonWebService.openSnackBar("There is some error in adding product to the cart", "ERROR")
      this.eventService.hideSpinner()
    });
  }

  goBack() {
    window.history.back();
  }

}
