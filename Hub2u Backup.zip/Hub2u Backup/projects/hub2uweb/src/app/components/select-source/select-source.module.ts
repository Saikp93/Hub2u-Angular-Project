import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SelectSourceComponent } from './select-source.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule } from '@angular/material/icon';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatCardModule } from '@angular/material/card';
import { Hub2usharedModule } from 'hub2ushared';
import { MatInputModule } from '@angular/material/input';
import { MatChipsModule } from '@angular/material/chips';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSliderModule } from '@angular/material/slider';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { FormsModule } from '@angular/forms';
import { FiltersComponent } from './filters/filters.component';
import { NgxSliderModule } from '@angular-slider/ngx-slider';

const routes: Routes = [
  {
    path: '',
    component: SelectSourceComponent
  }
];

@NgModule({
  declarations: [SelectSourceComponent, FiltersComponent],
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatTooltipModule,
    MatIconModule,
    NgxSpinnerModule,
    MatDialogModule,
    MatButtonModule,
    MatCardModule,
    FormsModule,
    MatInputModule,
    MatChipsModule,
    MatExpansionModule,
    MatCheckboxModule,
    MatSliderModule,
    MatSlideToggleModule,
    Hub2usharedModule,
    NgxSliderModule,
    RouterModule.forChild(routes)
  ]
})
export class SelectSourceModule { }
