import { Component, Inject, OnInit, Optional, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CommonService, FilterpipePipe, ProductService, ReportsService, MultipleFilterPipe, ConstantData } from 'hub2ushared';
import { EventService } from '../../shared/event.service';
import { DatePipe } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GetimageService } from 'hub2ushared';
import { CommonWebService } from '../../shared/common-web.service';

@Component({
  selector: 'app-select-source',
  templateUrl: './select-source.component.html',
  styleUrls: ['./select-source.component.scss'],
  providers: [FilterpipePipe, MultipleFilterPipe]
})
export class SelectSourceComponent implements OnInit {
  userInfo: any;
  functionId: string;
  userRole: string;
  previewImage;
  attr6;
  //imageURL = this.env.baseIMGUrl;
  item: any;
  cartLoader: any[] = [];
  dataloader = false;
  newfilter = [];
  newfilterArray = [];

  ItemPerPage = 10;
  pageSizes = [5, 10, 15, 20];
  pagedItems = [];
  pageNumber = 1;
  storeTags = [];

  @ViewChild('callImagePreview') callImagePreview: TemplateRef<any>;
  inquiryOutput: any = [];
  favItem: any;
  loader: boolean;
  searchValue: string = "";
  inquiryOutputOriginal: any = [];
  data: any;
  catalogsView: any;
  favPage: boolean;
  isFilterShow = false;
  minQty: number = 0;
  maxQty: number = 0;
  needByDate: any;
  sourceOrg: any;
  subInv: any = "";

  constructor(@Inject('environment') private env: any, private filterpipe: FilterpipePipe,
    private productService: ProductService, private commonWebService: CommonWebService,
    private commonService: CommonService, private datePipe: DatePipe, private dialog: MatDialog,
    private reportsService: ReportsService, private router: Router, private eventService: EventService,
    private multipleFilterPipe: MultipleFilterPipe, public datepipe: DatePipe, private constantData: ConstantData, private GetimageService: GetimageService,
    @Optional() @Inject(MAT_DIALOG_DATA) public modalData,
    ) {
    if(modalData) {
      this.item = modalData.item;
      this.favItem = modalData.favItem;
      this.favPage = modalData.favPage;
      if (modalData.view)
        this.catalogsView = modalData.view;
    } else {
      this.item = this.router.getCurrentNavigation().extras.state.item;
      this.favItem = this.router.getCurrentNavigation().extras.state.favItem;
      this.favPage = this.router.getCurrentNavigation().extras.state.favPage;
      if (this.router.getCurrentNavigation().extras.state.view)
        this.catalogsView = this.router.getCurrentNavigation().extras.state.view;
    }
  }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem('userDetails'));
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
    this.userRole = localStorage.getItem(this.userInfo.NTID + '_userRole');
    this.loader = true;
    this.onInitialLoad();
    this.getPreferenceData();
  }

  onInitialLoad() {
    // if (this.functionId == '99') {
      if (this.functionId == '143') {
      let object = {
        ReportId: 1081,
        ParametersInput: [
          {
            Name: "ITEM_NUMBER",
            Value: this.item['CIFA#'] != undefined ? this.item['CIFA#'] : this.item['CIFA_ITEM_NUMBER']
          },
          {
            Name: "USERNAME",
            Value: this.userInfo.NTID
          }
        ]
      };
      this.loader = true;
      this.reportsService.onGetDynamicReport(object).subscribe(response => {
        this.data = response.ROW;

        if (this.data && this.data.length > 0) {
          this.isFilterShow = response.ROW[0].FILTER_COLUMNS ? true : false;
          this.createInput()
        }
        this.loader = false;
      }, error => {
        this.loader = false;
      });
    }
    else if (this.functionId == '64') {
      let object = {
        ReportId: 60161,
        ParametersInput: [
          {
            Name: "SKU_NUMBER",
            Value: this.item['ATTRIBUTE8']
          }
        ]
      };
      this.loader = true;
      this.reportsService.onGetDynamicReport(object).subscribe(response => {
        this.data = response.ROW;
        if (this.data && this.data.length > 0) {
          this.isFilterShow = response.ROW[0].FILTER_COLUMNS ? true : false;
          this.minQty = Math.min(...response.ROW.map(item => item.ONHAND_QTY));
          this.maxQty = Math.max(...response.ROW.map(item => item.ONHAND_QTY));

          this.createXMinput();

          this.newfilterArray = [];
          if (response.ROW !== undefined && response.ROW !== null) {
            this.newfilterArray = this.convertToArray(response.ROW[0].FILTER_COLUMNS);
          }
          for (let elements of this.newfilterArray) {
            this.newfilter.push(
              { control: elements, label: this.getFilterLable(elements), tagsList: [], searchTxt: '' }
            )
          }
          for (let key of this.newfilter) {
            for (let x of this.data) {
              let findKey = key.tagsList.find(o => o.name === x[key.control]) ? false : true;
              if (findKey) {
                key.tagsList.push({ selected: false, name: x[key.control], value: this.data.filter(v => v[key.control] == x[key.control]).length })
              }
            }
            key.tagsList = key.tagsList.sort((a, b) => (a.value > b.value ? -1 : 1))
          }
        }
        this.loader = false;
      }, error => {
        this.loader = false;
      });
    }
    else {
      let skuNumber = [];
      if (this.functionId == '60' || this.functionId == '58') {
        skuNumber.push(this.item['CIFA#'].replace(/^0+/, ''))
      }
      else {
        skuNumber.push(this.item['CIFA_ITEM_NUMBER'].replace(/^0+/, ''))
      }
      let object = {
        bucketId: "",
        lastArchived: true,
        locatorId: "",
        siteId: this.item['SITE_ID'] || "'Y27','N00','Y34','U00','Y58','Y15','Y03','A51','Y08'",
        siteType: "",
        skuNumber: skuNumber,
        skuType: "",
        source: this.item['DESTINATION_SYSTEM'] || "CTDI"
      }
      this.loader = true;
      this.productService.details(object).subscribe(response => {
        this.data = response['details'];
        if (this.data && this.data.length > 0)
          this.createInput()
        this.loader = false;
      }, error => {
        this.loader = false;
      });
    }
  }

  createXMinput() {
    this.data.forEach(item => {
      let object;
      object = {
        "STORE_ID": item['STORE_ID'],
        "ONHAND_QTY": item['ONHAND_QTY'],
        "BUCKET": item['BUCKET'],
        "STORE_NAME": item['STORE_NAME'],
        "REGION": item['REGION'],
        "DIVISION": item['DIVISION']

      }
      this.inquiryOutput.push(object);
      this.inquiryOutputOriginal.push(object)
    })
  }

  createInput() {
    this.data.forEach(item => {
      let object;
      // if (this.functionId == '99') {
        if (this.functionId == '143') {
        object = {
          organisation: item['ORGANIZATION_CODE'],
          quantity: item['ONHAND_QTY'],
          subInventory: item['SUBINVENTORY_CODE'],
          location: item['WAREHOUSE_LOCATION']
        }
      }
      else {
        object = {
          itemCondition: item['itemCondition'],
          itemStatus: item['itemStatus'],
          quantity: item['quantity'],
          siteId: item['siteId']
        }
      }

      this.inquiryOutput.push(object);
      this.inquiryOutputOriginal.push(object)
    })
  }

  // getImage(item) {
  //   let imageSrc;
  //   if (item['CIFA#']) {
  //     imageSrc = this.imageURL + item['CIFA#'] + '.jpg'
  //   }
  //   else if (item['ITEM_NUMBER']) {
  //     imageSrc = this.imageURL + item['ITEM_NUMBER'].replace(/ /g, "-") + '.jpg'
  //   }
  //   else if (item['CIFA_ITEM_NUMBER']) {
  //     imageSrc = this.imageURL + item['CIFA_ITEM_NUMBER'] + '.jpg'
  //   }
  //   else if (item['MODEL#'] || item['Model#']) {
  //     imageSrc = this.imageURL + (item['MODEL#'] || item['Model#']).replace(/ /g, "-") + '.jpg'
  //   }
  //   else if (item['MODEL_NUMBER']) {
  //     imageSrc = this.imageURL + item['MODEL_NUMBER'].replace(/ /g, "-") + '.jpg'
  //   }
  //   return imageSrc;
  // }

  /**SOA TO JAVA */
  getImage(item) {
    let image = this.GetimageService.getImage(item)
    //console.log("image SelectSourceComponent ", image)
    return image;
  }
  search(text) {
    this.pageNumber = 1;
    this.inquiryOutput = this.filterpipe.transform(this.inquiryOutputOriginal, text);
    // this.pagedItems = this.inquiryOutput;

  }
  clearSearchData() {
    this.inquiryOutput = this.inquiryOutputOriginal;
  }

  openPreview(imagePath) {
    this.previewImage = imagePath
    let dialogRef = this.dialog.open(this.callImagePreview);
    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        if (result === 'yes') {
        } else if (result === 'no') {
        }
      }
    })
  }
  getFilterLable(text) {
    var txt = text.toUpperCase();
    switch (txt) {
      case 'REGION':
        return 'Region';
      case 'DIVISION':
        return 'Division';
      case 'STORE_ID':
        return 'Store ID';
      case 'ONHAND_QTY':
        return 'Quantity';
    }
  }
  getFormattedDate(date) {
    return this.datePipe.transform(date, 'yyyy-M-d');
  }

  getPreferenceData() {
    let request = {
      ParametersInput: [
        { Name: "USER_NAME", Value: this.userInfo.NTID }
       ],
      // ReportId: "112"
      // ReportId: "7001"
      ReportId:this.constantData.userprofileData[this.functionId],
    }
    this.reportsService.onGetDynamicReport(request).subscribe(response => {
      if (response != undefined && response.ROW != undefined) {
        this.needByDate = response.ROW[0].NEED_BY_DATE_TIME;
        this.attr6 = response.ROW[0].ATTRIBUTE5;
        this.sourceOrg = response.ROW[0].SOURCE_LOCATION
        this.subInv =  response.ROW[0].SUBINVENTORY 
      }
    }, error => {
      console.log(error);
    })
  }

  getDefaultOrderType() {
    if (this.functionId == '50' || this.functionId == '57' || this.functionId == '58' || this.functionId == '63') {
      return "INVENTORY"
    }
    // if (this.functionId == '51') {
      if (this.functionId == '136') {
      return "FULFILLMENT"
    }
    // if (this.functionId == '99' && (!this.attr6 || this.attr6 == "null")) {
    //   return 'PROJECT'
    // }
    if (this.functionId == '143' && (!this.attr6 || this.attr6 == "null")) {
      return 'PROJECT'
    }
    // if (this.functionId != '47' && this.functionId != '99' && this.functionId != '51' && this.functionId != '50' && this.functionId != '57' && this.functionId != '58' && this.functionId != '63') {
      if (this.functionId != '47' && this.functionId != '143' && this.functionId != '136' && this.functionId != '50' && this.functionId != '57' && this.functionId != '58' && this.functionId != '63') {
      return "PROJECT"
    }
  }

  addToCart(orgCode, subInventCode, i, item) {
    console.log("item", item)
    this.cartLoader[i] = true;
    let qty = this.favItem != undefined && this.favItem.MIN_ORD_QTY != undefined ? this.favItem.MIN_ORD_QTY : '1';
    // let date = new Date();
    // date.setDate(date.getDate() + 1);
    // let needbydate = this.getFormattedDate(date);
    let attribut6 = this.getDefaultOrderType();
    // let request = {
    //   "sourceSystem": "TECHAPP",
    //   "shoppingCartUpsertData": [
    //     {
    //       "attribute3": this.userRole.toUpperCase(),
    //       "cifaItemNumber": this.favItem.CIFA_ITEM_NUMBER ? this.favItem.CIFA_ITEM_NUMBER : this.favItem.ITEM_NUMBER,
    //       "itemDescription": this.favItem.ITEM_DESCRIPTION,
    //       "itemCategory": this.favItem.ITEM_CATEGORY,
    //       "quantity": qty,
    //       "needByDate": this.needByDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needByDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (2 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),
    //       "userName": this.userInfo.NTID,
    //       "sourceOrganizationCode": orgCode,
    //       "regionName": this.favItem.REGION_NAME ? this.favItem.REGION_NAME : this.favItem['Region Name'],
    //       "regionTemplate": this.favItem.TEMPLATE_NAME ? this.favItem.TEMPLATE_NAME : this.favItem['Template Name'],
    //       "attribute6": attribut6,
    //       "sourceSubInventory": (this.sourceOrg == (item['ORGANIZATION_CODE'] || item['SOURCE_ORGANIZATION_CODE'])) && this.functionId == '99' ? (this.subInv !== "" ? this.subInv : item['SOURCE_SUBINVENTORY']) : item['SOURCE_SUBINVENTORY'],
    //       "attribute4": this.favItem.ATTRIBUTE4 ? this.favItem.ATTRIBUTE4 : ''
    //     }
    //   ]
    // }
    let request = {
      "sourceSystem": "TECHAPP",
      "profile":this.userRole.toUpperCase(),
      "shoppingCartUpsertData": [
        {
          "quantity": qty,
          "kitQty": 1,
          "requestorName": this.userInfo.NTID,
          "profileType":this.userRole.toUpperCase(),
          "orderType": attribut6,
          // "deliveryLocationCode": "Pizza Hut|PH-034737| 743 S LEWIS ST, , METTER, GA, 30439, United States|Pizza Hut - PH#034737",
          "needByDate": this.needByDate ? this.datepipe.transform(new Date(new Date().getTime() + (this.needByDate * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd') : this.datepipe.transform(new Date(new Date().getTime() + (2 * 24 * 60 * 60 * 1000)), 'yyyy-MM-dd'),
          "cifaItemNumber": this.favItem.CIFA_ITEM_NUMBER ? this.favItem.CIFA_ITEM_NUMBER : this.favItem.ITEM_NUMBER,
          "itemDesc": this.favItem.ITEM_DESCRIPTION,
          "sourceOrganizationCode": orgCode,
          // "customer": "Pizza Hut",
          "regionName": this.favItem.REGION_NAME ? this.favItem.REGION_NAME : this.favItem['Region Name'],
          "templateName": this.favItem.TEMPLATE_NAME ? this.favItem.TEMPLATE_NAME : this.favItem['Template Name'],
          // "attribute13": "MES"
        }
      ]
    }
    
    this.productService.addToCart(request).subscribe(response => {
      this.commonService.updatedCart(true);
      let message = response['STATUS_MESSAGE'] || response['statusMessage'] || '';
      if (response['status'] === 'SUCCESS') {
        this.commonWebService.openSnackBar(message, "SUCCESS")
      }
      if (response['status'] === 'FAILED') {
        this.commonWebService.openSnackBar(message, "ERROR")
      }
      this.eventService.hideSpinner()
      this.cartLoader[i] = false;
    }, error => {
      this.commonWebService.openSnackBar("There is some error in adding product to the cart", "ERROR")
      this.eventService.hideSpinner()
      this.cartLoader[i] = false;
    });
  }

  goBack() {
    if (this.catalogsView)
      this.router.navigate(['hub2u/catalog'], { state: { view: this.catalogsView, page: "selectSource", favPage: this.favPage } });
    else
      window.history.back();
  }

  setPage($event) {
    if ($event !== undefined) {
      this.pagedItems = $event.pagedItems;
      this.pageNumber = $event.pageNumber;
      this.ItemPerPage = $event.itemsPerPage;
      document.body.scrollTop = 0; // For Safari
      document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
    }
  }
  convertToArray(columns: string) {
    let col;
    if (columns !== '' && columns !== null) {
      if (columns.indexOf(',') > -1) {
        col = columns.split(",").map(item => item.trim());
      }
      else {
        columns = columns + ',';
        col = columns.split(",")
      }
    }
    return col;
  }

  searchEventCall(tags) {
    sessionStorage.setItem(this.userInfo.NTID + "Filter", JSON.stringify(tags))
    //this.data = [];
    let isFilter = false;
    let filters = {
    };
    let filter1 = {};
    if (tags.filterArr) {
      for (let opt of tags.filterArr) {
        let arr = [];
        opt.tags.forEach(tag => {
          isFilter = true;
          arr.push(tag.name)
        })
        if (opt.control != 'ONHAND_QTY') filter1[opt.control] = arr
      }
    }

    let result;
    if (tags.minQty && tags.maxQty) {
      if (result)
        result = result.filter(item => (item.ONHAND_QTY) >= tags.minQty && (item.ONHAND_QTY) <= tags.maxQty);
      else
        result = this.inquiryOutputOriginal.filter(item => (item.ONHAND_QTY) >= tags.minQty && (item.ONHAND_QTY) <= tags.maxQty);
    }
    if (!result) {
      result = this.inquiryOutputOriginal;
    }
    if (isFilter) {
      this.data = this.multipleFilterPipe.transform(result, filter1)
    }
    else {
      this.data = result;
    }
    if ((this.data && this.data.length === 0) && isFilter == false && result.length === 0) {
      this.data = this.inquiryOutputOriginal;
    }

    this.searchValue = '';
    this.pageNumber = 1;
    // this.pagedItems = this.data
    this.inquiryOutput = this.data;
    this.storeTags = tags;
  }

}
