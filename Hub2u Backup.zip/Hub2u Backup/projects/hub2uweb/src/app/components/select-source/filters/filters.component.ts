import { Component, EventEmitter, Input, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SelectionModel } from '@angular/cdk/collections';
import { Options } from '@angular-slider/ngx-slider';
import { element } from 'protractor';

@Component({
  selector: 'app-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.scss'],
})
export class FiltersComponent implements OnInit {

  @Input() newFilter: any;
  @Input() loader = true;
  @Input() minQty : any;
  @Input() maxQty : any;

  @Output() filterEvent = new EventEmitter<any>();
  @Output() searchEvent = new EventEmitter<any>();
  searchText;
  selectionList = []
  panelState: boolean = false;
  Categories: any[] = [];
  subCategories: any[] = [];
  userInfo: any = {};
  isFilterData = false;
  reservedFlag = ''
  filterData = [];
  seletedFilters: any = {
    catalogs: null,
    tags: [],
    reserved: []
  };
  selectedFil: any = [{
    control: '',
    tags: []
  }];
  range = new FormGroup({
    start: new FormControl(),
    end: new FormControl(),
  });
  showTotalList: boolean = false;
  selection = new SelectionModel<any>(true, []);
  expand: boolean = true;
  icon: boolean = false;
  panelOpenState: boolean = true;
  itemState = "";
  expansionList = [];
  filterloader = false;
  lowValue: number = 0;
  highValue: number = 0;
  options: Options = {
    floor: 0,
    ceil: 0
  };
  @ViewChild('AddressFilterpopup') AddressFilterpopup: TemplateRef<any>;
  constructor() { }

  ngOnInit() {
    this.onInitialLoad();
    this.lowValue = this.minQty;
    this.highValue = this.maxQty;
    this.options = {
      floor: this.minQty,
      ceil: this.maxQty
    };
  }

  async onInitialLoad() {
    let userInfo = await localStorage.getItem("userDetails");
    this.userInfo = JSON.parse(userInfo);
    
  }

  onExpandCollapse() {
    this.filterloader = true;
    if (this.expand == true) {
      this.expand = false;
    }
    else {
      this.expand = true;
    }
    setTimeout(() => {
      this.filterloader = false;
    }, 300);
  }

  // ngOnChanges() {
  //   this.onFilterChange('');
  // }
  cancel(control, opt) {
    for (let item of this.selectedFil) {
      if (item.control == control) {
        item.tags.forEach(x => {
          if(control == 'ONHAND_QTY'){
            this.lowValue = this.options.floor;
            this.highValue = this.options.ceil;
          }
          if (x.name == opt && x.selected) {
            x.selected = false;
          }
        });
        item.tags = item.tags.filter(x => x.name != opt);
      }
    }
    this.searchEvent.emit({minQty:this.lowValue, maxQty: this.highValue, filterArr: this.selectedFil, resFlag: this.reservedFlag });
  }
  clearFilter() {
    this.lowValue = this.options.floor;
    this.highValue = this.options.ceil;
    for (let item of this.selectedFil) {
      item.tags.forEach(x => {
        x.selected = false;
      });
      item.tags = []
    }
    this.isFilterData = false;
    this.searchEvent.emit({minQty:this.options.floor, maxQty: this.options.ceil, filterArr: this.selectedFil, resFlag: this.reservedFlag });
  }
  clearDateRange() {
    this.range.controls.start.setValue(null);
    this.range.controls.end.setValue(null);
    this.searchEvent.emit({ startDate: this.range.controls.start.value, endDate: this.range.controls.end.value, filterArr: this.selectedFil, resFlag: this.reservedFlag });
  }

  onFilterChange() {
    this.filterloader = true;
    this.setTime();
    this.selectedFil = [];
    for (let filter of this.newFilter) {
      let seletedTags = [];
      if(filter.control == 'ONHAND_QTY'){
        seletedTags.push({name: this.lowValue + " - " + this.highValue});
      }else{
        filter.tagsList.forEach(x => {
          if (x.selected) {
            seletedTags.push(x);
            this.isFilterData = true;
          }
        });
      }
      this.selectedFil.push({
        label: filter.label,
        control: filter.control,
        tags: seletedTags
      })
      
    }
    //For showing no filters 
    let count = 0;
    for (let item of this.selectedFil) {
      if(item.tags.length > 0) {
        count++;
      }
    }
    if(count == 0)
      this.isFilterData = false;
    else 
      this.isFilterData = true;
    this.searchEvent.emit({minQty:this.lowValue, maxQty: this.highValue, filterArr: this.selectedFil});
  } 
  setTime() {
    this.filterloader = false;
    // setTimeout(() => {
    //   this.filterloader = false;
    // },2000);
  }

  changeCase(value){
    if(typeof value === 'string'){
      return value.toUpperCase();
    }
    return value;
  }

}
