import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthenticateComponent, AuthGuardService } from 'hub2ushared';

const routes: Routes = [
  {
    path: '',
    component: AuthenticateComponent
  },
  {
    path: 'hub2u',
    loadChildren: () => import('./components/main/main.module').then(m => m.MainModule),
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
