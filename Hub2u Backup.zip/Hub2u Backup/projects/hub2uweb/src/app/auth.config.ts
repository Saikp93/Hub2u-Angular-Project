import { AuthConfig } from "angular-oauth2-oidc";
import { environment } from "../environments/environment";

export const authConfig: AuthConfig = {
    // AZURE AD migration
    clientId: environment.clientId,
    issuer: environment.idp,
    responseType: 'id_token token',
    redirectUri: window.location.href,
    scope: 'openid profile email api://' + environment.clientId + '/read',
    strictDiscoveryDocumentValidation: false,
    showDebugInformation: true,
    silentRefreshRedirectUri: window.location.origin + '/silent-refresh.html',
    silentRefreshTimeout: 10000, // For faster testing
    timeoutFactor: 0.25, // For faster testing,
    logoutUrl: "https://login.microsoftonline.com/906aefe9-76a7-4f65-b82d-5ec20775d5aa/oauth2/v2.0/logout",
};

