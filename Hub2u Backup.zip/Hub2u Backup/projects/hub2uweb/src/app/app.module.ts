import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Hub2usharedModule } from 'hub2ushared';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { registerLocaleData, HashLocationStrategy, LocationStrategy, DatePipe } from '@angular/common';
import en from '@angular/common/locales/en';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OAuthModule, OAuthService } from 'angular-oauth2-oidc';
import { environment } from '../environments/environment';
import { CatalogsModule } from './components/catalogs/catalogs.module';
import { ReportsModule } from './components/reports/reports.module';
import { WmsModule } from './components/wms/wms.module';
import { HomeModule } from './components/home/home.module';
import { trackOrderModule } from './components/track-order-details/track-order-details.module';
import { ItsupportModule } from './components/itsupport/itsupport.module';
import { InterceptService } from 'projects/hub2ushared/src/lib/services/intercept.service';
import { MatDialogModule } from '@angular/material/dialog';
import { NgxSpinnerModule } from 'ngx-spinner';
import { UserIdleModule } from 'angular-user-idle';
import { UnderMaintenanceComponent } from './components/under-maintenance/under-maintenance.component';

registerLocaleData(en);

@NgModule({
  declarations: [
    AppComponent,
    UnderMaintenanceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    Hub2usharedModule,
    FormsModule,
    HttpClientModule,
    MatDialogModule,
    BrowserAnimationsModule,
    OAuthModule.forRoot(),
    CatalogsModule,
    ReportsModule,
    ItsupportModule,
    HomeModule,
    WmsModule,
    NgxSpinnerModule,
    trackOrderModule,
    UserIdleModule.forRoot({idle: 1200, timeout: 60}),
    //UserIdleModule.forRoot({idle: 5, timeout: 85, ping: 75}),    
  ],
  providers: [ 
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptService,
      multi: true
    },
    {
      provide: 'environment', useValue: environment
    },
    [DatePipe]
    // {provide: LocationStrategy, useClass: HashLocationStrategy}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }