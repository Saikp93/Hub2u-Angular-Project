import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router, RoutesRecognized } from '@angular/router';
import { OAuthService } from 'angular-oauth2-oidc';
import { AuthService, CommonService, ReportsService } from 'hub2ushared';
import { authConfig } from './auth.config';
import { filter } from 'rxjs/operators';
import { ConstantData } from 'projects/hub2ushared/src/public-api';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  userInfo: any = {};
  previousUrl: string = null;
  currentUrl: string = null;
  functionId: any;
  maintenanceFlag = false;
  constructor(private commonService: CommonService, private router: Router, private authService: AuthService, private oauthService: OAuthService, private reportService: ReportsService,
    private constantData: ConstantData) {
    authService.configureWithNewConfigApi(authConfig);
  }

  ngOnInit() {
    this.router.events.pipe(
      filter((event) => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.previousUrl = this.currentUrl;
      this.currentUrl = event.url;
      sessionStorage.setItem("Prev_Url", this.previousUrl)
    });

    this.authentication();
    this.onSwitchNPID();
  }
  onSwitchNPID() {
    this.commonService.switchNPID.subscribe(data => {
      this.authentication();
    })
  }
  async authentication() {
    const callBack = setInterval((interval) => {
      let userInfo = localStorage.getItem("userDetails");
      if (!userInfo && this.oauthService.hasValidAccessToken()) {
        this.userInfo = this.authService.getProfile();
        localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
        this.onCheckUserInfo();
      }
      else if (userInfo) {
        this.userInfo = JSON.parse(userInfo);
        this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
        this.loadRegion();
        this.router.url.includes('hub2u') ? this.router.navigate([this.router.url]) : this.router.navigate(['/hub2u']);
      }
      clearInterval(callBack);
    }, 1000);
  }

  onCheckUserInfo() {
    if (this.userInfo.NTID !== undefined) {
      if (localStorage.getItem(this.userInfo.NTID + "_responsibilities")) {
        this.router.navigate([window.location.pathname]);
      } else {
        let object = {
          //"ReportId": "10087",
        "ReportId": "7002", // oracle fusion
        "ParametersInput":
            [{ "Name": "BIND_APPLICATIONID", "Value": "7" },
            { "Name": "USER_NAME", "Value": this.userInfo.NTID }]
        };

        //this.commonService.onFetchUserResp(object).subscribe(response => {
        this.reportService.onGetDynamicReport(object).subscribe(response => {
          this.router.navigate([window.location.pathname == "/" ? "/hub2u" : "window.location.pathname"]);
          let resp = response || [];
          localStorage.setItem(this.userInfo.NTID + "_responsibilities", JSON.stringify(resp));
        }, error => {
        });
      }
    }
  }

  async loadRegion() {
    let request = {
      "ReportId":  this.constantData.regionReportId[this.functionId],
      "ParametersInput": [
        {
          "Name": "REQUESTOR",
          "Value": this.userInfo.NTID
        }
      ]
    };
    await this.reportService.onGetDynamicReport(request).subscribe(repsonse => {
      if (repsonse.ROW !== undefined) {
        let region = repsonse.ROW[0].LOOKUP_CODE;
        this.userInfo['region'] = region;
        localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
      }
    });
  }
}
