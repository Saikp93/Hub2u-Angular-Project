import { Injectable } from '@angular/core';
import { Network } from '@ionic-native/network/ngx'
import { BehaviorSubject, Observable,fromEvent, merge, of } from 'rxjs';
import { ToastController, Platform } from '@ionic/angular'; 
import { map } from 'rxjs/operators';

export enum ConnectionStatus {
  Online,
  Offline
}

@Injectable({
  providedIn: 'root'
})

export class ConnectivityService {
  private status: BehaviorSubject<ConnectionStatus> = new BehaviorSubject(ConnectionStatus.Offline);
  public appIsOnline$: Observable<boolean>;
  
  constructor(private network: Network, private toastController: ToastController, private plt: Platform) {
     this.plt.ready().then(() => {
      this.initializeNetworkEvents();
      let status = this.network.type !== 'none' ? ConnectionStatus.Online : ConnectionStatus.Offline;
      this.status.next(status);
    });
  }

  public initializeNetworkEvents() {

    this.network.onDisconnect().subscribe(() => {
      if (this.status.getValue() === ConnectionStatus.Online) {
        console.log('WE ARE OFFLINE');
        this.updateNetworkStatus(ConnectionStatus.Offline);
      }
    });

    this.network.onConnect().subscribe(() => {
      if (this.status.getValue() === ConnectionStatus.Offline) {
        console.log('WE ARE ONLINE');
        this.updateNetworkStatus(ConnectionStatus.Online);
      }
    });
  }
  private async updateNetworkStatus(status: ConnectionStatus) {
    this.status.next(status);

    let connection = status == ConnectionStatus.Offline ? 'Offline' : 'Online';
    let msg = ConnectionStatus.Offline ? 'You are now Offline, still you can work with latest searched data' : 'You are now Online';
    let toast = this.toastController.create({
      message: msg,
      duration: 1500,
      position: 'bottom',
      mode: 'ios',
      translucent: true
    });
    toast.then(toast => toast.present());
  }

  public onNetworkChange(): Observable<ConnectionStatus> {
    return this.status.asObservable();
  }

  public getCurrentNetworkStatus(): ConnectionStatus {
    return this.status.getValue();
  }
  private initConnectivityMonitoring() {

    if (!window || !navigator || !('onLine' in navigator)) return;

    this.appIsOnline$ = merge(
      of(null),
      fromEvent(window, 'online'),
      fromEvent(window, 'offline')
    ).pipe(map(() => navigator.onLine))

  }
  // public appIsOnline$: Observable<boolean>;
  // checkInterent: boolean;
  // constructor(private network: Network, private platform: Platform) {
  //   this.initConnectivityMonitoring();
  // }

  // initConnectivityMonitoring() {
  //   // if (!window || !navigator || !('onLine' in navigator)) return;

  //   // this.appIsOnline$ = merge(
  //   //   of(null),
  //   //   fromEvent(window, 'online'),
  //   //   fromEvent(window, 'offline')
  //   // ).pipe(map(() => navigator.onLine))
  //   if (!window || !navigator || !('onLine' in navigator)) return;

  //   this.appIsOnline$ = Observable.create(observer => {
  //     observer.next(true);
  //   }).pipe(mapTo(true));

  //   if (this.platform.is('cordova')) {
  //     // on Device - when platform is cordova
  //     this.appIsOnline$ = merge(
  //       this.network.onConnect().pipe(mapTo(true)),
  //       this.network.onDisconnect().pipe(mapTo(false))
  //     );
  //   } else {
  //     // on Browser - when platform is Browser
  //     this.appIsOnline$ = merge(
  //       of(navigator.onLine),
  //       fromEvent(window, 'online').pipe(mapTo(true)),
  //       fromEvent(window, 'offline').pipe(mapTo(false))
  //     );
  //   }

  //   return this.appIsOnline$
  // }
}