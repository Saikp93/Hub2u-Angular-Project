import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient, @Inject('environment') private env: any) { }

  addToCart(data: any) {
    return this.http.post(this.env.cartService + '/api/add-to-cart', data);
  }

  deleteFromCart(data: any) {
    return this.http.post(this.env.cartService + '/api/manage-cart', data);
  }

  addToFavorite(data: any) {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/insert-favorite', data);
  }

  saveCart(data: any) {
    return this.http.post(this.env.cartService + '/api/add-to-cart', data);
  }

  clearCart(data: any) {
    return this.http.post(this.env.cartService + '/api/manage-cart', data);
  }
  repeatOrder(data: any) {
    return this.http.post(this.env.cartService + '/api/requisition-to-cart', data);
  }

  onDeleteFavorite(data: any) {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/delete-favorite', data);
  }

  hub2uOrder(data: any) {
    return this.http.post(this.env.hub2uOrder + '/api/hub2uOrder', data);
  }

  getShipmentRest(data: any) {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/getRequisitionShipment', data);
  }

  insertShipmentRest(data: any) {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/insert-acknowledgement', data);
  }

  favoriteList(data: any) {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/favourite-list', data);
  }

  details(data: any) {
    return this.http.post(this.env.selectSource + '/api/details', data);
  }
}
