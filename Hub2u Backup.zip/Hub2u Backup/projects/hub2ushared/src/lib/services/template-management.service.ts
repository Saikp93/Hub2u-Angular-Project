import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TemplateManagementService {

  constructor(private http: HttpClient, @Inject('environment') private env: any) { }

  onGetDynamicReport(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL + '/GetDynamicReport', request);
  }

  getReportDisplayFields(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL + '/GetReportDisplayFields', request);
  }

  save(request): Observable<any> {
    let userInfo =  JSON.parse(localStorage.getItem('userDetails'));
   let userRole =  localStorage.getItem(userInfo.NTID + '_userRole');
    if(userRole.toUpperCase()=='COMCAST BUSINESS SERVICES USER IIP'){
      return this.http.post(this.env.catalogtemplateiip + '/api/template/save', request);
    }else{
      return this.http.post(this.env.announcementUpdate + '/records/save', request);
    }
    
  }

  maintenanceSave(request): Observable<any>{
    return this.http.post(this.env.hub2uOrder + '/api/hub2u-proj/maintenance/save',request)
  }

  uploadBulkOrder(request): Observable<any> {
    return this.http.post(this.env.hub2uOrder + '/api/load-bulk-orders', request);
  }
}





