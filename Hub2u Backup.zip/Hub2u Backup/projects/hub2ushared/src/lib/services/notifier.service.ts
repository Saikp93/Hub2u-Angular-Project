import { Injectable } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import { CommonWebService } from "projects/hub2uweb/src/app/shared/common-web.service";
// import { SnackbarComponent } from "../components/snackbar/snackbar/snackbar.component";

@Injectable({
    providedIn: 'root'
})

export class NotifierService {

    constructor(private snackbar: MatSnackBar,private commonWebService: CommonWebService){}

    showNotification(displayMessage: string){
        // this.snackbar.openFromComponent(SnackbarComponent,{
        //     data:{
        //         message: displayMessage
        //     },
        //     duration: 5000,
        //     horizontalPosition: 'end',
        //     verticalPosition: 'top',
        //     panelClass: ['notifysnackbar']
        // });
        this.commonWebService.openSnackBar(displayMessage, "SUCCESS");
    }
}