import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SettingsService {

  constructor(private http: HttpClient, @Inject('environment') private env: any) { }
  
  public getSubInventoryDetails(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL02 + '/resources/MobileApp/SubInventory/SubInventoryRestService/GetSubInventoryDetails', request);
  }

  public onSaveSettings(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/upsert-preferences', request);
  }

  /** Fusion API start **/
    public getLocationDetails(request): Observable<any> {
      return this.http.post(this.env.baseAPIFUSION01 + '/api/settings/getLocationDetails', request);
    }
  /** Fusion API end **/
}