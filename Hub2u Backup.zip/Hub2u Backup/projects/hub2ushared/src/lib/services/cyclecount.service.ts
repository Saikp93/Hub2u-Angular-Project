import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CyclecountService {

  constructor(private http: HttpClient, @Inject('environment') private env: any) { }

  countAction(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL08 + '/api/cycle-count', request);
  }
//SOA TO JAVA CHANGES
  getUserNames(request): Observable<any> {
    return this.http.post(this.env.userdetails + '/api/searchUser', request);
  }

  callemail(request): Observable<any> {
    return this.http.post(this.env.sentcountemail +
      "/api/sync/sent-email-notification",
      request);
  }
}
