import { HttpClient } from '@angular/common/http';
import { Inject, Injectable, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  switchNPID: EventEmitter<boolean>;
  cartUpdate: EventEmitter<boolean>;
  widgetUpdate: EventEmitter<boolean>;
  switchProfile: EventEmitter<boolean>;

  constructor(private http: HttpClient, @Inject('environment') private env: any) {
    this.switchNPID = new EventEmitter<boolean>();
    this.switchProfile = new EventEmitter<boolean>();
    this.cartUpdate = new EventEmitter<boolean>();
    this.widgetUpdate = new EventEmitter<boolean>();
  }



  updateServices(flag: boolean): void {
    this.switchNPID.emit(flag);
  }

  updateProfile(flag: boolean): void {
    this.switchProfile.emit(flag);
  }

  updatedCart(flag: boolean): void {
    this.cartUpdate.emit(flag);
  }

  refreshWidgetCount(flag: boolean): void {
    this.widgetUpdate.emit(flag);
  }

  filter(data: any[], property: any, searchString: any) {
    return data.filter(ele => ele[property] === searchString);
  }

  public onShowAnnouncements(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL08 + '/api/display-announcements-per-user', request);
  }

}
