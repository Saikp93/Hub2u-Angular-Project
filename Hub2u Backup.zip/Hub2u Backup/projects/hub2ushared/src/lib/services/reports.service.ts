import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReportsService {

  constructor(private http: HttpClient, @Inject('environment') private env: any) { }

  onGetDynamicReport(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL + '/GetDynamicReport', request);
  }

  public getReport(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL + '/DYNAMIC_58', request);
  }

  public getCpeOrderReeport(): Observable<any> {
    return this.http.get(this.env.baseAPIURL + '/DYNAMIC_58');
  }

  public getCnaOrderReport(): Observable<any> {
    return this.http.get(this.env.baseAPIURL + '/DYNAMIC_60');
  }
  public getConfirmOutstandingOrder(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL12 + '/api/select-release-batch', request);
  }
  public reserveQuantity(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL12 + '/api/select-reserve-quantity', request);
  }
  public unReserveQuantity(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL12 + '/api/un-reserve-sales-order', request);

  }
  public reserveBySupply(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL12 + '/api/reserve-against-supply', request);

  }
  public getSalerOrderDetails(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL12 + '/api/select-sales-order-details', request)

  }
  public getReportDisplayFields(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL + '/GetReportDisplayFields', request);
  }

  public getOrderReport(): Observable<any> {
    return this.http.get(this.env.baseAPIURL + '/DYNAMIC_51');
  }


  public uploadImage(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL02 + '/resources/MobileApp/CatalogImage/CatalogImageRest/UploadImages', request);
  }

  public uploadCatalogImage(request): Observable<any>{
    return this.http.post(this.env.baseIMGUrlJAVA + '/api/sync/adhoc/v1/upload-image', request);
  }
  // public getShipmentDetails(request): Observable<any> {
  //   return this.http.post(this.env.baseAPIURL08 + '/api/tracking-details', request);
  // }
  public uploadPO(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL04 + '/api/receipt', request);
  }
  public uploadMiscreceipts(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL04 + '/api/inventory', request);

  }

  public cancelOrder(request): Observable<any> {
    return this.http.post(this.env.hub2uOrder + '/api/hub2uOrder', request);
  }

  public UpdateScheduleArrivalDate(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL12 + '/api/update-schedule-arrival-date', request);

  }

  public submitTicket(request): Observable<any> {
    return this.http.post(this.env.submititticket + '/api/mysupport/ticket', request);
  }

  public callIIPApi(request): Observable<any> {
    return this.http.post(this.env.iipUrl + '/api/sync/manage-order', request);
  }

  public onSaveSettings(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/upsert-preferences', request);
  }
  public switchPreference(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/switch-preferences', request);
  }

 /** Fusion API start **/
  getSubInv(request): Observable<any> {
    return this.http.post(this.env.baseAPIFUSION01 + '/api/getSubInvDetails', request);
  }

 
  public getReportDisplayFieldsFromFusion(request): Observable<any> {
    //return this.http.post(this.env.baseAPIURL + '/GetReportDisplayFields', request);
    return this.http.post(this.env.baseAPIFUSION01 + '/api/settings/getLocationDetails', request);
  }
/** Fusion API end **/
}
