import { Inject, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GetimageService {
  imageURL = this.env.baseIMGUrlJAVA;
  imageURLSOA = this.env.baseIMGUrl;
  //imageURL = this.env.baseIMGUrl;
  constructor(@Inject('environment') private env: any) { }


  getImage(item) {
    let imageSrc;
    if (item['CIFA#']) {
      imageSrc = this.imageURL + '/api/sync/download-file/v1/itemNumber/' + item['CIFA#']
    }
    else if (item['CIFA']) {
      imageSrc = this.imageURL + '/api/sync/download-file/v1/itemNumber/' + item['CIFA']
    }
    else if (item['CIFA_ITEM_NUMBER']) {
      imageSrc = this.imageURL + '/api/sync/download-file/v1/itemNumber/' + item['CIFA_ITEM_NUMBER']
    }
    else if (item['MODEL#'] || item['Model#']) {
      imageSrc = this.imageURL + '/api/sync/download-file/v1/itemNumber/' + (item['MODEL#'] || item['Model#']).replace(/ /g, "-")
    }
    else if (item['MODEL_NUMBER']) {
      imageSrc = this.imageURL + '/api/sync/download-file/v1/itemNumber/' + item['MODEL_NUMBER'].replace(/ /g, "-")
    }
    else if (item['MANUFACTURER_PART_NUM']) {
      imageSrc = this.imageURL + '/api/sync/download-file/v1/itemNumber/' + item['MANUFACTURER_PART_NUM'].replace(/ /g, "-")
    }

    else {
      imageSrc = 'assets/images/no-image.jpg'
    }

    return imageSrc;
  }

  getImagefromcifa(cifaItem) {
    let imageSrc;
    imageSrc = this.imageURL + '/api/sync/download-file/v1/itemNumber/' + cifaItem

    return imageSrc;
  }


  // getImage(item) {
  //   let imageSrc;
  //   if (item['CIFA#']) {
  //     imageSrc = this.imageURL + item['CIFA#'] + '.jpg'
  //   }
  //   else if (item['CIFA_ITEM_NUMBER']) {
  //     imageSrc = this.imageURL + item['CIFA_ITEM_NUMBER'] + '.jpg'
  //   }
  //   else if (item['MODEL#'] || item['Model#']) {
  //     imageSrc = this.imageURL + (item['MODEL#'] || item['Model#']).replace(/ /g, "-") + '.jpg'
  //   }
  //   else if (item['MODEL_NUMBER']) {
  //     imageSrc = this.imageURL + item['MODEL_NUMBER'].replace(/ /g, "-") + '.jpg'
  //   }
  //   else if (item['MANUFACTURER_PART_NUM']) {
  //     imageSrc = this.imageURL + item['MANUFACTURER_PART_NUM'].replace(/ /g, "-") + '.jpg'
  //   }
  //   else {
  //     imageSrc = 'assets/images/no-image.jpg'
  //   }
  //   return imageSrc;
  // }

  // getImagefromcifa(cifaItem) {
  //   let imageSrc;
  //   imageSrc = this.imageURL + cifaItem + '.jpg'
  //   return imageSrc;
  // }
}
