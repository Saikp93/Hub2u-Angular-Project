import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';
import { InterceptorSkipHeader } from './intercept.service';

@Injectable({
  providedIn: 'root'
})
export class StorePreferenceDbService {

  constructor(private http: HttpClient, @Inject('environment') private env: any) { }

  httpOptions: Object = {
    headers: InterceptorSkipHeader
  };

  headers={
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
  }

  public storePreferenceinDB(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL08 + '/api/save-hub2u-user-pref-data', request, this.httpOptions);
  } 

  public getPreferencefromDB(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL08 + '/api/get-hub2u-user-pref-data', request, this.httpOptions);
  } 

}
