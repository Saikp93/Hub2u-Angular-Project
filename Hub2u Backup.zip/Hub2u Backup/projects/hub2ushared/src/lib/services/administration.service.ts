import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdministrationService {

  ntUser: any = null;
  selectedresponsibility: number = 7;

  constructor(private http: HttpClient, @Inject('environment') private env: any) { }

  public getResposibilities(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/get-responsibility-options', request);
  }

  public getRegions(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/get-region-responsibility', request);
  }

  public removeRegion(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/upsert-region-responsibility', request);

  }

  public addRegion(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/upsert-region-responsibility', request);
  }

  public getUserDetails(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/fetch-user-responsibilities', request);
  }
  public getUsers(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/get-user-responsibility', request);
  }
  public getSearchedUser(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/fetch-user-details', request);

  }

  public addUser(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/upsert-user-responsibilities', request);
  }

  public updateUser(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/upsert-user-responsibilities', request);
  }

  public removeUser(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/upsert-user-responsibilities', request);
  }

  setNtUser(ntUser) {
    this.ntUser = ntUser;
  }

  getNtUser() {
    return this.ntUser;
  }

  setSelectedresponsibility(selectedresponsibility) {
    this.selectedresponsibility = selectedresponsibility;
  }

  getSelectedresponsibility() {
    return this.selectedresponsibility;
  }

  getSelectedEmployees(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/bu/get-selected-user', request);
  }

  getAvailableEmployees(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/bu/get-other-user', request);
  }

  InsertUserDetails(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/bu/insert-user', request);
  }

  DeleteUserList(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/bu/delete-user', request);
  }
}




