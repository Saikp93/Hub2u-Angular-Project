import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BulkUploadService {

    constructor(private http: HttpClient, @Inject('environment') private env: any) { }

    public bulkExportCsv(request): Observable<any> {
        return this.http.post(this.env.hub2uOrder + '/api/getDqCsvOutput', request,{responseType: 'blob'})
    }
}