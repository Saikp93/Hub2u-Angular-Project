import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private http: HttpClient, @Inject('environment') private env: any) { }

  getRecentOrderCount(object): Observable<any> {
    return
  }

  getFrequentOrders(object): Observable<any> {
    return
  }

  getAnnoucements(object): Observable<any> {
    return
  }

  getMyDetails(object): Observable<any> {
    return
  }

  getTrackingDetails(object): Observable<any> {
    return this.http.post(this.env.shipmentTrackingUrl + '/api/tracking-details', object);
  }



  public hub2uOrderJavaApi(request): Observable<any> {
    return this.http.post(this.env.hub2uOrder + '/api/hub2uCheckOut', request);
  }

  public hub2uOrder(request): Observable<any> {
    return this.http.post(this.env.hub2uOrder + '/api/hub2uOrder', request);
  }

  getApprovalDetails(object): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/perform-Approval-operation', object);
  }
  public getZipCode(request): Observable<any> {
    return this.http.get(this.env.zipCodeURL + '/api/zipcode/' + request);
  }
  public getAddress(request): Observable<any> {
    return this.http.post(this.env.zipCodeURL + '/api/validateAddress', request);
  }
}
