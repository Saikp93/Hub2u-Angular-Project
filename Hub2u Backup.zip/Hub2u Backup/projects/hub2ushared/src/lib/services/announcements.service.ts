import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AnnouncementsService {

  constructor(private http: HttpClient, @Inject('environment') private env: any) { }

  getAnnouncementsForUserList(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL08 + '/api/display-announcements-per-user', request);
  }
  regUsingResp(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/get-region-responsibility', request);
  }



  getAnnouncementsForAdminList(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL08 + '/api/admin-announcements', request);
  }

  announcementsType() {
    const data = {};
    return this.http.get(this.env.baseAPIURL08 + '/api/announcements-type', data);
  }

  saveAnnouncement(announcementsInput) {
    const data = { "SaveAnnouncementsInput": announcementsInput };
    return this.http.post(this.env.baseAPIURL08 + '/api/save-announcements', data);
  }

  revokeAnnouncement(announcementsInput) {
    const data = { "RevokeAnnouncementsInput": announcementsInput };
    return this.http.post(this.env.baseAPIURL08 + '/api/revoke-announcements', data);
  }

  updateAnnouncementLikes(request) {
    return this.http.post(this.env.announcementUpdate + '/announcement/like', request);
  }

  updateAnnouncementRead(request) {
    return this.http.post(this.env.announcementUpdate + '/announcement/read', request);
  }

  imageUpload(request) {
    return this.http.post(this.env.announcementUpdate + '/announcement/image', request);
  }

}