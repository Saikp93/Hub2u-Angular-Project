import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { request } from 'https';
import { Observable } from 'rxjs';
import { InterceptorSkipHeader } from './intercept.service';

@Injectable({
  providedIn: 'root'
})
export class PdfGeneratorService {

  constructor(private http: HttpClient, @Inject('environment') private env: any) { }


  httpOptions: Object = {
    headers: InterceptorSkipHeader

  };

  headers = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  Submit(request): Observable<any> {
    return this.http.post(this.env.pdfgeneratorurl + '/api/async/generate-report', request, this.httpOptions
    );
  }

  fetchjobdetails(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL + '/GetDynamicReport', request)
  }

  getinputfeilds(request): Observable<any> {
    return this.http.post(this.env.baseAPIURL + '/GetReportDisplayFields', request)
  }

  getwebsectoken(req) {
    return this.http.post(this.env.pdfgeneratorurl + '/api/sync/get-web-token', '')
  }

  downloaddoc(request): Observable<any> {
    return this.http.post(this.env.pdfgeneratorurl + '/api/sync/download-file', request)
  }

  emailFile(request): Observable<any> {
    return this.http.post(this.env.pdfgeneratorurl + '/api/sync/email-file', request)
  }

  updatePrintStatus(request): Observable<any> {
    return this.http.post(this.env.pdfgeneratorurl + '/api/sync/update-print-status', request)
  }

  retryUpload(request): Observable<any> {
    return this.http.post(this.env.pdfgeneratorurl + '/api/sync/retry-partial-files', request)
  }


}