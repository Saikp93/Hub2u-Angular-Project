import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  constructor(private http: HttpClient, @Inject('environment') private env: any) { }

  getFeedback(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/getRequisitionFeedback', request);
  }

  insertFeedback(request): Observable<any> {
    return this.http.post(this.env.baseAPIJAVA02 + '/api/insertRequisitionFeedback', request);
  }
}