import { TestBed } from '@angular/core/testing';

import { CyclecountService } from './cyclecount.service';

describe('CyclecountService', () => {
  let service: CyclecountService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CyclecountService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
