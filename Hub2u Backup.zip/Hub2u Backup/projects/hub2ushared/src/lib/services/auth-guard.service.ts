import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { OAuthService } from 'angular-oauth2-oidc';
import { Platform } from '@ionic/angular';
import { AlertController } from '@ionic/angular'
@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(private alertController: AlertController, private router: Router, private platform: Platform, private oauthService: OAuthService) { }

  canActivate() {
    // if(this.tokenExpired(this.oauthService.getAccessToken())){
    //   alert("token is expired");
    // }
    if (this.oauthService.hasValidAccessToken()) {
      return true;
    } else {
      // alert('Trying to retain the Access Token, You will redirect to login page.');
      this.router.navigate(['/']);
    }

  }
  async presentWarningAlert(message) {
    const alert = await this.alertController.create({
      cssClass: 'warning-alert-class',
      header: 'Warning',
      subHeader: '',
      message: message,
      buttons: ['Ok']
    });

    await alert.present();
    const { role } = await alert.onDidDismiss();
  }
  tokenExpired(token: string) {
    const expiry: any = this.oauthService.getIdentityClaims();
    let exp = 0;
    if (expiry) {
      exp = expiry.exp
    }
    return (Math.floor((new Date).getTime() / 1000)) >= exp;
  }
}
