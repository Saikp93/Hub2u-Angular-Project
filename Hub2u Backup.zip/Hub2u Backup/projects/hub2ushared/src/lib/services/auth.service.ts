import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { LoginOptions, OAuthService } from 'angular-oauth2-oidc';
import { JwksValidationHandler } from 'angular-oauth2-oidc-jwks';
import { from, Observable } from 'rxjs';
import {NgZone} from '@angular/core';
import { Platform } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
 
export class AuthService {

  public authTokenNew: string = 'new_auth_token';
  public currentToken: string;
  constructor(private oauthService: OAuthService, private platform: Platform, private router: Router, private http: HttpClient, @Inject('environment') private env: any) { 
    this.currentToken = this.getToken();
  } 
  

  configureWithNewConfigApi(authConfig) { 
    this.oauthService.configure(authConfig);
    this.oauthService.customQueryParams = {
      response_mode: 'fragment'
    };

    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.setupAutomaticSilentRefresh();
    this.oauthService.showDebugInformation = true;
    this.oauthService.oidc = true;
    this.oauthService.requestAccessToken = true;
    this.oauthService.events.subscribe(({ type }) => {
      if (type === 'token_received') {
        console.log('token_received ', type);
        //this.router.navigate(['/hub2u']);
        this.router.navigate([window.location.pathname == '/' ? '/hub2u' : window.location.pathname]);
        // this.router.navigate([window.location.pathname]);
      }
      if (type === 'token_refreshed') {
        console.log('token_refreshed ', type);
      }
      if (type === 'silently_refreshed') {
        console.log('silently_refreshed ', type);
      }
      if (type === 'token_expires') {
        console.log('token_expires ', type);
        this.oauthService.silentRefresh().then(info => console.log('refresh ok', info)).catch((err) => {        
          // alert('Your session is expired, You will redirect to login page.');
          this.logout();
        });
      }
      if (type === 'silent_refresh_timeout') {
        this.oauthService.silentRefresh().then(info => console.log('refresh ok', info)).catch((err) => { 
          // alert('Your session is expired, You will redirect to login page.');
          this.logout();
        });
      }
    });
    const options = new LoginOptions();
    options.disableOAuth2StateCheck = true;
    // if (this.platform.is('ios')) {
    //    Browser.close();
    // }
    
    this.oauthService.loadDiscoveryDocument().then((doc) => {
      this.oauthService.tryLogin(options).then(() => {
        if (!this.oauthService.hasValidAccessToken()) {
          this.oauthService.initImplicitFlow();
        } else {
          this.router.navigate([window.location.pathname == '/' ? '/hub2u' : window.location.pathname]);
          //this.router.navigate([window.location.pathname]);
        }
      });
    });
  }

  refreshToken(){
    return from(this.oauthService.refreshToken().then(token =>{
      return token;
    }))
  }
  logout() {
    //sessionStorage.clear();
    // localStorage.clear();
    this.oauthService.logOut(true);
  }
  getToken(){
    const claims: any = this.oauthService.getIdentityClaims();
    if (claims) {
      return claims.onpremisessamaccountname.toUpperCase()
    }
  }
  getProfile() {
    const claims: any = this.oauthService.getIdentityClaims();
    if (claims) {
      let userInfo = {
        "NTID": claims.onpremisessamaccountname.toUpperCase(),
        "UserName": claims.givenname,
        "access_token": this.oauthService.getAccessToken(),
        "role": claims.roles,
      }
      return userInfo;
    }
    return undefined;
  }  

  onGetProfileImage(userId): Observable<any> {
    let url = this.env.baseAPIURL03 + '/api/user/' + userId + '/profile/picture';
    return this.http.get(url, { responseType: 'blob' });
  }

}
