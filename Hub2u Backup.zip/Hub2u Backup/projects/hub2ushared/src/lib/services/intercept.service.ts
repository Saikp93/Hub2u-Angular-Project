import { Injectable, Inject } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { from, Observable, Subject, throwError } from 'rxjs';
import { OAuthService } from 'angular-oauth2-oidc';
import { catchError, map, switchMap, tap, finalize } from 'rxjs/operators';
import { Platform } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { AuthService } from '../services/auth.service';
import { CommonWebService } from 'projects/hub2uweb/src/app/shared/common-web.service';

// import { Storage } from '@ionic/storage-angular';
export const InterceptorSkipHeader = 'X-Skip-Interceptor';

@Injectable()//{providedIn: 'root'}
export class InterceptService implements HttpInterceptor {


  constructor(private alertController: AlertController, private authService: AuthService, private platform: Platform, private oauthService: OAuthService, @Inject('environment') private env: any, private commonWebService: CommonWebService) { }
  refreshTokenInProgress = false;
  tokenRefreshedSource = new Subject();
  tokenRefreshed$ = this.tokenRefreshedSource.asObservable();
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (req.headers.has(InterceptorSkipHeader)) {
      const headers = req.headers.delete(InterceptorSkipHeader)
      return next.handle(req.clone({ headers })).pipe(catchError(error => {
        return this.handleResponseError(error, requestToForward, next);
      }))
    }

    let requestToForward = req;
    let tokenValue = "";
    //let getwebtokenurl = req.url.indexOf(this.env.pdfgeneratorurl)

    // if (getwebtokenurl > -1) {
    //   return next.handle(requestToForward).pipe(catchError(error => {
    //     return this.handleResponseError2(error, requestToForward, next);
    //   }));
    // }

    // else {
    if (this.oauthService.getAccessToken()) {
      if (!this.tokenExpired(this.oauthService.getAccessToken())) {
        let token = this.oauthService.getAccessToken();
        tokenValue = token !== '' ? 'Bearer ' + token : undefined;
        requestToForward = req.clone({ setHeaders: { Authorization: tokenValue } });
      } else {
        if (this.platform.is('ios') || this.platform.is('android') || this.platform.is('cordova')) {
          this.presentWarningAlert('Token is Expired, need to logout!!!');
          this.oauthService.logOut();
          // this.storage.clear();
          window.location.href = "https://login.microsoftonline.com/906aefe9-76a7-4f65-b82d-5ec20775d5aa/oauth2/v2.0/logout";
        } else {
          this.oauthService.logOut();
          sessionStorage.clear();
          localStorage.clear();
          window.location.href = "https://login.microsoftonline.com/906aefe9-76a7-4f65-b82d-5ec20775d5aa/oauth2/v2.0/logout";
        }
      }
    } else {
      console.debug('OidcSecurityService undefined: NO auth header!');
    }
    return next.handle(requestToForward).pipe(catchError(error => {
      return this.handleResponseError(error, requestToForward, next);
    }))
    // }
  }

  handleResponseError(error, request?, next?: HttpHandler) {
    // Business error
    if (error.status === 400) {
      //this.handle400Error(error);
    }
    // Invalid token error
    else if (error.status === 401 && (error.statusText.indexOf('token expired') > -1)) {
      return from(this.oauthService.refreshToken()).pipe(
        switchMap(() => {
          request = this.addAuthHeader(request);
          return next.handle(request);
        }),
        catchError(e => {
          if (e.status !== 401) {
            return throwError(e);
          } else {
            this.authService.logout();
          }
        })
      );
    }
    // Access denied error
    else if (error.status === 403) {
      // Show message
      // Logout
      //this.authService.logout();
    }
    // Server error
    else if (error.status === 500) {
      //this.commonWebService.openSnackBar('500 Internal Server Error', 'ERROR')
      // Show message
    }
    // Maintenance error
    else if (error.status === 503) {
      // Show message
      // Redirect to the maintenance page
    }
    return throwError(error);
  }

  handleResponseError2(error, request?, next?: HttpHandler) {
    if (error.status === 500) {
      this.commonWebService.openSnackBar('500 Internal Server Error', 'ERROR')
      // Show message
    }
    // Maintenance error
    else if (error.status === 503) {
      // Show message
      // Redirect to the maintenance page
    }
    return throwError(error);
  }

  refreshToken(): Observable<any> {
    if (this.refreshTokenInProgress) {
      return new Observable(observer => {
        this.tokenRefreshed$.subscribe(() => {
          observer.next();
          observer.complete();
        });
      });
    } else {
      this.refreshTokenInProgress = true;

      return this.authService.refreshToken().pipe(
        tap(() => {
          this.refreshTokenInProgress = false;
          this.tokenRefreshedSource.next();
        }),
        catchError((error: any) => {
          this.refreshTokenInProgress = false;
          this.authService.logout();
          return throwError(error.statusText);
        }));
    }
  }

  addAuthHeader(req) {
    //const authHeader = this.authService.getAuthorizationHeader(); 
    if (req.headers.has(InterceptorSkipHeader)) {
      const headers = req.headers.delete(InterceptorSkipHeader)
      if (headers) {
        return req.clone(headers);
      }
    }
  }



  handle400Error(error) {
    if (error && error.status === 400 && error.error && error.error.error === 'invalid_grant') {
      // If we get a 400 and the error message is 'invalid_grant', the token is no longer valid so logout.
      return this.authService.logout();
    }
    return throwError(error);
  }

  tokenExpired(token: string) {
    const expiry: any = this.oauthService.getIdentityClaims();
    let exp = 0;
    if (expiry) {
      exp = expiry.exp
    }
    // console.log("expiry", exp);
    // console.log("expiry time", (Math.floor((new Date).getTime() / 1000)), "exp - ", exp);
    return (Math.floor((new Date).getTime() / 1000)) >= exp;
  }
  async presentWarningAlert(message) {
    const alert = await this.alertController.create({
      cssClass: 'warning-alert-class',
      header: 'Warning',
      subHeader: '',
      message: message,
      buttons: ['Ok']
    });

    await alert.present();
    const { role } = await alert.onDidDismiss();
  }
}
