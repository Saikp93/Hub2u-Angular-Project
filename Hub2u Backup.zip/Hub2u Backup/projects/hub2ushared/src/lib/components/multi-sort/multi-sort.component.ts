import { Component, Input, OnInit, OnChanges, Output, EventEmitter, AfterContentInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ConstantData } from '../../constants/common-data';
import { MultiSortPipe } from '../../pipes/multi-sort.pipe';

@Component({
  selector: 'lib-multi-sort',
  templateUrl: './multi-sort.component.html',
  styleUrls: ['./multi-sort.component.scss'],
  providers: [MultiSortPipe]
})
export class MultiSortComponent implements OnInit {

  @Input() filterOptions = [];
  @Input() tableData;
  @Input() copyTableData;
  @Input() defaultSelected = '';
  // @Input() sortBySelected;
  @Input() pageName = '';
  @Input() isClearSort;
  @Input() sortbyValuesPreference = [];
  @Output() multiSortBy = new EventEmitter();
  @Output() storeSortByPreference = new EventEmitter();
  @Output() clearSortByPreference = new EventEmitter();

  sortBySelected: any =[];
  selectedSortItems: any= {};
  multiSelectedValues:any = [];
  storageValue: any;
  // copyTableData = this.tableData
  // copyData = Object.assign([], this.copyTableData)

  constructor(private constantData: ConstantData, private multiSortPipe: MultiSortPipe) { }

  // filterList = this.constantData.multiSortFilter;
  
  ngOnInit() {
    if (this.pageName == 'order-table') {
      this.multiSelectedValues = this.sortbyValuesPreference;
      this.multiSortData({ "value": this.multiSelectedValues });
    }

    // if(this.pageName == 'item-counting' && localStorage.getItem('sortOptions') !== null){
    //   this.storageValue = JSON.parse(localStorage.getItem('sortOptions'));
    //   this.multiSelectedValues = this.storageValue.modelValue;
    //   this.sortBySelected = this.storageValue.sortSelected;
    //   this.filterOptions = this.storageValue.filterOptions;
    //   this.multiSortData({ "value": this.multiSelectedValues });
    // }

    if(this.pageName == 'item-counting' && this.sortbyValuesPreference == undefined && localStorage.getItem('sortOptions') !== null){
      this.storageValue = JSON.parse(localStorage.getItem('sortOptions'));
      this.multiSelectedValues = this.storageValue.modelValue;
      this.sortBySelected = this.storageValue.sortSelected;
      this.filterOptions = this.storageValue.filterOptions;
      this.multiSortData({ "value": this.multiSelectedValues });
    } else {
      this.multiSelectedValues = this.sortbyValuesPreference;
      this.multiSortData({ "value": this.multiSelectedValues });
    }
  }

  changeorderMultiSort(data) {
    for (let item of this.filterOptions) {
      if (item.key == data.key) {
        item.order = !item.order
      }
    }
    this.multiSortData({ "value": this.multiSelectedValues });
  }

  multiSortData(event){
    let sel = [], unsel = []; this.sortBySelected = [];
    this.filterOptions.forEach(item => {
        if (event.value.indexOf(item.val) !== -1) {
          sel.push(item);
          // this.sortBySelected.push(item); 
          this.sortBySelected.push(item.key + ' ' + (item.order ? 'ASC' : 'DESC'))
          this.selectedSortItems[item.val] = item.order ? 'asc' : 'desc';
        }
        else {
          unsel.push(item);
          delete this.selectedSortItems[item.val];
        }
    });
    this.filterOptions = [...sel, ...unsel];
    this.tableData = this.multiSortPipe.transform(Object.assign([], this.copyTableData), this.selectedSortItems)
    this.multiSortBy.emit({ 'data': this.tableData, 'sortSelected': this.sortBySelected, 'modelValue': this.multiSelectedValues});
    localStorage.setItem("sortOptions", JSON.stringify({'sortSelected': this.sortBySelected,'modelValue': this.multiSelectedValues, 'filterOptions': this.filterOptions, 'selectedSortItems': this.selectedSortItems
    }));
  }

  storePreference() {
    this.storeSortByPreference.emit({ 'selectedData': this.multiSelectedValues, "filterOptionsList": this.filterOptions });
  }

  clearPreference() {
    this.multiSelectedValues = [];
    this.multiSortData({ "value": this.multiSelectedValues });
    this.clearSortByPreference.emit({ 'userPreferencedata': "" });
  }
}
