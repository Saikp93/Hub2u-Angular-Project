import { Component, Inject, OnInit } from '@angular/core';

@Component({
  selector: 'lib-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.scss'],
})
export class ErrorComponent implements OnInit {
  userInfo: string = '';

  constructor(@Inject('environment') private env: any) { }

  ngOnInit() {
    if (this.env.flatform === 'mobile') {

    } else {
      let userInfo = sessionStorage.getItem("userDetails");
      this.userInfo = JSON.parse(userInfo);
    }
  }

}
