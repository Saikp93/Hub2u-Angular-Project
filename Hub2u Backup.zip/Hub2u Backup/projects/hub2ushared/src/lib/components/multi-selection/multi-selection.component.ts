import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-multi-selection',
  templateUrl: './multi-selection.component.html',
  styleUrls: ['./multi-selection.component.scss'],
})
export class MultiSelectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
