import { AfterContentInit, Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ConstantData } from '../../constants/common-data';
import { CommonService } from '../../services/common.service';
import { ReportsService } from '../../services/reports.service';
import { Storage } from '@ionic/storage-angular';
import { AuthService } from '../../services/auth.service';
import { OAuthService } from 'angular-oauth2-oidc';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'lib-switch-ntid',
  templateUrl: './switch-ntid.component.html',
  styleUrls: ['./switch-ntid.component.scss'],
})
export class SwitchNtidComponent implements OnInit, AfterContentInit {
  @Output() onRefresh = new EventEmitter();
  switchUsername = new FormControl('');
  userInfo: any = {};
  switchBlock: string = '';
  userRole = "COMCAST TECH USER IIP";
  oldUser;
  loadSpinner = false;
  isError = false;
   constructor(private spinner: NgxSpinnerService, private reportService: ReportsService, private commonService: CommonService, private authService: AuthService, private oauthService: OAuthService, private constantData: ConstantData, @Inject('environment') private env: any, private router: Router, private storage: Storage) { }

  ngOnInit() {
    this.switchBlock = this.env.flatform === 'mobile' ? 'content ion-padding' : 'container-fluid max-width-1600 py-2';
    this.onInitialLoad();
  }
  ngAfterContentInit() {
  }
  async onInitialLoad() {
    if (this.env.flatform === 'mobile') {
      this.userInfo = JSON.parse(await this.storage.get('userDetails'));
      if (!this.userInfo && this.oauthService.hasValidAccessToken()) {
        this.userInfo = this.authService.getProfile();
        this.storage.set("userDetails", JSON.stringify(this.userInfo));
      }
    } else {
      this.userInfo = JSON.parse(await localStorage.getItem('userDetails'));
      if (!this.userInfo && this.oauthService.hasValidAccessToken()) {
        this.userInfo = this.authService.getProfile();
        localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
      }
    }
  }


  switchUser() {
    // this.loadSpinner = true;
    this.spinner.show();
    if (this.switchUsername.value !== null && this.switchUsername.value !== undefined) {
      this.oldUser = this.userInfo.NTID;
      this.userInfo.NTID = this.switchUsername.value.toUpperCase().trim()
      if (this.env.flatform === 'mobile') {
        this.storage.set("userDetails", JSON.stringify(this.userInfo));
        this.storage.set("switchNTID", 'true');
        this.clearMobileStorage();
      } else {
        localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
        localStorage.setItem("switchNTID", 'true');
        this.clearSession();
      }
      // this.onCheckUserInfo();
      this.switchUsername.setValue(null);
      this.storeResp();
      this.onRefresh.emit('');
      this.commonService.updateServices(true);
    }
  }

  clearSession() {
    let arr = []; // Array to hold the keys
    // Iterate over localStorage and insert the keys that meet the condition into arr
    for (let i = 0; i < localStorage.length; i++) {
      if (localStorage.key(i).includes(this.oldUser)) {
        arr.push(localStorage.key(i));
      }
    }

    // Iterate over arr and remove the items by key
    for (let i = 0; i < arr.length; i++) {
      localStorage.removeItem(arr[i]);
    }
  }
  clearMobileStorage() {
    this.storage.forEach((value, key, index) => {
      if (key.includes(this.oldUser)) {
        this.storage.remove(key);
      }
    })
  }
  storeResp() {

    let object = {
      // "ReportId": "10087",
     "ReportId": "7002",
     "ParametersInput":
        [{ "Name": "BIND_APPLICATIONID", "Value": "7" },
        { "Name": "USER_NAME", "Value": this.userInfo.NTID }]
    };
    // let object = {
    //       BIND_APPLICATIONID: '1',
    //       USER_NAME: this.userInfo.NTID
    //     };

    //this.commonService.onFetchUserResp(object).subscribe(async response => {
    this.reportService.onGetDynamicReport(object).subscribe(async response => {
      // this.router.navigate([window.location.pathname == "/" ? "/hub2u" : "window.location.pathname"]);
      let resp = response || [];
      if (resp.ROW !== undefined) {
        if (this.env.flatform === 'mobile') {
          this.storage.set(this.userInfo.NTID + "_responsibilities", JSON.stringify(resp));
        } else {
          localStorage.setItem(this.userInfo.NTID + "_responsibilities", JSON.stringify(resp));
        }
        if (this.userInfo !== null) {
          let roleNew = (resp && resp.ROW) ? resp.ROW.filter(e => e.TYPE == "USER_TYPE") : 0;
          if (roleNew.length > 0) {
            this.userRole = this.constantData.roles[roleNew[0].FUNCTION_ID];
            if (this.env.flatform === 'mobile') {
              this.storage.set(this.userInfo.NTID + "_userRole", this.userRole);
              this.storage.set(this.userInfo.NTID + "_functionId", roleNew[0].FUNCTION_ID);
            } else {
              localStorage.setItem(this.userInfo.NTID + "_userRole", this.userRole);
              localStorage.setItem(this.userInfo.NTID + "_functionId", roleNew[0].FUNCTION_ID);
            }
          } else {
            if (this.env.flatform === 'mobile') {
              this.storage.set(this.userInfo.NTID + "_userRole", "COMCAST TECH USER IIP");
              // this.storage.set(this.userInfo.NTID + "_functionId", '99');
              this.storage.set(this.userInfo.NTID + "_functionId", '143');
            } else {
              localStorage.setItem(this.userInfo.NTID + "_userRole", "COMCAST TECH USER IIP");
              // localStorage.setItem(this.userInfo.NTID + "_functionId", '99');
              localStorage.setItem(this.userInfo.NTID + "_functionId", '143');
            }
          }
          this.spinner.hide();
          this.router.navigate(['/hub2u']);
        }
        this.commonService.updateProfile(true);
      } else {
        this.spinner.hide();
        this.isError = true;
        this.userInfo.NTID = this.oldUser;
        if (this.env.flatform === 'mobile') {
          this.storage.set("userDetails", JSON.stringify(this.userInfo));
          this.storage.set("switchNTID", 'true');
        } else {
          localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
          localStorage.setItem("switchNTID", 'true');
        }
      }
    }, error => {
      this.spinner.hide();
      this.isError = true;
      this.userInfo.NTID = this.oldUser;

      if (this.env.flatform === 'mobile') {
        this.storage.set("userDetails", JSON.stringify(this.userInfo));
        this.storage.set("switchNTID", 'true');
      } else {
        localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
        localStorage.setItem("switchNTID", 'true');
      }
    });
  }
  getUserRole(resp) {

  }
}
