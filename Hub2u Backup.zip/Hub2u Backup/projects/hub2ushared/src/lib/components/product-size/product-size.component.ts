import { Component, EventEmitter, Input, OnInit, Output, ChangeDetectionStrategy } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'lib-product-size',
  templateUrl: './product-size.component.html',
  styleUrls: ['./product-size.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductSizeComponent implements OnInit {

  @Output() sizeEvent = new EventEmitter<number>();
  @Input() size;
  @Input() page = '';
  @Input() actualSize;
  @Input() disabled = '';
  @Input() muteText;
  @Input() min;
  @Input() max;
  @Input() lotSize = 1;
  functionId: string;
  userInfo: any;
  constructor() { }

  ngOnInit() {
    if (this.page !== 'order') {
      this.size = this.size ? this.size : 1;
    }
    let userInfo = localStorage.getItem("userDetails");
    this.userInfo = JSON.parse(userInfo);
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
  }

  ngOnChanges() {
    if (this.page !== 'order') {
      this.size = this.size ? this.size : 1;
    }
  }

  getMinSize() {
    //if(this.functionId == '51' && this.page=='catalog') {
      if(this.functionId == '136' && this.page=='catalog') {
      return this.lotSize
    } else {
      return this.min
    }
  }

  onInput() {
    let arrayOfPossibleNum = [];
    let min = +this.min;
    let max = +this.max;
    let lotSize = +this.lotSize
    let size = +this.size;
    if (this.max == "") {
      this.size = this.size;
    }
    else if (this.size > max) {
      this.size = max;
    }
    else if (this.size < min) {
      this.size = min;
    }
    else if (this.size > min && this.size < max) {
      for (let i = +min; i <= +max; i = +i + +lotSize) {
        arrayOfPossibleNum.push(i)
      }
      arrayOfPossibleNum.sort((a, b) => {
        return Math.abs(size - a) - Math.abs(size - b);
      })
      this.size = arrayOfPossibleNum[0]
    }
    else if (this.size == null || this.size < 0) {
      this.size = 1
    }
    this.sizeEvent.emit(this.size);
  }

  // onInput() {
  //   let arrayOfPossibleNum = [];
  //   let min = this.min;
  //   let max = this.max;
  //   let lotSize = this.lotSize
  //   let size = this.size;
  //   if(this.page !== 'order' && this.max == "") {
  //     this.size = this.size;
  //   }
  //   else if(this.page !== 'order' && this.size > this.max) {
  //     this.size = this.max;
  //   }
  //   else if(this.page !== 'order' && this.size < this.min) {
  //     this.size = this.min;
  //   }
  //   else if(this.page !== 'order' && this.size > this.min && this.size < this.max) {
  //     for(let i=+min; i<=+max; i= +i + +lotSize) {
  //       arrayOfPossibleNum.push(i)
  //     }
  //     arrayOfPossibleNum.sort((a, b) => {
  //       return Math.abs(size - a) - Math.abs(size - b);
  //     })
  //     this.size = arrayOfPossibleNum[0]
  //   }
  //   this.sizeEvent.emit(this.size);
  // }

  add() { 
    this.size = ((+this.size + +this.lotSize) > this.max) ? this.size : (+this.size + +this.lotSize);
    this.sizeEvent.emit(this.size);
  }
  remove() {
    if (this.size > 0) {
      this.size = (this.size - this.lotSize) == 0 ? 1 : (this.size - this.lotSize);
    }
    this.sizeEvent.emit(this.size);
  }

  // disableLogic(){
  //   if(page == 'order' && size)
  // }

}
