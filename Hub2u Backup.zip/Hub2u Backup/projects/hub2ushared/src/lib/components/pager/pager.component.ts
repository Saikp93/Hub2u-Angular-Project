import { Component, Input, OnInit, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { PagerService } from '../../services/pager.service';
import { SortPipe } from '../../pipes/sort.pipe';
import { SortOrderFilterPipe } from '../../pipes/sort-order-filter.pipe';
import { MultiSortPipe } from '../../pipes/multi-sort.pipe';
@Component({
  selector: 'lib-pager',
  templateUrl: './pager.component.html',
  styleUrls: ['./pager.component.scss'],
  providers:[SortPipe,SortOrderFilterPipe, MultiSortPipe]
})
export class PagerComponent implements OnInit {

  @Input() tableData;
  @Input() sortCol = '';
  @Input() sortItems = {};
  @Input() sortReverseOrder = false;
  @Input() ItemPerPage = 10; 
  @Input() pageNumber = 1;
  @Input() pageName = '';
  @Input() pageSizes = [5, 10, 15, 20];
  @Output() pagedItemsEvent = new EventEmitter();
  pager: any = {};
  pagedItems = [];
  
  constructor(private pagerService: PagerService, private cd: ChangeDetectorRef, private sort: SortPipe,
     private sortOrderFilterPipe: SortOrderFilterPipe, private multiSortPipe: MultiSortPipe) { }

  ngOnInit() {

  }
  ngOnChanges() {
    this.cd.detectChanges(); 
    this.sortData();
    this.setPage(this.pageNumber);
  }
  setPage(page: number) {
    if (this.tableData.length > 0) {
      if (page < 1 || page > this.pager.totalPages) {
        return;
      }
      this.pager = this.pagerService.getPager(this.tableData.length, page, this.ItemPerPage);
      this.pagedItems = this.tableData.slice(this.pager.startIndex, this.pager.endIndex + 1);
      this.pagedItemsEvent.emit({pagedItems : this.pagedItems, pageNumber : page, itemsPerPage: this.ItemPerPage});
    }else{
      this.pager = {};
      this.pagedItems = [];
    }
    this.pagedItemsEvent.emit({pagedItems : this.pagedItems, pageNumber : page, itemsPerPage: this.ItemPerPage});
  }
  sortData() {
    if (this.sortCol !== '') 
    if(this.pageName == 'order-table'){
      // this.tableData = this.sortOrderFilterPipe.transform(this.tableData, this.sortCol, this.sortReverseOrder); 
      if(localStorage.getItem('sortOptions')){
      this.sortItems = JSON.parse(localStorage.getItem('sortOptions')).selectedSortItems}
      this.tableData = this.multiSortPipe.transform(this.tableData, this.sortItems);
    }else{
      this.tableData = this.sort.transform(this.tableData, this.sortCol, this.sortReverseOrder); 
    }
  }
}
