import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'lib-need-by-date',
  templateUrl: './need-by-date.component.html',
  styleUrls: ['./need-by-date.component.scss'],
})
export class NeedByDateComponent implements OnInit {

  @Output() sizeEvent = new EventEmitter<number>();
  @Input() size;
  @Input() actualSize;
  @Input() disabled = '';
  @Input() muteText;
  @Input() min;
  @Input() max;
  @Input() lotSize = 1;
  functionId: string; 
  userInfo: any;
  constructor() { }

  ngOnInit() {
    this.size = this.size != 0 && this.size ? this.size : 1;
    this.min = this.min ? this.min : 1;
    this.max = this.max ? this.max : 100;
    let userInfo = localStorage.getItem("userDetails");
    this.userInfo = JSON.parse(userInfo);
    this.functionId = localStorage.getItem(this.userInfo.NTID + '_functionId');
  }

  ngOnChanges() {
    this.size = this.size ? this.size : 1;
  }

  onInput() {
    let arrayOfPossibleNum = [];
    let min = +this.min;
    let max = +this.max;
    let lotSize = +this.lotSize
    let size = +this.size;
    if (!this.max) {
      this.size = this.size;
    }
    else if (this.size > max) {
      this.size = max;
    }
    else if (this.size < min) {
      this.size = min;
    }
    else if (this.size > min && this.size < max) {
      for (let i = +min; i <= +max; i = +i + +lotSize) {
        arrayOfPossibleNum.push(i)
      }
      arrayOfPossibleNum.sort((a, b) => {
        return Math.abs(size - a) - Math.abs(size - b);
      })
      this.size = arrayOfPossibleNum[0]
    }
    else if (!this.size || this.size < 0) {
      this.size = 1
    }
    this.sizeEvent.emit(this.size);
  }

  add() {
    this.size = (+this.size + +this.lotSize);
    this.sizeEvent.emit(this.size);
  }
  remove() {
    if (this.size > 0) {
      this.size = (this.size - this.lotSize) == 0 ? 1 : (this.size - this.lotSize);
    }
    this.sizeEvent.emit(this.size);
  }
  
}
