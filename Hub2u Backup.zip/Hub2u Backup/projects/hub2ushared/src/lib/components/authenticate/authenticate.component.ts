import { Component, Inject, OnInit } from '@angular/core';

@Component({
  selector: 'lib-authenticate',
  templateUrl: './authenticate.component.html',
  styleUrls: ['./authenticate.component.scss'],
})
export class AuthenticateComponent implements OnInit {
  imagePath: string;
  constructor(@Inject('environment') private env: any) { }

  ngOnInit() {
    this.imagePath = this.env.flatform === 'mobile' ? 'logo.png' : 'assets/images/logo.png';
  }

}
