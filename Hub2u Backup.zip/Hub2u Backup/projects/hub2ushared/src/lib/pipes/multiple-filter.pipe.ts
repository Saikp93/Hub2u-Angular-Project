import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'multipleFilter'
})
export class MultipleFilterPipe implements PipeTransform {
  transform(arr: any[], filters?: any): any {
    if (!arr) return [];
    if (filters == undefined) return arr;
    if (!filters) return arr;
    if (!arr || !Object.keys(filters).length) {
      return arr;
    }
    const filterKeys = Object.keys(filters);
    return arr.filter((eachObj) => {
      return filterKeys.every(eachKey => {
        if (!filters[eachKey].length) {
          return true; // passing an empty filter means that filter is ignored.
        }
        return(filters[eachKey].some(key => key.toString().toLowerCase() === ((eachObj[eachKey] !== undefined && eachObj[eachKey] !== null) ? eachObj[eachKey].toString().toLowerCase() : null)))
        // return (filters[eachKey].toString()).toLowerCase().includes((eachObj[eachKey] !== undefined && eachObj[eachKey] !== null) ? eachObj[eachKey].toString().toLowerCase() : null);
      });
    });
  }
  matchExact(r, str) {
    var match = str.match(r);
    return match && str === match[0];
  }
}
