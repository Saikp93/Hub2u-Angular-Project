import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortOrderFilter'
})
export class SortOrderFilterPipe implements PipeTransform {


  transform(array: Array<string>, args: string, reverse: boolean = false, argsb?: string): Array<string> {
    if (!reverse) {
      return array.sort((a: any, b: any) => {
        if (args !== undefined) {
          if (args.indexOf("DATE") > -1) {
            return (<any>new Date(a[args]) - <any>new Date(b[args]) || a['LINE_NUMBER'] - b['LINE_NUMBER'])
          }
          else if (this.isString(a[args])) {
            return (a[args].toUpperCase() > b[args].toUpperCase()) ? 1 : -1
          }
          else if (this.isNumber(a[args])) {
            return (a[args] - b[args] || a['LINE_NUMBER'] - b['LINE_NUMBER']);
          } else {
            return 0;
          }
        } else {
          return 0;
        }
      });
    } else {
      return array.sort((a: any, b: any) => {
        if (args !== undefined) {
          if (args.indexOf("DATE") > -1) {
            return (<any>new Date(a[args]) - <any>new Date(b[args]) || b['LINE_NUMBER'] - a['LINE_NUMBER']);
          }
          else if (this.isString(a[args])) {
            return (a[args].toUpperCase() > b[args].toUpperCase() || a['LINE_NUMBER'] - b['LINE_NUMBER']) ? 1 : -1
          }
          else if (this.isNumber(a[args])) {
            return (a[args] - b[args] || b['LINE_NUMBER'] - a['LINE_NUMBER']);
          } else {
            return 0;
          }
        } else {
          return 0;
        }
      }).reverse();
    }
  }


  isString(value) {
    return typeof value === 'string' || value instanceof String;
  }
  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }
  isDate(date) {
    return (Date.parse(date) !== NaN)
  }

}
