import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sort'
})
export class SortPipe implements PipeTransform {

  transform(array: Array<string>, args: string, reverse: boolean = false): Array<string> {
    if (!reverse) {
      return array.sort((a: any, b: any) => {
        if (args !== undefined) {
          if (args.indexOf("DATE") > -1) {
            return <any>new Date(a[args]) - <any>new Date(b[args]);
          }
          else if (this.isString(a[args])) {
            if (a[args].toUpperCase() < b[args].toUpperCase()) return -1;
          }
          else if (this.isNumber(a[args])) {
            return a[args] - b[args];
          } else {
            return 0;
          }
        } else {
          return 0;
        }
      });
    } else {
      return array.sort((a: any, b: any) => {
        if (args !== undefined) {
          if (args.indexOf("DATE") > -1) {
            return <any>new Date(a[args]) - <any>new Date(b[args]);
          }
          else if (this.isString(a[args])) {
            if (a[args].toUpperCase() < b[args].toUpperCase()) return -1;
          }
          else if (this.isNumber(a[args])) {
            return a[args] - b[args];
          } else {
            return 0;
          }
        } else {
          return 0;
        }
      }).reverse();
    }
  }


  isString(value) {
    return typeof value === 'string' || value instanceof String;
  }
  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }
  isDate(date) {
    return (Date.parse(date) !== NaN)
  }

}
