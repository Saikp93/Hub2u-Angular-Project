import { MultiSortPipe } from './multi-sort.pipe';

describe('MultiSortPipe', () => {
  it('create an instance', () => {
    const pipe = new MultiSortPipe();
    expect(pipe).toBeTruthy();
  });
});
