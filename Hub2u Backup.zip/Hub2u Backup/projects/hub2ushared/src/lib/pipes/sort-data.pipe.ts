import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderBy'
})
export class SortDataPipe implements PipeTransform {

  transform(itemListdata: any[], field: string, reverse: boolean = false): any[] {
    if (!itemListdata) return [];

    if (field) {
      if (!reverse) {
        return itemListdata.sort((a, b) => a[field] > b[field] ? 1 : -1);
      } else {
        return itemListdata.sort((a, b) => a[field] > b[field] ? 1 : -1).reverse();
      }
    }
    else {
      if (!reverse) {
        return itemListdata.sort((a, b) => a > b ? 1 : -1);
      } else {
        return itemListdata.sort((a, b) => a > b ? 1 : -1).reverse();
      }
    }
  }

}