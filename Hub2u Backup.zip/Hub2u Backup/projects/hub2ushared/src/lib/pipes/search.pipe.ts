import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(dataObj: any, filterString: string ,propName: any ): any {
    if (dataObj.length === 0 || !filterString) {
      return dataObj
    }

    const resultArray = [];
    dataObj.filter((data) => {
      for(let i=0; i<=propName.length; i++) {
        if (data[propName[i]] && data[propName[i]].toString().toLowerCase().includes(filterString.toLowerCase())) {
          resultArray.push(data);
          break;
        }
      }
    }) 

    return resultArray;

}
}

