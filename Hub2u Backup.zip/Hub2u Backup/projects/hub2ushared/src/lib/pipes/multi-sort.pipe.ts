import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'multiSort'
})
export class MultiSortPipe implements PipeTransform {

  transform(array: Array<string>, args: object, argsb?: string): any {
    // for(let i=0; i<args.length; i++){
    //   if(i==0){
    //     array = this.sortAray(array, args[i]['val'], args[i]['order']);
    //   }
    //   else{
    //     array = this.sortAray(array, args[i]['val'], args[i]['order'],args[i-1]['val']);
    //   }
    // }



    return array.keySort(args);
  }

  sortAray(array, field, order, prevField?) {
    if (!order) {
      return array.sort((a: any, b: any) => {
        if (a[prevField] == b[prevField]) {
          if (field !== undefined) {
            if (field.indexOf("DATE") > -1) {
              return (<any>new Date(b[field]) - <any>new Date(a[field]));
            }
            else if (this.isString(a[field])) {
              return (b[field].toUpperCase() > a[field].toUpperCase()) ? 1 : -1
            }
            else if (this.isNumber(a[field])) {
              return (b[field] - a[field]);
            } else {
              return 0;
            }
          } else {
            return 0;
          }
        }
      });
    } else {
      return array.sort((a: any, b: any) => {
        if (a[prevField] == b[prevField]) {
          if (field !== undefined) {
            if (field.indexOf("DATE") > -1) {
              return (<any>new Date(a[field]) - <any>new Date(b[field]));
            }
            else if (this.isString(a[field])) {
              return (a[field].toUpperCase() > b[field].toUpperCase()) ? 1 : -1;
            }
            else if (this.isNumber(a[field])) {
              return (a[field] - b[field]);
            } else {
              return 0;
            }
          } else {
            return 0;
          }
        }
      });
    }
  }

  isString(value) {
    return typeof value === 'string' || value instanceof String;
  }
  isNumber(value: string | number): boolean {
    return ((value != null) &&
      (value !== '') &&
      !isNaN(Number(value.toString())));
  }
  isDate(date) {
    return (Date.parse(date) !== NaN)
  }

}

declare global {
  interface Array<T> {
    keySort(length: object): Array<T>;
  }
}
export { };

Array.prototype.keySort = function (keys) {
  keys = keys || {};
  var obLen = function (obj) {
    var size = 0,
      key;
    for (key in obj) {
      if (obj.hasOwnProperty(key)) size++;
    }
    return size;
  };

  var obIx = function (obj, ix) {
    var size = 0,
      key;
    for (key in obj) {
      if (obj.hasOwnProperty(key)) {
        if (size == ix) return key;
        size++;
      }
    }
    return false;
  };

  var keySort = function (a, b, d) {
    d = d !== null ? d : 1;
    if (a == b) return 0;
    return a > b ? 1 * d : -1 * d;
  };

  var KL = obLen(keys);

  if (!KL) return this.sort(keySort);

  for (var k in keys) {
    keys[k] =
      keys[k] == "desc" || keys[k] == -1
        ? -1
        : keys[k] == "skip" || keys[k] === 0
          ? 0
          : 1;
  }

  this.sort(function (a, b) {
    var sorted = 0,
      ix = 0;

    while (sorted === 0 && ix < KL) {
      var k = obIx(keys, ix);
      if (k) {
        var dir = keys[k];
        //sorted = keySort(a[k], b[k], dir);
        var va = a[k], vb = b[k];
        if (typeof a[k] === 'string' || a[k] instanceof String) {
          va = (a[k] === null) ? "" : "" + a[k];
          vb = (b[k] === null) ? "" : "" + b[k];
        }
        sorted = keySort(va, vb, dir);
        ix++;
      }
    }
    return sorted;
  });
  return this;
};
