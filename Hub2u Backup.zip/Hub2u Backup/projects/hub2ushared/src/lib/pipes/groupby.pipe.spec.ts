import { GroupbyPipe } from './groupby.pipe';

describe('GroupbyPipe', () => {
  it('create an instance', () => {
    const pipe = new GroupbyPipe();
    expect(pipe).toBeTruthy();
  });
});
