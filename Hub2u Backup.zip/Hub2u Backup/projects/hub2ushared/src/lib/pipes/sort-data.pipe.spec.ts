import { SortDataPipe } from './sort-data.pipe';

describe('SortDataPipe', () => {
  it('create an instance', () => {
    const pipe = new SortDataPipe();
    expect(pipe).toBeTruthy();
  });
});
