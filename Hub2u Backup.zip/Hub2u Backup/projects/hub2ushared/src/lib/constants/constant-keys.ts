import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class ConstantKeys {
  URL: any = {
    dev: ''
  };

  titles: any = {
    catalogPage: 'Catalog',
    homePage: 'Home'
  }
}