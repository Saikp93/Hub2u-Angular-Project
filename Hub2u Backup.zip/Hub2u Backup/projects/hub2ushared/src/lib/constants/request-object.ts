import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})

export class RequestObject {

    catalogBusinessUser = {
        // "ReportId": "10101",
        "ReportId": "7009",
        "ParametersInput": [
            { "Name": "USER_NAME", "Value": '' },
            { "Name": "CUSTOMER_NAME", "Value": '' },
            { "Name": "KIT_NAME", "Value": '' }
        ]
    };

    catalogTransferBSU = {
        //"ReportId": "10262",
        "ReportId": "7023",
        "ParametersInput": [
            { "Name": "USER_NAME", "Value": '' },
            { "Name": "KIT_NAME", "Value": '' }
        ]
    };

    catalogStoreFav = {
        "ReportId": "10144",
        "ParametersInput": [
            { "Name": "REQUESTOR_USER_NAME", "Value": "" }
        ]
    };

    catalogPrepaidFav= {
        "ReportId": "10154",
        "ParametersInput": [
            { "Name": "REQUESTOR_USER_NAME", "Value": "" }
        ]
    };

    catalogBusinessUserFav = {
        //"ReportId": "10125",
        "ReportId": "7015",
        "ParametersInput": [
            { "Name": "REQUESTOR_USER_NAME", "Value": "" }
        ]
    };

    catalogTechUser = {
        // ReportId: 10167,
        ReportId: 7035,
        ParametersInput: [
            {
                Name: "USER_NAME",
                Value: ''
            },
            {
                Name: 'REGION_NAME',
                Value: ''
            }
            ,
            {
                Name: 'TEMPLATE_NAME',
                Value: ''
            },
            {
                Name: 'P_ROW_NUM',
                Value: ''
            }

        ]
    };

    catalogXmSupplyChain = {
        ReportId: 50037,
        ParametersInput: [
            {
                Name: "USER_NAME",
                Value: ''
            },
            {
                Name: 'REGION_NAME',
                Value: ''
            },
            {
                Name: 'TEMPLATE_NAME',
                Value: ''
            },
            {
                Name: 'P_ROW_NUM',
                Value: ''
            }
        ]
    };

    catalogNonCpeUser = {
        ReportId: 10198,
        ParametersInput: [
            {
                Name: "USER_NAME",
                Value: ''
            },
            {
                Name: 'REGION_NAME',
                Value: ''
            }
            ,
            {
                Name: 'TEMPLATE_NAME',
                Value: ''
            },
            {
                Name: 'P_ROW_NUM',
                Value: ''
            }
    
        ]
    }

    catalogRegionalESA = {
        ReportId: 10094,
        ParametersInput: [
            {
                Name: "USER_NAME",
                Value: ''
            },
            {
                Name: 'REGION_NAME',
                Value: ''
            }
            ,
            {
                Name: 'TEMPLATE_NAME',
                Value: ''
            }

        ]
    };

    catalogRegional5G = {
        ReportId: 10218,
        ParametersInput: [
            {
                Name: "USER_NAME",
                Value: ''
            },
            {
                Name: 'REGION_NAME',
                Value: ''
            }
            ,
            {
                Name: 'TEMPLATE_NAME',
                Value: ''
            },
            // {
            //     Name: 'P_ROW_NUM',
            //     Value: ''
            // }

        ]
    };
    catalog5GFav = {
        ReportId: 10219,
        ParametersInput: [
            {
                Name: "REQUESTOR_USER_NAME",
                Value: ''
            }
        ]
    };

    catalogTechFav = {
        // ReportId: 10168,
        ReportId: 7033,
        ParametersInput: [
            {
                Name: "REQUESTOR_USER_NAME",
                Value: ''
            }
        ]
    };

    catalogXmSupplyChainFav = {
        ReportId: 50038,
        ParametersInput: [
            {
                Name: "REQUESTOR_USER_NAME",
                Value: ''
            }
        ]
    };

    catalogNonCpeFav = {
        ReportId: 10199,
        ParametersInput: [
            {
                Name: "REQUESTOR_USER_NAME",
                Value: ''
            }
        ]
    };

    catalogCPEUser = {
        "ReportId": "10011",
        "ParametersInput": [
            { "Name": "REQUESTOR_USER_NAME", "Value": "" },
            { "Name": "REGION_NAME", "Value": "" }
        ]
    };

    catalogCPEUserRegional = {
        //"ReportId": "10012",
        "ReportId": "10113",
        "ParametersInput": [
            { "Name": "USER_NAME", "Value": "" },
            { "Name": "TEMPLATE_NAME", "Value": "" }
        ]
    };

    catalogCPEUserFav = {
        // "ReportId": "10016",
        "ReportId": "10127",
        "ParametersInput": [
            {
                "Name": "REQUESTOR_USER_NAME",
                "Value": ""
            }]
    };

    storeUserRegional = {
        "ReportId": "10150",
        "ParametersInput": [
            { "Name": "USER_NAME", "Value": "" },
            { "Name": "REGION_NAME", "Value": "" },
            { "Name": "TEMPLATE_NAME", "Value": "" }
        ]
    };

    catalogPrepaidDealer = {
        "ReportId": 1049,
        "ParametersInput": [
            { "Name": "REQUESTOR_USER_NAME", "Value": "" },
            { "Name": "REGION_NAME", "Value": "" }
        ]
    }

    catalogESAUser = {
        "ReportId": 10068,
        "ParametersInput": [
            { "Name": "REQUESTOR_USER_NAME", "Value": "" },
            { "Name": "REGION_NAME", "Value": "" }
        ]
    }

    catalogESAUserFav = {
        "ReportId": 10083,
        "ParametersInput": [
            { "Name": "REQUESTOR_USER_NAME", "Value": "" }
        ]
    }

    PrepaidDealerRegional = {
        "ReportId": "10153",
        "ParametersInput": [
            { "Name": "USER_NAME", "Value": "TSEROW378" },
            { "Name": "REGION_NAME", "Value": "HQ REGION" },
            { "Name": "TEMPLATE_NAME", "Value": "PREPAID CATALOG" }
        ]
    }

    cnaUsercatalogs = {
        "ReportId": 10026,
        "ParametersInput": [
            { "Name": "REQUESTOR_USER_NAME", "Value": "" },
            { "Name": "REGION_NAME", "Value": "" }
        ]
    }

    catalogCNAuser = {
        "ReportId": "10027",
        "ParametersInput": [
            { "Name": "USER_NAME", "Value": "" },
            { "Name": "TEMPLATE_NAME", "Value": "" }
        ]
    }
}