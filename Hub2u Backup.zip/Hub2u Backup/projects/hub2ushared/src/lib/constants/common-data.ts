import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class ConstantData {
  public navigation = [
    { title: 'Home', name: 'home', mobileIcon: 'home-outline', webIcon: 'home', hidden: false, webLink: 'home', mobileLink: '/home' },
    { title: 'Catalogs', name: 'catalogs', mobileIcon: 'albums-outline', webIcon: 'style', hidden: false, webLink: 'catalog', mobileLink: '/catalog' },
    { title: 'Inventory Operations', name: 'wms', mobileIcon: 'analytics', webIcon: 'local_shipping', hidden: false, webLink: 'wms', mobileLink: '/wms' },
    { title: 'Reports', name: 'reports', mobileIcon: 'file-tray-full-sharp', webIcon: 'list_alt', hidden: false, webLink: 'reports', mobileLink: '/reports' },
    { title: 'Settings', name: 'settings', mobileIcon: 'cog-sharp', webIcon: 'settings', hidden: false, webLink: 'settings', mobileLink: '/settings' }
  ];

  public mainNavigation = [
    { title: 'My Orders', functionId: '999', mobileIcon: 'bag-check-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/myorders', mobileLink: '' },
    { title: 'Catalog Search', functionId: '15', mobileIcon: 'search-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/catalog/catalogsearch', mobileLink: '' },
    // { title: 'Administration', functionId: '1', mobileIcon: 'person-add-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/administration', mobileLink: '' },
    { title: 'Administration', functionId: '141', mobileIcon: 'person-add-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/administration', mobileLink: '' },
    { title: 'Catalog Image Upload', functionId: '145', mobileIcon: 'cloud-upload-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/catalog/catalogimage', mobileLink: '/catalogimage' },
    { title: 'BU Administration', functionId: '137', mobileIcon: 'person-add-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/bu-administration', mobileLink: '' },
    //{ title: 'BU Administration', functionId: '6', mobileIcon: 'person-add-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/bu-administration', mobileLink: '' },
    { title: 'Announcements', functionId: '13', mobileIcon: 'folder-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/announcements', mobileLink: 'layout/announcements' },
    // { title: 'Outstanding Sales Orders', functionId: '14', mobileIcon: 'cart-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '', mobileLink: '' },
    //{ title: 'Catalog Management', functionId: '52', mobileIcon: 'person-add-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/template-management', mobileLink: '' },
    { title: 'Catalog Management', functionId: '140', mobileIcon: 'person-add-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/template-management', mobileLink: '' },
    // { title: 'Project Template Maintenance', functionId: '67', mobileIcon: 'person-add-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/template-maintenance', mobileLink: '' },
    { title: 'Project Template Maintenance', functionId: '142', mobileIcon: 'person-add-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/template-maintenance', mobileLink: '' },
    //{ title: 'Bulk Upload', functionId: '62', mobileIcon: 'cloud-upload-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/bulkupload', mobileLink: '' },
    { title: 'Bulk Upload', functionId: '139', mobileIcon: 'cloud-upload-outline', webIcon: 'mail', hidden: true, disabled: false, webLink: '/hub2u/bulkupload', mobileLink: '' },
  ];


  public subNavigation = [
    { title: 'Terms and Conditions', id: '1', mobileIcon: 'receipt-outline', webIcon: 'assignment', disabled: false, webLink: 'termsConditions', mobileLink: '' },
    { title: 'Help', id: '2', mobileIcon: 'people-outline', webIcon: 'help_outline', disabled: false, webLink: 'help', mobileLink: '' },
    { title: 'IT Support', id: '3', mobileIcon: 'chatbubble-ellipses-outline', webIcon: 'report_problem', disabled: false, webLink: 'itsupport', mobileLink: '' },
    { title: 'Submit Feedback', id: '4', mobileIcon: 'reader-outline', webIcon: 'speaker_notes', disabled: false, webLink: 'https://feedbackform.b4.app.cloud.comcast.net/home?appId=1' },
  ];

  public roles = {
    50: 'Comcast Store User',
    51: 'Comcast Business Services User',
    58: 'Comcast CPE User',
    57: 'Prepaid Dealer',
    60: 'Comcast CNA USER',
    143: 'COMCAST TECH USER IIP',
    // 99: 'COMCAST TECH USER IIP',
    61: 'Comcast ESA User',
    63: 'Comcast NONCPE User',
    64: 'XM Supply Chain',
    66: 'Comcast 5G User',
    136:'Comcast Business Services User iip'
  };

  public catalogs = {
    50: 1049,
    51: 1049,
    58: 10011,
    57: 1049,
    60: 10026,
    // 99: 10189,
    61: 10068,
    63: 10213,
    64: 50031,
    66: 10217,
    136:1049,
    143: 7003,
  }

  public cifaItemDetails = {
    50: 10161,
    51: 10099,
    57: 10116,
    58: 10116,
    60: 1091,
    // 99: 10177,
    143:7036,
    61: 10085,
    63: 10205,
    64: 50034,
    66: 10224,
    136:7016
  }
  public catalogsGridView = {
    50: true,
    51: true,
    57: true,
    58: false,
    60: true,
    99: true,
    61: true,
    63: true,
    64: true,
    66: true
  }
  public checkoutdetailsId = {
    50: 10110,
    51: 10106,
    57: 10111,
    58: 10108,
    60: 10107,
    99: 10109,
    61: 10057,
    63: 10209,
    64: 50032,
    66: 10227,
    136: 7020
  }
  public bulkUploadRecords = {
    50: 60014,
    64: 60014,
    // 50: 50014,
    51: 50014,
    57: 50014,
    58: 50014,
    60: 50014,
    99: 60175,
    61: 50014,
    136: 7027,
    143:7040
  }
  public bulkUploadExportData = {
    50: 60015,
    64: 60015,
    // 50: 50015,
    51: 50015,
    57: 50015,
    58: 50015,
    60: 50015,
    99: 60176,
    61: 50015,
    136: 7028,
    143:7041
  }
  public bulkUploadRecCount = {
    50: 60016,
    64: 60016,
    // 50: 50016,
    51: 50016,
    57: 50016,
    58: 50016,
    60: 50016,
    99: 60177,
    61: 50016,
    136: 7029,
    143: 7043
  }
  public bulkUploadOrderListexport = {
    50: 60008,
    64: 60008,
    // 50: 50008,
    51: 50008,
    57: 50008,
    58: 50008,
    60: 50008,
    99: 60180,
    61: 50008,
    136: 7026
  }
  public bulkUploadDisplayFields = {
    50: 60145,
    64: 60145,
    // 50: 10145,
    51: 10145,
    57: 10145,
    58: 10145,
    60: 10145,
    99: 60179,
    61: 10145,
    136: 7025,
    143: 7039
  }
  // 
  public bulkUploadColumnMap = {
    50: 60138,
    64: 60138,
    // 50: 10138,
    51: 10138,
    57: 10138,
    58: 10138,
    60: 10138,
    99: 60175,
    61: 10138,
    136: 10138,
    143:7040
  }
  public bulkUploadTemplate = {
    50: 60011,
    64: 60011,
    // 50: 50011,
    51: 50011,
    57: 50011,
    58: 50011,
    60: 50011,
    99: 60011,
    61: 50011,
    136: 50011,
    143: 7042
  }

  public deliverySiteId = {
    51: 1088,
    57: 1088,
    58: 10010,
    60: 10031,
    61: 1088,
    63: 10021,
    64: 50041,
    136:1088
    
  };

  public sourceSiteId = {
    50: 10010,
    51: 60201,
    57: 10010,
    58: 10010,
    60: 10010,
    // 99: 10192,
    61: 10010,
    63: 10021,
    64: 50041,
    66: 1088,
    136:60201,
    143:10192
  };

  public deliverLocId = {
    // 99: 10008,
    63: 10021,
    58: 10010,
    60: 10010,
    51: 1088,
    57: 1088,
    61: 1088,
    50: 10008,
    64: 50041,
    66: 10233,
    143:7044

  };

  public reportID = {
    'catalogRegion': 113,
    'catalogFavorites': 1032,
    'catalogSubCategories': 1049
  };

  public recentOrderId = {
    50: 1121,
    51: 1123,
    57: 1121,
    58: 1115,
    60: 1115,
    99: 1115,
    61: 1115,
    63: 1115,
    66: 1115
  };

  public dynamicrecentOrderId = {
    50: 10141,
    51: 10095,
    57: 10134,
    58: 10120,
    60: 1029,
    99: 10170,
    61: 10067,
    63: 10201,
    64: 50029,
    66: 10221,
    136:7010
  };

  public dynamicSearchId = {
    50: 10151,
    51: 10097,
    57: 1118,
    58: 10115,
    60: 1118,
    99: 10173,
    61: 10082
  }

  public globalSearchId = {
    51: 10139,
    61: 10075,
    99: 10178,
  }

  public exportingOrdersId = {
    50: 10143,
    61: 10084,
    51: 10103,
    58: 10122,
    57: 10157,
    99: 10174,
    63: 10204,
    64: 50036,
    66: 10223,
    136:7012
  }

  public exportingDynamicReportsId = {
    61: 10076,
    51: 10105,
    58: 40002,
    57: 10156,
    63: 10208
  }

  public dynamicmyorderId = {
    50: 10141,
    51: 10095,
    57: 10134,
    58: 10120,
    60: 10024,
    99: 10170,
    61: 10067,
    63: 10201,
    64: 50029,
    66: 10221,
    136:7010
  };

  public dynamicorderDetailsId = {
    50: 10142,
    51: 10098,
    57: 10135,
    58: 10121,
    60: 1030,
    99: 10171,
    61: 10069,
    63: 10202,
    64: 50035,
    66: 10222,
    136:7011
  };

  public tempMangReportId = {
    50: 10149,
    51: 10112,
    57: 10195,
    58: 10126,
    60: 1101,
    // 99: 10172,
    143:7032,
    61: 10073,
    63: 10206,
    66: 10225,
    136:60211
  };

  public dynamicReports = {
    50: 10086,
    51: 10086,
    57: 10086,
    58: 10086,
    60: 2021,
    99: 10086,
    61: 10086,
    63: 10086,
    64: 10086,
    66: 10086,
    136:10086,
    143:10086
  };

  public orderdetailsId = {
    50: 1119,
    51: 10129,
    57: 1119,
    58: 10123,
    60: 10022,
    99: 1119,
    61: 10070,
    63: 1119,
    64: 50027,
    66: 10231,
    136:7003,
    143:7003
  };

  public frequestOrdersId = {
    50: 10140,
    51: 10096,
    57: 10136,
    58: 10114,
    60: 1114,
    // 99: 10169,
    61: 10071,
    63: 10200,
    64: 50028,
    66: 10220,
    136:7004,
    143: 7038,
    
  };

  public cartDynamicId = {
    50: 10060,
    51: 10058,
    57: 10063,
    58: 10061,
    60: 10062,
    // 99: 10059,
    61: 10064,
    63: 10211,
    64: 50033,
    66: 10226,
    136:7019,
    143:7037
  }

  regionReportId = {
    50: 1126,
    51: 1126,
    57: 1126,
    58: 1126,
    60: 1126,
    // 99: 10188,
    143:7034,
    61: 10093,
    63: 10212,
    64: 50030,
    66: 10216,
    136:7005
  }

  buadmindynamicfields = {
    50: 10196,
    51: 10196,
    57: 10196,
    58: 10196,
    60: 10196,
    61: 10196,
    63: 10196,
    64: 10196,
    66: 10196,
    136:7018,
    143:7031,
  }

  public freOnhandenquiry = {
    50: 114,
    51: 114,
    57: 114,
    58: 114,
    60: 114,
    99: 114,
    61: 10075
  };

  public settingsDynamicFields = {
    50: 10080,
    //51: 10077,
    136: 7000,
    57: 10081,
    58: 10078,
    60: 10079,
    //99: 10065,
    143:7030,
    61: 10074,
    63: 10197,
    64: 50039,
    66: 10215
     }

  public checkStatus = {
    50: 10092,
    51: 10092,
    57: 10092,
    58: 10092,
    60: 10092,
    99: 50057,
    61: 10092,
    63: 10092,
    64: 10092,
    66: 10092
  }

  public userprofileData = {
    50: 112,
    51: 112,
    57: 112,
    58: 112,
    60: 112,
    99: 112,
    61: 112,
    63: 112,
    64: 112,
    66: 112,
    136:7001,
    143:7001
  }

  public getresponsibilities = {
    50: 10087,
    51: 10087,
    57: 10087,
    58: 10087,
    60: 10087,
    99: 10087,
    61: 10087,
    63: 10087,
    64: 10087,
    66: 10087,
    136:7002,
    143:7002
  }

  public userRoles = {
    storeUser: 'Comcast Store User',
    businessUser: 'Comcast Business User',
    techUser: 'COMCAST TECH USER IIP',
    cpeUser: 'Comcast CPE User'
  }

  public borderColor = {
    'SHIPPED': 'solid 4px #0089CF',
    'BACKORDERED': 'solid 4px #3A5168',
    'IN PROCESS': 'solid 4px #8ABA01',
    'APPROVED': 'solid 4px #0DB14B',
    'CANCELLED': 'solid 4px #FF7C7C',
    'REJECTED': 'solid 4px  #F51919',
    'INCOMPLETE': 'solid 4px #788991',
    'ON PROJECT HOLD': 'solid 4px #FA9A18',
    'SUBMITTED': 'solid 4px #6EB719',
    'PENDING APPROVAL': 'solid 4px #FDB913',
  }
  public orderStatusParam = {
    57: "Prepaid Dealer",
    58: "CPE",
    60: "CPE",
    99: "TECH",
    63: "NONCPE"
  };

  public statusColors = {
    'IN PROCESS': '#8ABA01',
    'PROJECT HOLD': '#FA9A18',
    'DECLINED': '#FF7B7B',
    'INCOMPLETE': '#788991',
    'BACKORDERED': '#3A5168',
    'SHIPPED': '#0089CF',
    'OTHERS': '#9169C7',
    'CANCELLED': '#FF7C7C',
    'SUBMITTED': '#6EB719',
    'PENDING APPROVAL': '#FFB500',
    'APPROVED': '#0DB14B',
    'REJECTED': ' #F51919',
    'OPEN': '#8E8E00',
    'INPROGRESS': '#8ABA01',
    'INTRANSIT': '#9750F8',
    'DELIVERED': '#05C3C3',
    'FAILED': '#9A0000',
    'ERROR': '#9A0000',
    'CLOSED': '#05C3C3'
  }
  public orderFilter = [
    // { key: 'Locator', val: 'REQUISITION_NUMBER' },
    // { key: 'Item Number', val: 'REQUISITION_NUMBER' },
    { key: 'Item Number', val: 'ORDERED_ITEM', 'order': false },
    { key: 'Order Number', val: 'ORDER_NUMBER', 'order': false },
    { key: 'Need By Date', val: 'NEED_BY_DATE', 'order': false },
    { key: 'Status', val: 'RELEASED_STATUS', 'order': false }] 

    public multiSortFilter = [
      // { key: 'Locator', val: 'REQUISITION_NUMBER' },
      // { key: 'Item Number', val: 'REQUISITION_NUMBER' },
      { key: 'Item Number', val: 'ORDERED_ITEM', 'order': true},
      { key: 'Order Number', val: 'ORDER_NUMBER', 'order': true},
      { key: 'Need By Date', val: 'NEED_BY_DATE', 'order': true},
      { key: 'Status', val: 'RELEASED_STATUS', 'order': true}] 
}