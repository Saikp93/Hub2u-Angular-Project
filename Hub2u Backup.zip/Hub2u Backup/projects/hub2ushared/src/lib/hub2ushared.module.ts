import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AuthenticateComponent } from './components/authenticate/authenticate.component';
import { LoaderComponent } from './components/loader/loader.component';
import { ProductSizeComponent } from './components/product-size/product-size.component';
import { SwitchNtidComponent } from './components/switch-ntid/switch-ntid.component';
import { PagerComponent } from './components/pager/pager.component';
import { MultiSortComponent } from './components/multi-sort/multi-sort.component';
import { ErrorComponent } from './components/error/error.component';
import { ConstantData } from './constants/common-data';
import { ConstantKeys } from './constants/constant-keys';
import { clientInfo } from './constants/client-info';
import { ConnectivityService } from './services/connectivity.service';
import { ReportsService } from './services/reports.service';
import { PagerService } from './services/pager.service';
import { TemplateManagementService } from './services/template-management.service';
import { OnlyNumberDirective } from './directives/only-number.directive';
import { AutofocusDirective } from './directives/autofocus.directive';
import { MatSelectModule } from '@angular/material/select';
import { SafehtmlPipe } from './pipes/safehtml.pipe';
import { EllipsisPipe } from './pipes/ellipsis.pipe';
import { SearchPipe } from './pipes/search.pipe';
import { FilterpipePipe } from './pipes/filterpipe.pipe';
import { SortPipe } from './pipes/sort.pipe';
import { MultipleFilterPipe } from './pipes/multiple-filter.pipe';
import { GroupbyPipe } from './pipes/groupby.pipe';
import { SortDataPipe } from './pipes/sort-data.pipe';
import { RequestObject } from './constants/request-object';
import { SortOrderFilterPipe } from './pipes/sort-order-filter.pipe';
import { MultiSortPipe } from './pipes/multi-sort.pipe';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { GetimageService } from './services/getimage.service';
import { SettingsService } from './services/settings.service';
import { AdministrationService } from './services/administration.service';
import { AnnouncementsService } from './services/announcements.service';
import { AuthGuardService } from './services/auth-guard.service';
import { BulkUploadService } from './services/bulkupload.service';
import { FeedbackService } from './services/feedback.service';
import { HomeService } from './services/home.service';
import { MessageService } from './services/message.service';
import { ProductService } from './services/product.service';
import { SourceService } from './services/source.service';
import { NeedByDateComponent } from './components/need-by-date/need-by-date.component';



@NgModule({
  declarations: [ProductSizeComponent, NeedByDateComponent, LoaderComponent, AuthenticateComponent, SafehtmlPipe,EllipsisPipe, SwitchNtidComponent, ErrorComponent, SearchPipe, AutofocusDirective, OnlyNumberDirective, FilterpipePipe, SortPipe, MultipleFilterPipe, PagerComponent, MultiSortComponent, GroupbyPipe, SortDataPipe, SortOrderFilterPipe, MultiSortPipe],
  imports: [FormsModule, ReactiveFormsModule, CommonModule, MatSelectModule, NgxSpinnerModule, MatIconModule, MatMenuModule],
  exports: [ProductSizeComponent, NeedByDateComponent, LoaderComponent, AuthenticateComponent, SwitchNtidComponent, PagerComponent, MultiSortComponent, ErrorComponent, SearchPipe, AutofocusDirective, OnlyNumberDirective, FilterpipePipe, SortPipe, SortDataPipe, MultipleFilterPipe, SafehtmlPipe,EllipsisPipe, SortOrderFilterPipe],
  providers: [ReportsService, ConstantKeys, ConstantData, clientInfo, RequestObject, ConnectivityService, PagerService, TemplateManagementService, GetimageService, SettingsService, AdministrationService, AnnouncementsService, AuthGuardService, BulkUploadService, FeedbackService, HomeService, MessageService, ProductService, SourceService]
})
export class Hub2usharedModule { }

